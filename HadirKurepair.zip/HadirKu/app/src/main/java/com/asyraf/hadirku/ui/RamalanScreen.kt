package com.asyraf.hadirku.ui

import com.asyraf.hadirku.i18n.tr
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.asyraf.hadirku.MainViewModel
import com.asyraf.hadirku.Sheet
import com.asyraf.hadirku.pg.Kekayaan
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.PgState
import com.asyraf.hadirku.pg.Ramalan
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/* ================= ramalan baki sampai gaji ================= */

@Composable
private fun ramalanKini(vm: MainViewModel, s: PgState): Ramalan.Hasil {
    val today = vm.today()
    return remember(s, today) { Ramalan.kira(s, today) }
}

private fun hariLagi(r: Ramalan.Hasil): String = when (r.hari) {
    0 -> "hari ini"
    1 -> "esok"
    else -> r.hari.toString() + " hari lagi"
}

private fun jenisItem(j: String) = when (j) { "hutang" -> "hutang"; else -> "komitmen" }

/** Ringkasan satu baris untuk tab Poket. Tekan → Laporan → Ramalan. */
@Composable
fun RamalanRingkas(vm: MainViewModel, s: PgState) {
    val pal = LocalPal.current
    if (s.transactions.isEmpty()) return
    val r = ramalanKini(vm, s)
    val bebas = r.terendahBebas
    val tone = when { bebas < -0.004 -> Tone.BAD; bebas < r.kadar * 3 -> Tone.WARN; else -> Tone.GOOD }
    Block(Modifier.pressable({ vm.setLapViewMode("ramalan"); vm.go("laporan") }, scaleTo = 0.98f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Txt("Sampai gaji " + PG.fmtShort(r.payday) + " · " + hariLagi(r), size = 12.5f, color = pal.muted)
                Spacer(Modifier.height(2.dp))
                Txt(
                    rich(if (r.hari > 0) "Boleh belanja **" + M(r.bolehSehari) + "** sehari" else "Gaji dijangka masuk hari ini"),
                    size = 15f,
                )
                Txt(
                    "Baki dijangka sebelum gaji " + M(bebas) + if (r.simpanan > 0.004) " (tanpa simpanan)" else "",
                    size = 12.5f, color = when (tone) { Tone.BAD -> pal.bad; Tone.WARN -> pal.warn; else -> pal.muted },
                )
            }
            Txt("›", size = 24f, color = pal.muted)
        }
    }
}

@Composable
fun RamalanView(vm: MainViewModel) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    if (s.transactions.isEmpty()) {
        Empty(rich("Belum ada transaksi. Rekod baki bank dan belanja dulu, kemudian ramalan akan dikira sendiri."))
        return
    }
    val r = ramalanKini(vm, s)
    val bebas = r.terendahBebas
    val tone = when { bebas < -0.004 -> Tone.BAD; bebas < r.kadar * 3 -> Tone.WARN; else -> Tone.GOOD }

    // ---------- utama ----------
    Block {
        Txt("Sampai gaji " + PG.HARI_PENUH[PG.weekday(r.payday)] + ", " + PG.fmtShort(r.payday) + " · " + hariLagi(r), size = 12f, color = pal.muted)
        Spacer(Modifier.height(4.dp))
        MoneyAnim(bebas, 30f, color = if (bebas < -0.004) pal.bad else pal.ink)
        Txt(
            "baki dijangka sehari sebelum gaji masuk" + if (r.simpanan > 0.004) " · tanpa poket simpanan " + M(r.simpanan) else "",
            size = 12.5f, color = pal.muted,
        )
        Spacer(Modifier.height(10.dp))
        Pill(
            when (tone) {
                Tone.BAD -> "Tak cukup " + M(-bebas) + " sebelum gaji"
                Tone.WARN -> "Tipis — belanja berhati-hati"
                else -> "Cukup sampai gaji, insyaAllah"
            },
            tone,
        )
    }
    Stats(listOf(
        M(r.bolehSehari) to "Boleh belanja / hari",
        M(r.kadar) to "Biasa belanja / hari",
        M(r.otSehari) to "OT purata / hari",
    ))
    if (r.kadar > 0.004 && r.hari > 0) {
        val lebih = r.kadar > r.bolehSehari + 0.004
        Notice(
            rich(
                if (lebih) "Belanja biasa (**" + M(r.kadar) + "**) lebih daripada yang mampu (**" + M(r.bolehSehari) + "**) sehari. Kurangkan **" + M(r.kadar - r.bolehSehari) + "** sehari sampai gaji."
                else "Belanja biasa **" + M(r.kadar) + "** sehari masih bawah had **" + M(r.bolehSehari) + "**." +
                    if (r.otSehari > 0.004) (if (r.kadar <= r.otSehari) " Dan masih bawah OT purata sehari ✔" else " Tapi lebih daripada OT purata sehari.") else "",
            ),
            if (lebih) Tone.WARN else Tone.INFO,
        )
    }

    // ---------- carta ----------
    ChartBlock("Baki bank hari ke hari", "Turun ikut belanja biasa & bayaran, naik pada hari gaji") {
        val n = r.siri.size
        val ticks = buildList {
            add(0 to "Kini")
            if (n > 3) add((n - 2) / 2 to PG.fmtShort(r.siriTarikh[(n - 2) / 2]))
            add((n - 1) to PG.fmtShort(r.payday))
        }
        BakiChart(
            vals = r.siri, ticks = ticks, warna = pal.c1, markIdx = n - 1,
            tip = { i -> (if (i == 0) "Sekarang" else if (i == n - 1) "Selepas gaji " + PG.fmtShort(r.payday) else "Hujung " + PG.fmtShort(r.siriTarikh[i])) + " · " + M(r.siri[i]) },
            garisBawah = r.simpanan,
        )
        if (r.simpanan > 0.004) Legend(listOf(LegItem("Baki bank", pal.c1, true), LegItem("Paras poket simpanan", pal.warn, true)))
    }

    // ---------- kiraan ----------
    Slip("Kiraan ramalan", "Gaji " + PG.fmtShort(r.payday)) {
        SlipRow("Baki bank sekarang", M(r.bank))
        if (r.simpanan > 0.004) SlipRow("Tolak poket simpanan", M(-r.simpanan))
        r.sebelum.forEach { SlipRow(it.nama + " · " + jenisItem(it.jenis) + " · " + PG.fmtShort(it.tarikh), M(-it.jumlah)) }
        if (r.hari > 0) SlipRow("Belanja biasa " + M(r.kadar) + " × " + r.hari + " hari", M(-r.kadar * r.hari))
        SlipRow("Baki dijangka sebelum gaji", M(bebas), true)
        SlipRow("+ " + r.gaji.label + if (r.gaji.otSetakat) " (OT setakat ini)" else "", Mp(r.gaji.jumlah))
        r.padaGaji.forEach { SlipRow(it.nama + " · " + PG.fmtShort(it.tarikh) + " (guna gaji ini)", M(-it.jumlah)) }
        SlipRow("Baki selepas gaji & bayaran", M(r.selepas - r.simpanan), true)
        SlipNote(rich(
            "Belanja biasa = purata duit keluar dari bank " + r.kadarHari + " hari lepas (belanja, ambil ATM, top up e-wallet). " +
                "Komitmen, bayaran hutang dan belanja guna kad kredit di atas tidak dikira dua kali.",
        ))
        if (r.kadarHari in 1..13) SlipNote(rich("Purata dari **" + r.kadarHari + " hari** sahaja. Ramalan makin tepat bila rekod lebih lama."))
        if (r.gaji.jumlah <= 0.004) SlipNote(rich("Gaji dijangka RM0. Isi gaji di **Tetapan → Gaji & OT**."))
        if (r.simpanan > 0.004) SlipNote(rich("Poket simpanan: " + Ramalan.poketSimpanan(s).joinToString(", ") { it.nama } + ". Tak dikira duit boleh belanja."))
    }
    Note("Hari gaji 15hb (advance) dan 30hb. Komitmen ikut tarikh jatuh tempo; yang tiada tempo ikut gaji kitarannya (15hb / 30hb).")
}

/* ================= kekayaan bersih ================= */

@Composable
fun KekayaanView(vm: MainViewModel) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val today = vm.today()
    var tempoh by remember { mutableStateOf("12") }
    val bulan = tempoh.toIntOrNull() ?: 12
    val k = remember(s, today, bulan) { Kekayaan.siri(s, today, bulan) }
    val aset = remember(s) { Kekayaan.asetDari(s) }
    val kini = k.kini

    Block {
        Txt("Kekayaan bersih hari ini", size = 12f, color = pal.muted)
        Spacer(Modifier.height(4.dp))
        MoneyAnim(kini.bersih, 30f, color = if (kini.bersih < -0.004) pal.bad else pal.ink)
        Txt("Semua duit + aset lain − semua hutang", size = 12.5f, color = pal.muted)
        val bi = k.bulanIni
        if (bi != null) {
            Spacer(Modifier.height(8.dp))
            Txt(
                rich((if (bi >= 0) "▲ **" else "▼ **") + M(abs(bi)) + "** bulan ini (sejak hujung bulan lepas)" +
                    (if (PG.parse(today).d < 30) " · gaji hujung bulan belum masuk" else ""), if (bi >= 0) pal.good else pal.bad),
                size = 13.5f, color = pal.muted,
            )
        }
    }
    Stats(listOf(M(kini.duit) to "Duit", M(kini.aset) to "Aset lain", M(kini.hutang) to "Hutang"))

    ChartBlock("Bulan ke bulan", "Hujung setiap bulan · titik terakhir = hari ini") {
        Chips(listOf("6" to "6 bulan", "12" to "1 tahun", "24" to "2 tahun", "60" to "5 tahun"), tempoh, { tempoh = it })
        if (k.titik.size >= 2) {
            val n = k.titik.size
            val ticks = buildList {
                add(0 to fmtYmPendek(k.titik[0].tarikh))
                if (n > 4) add((n - 1) / 2 to fmtYmPendek(k.titik[(n - 1) / 2].tarikh))
                add((n - 1) to "Kini")
            }
            BakiChart(
                vals = k.titik.map { it.bersih }, ticks = ticks, warna = pal.good, markIdx = null,
                tip = { i ->
                    val t = k.titik[i]
                    (if (i == n - 1) "Hari ini" else fmtYm(t.tarikh)) + " · " + M(t.bersih) + "  (duit " + compact(t.duit) + (if (t.aset > 0) " + aset " + compact(t.aset) else "") + (if (t.hutang > 0) " − hutang " + compact(t.hutang) else "") + ")"
                },
            )
        } else {
            Txt("Carta keluar selepas ada data sekurang-kurangnya sebulan.", size = 13f, color = pal.muted)
        }
    }

    // ---------- unjuran ----------
    val pu = k.purataSebulan
    if (pu != null && k.bulanDikira >= 2) {
        Block {
            Txt("Kalau kadar ini kekal", size = 15f, weight = FontWeight.Bold)
            Txt("Purata " + (if (pu >= 0) "naik " else "turun ") + M(abs(pu)) + " sebulan (" + k.bulanDikira + " bulan lepas)", size = 12.5f, color = pal.muted)
            Spacer(Modifier.height(8.dp))
            Kvl(listOf(
                Triple(rich("1 tahun lagi"), M(kini.bersih + pu * 12), null),
                Triple(rich("3 tahun lagi"), M(kini.bersih + pu * 36), null),
                Triple(rich("5 tahun lagi"), M(kini.bersih + pu * 60), if (pu >= 0) pal.good else pal.bad),
            ), strongIdx = setOf(2))
            Spacer(Modifier.height(6.dp))
            Txt("Unjuran lurus ikut purata lepas, bukan janji. Kalau komitmen habis (cth kereta) atau gaji naik, kadar ini naik sendiri.", size = 12f, color = pal.muted)
        }
    }

    // ---------- aset lain ----------
    SecHead("Aset lain", "+ Aset") { vm.open(Sheet.Aset(null)) }
    if (aset.isEmpty()) {
        Note("Tambah KWSP, ASB, Tabung Haji atau emas supaya kekayaan sebenar nampak. Kemas kini nilainya sebulan sekali.")
    } else {
        ListBlock {
            aset.forEach { a ->
                PRow(a.nama, M(a.nilai), { vm.open(Sheet.Aset(a.id)) },
                    subs = listOf("Dikemas kini " + (if (a.dikemas.isNotEmpty()) PG.fmtShort(a.dikemas) + " " + a.dikemas.substring(0, 4) else "-") + " · tekan untuk kemas kini nilai"))
            }
        }
    }

    // ---------- hutang ----------
    val hl = s.debts.map { it to Kekayaan.hutangPada(s.copy(debts = listOf(it)), today) }.filter { it.second > 0.004 }
    if (hl.isNotEmpty()) {
        SecHead("Hutang", right = M(kini.hutang))
        ListBlock {
            hl.forEach { (d, v) -> PRow(d.nama, M(-v), { vm.open(Sheet.HMenu(d.id)) }, rightColor = pal.out, subs = listOf(jenisHutang(d.jenis))) }
        }
    }
    Note("Duit = semua poket bank, tunai & e-wallet (poket simpanan termasuk). Rumah dan kereta tidak dikira kecuali ditambah sebagai aset; pinjamannya dikira kalau direkod sebagai hutang.")
}

private fun fmtYmPendek(d: String): String { val p = PG.parse(d); return PG.BULAN[p.m - 1] + " " + (p.y % 100).toString().padStart(2, '0') }

/* ================= helaian aset ================= */

@Composable
fun AsetSheet(vm: MainViewModel, id: String?) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val a = remember(s, id) { if (id != null) Kekayaan.asetDari(s).find { it.id == id } else null }
    var nama by remember { mutableStateOf(a?.nama ?: "") }
    var nilai by remember { mutableStateOf(a?.let { PG.toFixed(it.nilai, 2) } ?: "") }
    var err by remember { mutableStateOf("") }
    val fr = autoFocus(a == null)
    SheetBody(actions = { SheetActions("Simpan", { err = vm.simpanAset(a?.id, nama, nilai) }, { vm.close() }) }) {
        SheetTitle(if (a != null) "Kemas kini " + a.nama else "Aset baru", rich("Masukkan nilai **hari ini**. Setiap kemas kini disimpan bertarikh supaya carta bulan lepas kekal tepat."))
        Form {
            FieldText("Nama", nama, { nama = it }, placeholder = "cth: KWSP", maxLen = 30, fr = fr)
            if (a == null) FieldChips("Pilihan cepat", listOf("KWSP" to "KWSP", "ASB" to "ASB", "Tabung Haji" to "Tabung Haji", "Emas" to "Emas"), nama, { nama = it })
            FieldText("Nilai sekarang (RM)", nilai, { nilai = it }, placeholder = "0.00", kb = KeyboardType.Decimal, big = true)
        }
        Box(Modifier.padding(horizontal = GL)) { FormError(err) }
        if (a != null && a.sejarah.size > 1) {
            SecHead("Sejarah nilai")
            ListBlock {
                a.sejarah.takeLast(6).reversed().forEach { (t, v) ->
                    Row(Modifier.fillMaxWidth().hairlines(pal.line).padding(horizontal = GL, vertical = 9.dp)) {
                        Txt(PG.fmtDate(t), Modifier.weight(1f), size = 13.5f, color = pal.muted, num = true)
                        Txt(M(v), size = 13.5f, num = true)
                    }
                }
            }
        }
        if (a != null) { Spacer(Modifier.height(8.dp)); DelZone("Padam aset", "Padam " + a.nama + "? Sejarah nilainya juga dibuang.", { vm.padamAset(a.id) }) }
    }
}

/* ================= carta baki (boleh negatif) ================= */

/**
 * Carta garis untuk baki / kekayaan: paksi sifar jelas, kawasan di bawah garis berlorek lembut,
 * nilai negatif dilukis merah lembut. Tekan / leret untuk lihat nilai setiap titik.
 * [markIdx] = titik penting (cth hari gaji, dilukis putus-putus). [garisBawah] = paras rujukan (cth poket simpanan).
 */
@Composable
fun BakiChart(
    vals: List<Double>,
    ticks: List<Pair<Int, String>>,
    warna: Color,
    markIdx: Int?,
    tip: (Int) -> String,
    garisBawah: Double = 0.0,
) {
    val pal = LocalPal.current
    val tm = rememberTextMeasurer()
    if (vals.isEmpty()) return
    val n = max(1, vals.size - 1)
    var cur by remember(vals.size) { mutableIntStateOf(vals.size - 1) }
    val reveal = appear(vals, 900)
    Column {
        Txt(tip(cur.coerceIn(0, vals.size - 1)), size = 12.5f, weight = FontWeight.SemiBold, color = if (vals[cur.coerceIn(0, vals.size - 1)] < 0) pal.bad else pal.ink, maxLines = 1)
        Spacer(Modifier.height(4.dp))
        Canvas(
            Modifier.fillMaxWidth().height(176.dp)
                .pointerInput(n) {
                    detectTapGestures { o ->
                        val L = 44.dp.toPx(); val R = 12.dp.toPx()
                        cur = (((o.x - L) / (size.width - L - R)) * n).roundToInt().coerceIn(0, n)
                    }
                }
                .pointerInput(n) {
                    detectHorizontalDragGestures { ch, _ ->
                        val L = 44.dp.toPx(); val R = 12.dp.toPx()
                        cur = (((ch.position.x - L) / (size.width - L - R)) * n).roundToInt().coerceIn(0, n)
                    }
                },
        ) {
            val L = 44.dp.toPx(); val R = 12.dp.toPx(); val T = 10.dp.toPx(); val B = 22.dp.toPx()
            val pw = size.width - L - R; val ph = size.height - T - B
            var lo = min(0.0, vals.minOrNull() ?: 0.0)
            var hi = max(0.0, vals.maxOrNull() ?: 0.0)
            if (garisBawah > 0) hi = max(hi, garisBawah)
            if (hi - lo < 1.0) hi = lo + 1.0
            val padV = (hi - lo) * 0.08
            hi += padV; if (lo < 0) lo -= padV
            fun x(i: Int) = L + (i.toFloat() / n) * pw
            fun y(v: Double) = (T + ph - ((v - lo) / (hi - lo)) * ph).toFloat()
            val ts = TextStyle(fontSize = 10.5.sp, color = pal.muted)

            // grid: atas, sifar, bawah
            listOf(hi, 0.0, lo).distinct().forEach { gv ->
                val yy = y(gv)
                drawLine(if (gv == 0.0) pal.lineStrong else pal.grid, Offset(L, yy), Offset(size.width - R, yy), strokeWidth = 1.dp.toPx())
                val lay = tm.measure(compact(gv), ts)
                drawText(lay, topLeft = Offset(L - 6.dp.toPx() - lay.size.width, yy - lay.size.height / 2f))
            }
            if (garisBawah > 0) {
                val yy = y(garisBawah)
                drawLine(pal.warn, Offset(L, yy), Offset(size.width - R, yy), strokeWidth = 1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 6f)))
            }
            ticks.forEach { (i, t) ->
                val lay = tm.measure(tr(t), ts)
                val cx = x(i.coerceIn(0, n))
                val left = when { i <= 0 -> cx; i >= n -> cx - lay.size.width; else -> cx - lay.size.width / 2f }
                drawText(lay, topLeft = Offset(left.coerceIn(0f, size.width - lay.size.width), size.height - lay.size.height.toFloat()))
            }
            if (markIdx != null && markIdx in 0..n) {
                drawLine(pal.lineStrong, Offset(x(markIdx), T), Offset(x(markIdx), T + ph), strokeWidth = 1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f)))
            }

            val last = ((vals.size - 1) * reveal.value).roundToInt().coerceIn(0, vals.size - 1)
            val y0 = y(0.0)
            val area = Path().apply {
                moveTo(x(0), y0)
                for (i in 0..last) lineTo(x(i), y(vals[i]))
                lineTo(x(last), y0); close()
            }
            drawPath(area, warna.copy(alpha = 0.12f))
            val line = Path().apply { for (i in 0..last) if (i == 0) moveTo(x(i), y(vals[i])) else lineTo(x(i), y(vals[i])) }
            drawPath(line, warna, style = Stroke(width = 2.2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
            // titik negatif → merah lembut
            for (i in 0..last) if (vals[i] < 0) drawCircle(pal.out, radius = 2.6.dp.toPx(), center = Offset(x(i), y(vals[i])))

            val c = cur.coerceIn(0, vals.size - 1)
            if (reveal.value >= 0.999f) {
                drawLine(pal.lineStrong, Offset(x(c), T), Offset(x(c), T + ph), strokeWidth = 1.dp.toPx())
                drawCircle(pal.surface, radius = 6.dp.toPx(), center = Offset(x(c), y(vals[c])))
                drawCircle(if (vals[c] < 0) pal.out else warna, radius = 4.dp.toPx(), center = Offset(x(c), y(vals[c])))
            }
        }
    }
}
