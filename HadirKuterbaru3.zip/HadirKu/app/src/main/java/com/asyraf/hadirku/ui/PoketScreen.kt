package com.asyraf.hadirku.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.asyraf.hadirku.MainViewModel
import com.asyraf.hadirku.Sheet
import com.asyraf.hadirku.pg.PG

/** Tab Poket (viewUtama PoketGaji). */
@Composable
fun PoketScreen(vm: MainViewModel) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val today = vm.today()
    val b = remember(s) { PG.balances(s) }
    val tot = remember(s) { PG.total(s) }
    val bs = remember(s) { PG.bankStatus(s) }
    val dw = s.pockets.filter { it.dompet && !it.tunai }
    val tn = s.pockets.filter { it.tunai }
    val tTunai = remember(s) { PG.totalTunai(s) }
    val tEw = remember(s) { PG.totalEwallet(s) }
    var susun by remember { mutableStateOf(false) }
    val per = PG.finPeriod(today, 1)
    val rep = remember(s, per) { PG.periodReport(s, per) }
    val repPrev = remember(s, per) { PG.periodReport(s, PG.shiftPeriod(per, -1, 1)) }

    Hero(if (dw.isNotEmpty() || tn.isNotEmpty()) "Baki dalam bank" else "Jumlah semua poket", tot, neg = tot < 0) {
        if (dw.isNotEmpty() || tn.isNotEmpty()) {
            if (tn.isNotEmpty()) Txt(rich("Tunai dalam dompet **" + M(tTunai) + "**"), size = 13f, color = pal.muted)
            if (dw.isNotEmpty()) Txt(rich("E-wallet: " + dw.joinToString(" · ") { it.nama + " **" + M(b[it.id] ?: 0.0) + "**" }), size = 13f, color = pal.muted)
            Txt(rich("Semua duit (bank" + (if (tn.isNotEmpty()) " + tunai" else "") + (if (dw.isNotEmpty()) " + e-wallet" else "") + ") **" + M(PG.round2(tot + tTunai + tEw)) + "**"), size = 13f, color = pal.muted)
            Spacer(Modifier.height(6.dp))
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f)) {
                when {
                    bs == null -> Pill("Belum semak dengan bank", Tone.NEUTRAL)
                    Math.abs(bs.beza) < 0.005 -> Pill("✔ Sama dengan bank · " + PG.fmtShort(bs.check.tarikh), Tone.GOOD)
                    else -> Pill("Beza " + M(Math.abs(bs.beza)) + " dengan bank · " + PG.fmtShort(bs.check.tarikh), Tone.BAD)
                }
            }
            Btn("Semak baki bank", { vm.open(Sheet.Bank) }, kind = BtnKind.SMALL, color = pal.accentStrong)
        }
    }
    DompetTunaiCard(vm, s, b)
    RamalanRingkas(vm, s)
    val belum = b[PG.BELUM_AGIH] ?: 0.0
    if (belum > 0.004) Notice(rich("**" + M(belum) + "** belum diagih ke poket."), Tone.WARN, "Agih") {
        vm.newTx(com.asyraf.hadirku.pg.Tx(jenis = "pindah", poket = PG.BELUM_AGIH), "Agih ke poket")
    }
    else if (belum < -0.004) Notice(rich("Belum Agih negatif **" + M(belum) + "**. Semak transaksi Pindah."), Tone.BAD)

    val due = vm.backupDue()
    if (due != null) {
        Block {
            Row(verticalAlignment = Alignment.Top) {
                Box(Modifier.size(44.dp).background(pal.accentSoft, RoundedCornerShape(11.dp)), contentAlignment = Alignment.Center) { Ico(Ic.DOWNLOAD, pal.accentStrong, 22.dp, stroke = 2f) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Txt(if (due.second) "Belum pernah simpan salinan" else "Salinan terakhir " + due.first + " hari lalu", size = 15f, weight = FontWeight.Bold)
                    Txt("Data hanya ada dalam telefon ini. Kalau telefon hilang atau rosak, salinan sahaja boleh pulihkan semuanya.", size = 13.5f, color = pal.muted)
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Btn("Nanti", { vm.snoozeBackup() }, Modifier.weight(1f))
                Btn("Simpan salinan", { vm.open(Sheet.BackupMenu) }, Modifier.weight(1f), kind = BtnKind.PRIMARY)
            }
        }
    }

    SecHeadLinks("Poket", if (susun) listOf("Siap" to { susun = false; vm.lastMoved = null })
        else listOf("Susun" to { susun = true; vm.lastMoved = null }, "+ Poket" to { vm.open(Sheet.PocketForm(null)) }))
    if (susun) SusunPoketList(vm, s.pockets) { p -> M(b[p.id] ?: 0.0) }
    else ListBlock {
        s.pockets.forEach { p ->
            val bal = b[p.id] ?: 0.0
            PRow(
                p.nama, M(bal), { vm.open(Sheet.PocketMenu(p.id)) }, tag = if (p.tunai) "tunai" else if (p.dompet) "e-wallet" else null, neg = bal < -0.004,
                subs = if (p.id == PG.BELUM_AGIH) listOf("Gaji masuk ke sini dulu, kemudian diagih") else if (p.tunai) listOf("Duit tunai dalam dompet · tidak dikira dalam bank") else emptyList(),
            )
        }
    }

    val ks = remember(s, today) { PG.commitmentSummary(PG.commitmentStatus(s, today)) }
    val cyc = PG.otCycleOf(today, vm.otSd())
    val os = remember(s, cyc.start) { PG.otSummary(s, cyc) }
    val dl = remember(s, today) { PG.debtStatus(s, today) }
    val dsum = PG.debtSummary(dl)
    val pl = if (dl.isNotEmpty() && dsum.baki > 0.004) remember(s, today) { PG.debtPlan(s, vm.budgetNow(), s.settings.hutangStrategi, today) } else null
    val hsub = when {
        dl.isEmpty() -> "Tiada hutang direkod"
        dsum.baki <= 0.004 -> "✔ Semua langsai"
        pl != null && pl.cukup && !pl.never -> "Bebas hutang " + monthShort(today, pl.bulan)
        else -> "Semak pelan bayaran"
    }
    val ak = akruanOn(s)
    Tiles(listOf(
        TileData("Komitmen belum dibayar", M(ks.baki), if (ks.belum > 0) "${ks.belum} komitmen belum selesai" else "Semua dah dibayar") { vm.setBayarSeg("komitmen"); vm.go("bayaran") },
        TileData("OT kitaran ini", M(os.nilai), fmtH(os.kiraHad) + " / " + PG.jsNum(os.had) + " jam had") { vm.kerjaSeg = "ot"; vm.go("kerja") },
        TileData("Jumlah hutang", M(dsum.baki), hsub) { vm.setBayarSeg("hutang"); vm.go("bayaran") },
        if (ak) TileData("Perbelanjaan bulan ini", M(rep.belanja), if (repPrev.belanja > 0) "Bulan lepas " + M(repPrev.belanja) else "Lihat laporan") { vm.go("laporan") }
        else TileData("Keluar bulan ini", M(rep.keluar), if (repPrev.keluar > 0) "Bulan lepas " + M(repPrev.keluar) else "Lihat laporan") { vm.go("laporan") },
    ))
}
