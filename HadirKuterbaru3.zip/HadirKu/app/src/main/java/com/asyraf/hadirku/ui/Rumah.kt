@file:OptIn(ExperimentalLayoutApi::class)

package com.asyraf.hadirku.ui

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.asyraf.hadirku.MainViewModel
import com.asyraf.hadirku.Sheet
import com.asyraf.hadirku.kongsi.Barang
import com.asyraf.hadirku.kongsi.Kongsi
import com.asyraf.hadirku.kongsi.Status
import com.asyraf.hadirku.rumah.Belanja
import com.asyraf.hadirku.rumah.Peringatan
import com.asyraf.hadirku.pg.PG
import kotlinx.coroutines.launch

/* ======================================================================
 *  Rumah tangga: boleh belanja hari ni, senarai barang, bil, projek,
 *  nafkah dan ringkasan mingguan.
 * ====================================================================== */

/** Notis status sambungan Firebase (hanya bila belum sedia). */
@Composable
fun KongsiStatusNotice() {
    val st by Kongsi.status.collectAsState()
    val ralat by Kongsi.ralat.collectAsState()
    when (st) {
        Status.SEDIA -> {}
        Status.SAMBUNG, Status.MATI -> Notice(rich("Menyambung ke Firebase untuk kongsi dengan suami…"), Tone.INFO)
        Status.RALAT -> Notice(rich(ralat.ifEmpty { "Tak dapat bersambung." }), Tone.WARN, "Cuba lagi") { Kongsi.cubaLagi() }
    }
}

// ---------------- Senarai barang ----------------

@Composable
fun SenaraiScreen(vm: MainViewModel) {
    val pal = LocalPal.current
    val list by Kongsi.barang.collectAsState()
    val sej by Kongsi.sejarah.collectAsState()
    val today = vm.today()
    KongsiStatusNotice()
    val ada = list.map { Kongsi.kunciBarang(it.nama) }.toSet()
    val cad = remember(sej, ada, today) { Belanja.cadangan(sej, ada, today) { Kongsi.kunciBarang(it) } }
    val belum = list.filter { !it.dibeli }
    val dah = list.filter { it.dibeli }

    if (list.isEmpty()) Empty(rich("Senarai kosong. Tekan **Tambah barang**. Isteri boleh nampak dan tambah barang yang sama dari telefon dia."))
    if (belum.isNotEmpty()) {
        SecHead("Perlu beli", right = belum.size.toString() + " barang")
        ListBlock { belum.forEach { BarangRow(it) } }
    }
    if (dah.isNotEmpty()) {
        SecHeadLinks("Dah masuk troli (" + dah.size + ")", listOf("Batal semua" to { dah.forEach { Kongsi.tickBarang(it.id, false) } }))
        ListBlock { dah.forEach { BarangRow(it) } }
        Btn("Rekod belanja " + dah.size + " barang", { vm.rekodBelanjaBarang() }, Modifier.fillMaxWidth().padding(horizontal = GL), kind = BtnKind.PRIMARY)
        Btn("Dah beli, tak perlu rekod", { vm.buangBarangDitick() }, Modifier.fillMaxWidth().padding(horizontal = GL))
        Note("Lepas rekod, barang ini dibuang dari senarai dan tarikh beli diingat untuk cadangan beli semula.")
    }
    if (cad.isNotEmpty()) {
        SecHead("Mungkin dah nak habis")
        ListBlock {
            cad.forEach { c ->
                Row(Modifier.fillMaxWidth().hairlines(pal.line).padding(horizontal = GL, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Txt(c.nama, size = 15f, weight = FontWeight.SemiBold)
                        Txt("Biasa dibeli setiap " + c.selang + " hari · kali terakhir " + PG.fmtShort(c.terakhir), size = 12.5f, color = pal.muted)
                    }
                    Btn("+ Tambah", { Kongsi.tambahBarang(c.nama); vm.toast(c.nama + " ditambah") }, kind = BtnKind.SMALL, color = pal.accentStrong)
                }
            }
        }
    }
}

@Composable
private fun BarangRow(b: Barang) {
    val pal = LocalPal.current
    Row(
        Modifier.fillMaxWidth().hairlines(pal.line).pressable({ Kongsi.tickBarang(b.id, !b.dibeli) }, scaleTo = 0.985f).padding(start = GL, end = 4.dp, top = 6.dp, bottom = 6.dp).heightIn(min = 44.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        val shape = RoundedCornerShape(5.dp)
        Box(
            Modifier.size(24.dp).background(if (b.dibeli) pal.accent else Color.Transparent, shape).border(1.5.dp, if (b.dibeli) pal.accent else pal.lineStrong, shape),
            contentAlignment = Alignment.Center,
        ) { if (b.dibeli) Txt("✓", size = 14f, weight = FontWeight.Bold, color = pal.accentInk) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Txt(b.nama, size = 15f, weight = FontWeight.Medium, color = if (b.dibeli) pal.muted else pal.ink)
            val sub = listOfNotNull(b.nota.ifEmpty { null }, if (b.oleh.isNotEmpty() && b.oleh != Kongsi.uid()) "oleh " + Kongsi.namaAhli(b.oleh) else null)
            if (sub.isNotEmpty()) Txt(sub.joinToString(" · "), size = 12.5f, color = pal.muted)
        }
        Box(Modifier.size(44.dp).clickable { Kongsi.padamBarang(b.id) }, contentAlignment = Alignment.Center) { Txt("✕", size = 15f, color = pal.muted) }
    }
}

@Composable
fun BarangFormSheet(vm: MainViewModel) {
    var nama by remember { mutableStateOf("") }
    var nota by remember { mutableStateOf("") }
    var n by remember { mutableStateOf(0) }
    val fr = autoFocus(true)
    fun tambah(): Boolean {
        if (nama.isBlank()) return false
        if (Kongsi.hid().isEmpty()) { vm.toast("Belum bersambung ke Firebase. Semak internet, kemudian cuba lagi."); return false }
        Kongsi.tambahBarang(nama, nota); n++; nama = ""; nota = ""
        return true
    }
    SheetBody(actions = {
        SheetActions("Tambah & tutup", { tambah(); vm.close() }, { vm.close() }, cancel = "Tutup", extra = "Tambah lagi", onExtra = { if (tambah()) runCatching { fr.requestFocus() } })
    }) {
        SheetTitle("Tambah barang", if (n > 0) rich("**$n** barang ditambah.") else rich("Contoh: beras 10kg, minyak masak, susu anak."))
        Form {
            FieldText("Barang", nama, { nama = it }, placeholder = "cth: Beras", maxLen = 60, fr = fr)
            FieldText("Nota (pilihan)", nota, { nota = it }, placeholder = "cth: 2 botol, jenama biasa", maxLen = 60)
        }
        if (Kongsi.hid().isEmpty()) Note("Belum bersambung ke Firebase. Sambung ke internet sekali untuk aktifkan senarai kongsi.", Modifier.padding(top = 8.dp))
        else Note("Tiada internet pun tak apa: barang disimpan dan dihantar ke telefon suami bila ada internet.", Modifier.padding(top = 8.dp))
    }
}

// ---------------- Nafkah ----------------

/** Hantar nafkah ke app isteri dan lihat status terima. */
@Composable
fun NafkahBlock(vm: MainViewModel) {
    val pal = LocalPal.current
    val list by Kongsi.nafkah.collectAsState()
    val saya = list.filter { it.dari == Kongsi.uid() }.take(4)
    SecHead("Nafkah", "Hantar nafkah") { vm.hantarNafkah() }
    if (saya.isEmpty()) Note("Rekod duit yang kau bagi kepada isteri. Ia dicatat sebagai Keluar dari poket kau, dan muncul dalam app isteri untuk dia tekan Terima.")
    else ListBlock {
        saya.forEach { n ->
            Row(Modifier.fillMaxWidth().hairlines(pal.line).padding(horizontal = GL, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Txt(M(n.jumlah), size = 15f, weight = FontWeight.SemiBold, num = true)
                    Txt((if (n.tarikh.isNotEmpty()) PG.fmtShort(n.tarikh) else "") + (if (n.catatan.isNotEmpty()) " · " + n.catatan else ""), size = 12.5f, color = pal.muted)
                }
                Pill(if (n.diterima) "✔ Diterima" else "Belum diterima", if (n.diterima) Tone.GOOD else Tone.NEUTRAL)
            }
        }
    }
}

// ---------------- Projek rumah baru ----------------

@Composable
fun ProjekView(vm: MainViewModel) {
    val pal = LocalPal.current
    val list by Kongsi.projek.collectAsState()
    KongsiStatusNotice()
    if (list.isEmpty()) {
        Empty(rich("Buat projek seperti **Rumah baru** dan senaraikan lampu, kipas, aircond dan perabot. Bajet dan belanja sebenar dipaparkan bersebelahan, dan dikongsi dengan isteri."))
        Btn("Buat projek", { vm.open(Sheet.ProjekForm(null)) }, Modifier.fillMaxWidth().padding(horizontal = GL), kind = BtnKind.PRIMARY)
        return
    }
    list.forEach { p ->
        val bajet = p.item.sumOf { it.bajet }
        val sebenar = p.item.sumOf { it.sebenar }
        SecHeadLinks(p.nama, listOf("+ Item" to { vm.open(Sheet.ItemForm(p.id, null)) }, "Edit" to { vm.open(Sheet.ProjekForm(p.id)) }))
        SummaryCard("Belanja sebenar vs bajet", sebenar, bajet, if (bajet > 0) sebenar / bajet else 0.0,
            rich(if (bajet <= 0.004) "Belum ada bajet." else if (sebenar > bajet + 0.004) "Lebih bajet **" + M(sebenar - bajet) + "**" else "Baki bajet **" + M(bajet - sebenar) + "**"), sebenar > bajet + 0.004)
        if (p.item.isEmpty()) Empty(rich("Tiada item lagi. Tekan **+ Item**."))
        else ListBlock {
            p.item.forEach { i ->
                val beza = i.bajet - i.sebenar
                Row(
                    Modifier.fillMaxWidth().hairlines(pal.line).pressable({ vm.open(Sheet.ItemForm(p.id, i.id)) }, scaleTo = 0.985f).padding(horizontal = GL, vertical = 11.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Txt(i.nama, size = 15f, weight = FontWeight.SemiBold)
                        Txt("Bajet " + M(i.bajet) + " · sebenar " + M(i.sebenar), size = 12.5f, color = pal.muted)
                    }
                    Txt(if (i.sebenar <= 0.004) "Belum beli" else if (beza < -0.004) "Lebih " + M(-beza) else "Jimat " + M(beza), size = 13f, weight = FontWeight.SemiBold,
                        color = if (i.sebenar <= 0.004) pal.muted else if (beza < -0.004) pal.bad else pal.good)
                }
            }
        }
    }
    Btn("+ Projek lain", { vm.open(Sheet.ProjekForm(null)) }, Modifier.fillMaxWidth().padding(horizontal = GL))
}

@Composable
fun ProjekFormSheet(vm: MainViewModel, id: String?) {
    val p = if (id != null) Kongsi.projek.value.find { it.id == id } else null
    var nama by remember { mutableStateOf(p?.nama ?: "") }
    var err by remember { mutableStateOf("") }
    val fr = autoFocus(id == null)
    SheetBody(actions = { SheetActions("Simpan", { err = vm.simpanProjek(id, nama) }, { vm.close() }) }) {
        SheetTitle(if (id != null) "Edit projek" else "Projek baru")
        Form { FieldText("Nama projek", nama, { nama = it }, placeholder = "cth: Rumah baru", maxLen = 40, fr = fr) }
        Box(Modifier.padding(horizontal = GL)) { FormError(err) }
        if (id != null) { Spacer(Modifier.height(8.dp)); DelZone("Padam projek", "Padam projek ini dan semua itemnya (untuk kau dan isteri)?", { vm.padamProjek(id) }) }
    }
}

@Composable
fun ItemFormSheet(vm: MainViewModel, pid: String, iid: String?) {
    val p = Kongsi.projek.value.find { it.id == pid }
    val i = p?.item?.find { it.id == iid }
    var nama by remember { mutableStateOf(i?.nama ?: "") }
    var bajet by remember { mutableStateOf(if (i != null && i.bajet > 0) PG.toFixed(i.bajet, 2) else "") }
    var sebenar by remember { mutableStateOf(if (i != null && i.sebenar > 0) PG.toFixed(i.sebenar, 2) else "") }
    var err by remember { mutableStateOf("") }
    val fr = autoFocus(iid == null)
    SheetBody(actions = { SheetActions("Simpan", { err = vm.simpanItem(pid, iid, nama, bajet, sebenar) }, { vm.close() }) }) {
        SheetTitle(if (iid != null) "Edit item" else "Item baru", if (p != null) rich("Projek **" + p.nama + "**") else null)
        Form {
            FieldText("Item", nama, { nama = it }, placeholder = "cth: Kipas siling", maxLen = 40, fr = fr)
            FieldText("Bajet (RM)", bajet, { bajet = it }, placeholder = "0.00", kb = KeyboardType.Decimal)
            FieldText("Belanja sebenar (RM)", sebenar, { sebenar = it }, placeholder = "0.00", kb = KeyboardType.Decimal, small = "Atau tekan \"Rekod belanja dari poket\" supaya jumlah ditambah sendiri.")
        }
        Box(Modifier.padding(horizontal = GL)) { FormError(err) }
        if (iid != null) {
            MenuBtn("Rekod belanja dari poket", { vm.rekodItem(pid, iid) })
            Spacer(Modifier.height(8.dp)); DelZone("Padam item", "Padam item ini?", { vm.padamItem(pid, iid) })
        }
    }
}

// ---------------- Tetapan ----------------

@Composable
fun KongsiSection(vm: MainViewModel) {
    val pal = LocalPal.current
    val la = launch()
    val st by Kongsi.status.collectAsState()
    val ralat by Kongsi.ralat.collectAsState()
    val rumah by Kongsi.rumah.collectAsState()
    val scope = rememberCoroutineScope()
    var nama by remember { mutableStateOf(Kongsi.namaSaya()) }
    var kod by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    SecHead("Kongsi dengan isteri")
    Column(Modifier.fillMaxWidth()) {
        StatusRow("Sambungan", when (st) {
            Status.SEDIA -> "✔ Bersambung · " + (rumah?.ahli?.size ?: 1) + " ahli dalam rumah ini" + (rumah?.let { r -> r.ahli.filter { it != Kongsi.uid() }.joinToString { Kongsi.namaAhli(it) }.ifEmpty { null }?.let { " ($it)" } } ?: "")
            Status.RALAT -> ralat
            else -> "Menyambung…"
        }) { if (st == Status.RALAT) Btn("Cuba lagi", { Kongsi.cubaLagi() }, kind = BtnKind.SMALL) }
        val k = rumah?.kod
        if (k != null && k.isNotEmpty()) {
            Column(Modifier.fillMaxWidth().background(pal.surface).hairlines(pal.line).padding(horizontal = GL, vertical = 12.dp)) {
                Txt("Kod rumah", size = 12f, color = pal.muted)
                Txt(k.chunked(3).joinToString(" "), size = 28f, weight = FontWeight.Bold, color = pal.accentStrong, num = true)
                Txt("Kod rumah dalam app ini. Untuk kongsi dengan isteri, masukkan kod dari app Duitku Isteri di bawah.", size = 12.5f, color = pal.muted)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Btn("Salin kod", { la.copy(k, "Kod disalin") }, Modifier.weight(1f), kind = BtnKind.SMALL)
                    Btn("Kongsi kod", { la.share("kod-rumah.txt", "text/plain", "Kod rumah Duitku: $k", "Kod rumah Duitku") }, Modifier.weight(1f), kind = BtnKind.SMALL)
                }
            }
        }
    }
    Form {
        FieldText("Nama saya", nama, { nama = it }, placeholder = "cth: Abang", maxLen = 20, after = {
            if (nama.trim() != Kongsi.namaSaya()) LinkBtn("Simpan nama", { Kongsi.tukarNama(nama); vm.toast("Nama disimpan") })
        }, small = "Nama ini dipaparkan pada telefon isteri, contohnya \"✔ Abang\" pada barang yang dah dibeli.")
        FieldText("Kod dari app isteri", kod, { kod = it.uppercase().filter { c -> c.isLetterOrDigit() }.take(6) }, placeholder = "Kod 6 aksara",
            small = "Buka app isteri → Tetapan → Kongsi dengan suami untuk lihat kod 6 aksara. Senarai dalam rumah app ini (kalau ada) tidak dibawa bersama.", after = {
                if (kod.length == 6) LinkBtn(if (busy) "Menyambung…" else "Masuk rumah ini", {
                    if (!busy) { busy = true; err = ""; scope.launch { err = Kongsi.masukRumah(kod) ?: ""; busy = false; if (err.isEmpty()) { kod = ""; vm.toast("Bersambung dengan app isteri") } } }
                })
            })
    }
    Box(Modifier.padding(horizontal = GL)) { FormError(err) }
}

