package com.asyraf.hadirku.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.asyraf.hadirku.MainViewModel
import com.asyraf.hadirku.Sheet
import com.asyraf.hadirku.pg.CommitStat
import com.asyraf.hadirku.pg.DebtPlan
import com.asyraf.hadirku.pg.DebtStat
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.PgState

@Composable
fun BayaranScreen(vm: MainViewModel) {
    val seg = if (vm.bayar in setOf("komitmen", "hutang", "projek")) vm.bayar else "komitmen"
    Seg(listOf("komitmen" to "Komitmen", "hutang" to "Hutang", "projek" to "Projek"), seg) { vm.setBayarSeg(it) }
    when (seg) {
        "projek" -> ProjekView(vm)
        "hutang" -> HutangView(vm)
        else -> KomitmenView(vm)
    }
}

@Composable
fun StatusPill(status: String) = when (status) {
    "sudah" -> Pill("✔ Sudah", Tone.GOOD)
    "separuh" -> Pill("Separuh", Tone.WARN)
    else -> Pill("Belum", Tone.BAD)
}

@Composable
private fun KomitmenView(vm: MainViewModel) {
    val s by vm.pg.collectAsState()
    val today = vm.today()
    val per = PG.commitmentPeriod(today, 1)
    val list = remember(s, today) { PG.commitmentStatus(s, today) }
    val sm = PG.commitmentSummary(list)
    if (list.isEmpty()) {
        Empty(rich("Belum ada komitmen. Tambah sewa, ansuran, TNB, air dan internet dengan **tarikh jatuh tempo** supaya status bayaran dijejak sendiri setiap bulan, nampak dalam kalendar, dan dapat peringatan 3 hari & 1 hari sebelum."))
        Btn("Tambah komitmen", { vm.open(Sheet.KForm(null)) }, Modifier.fillMaxWidth().padding(horizontal = GL), kind = BtnKind.PRIMARY)
        NafkahBlock(vm)
        return
    }
    SummaryCard(
        "Komitmen " + periodLabel(per), sm.dibayar, sm.jumlah, if (sm.jumlah > 0) sm.dibayar / sm.jumlah else 0.0,
        rich(if (sm.belum > 0) sm.belum.toString() + " komitmen belum selesai · baki " + M(sm.baki) else "✔ Semua komitmen bulan ini sudah dibayar"), sm.belum > 0,
    )
    KomitmenKalendar(vm, list, today)
    listOf("15" to "Bayar guna gaji 15hb", "30" to "Bayar guna gaji 30hb").forEach { (k, title) ->
        val items = list.filter { it.kitaran == k }.sortedBy { it.c.tempo.takeIf { t -> t in 1..31 } ?: 99 }
        if (items.isEmpty()) return@forEach
        SecHead(title, right = M(items.sumOf { it.jumlah }))
        ListBlock { items.forEach { c -> KRow(vm, s, c, today) } }
    }
    Btn("+ Tambah komitmen", { vm.open(Sheet.KForm(null)) }, Modifier.fillMaxWidth().padding(horizontal = GL))
    NafkahBlock(vm)
}

/** Keadaan komitmen bulan ini: label & nada (ikut tarikh jatuh tempo kalau ada). */
fun keadaanK(c: CommitStat, today: String): Pair<String, Tone> {
    if (c.status == "sudah") return (if (c.manualTanda) "✔ Ditanda" else "✔ Sudah") to Tone.GOOD
    val pre = if (c.status == "separuh") "Separuh · " else ""
    val due = PG.tempoDate(c.c, today) ?: return (if (c.status == "separuh") "Separuh" else "Belum") to (if (c.status == "separuh") Tone.WARN else Tone.BAD)
    val n = PG.hariAntara(today, due)
    return when {
        n < 0 -> pre + "Lewat " + (-n) + " hari" to Tone.BAD
        n == 0 -> pre + "Hari ini" to Tone.BAD
        n == 1 -> pre + "Esok" to Tone.WARN
        n <= 3 -> pre + "H-" + n to Tone.WARN
        else -> pre + "Belum" to Tone.NEUTRAL
    }
}

@Composable
private fun KRow(vm: MainViewModel, s: PgState, c: CommitStat, today: String) {
    val pal = LocalPal.current
    val (lbl, tone) = keadaanK(c, today)
    val due = PG.tempoDate(c.c, today)
    Row(
        Modifier.fillMaxWidth().hairlines(pal.line).pressable({ vm.open(Sheet.KMenu(c.id)) }, scaleTo = 0.985f).padding(horizontal = GL, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Txt(c.nama, size = 15f, weight = FontWeight.SemiBold)
            Txt(
                (if (due != null) "Tempo " + PG.fmtShort(due) + " · " else "") + pname(s, c.poket) +
                    (if (c.status == "separuh") " · baki " + M(c.baki) else "") + (if (c.manualTanda) " · ditanda di luar app" else ""),
                size = 12.5f, color = pal.muted,
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Txt(M(c.jumlah), size = 15f, num = true)
            Pill(lbl, tone)
        }
    }
}

/** Kalendar bulan ini: komitmen pada hari jatuh tempo, berwarna ikut keadaan. Tekan hari → menu komitmen. */
@Composable
private fun KomitmenKalendar(vm: MainViewModel, list: List<CommitStat>, today: String) {
    val pal = LocalPal.current
    val p = PG.parse(today)
    val n = PG.lastDay(p.y, p.m)
    val lead = (PG.weekday(PG.iso(p.y, p.m, 1)) + 6) % 7
    val byDay = list.mapNotNull { c -> PG.tempoDate(c.c, today)?.let { PG.parse(it).d to c } }.groupBy({ it.first }, { it.second })
    val tiada = list.count { PG.tempoDate(it.c, today) == null }
    SecHead("Kalendar " + PG.fmtMonth(PG.ym(today)))
    Column(Modifier.fillMaxWidth().background(pal.surface).hairlines(pal.line, top = true, bottom = true)) {
        Row(Modifier.fillMaxWidth().hairlines(pal.line)) {
            listOf("Isn", "Sel", "Rab", "Kha", "Jum", "Sab", "Ahd").forEach { h ->
                Txt(h, Modifier.weight(1f).padding(vertical = 6.dp), size = 11.5f, weight = FontWeight.SemiBold, color = pal.muted, align = TextAlign.Center)
            }
        }
        val cells: List<Int?> = List(lead) { null } + (1..n).toList()
        Column(Modifier.fillMaxWidth().background(pal.line), verticalArrangement = Arrangement.spacedBy(1.dp)) {
            cells.chunked(7).forEach { week ->
                Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(1.dp)) {
                    (0 until 7).forEach { i ->
                        val d = week.getOrNull(i)
                        val items = if (d != null) byDay[d].orEmpty() else emptyList()
                        val iso = if (d != null) PG.iso(p.y, p.m, d) else ""
                        Column(
                            Modifier.weight(1f).fillMaxHeight().defaultMinSize(minHeight = 52.dp)
                                .background(if (d == null) pal.surface2 else pal.surface)
                                .then(if (d != null && iso == today) Modifier.border(2.dp, pal.accent) else Modifier)
                                .then(if (items.isNotEmpty()) Modifier.clickable { vm.open(Sheet.KMenu(items[0].id)) } else Modifier)
                                .padding(3.dp),
                        ) {
                            if (d != null) {
                                Txt(d.toString(), size = 11.5f, weight = FontWeight.SemiBold, color = if (iso < today) pal.muted else pal.ink)
                                items.take(2).forEach { c ->
                                    val col = when (keadaanK(c, today).second) { Tone.GOOD -> pal.good; Tone.BAD -> pal.bad; Tone.WARN -> pal.warn; else -> pal.accentStrong }
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(Modifier.size(5.dp).background(col, CircleShape))
                                        Spacer(Modifier.width(2.dp))
                                        Txt(c.nama, size = 9.5f, color = col, maxLines = 1)
                                    }
                                }
                                if (items.size > 2) Txt("+" + (items.size - 2), size = 9.5f, color = pal.muted)
                            }
                        }
                    }
                }
            }
        }
    }
    Txt("Hijau: dah bayar · Perang: 3 hari lagi · Merah: hari ini / lewat", Modifier.padding(horizontal = GL, vertical = 8.dp), size = 12f, color = pal.muted)
    if (tiada > 0) Note(tiada.toString() + " komitmen belum ada tarikh tempo. Tekan komitmen itu → Edit komitmen untuk tambah, supaya muncul dalam kalendar & dapat peringatan.")
}

fun tambahLbl(belanja: Double, tunai: Double): String =
    if (belanja > 0.004 && tunai > 0.004) "belanja & tunai kad" else if (tunai > 0.004) "tunai kad" else "belanja kad"

fun bulanIniLine(d: DebtStat): String {
    if (d.jenis != "kad" || !(d.tambahan > 0.004) || d.status == "sudah" || d.status == "langsai") return ""
    val parts = ArrayList<String>()
    if (d.belanjaKad > 0.004) parts.add("belanja kad " + M(d.belanjaKad))
    if (d.tunaiKad > 0.004) parts.add("tunai " + M(d.tunaiKad))
    if (d.dibayar <= 0.004) return "Bulan ini: pelan " + M(d.sasaranAsal) + " + " + parts.joinToString(" + ")
    if (d.status != "pelan") return "Bayaran ditolak dari pelan dulu: baki pelan " + M(d.pelanBaki) + ", kemudian " + parts.joinToString(" + ")
    return "✔ Pelan " + M(d.sasaranAsal) + " dah dibayar · baki " + tambahLbl(d.belanjaKad, d.tunaiKad) + " " + M(d.tambahanBaki)
}

/** Sebab/asas bayaran minimum dalam ayat ringkas, cth "5% × pokok RM9,252.96 (sebelum bayaran RM14.86)". */
fun minWhy(d: DebtStat): String {
    val mi = d.minInfo ?: return ""
    val pc = pct(mi.peratus) + "%"
    val epp = d.eppPokok > 0.004 || d.eppDue > 0.004
    val sebelum = if (d.dibayar > 0.004) " (sebelum bayaran " + M(d.dibayar) + ")" else ""
    if (mi.cara == "biasa") return when (mi.sebab) {
        "ansuran" -> "ansuran EPP bulan ini"
        "baki" -> if (mi.ansuran > 0.004) "ansuran EPP " + M(mi.ansuran) + " + baki biasa penuh" else "baki kad penuh"
        else -> (if (mi.ansuran > 0.004) "ansuran EPP " + M(mi.ansuran) + " + " else "") +
            (if (mi.sebab == "lantai") "minimum terendah " + M(mi.lantai) else pc + " × baki biasa " + M(mi.asas) + sebelum)
    }
    val asasLbl = if (epp) "pokok" else "baki kad"
    return when (mi.sebab) {
        "peratus" -> pc + " × " + asasLbl + " " + M(mi.asas) + sebelum
        "lantai" -> "minimum terendah (" + pc + " × " + asasLbl + " cuma " + M(PG.round2(mi.asas * mi.peratus / 100)) + ")"
        "ansuran" -> "ansuran EPP bulan ini (lebih besar daripada " + pc + " × pokok)"
        "baki" -> "baki kad penuh"
        else -> ""
    }
}

/** "Minimum RMx = 5% × pokok RMy" — untuk kad kredit sahaja. */
fun minLine(d: DebtStat): String {
    val mi = d.minInfo ?: return ""
    if (d.jenis != "kad" || mi.jumlah <= 0.004 || d.status == "langsai") return ""
    val w = minWhy(d)
    return "Minimum **" + M(mi.jumlah) + "**" + if (w.isNotEmpty()) " = " + w else ""
}

/** Pecahan hutang kad: pokok (baki kad + pokok EPP) diasingkan daripada faedah EPP yang belum dibil. */
fun kadLines(d: DebtStat): List<String> {
    if (d.jenis != "kad") return emptyList()
    val out = ArrayList<String>()
    if (d.eppBaki > 0.004) {
        out.add("Pokok **" + M(d.pokok) + "** (kad " + M(d.baki) + " + EPP " + M(d.eppPokok) + ")")
        out.add((if (d.eppFaedah > 0.004) "Faedah EPP belum dibil **" + M(d.eppFaedah) + "**" else "EPP 0% faedah") +
            " · " + d.eppAktif + " pelan, ansuran " + M(d.eppDue) + " bulan ini")
    }
    val ml = minLine(d)
    if (ml.isNotEmpty()) out.add(ml)
    return out
}

/** Anggaran faedah kad (kadar tahunan kad) atas baki kad selepas bayar minimum — berasingan daripada faedah EPP. */
fun faedahKadLine(d: DebtStat): String {
    if (d.jenis != "kad" || !(d.d.kadar > 0) || d.baki <= 0.004) return ""
    val lepasMin = Math.max(0.0, d.baki - Math.max(0.0, d.min - d.dibayar))
    if (lepasMin <= 0.004) return ""
    val f = PG.round2(lepasMin * d.d.kadar / 1200)
    return "Faedah kad ~" + M(f) + " sebulan kalau bayar minimum sahaja (" + pct(d.d.kadar) + "% setahun atas baki kad " + M(lepasMin) +
        (if (d.eppPokok > 0.004) ", bukan atas pokok EPP belum dibil" else "") + ")"
}

@Composable
fun HutangPill(status: String) = when (status) {
    "langsai" -> Pill("✔ Langsai", Tone.GOOD)
    "sudah" -> Pill("✔ Sudah", Tone.GOOD)
    "pelan" -> Pill("✔ Pelan", Tone.GOOD)
    "min" -> Pill("Minimum", Tone.WARN)
    "separuh" -> Pill("Separuh", Tone.WARN)
    else -> Pill("Belum", Tone.BAD)
}

@Composable
private fun HutangView(vm: MainViewModel) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val today = vm.today()
    val list = remember(s, today) { PG.debtStatus(s, today) }
    val sm = PG.debtSummary(list)
    if (list.isEmpty()) {
        Empty(rich("Belum ada hutang direkod. Tambah kad kredit, pinjaman peribadi atau beli dulu bayar kemudian (contohnya SPayLater atau Atome) untuk jejak baki, bayaran bulanan dan tarikh bebas hutang."))
        Btn("Tambah hutang", { vm.open(Sheet.HForm(null)) }, Modifier.fillMaxWidth().padding(horizontal = GL), kind = BtnKind.PRIMARY)
        return
    }
    val plan = remember(s, today) { PG.debtPlan(s, vm.budgetNow(), s.settings.hutangStrategi, today) }
    Hero("Jumlah hutang", sm.baki) {
        when {
            sm.baki <= 0.004 -> Pill("✔ Semua hutang langsai", Tone.GOOD)
            !plan.kosong && !plan.cukup -> Pill("Bajet bawah bayaran minimum", Tone.WARN)
            plan.cukup && !plan.never -> Pill("Bebas hutang " + monthShort(today, plan.bulan), Tone.GOOD)
            else -> Pill("Bayaran tak cukup tampung faedah", Tone.BAD)
        }
    }
    SummaryCard(
        "Bayaran hutang bulan ini", sm.dibayar, sm.sasaran, if (sm.sasaran > 0) sm.dibayar / sm.sasaran else 0.0,
        rich(if (sm.belum > 0) sm.belum.toString() + " hutang belum dibayar penuh · baki " + M(Math.max(0.0, sm.sasaran - sm.dibayar)) else "✔ Semua bayaran hutang bulan ini sudah dibuat"), sm.belum > 0,
    )
    SecHead("Senarai hutang", "+ Hutang") { vm.open(Sheet.HForm(null)) }
    ListBlock {
        list.forEach { d ->
            val g = d.guna
            val subs = ArrayList<String>()
            subs.addAll(kadLines(d))
            val bl = bulanIniLine(d)
            if (bl.isNotEmpty()) subs.add(bl)
            Column(Modifier.fillMaxWidth().hairlines(pal.line).pressable({ vm.open(Sheet.HMenu(d.id)) }, scaleTo = 0.985f).padding(horizontal = GL, vertical = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Txt(d.nama, Modifier.weight(1f), size = 15f, weight = FontWeight.SemiBold)
                    Txt(if (d.jumlah < -0.004) "Lebih " + M(-d.jumlah) else M(d.jumlah), size = 15f, weight = FontWeight.SemiBold, num = true)
                }
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Txt(jenisHutang(d.jenis) + " · " + pct(d.kadar) + "% setahun" + if (d.sasaran > 0) " · bulan ini " + M(d.dibayar) + " / " + M(d.sasaran) else "", Modifier.weight(1f), size = 12.5f, color = pal.muted)
                    Spacer(Modifier.width(8.dp))
                    HutangPill(d.status)
                }
                subs.forEach { Txt(rich(it), Modifier.padding(top = 4.dp), size = 12.5f, color = pal.muted) }
                if (g != null) {
                    Spacer(Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.weight(1f)) { Bar(g, over = g >= 0.9, warn = g >= 0.7, h = 5.dp) }
                        Spacer(Modifier.width(10.dp))
                        Txt("Guna " + Math.round(g * 100) + "% daripada had " + M(d.d.hadKredit), size = 12f, color = pal.muted)
                    }
                }
            }
        }
    }
    PlanSection(vm, s, plan, today)
}

@Composable
private fun PlanSection(vm: MainViewModel, s: PgState, plan: DebtPlan, today: String) {
    val pal = LocalPal.current
    if (plan.kosong) return
    SecHead("Pelan bebas hutang", "Ubah pelan") { vm.open(Sheet.PlanForm) }
    Block {
        Txt(rich("Bajet **" + M(vm.budgetNow()) + "** sebulan · " + if (s.settings.hutangStrategi == "snowball") "baki terkecil dulu" else "faedah tertinggi dulu"), size = 14f)
        Spacer(Modifier.height(10.dp))
        if (!plan.cukup) {
            Column(Modifier.fillMaxWidth().background(pal.warnSoft).padding(10.dp)) {
                Txt(rich("Bajet kurang daripada jumlah bayaran minimum **" + M(plan.minimum) + "**. Naikkan bajet supaya pelan boleh dikira."), size = 14f, color = pal.warn)
                Spacer(Modifier.height(8.dp))
                Btn("Guna " + M(plan.minimum), { vm.planMin() }, kind = BtnKind.SMALL, color = pal.warn)
            }
            return@Block
        }
        val a = plan.asas ?: return@Block
        val cap = 120
        val planVals = plan.siri
        val minVals = a.siri.take(cap + 1)
        val n = Math.max(planVals.size, minVals.size) - 1
        val titles = (0..n).map { if (it == 0) "Sekarang" else PG.fmtMonth(ymAfter(today, it)) }
        val ticks = arrayListOf(0 to "Kini")
        val years = (1..n).filter { ymAfter(today, it).substring(5) == "01" }
        val step = Math.max(1, Math.ceil(years.size / 5.0).toInt())
        years.forEachIndexed { k, yi -> if (k % step == 0 && yi > n * 0.08 && yi < n * 0.97) ticks.add(yi to ymAfter(today, yi).substring(0, 4)) }
        Kvl(listOf(
            Triple(rich("Bebas hutang"), if (plan.never) "Tak langsai" else monthShort(today, plan.bulan), null),
            Triple(rich("Tempoh"), if (plan.never) "—" else tempoh(plan.bulan), null),
            Triple(rich("Anggaran faedah"), M(plan.faedah), null),
        ))
        Spacer(Modifier.height(6.dp))
        Txt(
            if (a.never) rich("Kalau bayar minimum sahaja, baki hampir tak berkurang kerana faedah.")
            else rich("Kalau bayar minimum sahaja: " + tempoh(a.bulan) + " dan faedah " + M(a.faedah) + ". Pelan ini jimat **" + M(plan.jimatFaedah) + "** faedah dan " + tempoh(Math.max(0, plan.jimatBulan ?: 0)) + "."),
            size = 14f,
        )
        Spacer(Modifier.height(10.dp))
        Txt("Unjuran baki hutang", size = 15f, weight = FontWeight.Bold)
        Txt("Tarikh di hujung garis ialah bulan langsai. Sentuh atau leret carta untuk lihat setiap bulan.", size = 12.5f, color = pal.muted)
        Spacer(Modifier.height(8.dp))
        LineChart(
            listOf(
                LSeries("Ikut pelan", pal.c1, planVals, if (plan.never) "Tak langsai" else monthShort(today, plan.bulan)),
                LSeries("Bayar minimum sahaja", pal.c2, minVals, if (a.never) "Tak langsai" else if (a.bulan > cap) "10 thn +" else monthShort(today, a.bulan)),
            ),
            titles, ticks,
        )
        Spacer(Modifier.height(6.dp))
        Legend(listOf(LegItem("Ikut pelan", pal.c1, true), LegItem("Bayar minimum sahaja", pal.c2, true)))
        val trows = ArrayList<List<String>>()
        var t = 0
        while (t <= n) { trows.add(listOf(titles[t], planVals.getOrNull(t)?.let { M(it) } ?: "Langsai", minVals.getOrNull(t)?.let { M(it) } ?: "Langsai")); t += if (n > 36) 12 else 6 }
        TableView(listOf("Bulan", "Ikut pelan", "Minimum sahaja"), trows)
        Spacer(Modifier.height(10.dp))
        Txt("Turutan langsai", size = 13f, color = pal.muted)
        Spacer(Modifier.height(6.dp))
        plan.urutan.forEachIndexed { i, u ->
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(24.dp).background(pal.surface2, CircleShape).border(1.dp, pal.line, CircleShape), contentAlignment = Alignment.Center) {
                    Txt((i + 1).toString(), size = 12f, weight = FontWeight.Bold, color = pal.muted, align = TextAlign.Center)
                }
                Spacer(Modifier.width(10.dp))
                Txt(u.nama, Modifier.weight(1f), size = 14f)
                Txt(u.bulan?.let { monthShort(today, it) } ?: "—", size = 13f, color = pal.muted, num = true)
            }
        }
        Spacer(Modifier.height(6.dp))
        Txt("Anggaran: faedah dikira setiap bulan atas baki kad. Ansuran EPP yang tinggal dimasukkan ikut jadual; belanja baru guna kad tidak dimasukkan.", size = 12.5f, color = pal.muted)
    }
}
