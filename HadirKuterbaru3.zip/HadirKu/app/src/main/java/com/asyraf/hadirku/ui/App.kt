package com.asyraf.hadirku.ui

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.LocalOverscrollConfiguration
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.layout
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.fragment.app.FragmentActivity
import com.asyraf.hadirku.MainViewModel
import com.asyraf.hadirku.Sheet
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.Tx
import com.asyraf.hadirku.system.Notif
import com.asyraf.hadirku.kongsi.Kongsi
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

/** Tindakan fail & sistem yang perlukan Activity (simpan, kongsi, salin, kamera). */
class Launch(
    val saveFile: (name: String, mime: String, text: String, ok: String, backup: Boolean) -> Unit,
    val share: (name: String, mime: String, text: String, title: String) -> Unit,
    val copy: (text: String, ok: String) -> Unit,
    val pickImport: () -> Unit,
    val pickScan: (onUri: (Uri) -> Unit) -> Unit,
    val takePhoto: (onUri: (Uri) -> Unit) -> Unit,
    val activity: FragmentActivity,
)

val LocalLaunch = staticCompositionLocalOf<Launch?> { null }

@Composable
fun launch(): Launch = LocalLaunch.current!!

private fun shareFile(ctx: Context, name: String, mime: String, text: String, title: String): Boolean = try {
    val dir = File(ctx.cacheDir, "kongsi").apply { mkdirs() }
    val f = File(dir, name)
    f.writeText(text, Charsets.UTF_8)
    val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
    val i = Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM, uri).putExtra(Intent.EXTRA_SUBJECT, title)
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    ctx.startActivity(Intent.createChooser(i, title).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    true
} catch (e: Exception) {
    false
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HadirApp(vm: MainViewModel, activity: FragmentActivity) {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    val pg by vm.pg.collectAsState()
    val now by vm.now.collectAsState()

    // ---------- fail ----------
    var pendingSave by remember { mutableStateOf<Triple<String, String, Boolean>?>(null) }
    val onSaved: (Uri?) -> Unit = { uri ->
        val p = pendingSave
        if (uri != null && p != null) vm.saveTextTo(uri, p.first, p.second, p.third)
        pendingSave = null
    }
    val saveJson = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json"), onSaved)
    val saveMd = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/markdown"), onSaved)
    val saveCsv = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv"), onSaved)
    val importL = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) vm.importPick(uri) }
    var scanCb by remember { mutableStateOf<((Uri) -> Unit)?>(null) }
    var camUri by remember { mutableStateOf<Uri?>(null) }
    val scanL = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) scanCb?.invoke(uri) }
    val camL = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok -> val u = camUri; if (ok && u != null) scanCb?.invoke(u) }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 && !Notif.canPost(activity)) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    val launch = remember {
        Launch(
            saveFile = { name, mime, text, ok, backup ->
                pendingSave = Triple(text, ok, backup)
                try {
                    when {
                        mime.contains("json") -> saveJson.launch(name)
                        mime.contains("csv") -> saveCsv.launch(name)
                        else -> saveMd.launch(name)
                    }
                } catch (e: Exception) { vm.toast("Tak dapat buka pemilih fail") }
            },
            share = { name, mime, text, title -> if (!shareFile(ctx, name, mime, text, title)) vm.toast("Tak dapat kongsi. Cuba simpan fail.") },
            copy = { text, ok ->
                try {
                    ctx.getSystemService(ClipboardManager::class.java)?.setPrimaryClip(ClipData.newPlainText("Duitku", text))
                    vm.toast(ok)
                } catch (e: Exception) { vm.toast("Tak dapat salin") }
            },
            pickImport = { try { importL.launch(arrayOf("application/json", "text/plain", "application/octet-stream", "*/*")) } catch (e: Exception) { vm.toast("Tak dapat buka pemilih fail") } },
            pickScan = { cb -> scanCb = cb; try { scanL.launch(arrayOf("image/*", "application/pdf")) } catch (e: Exception) { vm.toast("Tak dapat buka galeri") } },
            takePhoto = { cb ->
                scanCb = cb
                try {
                    val dir = File(ctx.cacheDir, "imbas").apply { mkdirs() }
                    val f = File(dir, "resit-" + System.currentTimeMillis() + ".jpg")
                    val u = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
                    camUri = u
                    camL.launch(u)
                } catch (e: Exception) { vm.toast("Kamera tak dapat dibuka") }
            },
            activity = activity,
        )
    }

    BackHandler(enabled = vm.sheet == null && vm.tab != "kerja") { vm.go("kerja") }

    // kedudukan skrol diingat bagi setiap tab (balik ke tab = di tempat sama, macam iPhone)
    val scrolls = remember { HashMap<String, ScrollState>() }
    val scrollOf: (String) -> ScrollState = { t -> scrolls.getOrPut(t) { ScrollState(0) } }
    val scope = rememberCoroutineScope()
    // tekan tab yang sedang dibuka sekali lagi → naik ke atas dengan licin
    val toTop: (String) -> Unit = { t -> scope.launch { scrollOf(t).animateScrollTo(0, tween(520, easing = IosOut)) } }

    // butang Transaksi mengecil jadi bulat bila skrol ke bawah, kembang semula bila skrol ke atas
    var fabOpen by remember { mutableStateOf(true) }
    LaunchedEffect(vm.tab) {
        fabOpen = true
        val st = scrollOf(vm.tab)
        var anchor = st.value
        snapshotFlow { st.value }.collect { v ->
            val d = v - anchor
            when {
                v <= 8 -> { fabOpen = true; anchor = v }
                d > 28 -> { fabOpen = false; anchor = v }
                d < -28 -> { fabOpen = true; anchor = v }
                (fabOpen && d < 0) || (!fabOpen && d > 0) -> anchor = v
            }
        }
    }

    // matikan "stretch" Android; lantunan iOS dibuat sendiri (iosScroll)
    CompositionLocalProvider(LocalLaunch provides launch, LocalSaiz provides vm.saiz, LocalOverscrollConfiguration provides null) {
        Box(Modifier.fillMaxSize().background(pal.bg)) {
            Column(Modifier.fillMaxSize()) {
                TopBar(vm, now)
                // laporan app tergantung / tertutup (system/Jaga.kt)
                val lap = vm.laporanJaga
                AnimatedVisibility(visible = lap != null) {
                    Row(
                        Modifier.fillMaxWidth().background(pal.badSoft).padding(horizontal = GL, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Txt(rich("**Duitku tergantung / tertutup tadi.** Salin laporan dan hantar kepada Claude."), Modifier.weight(1f), size = 13f, color = pal.bad)
                        Spacer(Modifier.width(8.dp))
                        Column(horizontalAlignment = Alignment.End) {
                            LinkBtn("Salin laporan", { launch.copy(lap ?: "", "Laporan disalin") }, size = 13f)
                            LinkBtn("Tutup", { vm.buangLaporan() }, size = 13f)
                        }
                    }
                }
                AnimatedVisibility(visible = pg.contoh) {
                    Row(
                        Modifier.fillMaxWidth().background(pal.accentSoft).padding(horizontal = GL, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Txt(rich("Ini **data contoh** untuk tunjuk cara app berfungsi."), Modifier.weight(1f), size = 13.5f, color = pal.accentStrong)
                        Column(horizontalAlignment = Alignment.End) {
                            LinkBtn("Mula data sendiri", {
                                vm.open(Sheet.Confirm("Mula dengan data sendiri?", "Data contoh akan dibuang. Selepas ini masukkan baki bank anda sekarang sebagai titik mula. Rekod kehadiran kekal.", "Mula sekarang", "start-fresh"))
                            }, size = 13f)
                            LinkBtn("Pulihkan salinan", { launch.pickImport() }, size = 13f)
                        }
                    }
                }
                Box(Modifier.weight(1f).fillMaxWidth().imePadding()) {
                    // tukar tab: pudar + zum kecil dengan spring (gaya iOS)
                    AnimatedContent(
                        targetState = vm.tab,
                        // tukar tab: meluncur perlahan ikut arah tab (kanan → dari kanan, kiri → dari kiri)
                        transitionSpec = {
                            val dir = if (tabIndex(targetState) >= tabIndex(initialState)) 1 else -1
                            (slideInHorizontally(spring(dampingRatio = 0.9f, stiffness = 240f)) { w -> dir * w / 5 } +
                                fadeIn(tween(300, easing = IosEase)))
                                .togetherWith(
                                    slideOutHorizontally(tween(300, easing = IosEase)) { w -> -dir * w / 10 } +
                                        fadeOut(tween(180, easing = IosEase)),
                                )
                        },
                        label = "tab",
                    ) { tab ->
                        val sc = scrollOf(tab)
                        Column(Modifier.fillMaxSize().iosScroll(sc).padding(bottom = 96.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            when (tab) {
                                "kerja" -> KerjaScreen(vm)
                                "poket" -> PoketScreen(vm)
                                "transaksi" -> TransaksiScreen(vm)
                                "senarai" -> SenaraiScreen(vm)
                                "bayaran" -> BayaranScreen(vm)
                                "laporan" -> LaporanScreen(vm)
                                else -> TetapanScreen(vm)
                            }
                        }
                    }
                }
                BottomTabs(vm, toTop)
            }
            if (vm.tab != "tetapan") Fab(vm, fabOpen, Modifier.align(Alignment.BottomEnd))
            ToastHost(vm, Modifier.align(Alignment.BottomCenter))
            SheetHost(vm)
        }
    }
}

/* ================= logo ================= */

@Composable
fun Logo(size: Dp = 28.dp) {
    Canvas(Modifier.size(size)) {
        val k = this.size.width / 512f
        drawRoundRect(Color(0xFF0C7C8C), cornerRadius = CornerRadius(116 * k, 116 * k))
        val ty = 12 * k
        rotate(-9f, pivot = Offset(256 * k, 170 * k + ty)) {
            drawRoundRect(Color(0xFFBDE5EB), topLeft = Offset(178 * k, 92 * k + ty), size = Size(168 * k, 120 * k), cornerRadius = CornerRadius(14 * k, 14 * k))
            drawCircle(Color(0x8C0C7C8C), radius = 20 * k, center = Offset(262 * k, 152 * k + ty), style = Stroke(7 * k))
        }
        val pocket = Path().apply {
            moveTo(140 * k, 162 * k + ty); lineTo(372 * k, 162 * k + ty); lineTo(372 * k, 318 * k + ty)
            lineTo(361 * k, 336 * k + ty); lineTo(262 * k, 388 * k + ty); lineTo(250 * k, 388 * k + ty)
            lineTo(151 * k, 336 * k + ty); lineTo(140 * k, 318 * k + ty); close()
        }
        drawPath(pocket, Color(0xFFF3FAFB))
        drawRect(Color(0xFFD6EEF1), topLeft = Offset(140 * k, 162 * k + ty), size = Size(232 * k, 20 * k))
        val tick = Path().apply { moveTo(200 * k, 268 * k + ty); lineTo(240 * k, 306 * k + ty); lineTo(314 * k, 228 * k + ty) }
        drawPath(tick, Color(0xFF0C7C8C), style = Stroke(26 * k, cap = StrokeCap.Round))
    }
}

/* ================= bar atas ================= */

@Composable
private fun TopBar(vm: MainViewModel, now: Long) {
    val pal = LocalPal.current
    val today = vm.today()
    val ctxText = when (vm.tab) {
        "kerja" -> "Kitaran OT " + vm.otSd() + "hb"
        "poket", "bayaran" -> periodLabel(PG.finPeriod(today, 1))
        "senarai" -> "Senarai barang"
        "transaksi" -> if (vm.pg.value.settings.otPendapatan && vm.txPocket.isEmpty()) "Lejar harian" else "Duit masuk & keluar"
        "laporan" -> when (vm.lapView) { "ramalan" -> "Ramalan sampai gaji"; "kekayaan" -> "Kekayaan bersih"; else -> "Laporan bulanan" }
        else -> "Tetapan & data"
    }
    Row(
        Modifier.fillMaxWidth().background(pal.surface).statusBarsPadding().hairlines(pal.line).padding(start = GL, end = 8.dp, top = 10.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Logo(28.dp)
        Spacer(Modifier.width(9.dp))
        Txt("Duitku", size = 19f, weight = FontWeight.Bold)
        Spacer(Modifier.weight(1f))
        AnimatedContent(
            targetState = ctxText,
            transitionSpec = {
                (fadeIn(tween(240, easing = IosEase)) + slideInVertically(tween(280, easing = IosOut)) { it / 2 })
                    .togetherWith(fadeOut(tween(140)) + slideOutVertically(tween(180, easing = IosEase)) { -it / 2 })
            },
            label = "ctx",
        ) { t -> Txt(t, size = 13f, color = pal.muted, maxLines = 1) }
        Spacer(Modifier.width(6.dp))
        val on = vm.tab == "tetapan"
        val rot by animateFloatAsState(targetValue = if (on) 90f else 0f, animationSpec = tween(400), label = "gear")
        Box(
            Modifier.size(40.dp).background(if (on) pal.accentSoft else Color.Transparent, RoundedCornerShape(8.dp))
                .pressable({ vm.close(); vm.go(if (on) "kerja" else "tetapan") }, scaleTo = 0.88f),
            contentAlignment = Alignment.Center,
        ) {
            Ico(Ic.GEAR, if (on) pal.accent else pal.muted, 20.dp, modifier = Modifier.graphicsLayer { rotationZ = rot })
        }
    }
}

/* ================= tab bawah ================= */

private val TABS = listOf(
    Triple("kerja", "OT", Ic.KERJA),
    Triple("poket", "Poket", Ic.POKET),
    Triple("transaksi", "Transaksi", Ic.TRANSAKSI),
    Triple("senarai", "Senarai", Ic.SENARAI),
    Triple("bayaran", "Bayaran", Ic.BAYARAN),
    Triple("laporan", "Laporan", Ic.LAPORAN),
)

private fun tabIndex(id: String): Int = TABS.indexOfFirst { it.first == id }.let { if (it < 0) TABS.size else it }

@Composable
private fun BottomTabs(vm: MainViewModel, onReselect: (String) -> Unit) {
    val pal = LocalPal.current
    val tick = rememberTick()
    val dens = LocalDensity.current
    var lebarPx by remember { mutableIntStateOf(0) }
    Box(Modifier.fillMaxWidth().background(pal.surface).hairlines(pal.line, top = true, bottom = false).navigationBarsPadding().onSizeChanged { lebarPx = it.width }) {
        // kapsul lembut di belakang ikon tab aktif, meluncur dengan spring bila tukar tab
        val w = with(dens) { (lebarPx / TABS.size).toDp() }
        val idx = TABS.indexOfFirst { it.first == vm.tab }
        val lastIdx = remember { mutableIntStateOf(0) }
        if (idx >= 0) lastIdx.intValue = idx
        val pillW = if (w < 56.dp) (w - 6.dp).coerceAtLeast(0.dp) else 52.dp
        val x by animateDpAsState(
            targetValue = w * lastIdx.intValue + (w - pillW) / 2,
            animationSpec = spring(dampingRatio = 0.74f, stiffness = 380f),
            label = "kapsul",
        )
        val pa by animateFloatAsState(targetValue = if (idx >= 0) 1f else 0f, animationSpec = tween(200), label = "kapsulA")
        Box(
            Modifier.offset(x = x, y = 6.dp).width(pillW).height(28.dp)
                .graphicsLayer { alpha = pa }
                .background(pal.accentSoft, RoundedCornerShape(14.dp)),
        )
        Row(Modifier.fillMaxWidth()) {
            TABS.forEach { (id, label, ic) ->
                val on = vm.tab == id
                val sc by animateFloatAsState(
                    targetValue = if (on) 1.12f else 1f,
                    animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
                    label = "tab",
                )
                val col by animateColorAsState(if (on) pal.accent else pal.muted, label = "tabWarna")
                Column(
                    Modifier.weight(1f).height(58.dp).clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                        tick()
                        if (on && vm.sheet == null) onReselect(id) else { vm.close(); vm.go(id) }
                    },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    Ico(ic, col, 22.dp, modifier = Modifier.graphicsLayer { scaleX = sc; scaleY = sc })
                    Spacer(Modifier.height(3.dp))
                    Txt(label, size = 11.5f, weight = if (on) FontWeight.Bold else FontWeight.Medium, color = col)
                }
            }
        }
    }
}

/* ================= butang terapung ================= */

@Composable
private fun Fab(vm: MainViewModel, expanded: Boolean, modifier: Modifier) {
    val pal = LocalPal.current
    val tick = rememberTick()
    val endPad by animateDpAsState(if (expanded) 20.dp else 16.dp, spring(dampingRatio = 0.8f, stiffness = 420f), label = "fabPad")
    val ticked = Kongsi.barang.collectAsState().value.count { it.dibeli }
    val label = when {
        vm.tab == "kerja" -> "Key in OT"
        vm.tab == "senarai" && ticked > 0 -> "Rekod belanja ($ticked)"
        vm.tab == "senarai" -> "Tambah barang"
        vm.tab == "bayaran" && vm.bayar == "projek" -> "Transaksi"
        vm.tab == "bayaran" -> "Bayar"
        else -> "Transaksi"
    }
    // denyut lembut supaya butang nampak hidup
    val inf = rememberInfiniteTransition(label = "fab")
    val breathe = inf.animateFloat(
        initialValue = 1f, targetValue = 1.04f,
        animationSpec = infiniteRepeatable(tween(1400), RepeatMode.Reverse), label = "fabnafas",
    )
    Box(modifier.navigationBarsPadding().padding(end = GL, bottom = 58.dp + 14.dp)) {
        Row(
            Modifier.graphicsLayer { scaleX = breathe.value; scaleY = breathe.value }
                .height(52.dp).background(pal.accent, RoundedCornerShape(28.dp))
                .pressable({ tick(); fabAction(vm) }, scaleTo = 0.9f)
                .padding(start = 16.dp, end = endPad),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Ico(Ic.PLUS, pal.accentInk, 20.dp, stroke = 2.4f)
            AnimatedVisibility(
                visible = expanded,
                enter = expandHorizontally(spring(dampingRatio = 0.82f, stiffness = 420f), expandFrom = Alignment.Start) + fadeIn(tween(200, delayMillis = 60)),
                exit = shrinkHorizontally(tween(240, easing = IosEase), shrinkTowards = Alignment.Start) + fadeOut(tween(120)),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Spacer(Modifier.width(8.dp))
                    AnimatedContent(
                        targetState = label,
                        transitionSpec = { (fadeIn(tween(180)) + scaleIn(initialScale = 0.8f)).togetherWith(fadeOut(tween(120)) + scaleOut(targetScale = 0.8f)) },
                        label = "fablabel",
                    ) { l -> Txt(l, size = 15f, weight = FontWeight.Bold, color = pal.accentInk, maxLines = 1) }
                }
            }
        }
    }
}

private fun fabAction(vm: MainViewModel) {
    val s = vm.pg.value
    val today = vm.today()
    when {
        vm.tab == "kerja" -> vm.open(Sheet.OtDay(today))
        vm.tab == "senarai" -> if (Kongsi.barang.value.any { it.dibeli }) vm.rekodBelanjaBarang() else vm.open(Sheet.BarangForm)
        vm.tab == "bayaran" && vm.bayar == "hutang" -> {
            val nd = PG.debtStatus(s, today).find { it.baki > 0.004 && it.bakiBayar > 0.004 }
            when {
                nd != null && nd.jenis == "kad" -> vm.open(Sheet.CardPay(nd.id))
                nd != null -> vm.newTx(Tx(jenis = "keluar", poket = nd.poket, jumlah = nd.bakiBayar, perkara = "Bayar " + nd.nama, hutangId = nd.id), "Bayar " + nd.nama)
                s.debts.isEmpty() -> vm.open(Sheet.HForm(null))
                else -> vm.toast("Semua bayaran hutang bulan ini sudah dibuat")
            }
        }
        vm.tab == "bayaran" -> {
            // komitmen belum bayar yang paling awal jatuh tempo (tanpa tempo → ikut hari gaji kitarannya)
            val next = PG.commitmentStatus(s, today).filter { it.status != "sudah" }
                .minByOrNull { c ->
                    val p = PG.parse(today)
                    PG.tempoDate(c.c, today) ?: PG.iso(p.y, p.m, if (c.kitaran == "15") 15 else minOf(30, PG.lastDay(p.y, p.m)))
                }
            when {
                next != null -> vm.newTx(Tx(jenis = "keluar", poket = next.poket, jumlah = next.baki, perkara = next.nama, komitmenId = next.id), "Bayar " + next.nama)
                s.commitments.isEmpty() -> vm.open(Sheet.KForm(null))
                else -> vm.toast("Semua komitmen bulan ini sudah dibayar")
            }
        }
        else -> vm.newTx(Tx(poket = vm.txPocket))
    }
}

/* ================= toast ================= */

@Composable
private fun ToastHost(vm: MainViewModel, modifier: Modifier) {
    val pal = LocalPal.current
    var shown by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(vm.toastId) {
        val m = vm.toastMsg
        if (m != null) {
            shown = m
            delay(2400)
            shown = null
        }
    }
    Box(modifier.navigationBarsPadding().padding(bottom = 58.dp + 80.dp, start = GL, end = GL)) {
        AnimatedVisibility(
            visible = shown != null,
            enter = fadeIn(tween(160)) + slideInVertically(tween(220)) { it / 2 },
            exit = fadeOut(tween(200)) + slideOutVertically(tween(200)) { it / 3 },
        ) {
            Box(
                Modifier.widthIn(max = 420.dp).background(pal.ink, RoundedCornerShape(12.dp))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { shown = null }
                    .padding(horizontal = 16.dp, vertical = 10.dp),
            ) {
                Txt(shown ?: "", size = 14f, weight = FontWeight.SemiBold, color = pal.bg)
            }
        }
    }
}

/* ================= helaian bawah ================= */

@Composable
private fun SheetHost(vm: MainViewModel) {
    val pal = LocalPal.current
    var last by remember { mutableStateOf<Sheet?>(null) }
    val cur = vm.sheet
    if (cur != null) last = cur
    BackHandler(enabled = cur != null) { vm.close() }
    // tarik helaian ke bawah untuk tutup (gaya iPhone); latar gelap pudar ikut tarikan
    var drag by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(cur) { if (cur != null) drag = 0f }
    val dens = LocalDensity.current
    val closeAt = with(dens) { 120.dp.toPx() }
    val dragState = rememberDraggableState { d -> drag = (drag + d).coerceAtLeast(0f) }
    AnimatedVisibility(visible = cur != null, enter = fadeIn(tween(260, easing = IosEase)), exit = fadeOut(tween(200, easing = IosEase))) {
        Box(
            Modifier.fillMaxSize().graphicsLayer { alpha = 1f - (drag / (closeAt * 4f)).coerceIn(0f, 0.6f) }.background(pal.scrim)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { vm.close() },
        )
    }
    AnimatedVisibility(
        visible = cur != null,
        // helaian naik dari bawah dengan spring sedikit melantun, turun dengan lengkung iOS
        enter = slideInVertically(spring(dampingRatio = 0.82f, stiffness = 330f)) { it } + fadeIn(tween(160)),
        exit = slideOutVertically(tween(260, easing = IosEase)) { it } + fadeOut(tween(220, delayMillis = 60)),
    ) {
        // borang transaksi dibuka skrin penuh; helaian lain kekal sebagai helaian bawah
        val full = last is Sheet.TxForm
        Box(Modifier.fillMaxSize().imePadding(), contentAlignment = Alignment.BottomCenter) {
          // key(full): bila helaian bawah (cth menu poket) bertukar ke borang transaksi skrin penuh, bina susun atur BAHARU.
          // Dulu modifier statusBarsPadding() ditambah pada node yang sama dalam BoxWithConstraints → Compose
          // terperangkap mengira WindowInsets (ExcludeInsets.equals berulang) dan app beku ("not responding").
          key(full) {
            Column(
                (if (full) Modifier.fillMaxSize().background(pal.surface).statusBarsPadding()
                else Modifier.fillMaxWidth().widthIn(max = 560.dp).hadTinggi(0.92f)
                    .graphicsLayer { translationY = drag }
                    .background(pal.surface, RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp)))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
                    .navigationBarsPadding()
                    .then(if (full) Modifier else Modifier.padding(bottom = 10.dp)),
            ) {
                if (!full) Box(
                    Modifier.fillMaxWidth().height(26.dp).draggable(
                        state = dragState,
                        orientation = Orientation.Vertical,
                        onDragStopped = { v ->
                            if (drag > closeAt || v > 1400f) vm.close()
                            else animate(drag, 0f, v, spring(dampingRatio = 0.8f, stiffness = 520f)) { x, _ -> drag = x }
                        },
                    ),
                    contentAlignment = Alignment.Center,
                ) {
                    val gw by animateDpAsState(if (drag > 0f) 48.dp else 40.dp, label = "grab")
                    Box(Modifier.padding(top = 4.dp).width(gw).height(4.dp).background(pal.lineStrong, RoundedCornerShape(4.dp)))
                }
                val s = last
                if (s != null) key(s) { SheetContent(vm, s) }
            }
          }
        }
    }
}

/** Tinggi maksimum = [f] × ruang yang ada (ganti BoxWithConstraints, tanpa subcompose). */
private fun Modifier.hadTinggi(f: Float): Modifier = this.layout { m, c ->
    val mh = if (c.hasBoundedHeight) (c.maxHeight * f).toInt() else c.maxHeight
    val p = m.measure(c.copy(minHeight = minOf(c.minHeight, mh), maxHeight = mh))
    layout(p.width, p.height) { p.placeRelative(0, 0) }
}

/** Isi helaian yang boleh skrol, dengan butang tindakan melekat di bawah. */
@Composable
fun SheetBody(actions: (@Composable () -> Unit)? = null, content: @Composable () -> Unit) {
    Column {
        Column(Modifier.weight(1f, fill = false).iosScroll(rememberScrollState())) { content() }
        if (actions != null) actions()
    }
}

fun periodLabel(per: com.asyraf.hadirku.pg.Period): String =
    if (per.start.substring(8) == "01") PG.fmtMonth(PG.ym(per.start)) else PG.fmtShort(per.start) + " – " + PG.fmtShort(per.end)
