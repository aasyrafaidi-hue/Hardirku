package com.asyraf.hadirku.pg

/* Model data PoketGaji (sama dengan format salinan JSON v2 PoketGaji PWA). */

data class Pocket(
    val id: String,
    val nama: String,
    val sasaran: Double = 0.0,
    val tetap: Boolean = false,
    /** duit poket ini di luar bank (e-wallet ATAU tunai) — tidak dikira dalam baki bank */
    val dompet: Boolean = false,
    /** tambahan HadirKu: duit tunai fizikal dalam dompet (sentiasa dompet = true juga) */
    val tunai: Boolean = false,
)

data class Tx(
    val id: String = "",
    val tarikh: String = "",
    val jenis: String = "keluar",
    val poket: String = "",
    val ke: String = "",
    val jumlah: Double = 0.0,
    val perkara: String = "",
    val komitmenId: String = "",
    val hutangId: String = "",
    val kadId: String = "",
    val catatan: String = "",
    val dibuat: Long = 0,
    val otBayar: Double? = null,
    val fee: Double? = null,
    val feePct: Double? = null,
    val kategori: String? = null,
    val katAuto: Boolean = false,
)

data class Commitment(
    val id: String,
    val nama: String,
    val jumlah: Double,
    val kitaran: String = "30",
    val poket: String = "",
    val manual: Map<String, Boolean> = emptyMap(),
    /** hari jatuh tempo dalam bulan (1–31; 29–31 jadi hari akhir bulan pendek). 0 = tiada tarikh tetap */
    val tempo: Int = 0,
)

data class DebtLog(
    val id: String,
    val tarikh: String,
    val jenis: String,
    val jumlah: Double,
    val catatan: String = "",
    val dibuat: Long = 0,
)

data class Epp(
    val id: String,
    val nama: String = "EPP",
    val pokok: Double = 0.0,
    val tempoh: Int = 1,
    val kadar: Double = 0.0,
    val ansuran: Double = 0.0,
    val mula: String = "",
    val catatan: String = "",
)

data class Debt(
    val id: String,
    val nama: String,
    val jenis: String = "kad",
    val kadar: Double = 0.0,
    val minPeratus: Double = 5.0,
    /** null = kosong ('' dalam JS) → lantai lalai RM50 */
    val minLantai: Double? = 50.0,
    val ansuran: Double = 0.0,
    val rancangan: Double = 0.0,
    val hadKredit: Double = 0.0,
    val poket: String = "",
    val log: List<DebtLog> = emptyList(),
    val epp: List<Epp> = emptyList(),
    val kitaran: String? = null,
    /**
     * Asas bayaran minimum kad kredit (tambahan HadirKu, tiada dalam PoketGaji JS):
     *  "jumlah" = minPeratus% × (baki kad + pokok EPP belum dibil), sekurang-kurangnya lantai & ansuran EPP bulan ini (lalai)
     *  "biasa"  = ansuran EPP bulan ini penuh + minPeratus% × baki selebihnya (cara asal PoketGaji)
     */
    val minAsas: String = "jumlah",
)

data class BankCheck(
    val id: String,
    val tarikh: String,
    val baki: Double,
    val catatan: String = "",
    val dibuat: Long = 0,
)

data class OtEntry(val jenis: String, val jam: Double? = null)

data class Gaji(
    val basic: Double = 2500.0,
    val night: Double = 0.0,
    val transport: Double = 0.0,
    val jamNormal: Double = 9.0,
    val hadOT: Double = 104.0,
    val potongan: Double = 0.0,
    val advance: Double = 0.0,
)

data class TunaiFee(val mode: String = "pct", val nilai: Double? = null)

data class PgSettings(
    val gaji: Gaji = Gaji(),
    val komitmenMulaHari: Int = 1,
    val otMulaHari: Int = 22,
    val hutangBajet: Double = 0.0,
    val hutangStrategi: String = "avalanche",
    val otPendapatan: Boolean = true,
    val tunaiFee: TunaiFee? = null,
    val cfoMatlamat: String? = null,
    /** Kunci tetapan lain yang tidak dikenali (contoh 'agihan' lama), disimpan semula seperti asal. */
    val extraJson: String? = null,
)

data class PgState(
    val version: Int = 2,
    val contoh: Boolean = false,
    val settings: PgSettings = PgSettings(),
    val pockets: List<Pocket> = emptyList(),
    val transactions: List<Tx> = emptyList(),
    val commitments: List<Commitment> = emptyList(),
    val debts: List<Debt> = emptyList(),
    val bankChecks: List<BankCheck> = emptyList(),
    val ot: Map<String, OtEntry> = emptyMap(),
)

data class Label(val id: String, val label: String, val short: String = label, val ai: String = "")
