# Duitku — urus duit + kehadiran kerja dalam satu app

App Android native (Kotlin + Jetpack Compose), dahulu dikenali sebagai **HadirKu**. Gabungan rekod kehadiran (disiplin, geofence, amaran lupa check-in) dan **PoketGaji v0.9.3** (poket, lejar harian, komitmen, hutang, OT, laporan, AI, fail CFO). Rupa **Lejar Moden** — kertas putih lembut, kad bulat berbayang ringan, hijau zamrud (#075B46 cerah, #75C4A1 gelap). Masuk hijau (+), keluar merah lembut (−). Lihat `PERUBAHAN_LEJAR_MODEN.md` untuk butiran reka bentuk baharu, navigasi 5 tab (Utama · Lejar · Bayaran · Laporan · Tetapan) dan laporan ujian.

> Nama pakej (`com.asyraf.hadirku`) dan kunci tandatangan kekal sama, jadi APK Duitku **update** atas HadirKu yang sedia ada — semua data kekal.

## Tab

| Tab | Isi |
|---|---|
| **OT** | Nilai OT kitaran (22hb–21hb) + palang had OT, jam 1.5x / 2.0x / 3.0x, kad **Hari ini**, peringatan hari belum diisi, log harian (terkini di atas, hari depan disembunyikan). Key in guna **helaian papan nombor**: tarikh ‹ ›, jenis hari (Biasa / Off / Rest / Umum / Cuti), jam besar dengan kiraan OT terus, jam cepat 8–12, papan nombor sendiri (⌫, C, −½, +½) dan Simpan. *Simpan & hari seterusnya* simpan tanpa tutup dan terus ke esoknya. |
| **Poket** | Baki bank & e-wallet, semak bank, belum agih, senarai poket, jubin komitmen / OT / hutang / perbelanjaan |
| **Transaksi** | Kalendar & senarai lejar harian (OT dikira pendapatan), butiran hari |
| **Bayaran** | **Komitmen** (kalendar bulan ini, tarikh jatuh tempo, status Lewat / Hari ini / Esok / H-3, gaji 15hb / 30hb, nafkah di bawah), **Hutang** (kad, pinjaman, BNPL, EPP, bayar kad, pelan bebas hutang + carta), **Projek** |

> **Minimum kad kredit (lalai):** peratus minimum × (baki kad + pokok EPP belum dibil), sekurang-kurangnya minimum terendah (RM50) dan ansuran EPP bulan ini. Faedah EPP belum dibil dipaparkan berasingan daripada pokok. Boleh tukar per kad ke cara asal PoketGaji (ansuran EPP penuh + peratus baki biasa) dalam **Edit hutang → Minimum dikira daripada**.

> **Tab Hutang (ringkas):**
> - **Bayaran hutang bulan ini**: jumlah dah bayar + palang, dan jadual *Hutang · Perlu bayar · Dah bayar · Tinggal* (baris Jumlah kalau lebih satu hutang). Tekan baris untuk butiran.
> - **Senarai hutang**: satu baris setiap hutang — nama, jumlah hutang, dan baris kecil *kadar · minimum · guna had*.
> - **Butiran** (tekan hutang): jadual berkumpulan — *Butiran hutang* (baki kad, pokok & faedah EPP, jumlah), *Bulan ini* (minimum + sebabnya, perlu bayar, dah bayar, tinggal nak bayar), *Maklumat lain* (ansuran EPP, anggaran faedah kad, faedah ikut penyata, had kredit), kemudian butang tindakan.

> **Faedah & minimum: isi peratus ATAU nilai RM.** Setiap medan peratus hutang ada suis **% | RM** di hujungnya:
> - **Faedah** → "Faedah sebulan (RM)" ikut penyata (caj kewangan). App kira sendiri kadar setahun = faedah × 12 ÷ baki penyata, dan papar "≈18.5% setahun".
> - **Minimum kad** → "Bayaran minimum (RM)" ikut penyata. Dalam bulan ia diisi, minimum = nilai itu **tepat** (tidak lebih daripada baki). Bulan seterusnya dianggar ikut peratus yang dikira (minimum ÷ (baki penyata + pokok EPP)) dan ditanda "anggaran, kemas kini ikut penyata baru".
> - **Faedah EPP** → "Jumlah faedah (RM)" untuk seluruh tempoh; kadar rata dikira sendiri dan jumlah bayaran = pokok + faedah tepat.
> - **Kemas kini baki ikut penyata** kini ada dua medan pilihan: **Bayaran minimum** dan **Faedah dalam penyata**. Isi dari penyata yang sama setiap bulan; app terus guna nilai RM itu (faedah tidak ditambah ke baki kerana baki penyata dah termasuk faedah).
> - Peratus yang dikira tetap disimpan, jadi pelan bebas hutang, simulasi, Ramalan dan fail CFO berjalan seperti biasa. Data lama tanpa medan RM kekal mod peratus.
| **Transaksi baru** | Skrin penuh: Masuk / Keluar / Pindah (+ Lain), baris Tarikh · Jumlah · Kategori · Poket · Perkara, Catatan + kamera imbas resit, butang Simpan / Teruskan. Papan nombor sendiri (boleh + / −), grid kategori & poket. Pilih / Selesai / Enter terus ke medan seterusnya. |
| **Laporan** | 4 bahagian: **Ringkasan** (penyata, OT vs belanja harian, pie, trend 6 bulan, belanja terbesar, fail CFO) · **Poket** · **Ramalan** (baki sampai gaji) · **Kekayaan** (kekayaan bersih bulan ke bulan) |
| **Tetapan (gear)** | Tema, saiz tulisan, gaji & OT, jadual shift, Pembantu AI, cuti umum (Calendarific), poket, semakan bank, data |

## Bank, tunai dan e-wallet (diasingkan)
- Setiap poket ada tempat simpan: **Bank**, **Tunai (dompet)** atau **E-wallet** (Edit poket → *Duit poket ini disimpan di*).
- Tab Poket tunjuk **Baki dalam bank**, **Tunai dalam dompet**, e-wallet dan **Semua duit** secara berasingan. *Semak baki bank* hanya kira duit bank.
- Kad **Dompet tunai**: *Ambil ATM* (pindah dari poket bank → dompet tunai: bank turun, tunai naik), *Belanja* (belanja tunai, bank tak berubah), *Kira duit* (masukkan duit sebenar dalam dompet; beza direkod sebagai belanja tak direkod, duit masuk, atau pelarasan).
- Dompet Tunai dibuat sendiri sekali (selepas Belum Agih). Kalau sudah ada poket e-wallet bernama Tunai/Cash, poket itu yang ditukar jadi dompet tunai.
- Resit yang dibaca AI sebagai dibayar tunai terus pilih dompet tunai. Belanja guna kad kredit hanya dari poket bank.
- Dalam fail salinan, dompet tunai disimpan sebagai `"dompet": true, "tunai": true` — PoketGaji PWA membacanya sebagai e-wallet (tetap di luar bank).

## Susun & pilih poket
- Tab Poket atau Tetapan → Poket → **Susun**: anak panah naik/turun pada setiap poket. Belum Agih sentiasa di atas. Susunan ini dipakai di semua senarai dan pilihan poket, dan disimpan dalam fail salinan.
- Semua pilihan poket (transaksi, pindah, komitmen, hutang, bayar kad, tunai dari kad) dipaparkan dalam **grid 4 lajur** sama lebar; nama panjang turun ke baris kedua, dan poket tunai / e-wallet ada tag kecil.

## Satu sumber OT
Log OT PoketGaji ialah satu-satunya sumber OT. Bila check-out (atau edit rekod hari), jam di tempat kerja (dibundar ke bawah, lalai 30 minit) diisi ke log OT dengan jenis hari ikut jadual shift: hari kerja = Biasa, rest day = Rest, cuti umum = Umum, hari lain = Off, Cuti/MC = Tidak bekerja. Log masih boleh diubah manual.

## Salinan data
- **Simpan salinan** menghasilkan fail format PoketGaji v2 (`duitku-salinan-YYYY-MM-DD.json`) dengan bahagian tambahan `hadirku` (tetapan & rekod kehadiran — nama kunci dikekalkan supaya salinan lama tetap boleh dibaca). Fail ini masih boleh dibuka oleh PoketGaji PWA.
- **Pulihkan salinan** terima: salinan Duitku / gabungan, salinan PoketGaji biasa, atau salinan HadirKu v1. Hari yang ada rekod kehadiran lengkap tapi tiada log OT akan diisi sendiri.
- Kunci API (Anthropic, Calendarific) kekal dalam telefon, tidak masuk fail salinan.

## Bina APK di GitHub
1. Repo `Hadirmu` (private) sudah ada workflow `.github/workflows/build.yml` yang ekstrak `HadirKu.zip` (nama zip dikekalkan supaya workflow lama terus berfungsi).
2. Ganti `HadirKu.zip` dalam repo dengan zip baharu → **Commit changes**. (Pilihan: ganti juga `.github/workflows/build.yml` dengan versi dalam zip ini supaya fail APK dinamakan `Duitku-v2.0.N.apk`.)
3. Tab **Actions** → tunggu tanda hijau → **Releases** → muat turun APK.
4. Kunci tandatangan sama (`app/hadirku-release.jks`), jadi APK baharu **update** atas app lama tanpa padam rekod kehadiran.

## Kali pertama selepas update
Kalau app baru dipasang (bukan update), ia bermula dengan data contoh PoketGaji. Tekan **Pulihkan salinan** dan pilih fail salinan anda — semua poket, transaksi, komitmen, hutang, log OT dan rekod kehadiran dipulihkan.

## Ramalan baki sampai gaji (Laporan → Ramalan)
- Hari gaji: **15hb** (advance, kalau nilai advance diisi dalam Tetapan) dan **30hb** (atau hari akhir bulan pendek). Gaji yang masuk awal (≤ 4 hari sebelum) dikesan, jadi ramalan terus ke gaji seterusnya.
- **Perlu dibayar sebelum gaji**: komitmen & hutang yang kitarannya sudah lepas tapi belum dibayar, dan bil rumah dikongsi yang jatuh tempo sebelum hari gaji (bil yang namanya sama dengan komitmen tidak dikira dua kali).
- **Dibayar guna gaji ini**: komitmen & hutang kitaran hari gaji itu (15 / 30).
- **Belanja biasa sehari** = purata duit keluar dari bank 60 hari lepas (belanja, ambil ATM, top up e-wallet), tidak termasuk komitmen, bayaran hutang, belanja guna kad dan bil.
- **Poket simpanan** (nama ada simpan / tabung / kecemasan / ASB / haji / pelaburan) tidak dikira duit boleh belanja.
- Paparan: baki dijangka sehari sebelum gaji, **boleh belanja RM X sehari**, belanja biasa vs OT purata sehari, carta baki hari ke hari (tekan / leret untuk nilai), dan kiraan penuh. Ringkasan satu baris juga di tab **Poket**.

## Kekayaan bersih (Laporan → Kekayaan)
- **Kekayaan bersih = semua duit (bank + tunai + e-wallet) + aset lain − semua hutang** (baki kad + pokok EPP belum dibil + pinjaman).
- Carta hujung setiap bulan (6 bulan / 1 / 2 / 5 tahun), perubahan bulan ini, purata naik/turun sebulan, dan unjuran lurus 1 / 3 / 5 tahun.
- **Aset lain** (KWSP, ASB, Tabung Haji, emas…): tambah & kemas kini nilai bila-bila. Setiap kemas kini disimpan bertarikh; sebelum rekod pertama, nilai pertama dipakai supaya aset baru tidak nampak macam lonjakan. Disimpan dalam `settings.aset` fail salinan (PoketGaji PWA kekalkan kunci ini).

## Bahasa: Bahasa Melayu / English (UK)
- **Tetapan → Bahasa · Language**: pilih *Bahasa Melayu* atau *English (UK)*. Seluruh paparan dibina semula serta-merta; data tidak berubah.
- Cara kerja (`i18n/Bahasa.kt`): teks dalam kod kekal Bahasa Melayu. Bila English dipilih, setiap teks diterjemah semasa dipaparkan (`Txt`, `rich`, placeholder, label carta, notifikasi) guna kamus **`assets/i18n/en.tsv`** (~1,350 entri):
  1. padanan penuh ayat;
  2. corak nombor: `15hb` → 15th, `Lewat 3 hari` → 3 days late, `H-2` → 2 days left, `2 hari lagi` → in 2 days, `5 bulan lepas` → last 5 months, `11 jam` → 11 hours…;
  3. cebisan ayat (ayat yang dicantum dengan nombor / tarikh), padanan terpanjang dulu.
- Nama hari & bulan ditukar terus dalam `PG` (Mon, Tue… / January…). Ringkasan & nota imbas resit AI juga dalam English.
- **Data kau sendiri** (nama poket, perkara transaksi, kedai) tidak diterjemah. Perkataan tunggal hanya diterjemah dalam ayat kalau ditanda `f` dalam kamus.
- Teks baru yang belum ada dalam kamus akan kekal Bahasa Melayu dalam mod English. Tambah baris `melayu<TAB>english` dalam `en.tsv`.

## Komitmen bertarikh (ganti Bil rumah)
- Bahagian **Bil rumah** dibuang. Kalendar, tarikh jatuh tempo dan peringatan kini dalam **Bayaran → Komitmen**.
- **Edit komitmen → Jatuh tempo (hari bulan)** (pilihan, 1–31; 29–31 jadi hari akhir bulan pendek). Disimpan sebagai `tempo` dalam fail salinan.
- Kalendar bulan ini tunjuk komitmen pada hari tempo: hijau dah bayar, perang 3 hari lagi, merah hari ini / lewat. Tekan hari → menu komitmen.
- Status setiap komitmen ikut tarikh: *Lewat n hari / Hari ini / Esok / H-n / Belum / ✔ Sudah*. Senarai disusun ikut tarikh tempo dalam kumpulan gaji 15hb & 30hb.
- **Peringatan** 3 hari & 1 hari sebelum tempo (sekitar 8 pagi), untuk komitmen yang belum dibayar. Tekan notifikasi → Komitmen.
- Butang **Bayar** (tab Bayaran) terus pilih komitmen belum bayar yang paling awal jatuh tempo.
- **Ramalan** kini guna tarikh tempo: komitmen yang jatuh tempo sebelum gaji ditolak pada tarikhnya; yang jatuh tempo selepas gaji tapi dibayar guna gaji itu disenaraikan di bawah "guna gaji ini".
- Bil rumah dalam Firebase tidak dipadam; app Duitku Isteri masih boleh guna bil miliknya sendiri.

## Pembaikan: app beku bila tekan "Bayar & rekod dari poket" (bil)
Punca: bila helaian bawah (menu bil) bertukar terus ke borang transaksi skrin penuh, modifier `statusBarsPadding()` ditambah pada susun atur yang sama di dalam `BoxWithConstraints`. Compose terperangkap mengira ruang status bar / navigation bar berulang kali (`ExcludeInsets.equals` bersarang makin dalam), dan app beku. Laporan Jaga v2.0.9 tunjuk corak ini.
Baiki: helaian skrin penuh & helaian bawah kini dibina sebagai susun atur berasingan (`key(full)`), dan `BoxWithConstraints` diganti dengan pengukur ringan (`hadTinggi`). Laluan lain yang sama (cth menu poket → Belanja) juga terbaiki.
Nama kelas kini dikekalkan dalam APK (`-dontobfuscate`), jadi laporan Jaga seterusnya boleh dibaca terus.

## Penjaga app (system/Jaga.kt)
Kalau app tergantung lebih 5 saat atau tertutup sebab ralat, laporan ringkas disimpan. Bila app dibuka semula, jalur merah lembut di atas tunjuk **Salin laporan** — hantar teks itu kepada Claude untuk dibaiki dengan tepat.

## Kenapa OT kekal tab sendiri
OT dikira ikut kitaran **22hb–21hb**, manakala Poket, Transaksi, Bayaran dan Laporan ikut bulan biasa **1hb–hujung bulan**. Kalau OT digabung ke tab lain, dua jenis tempoh akan bercampur dalam satu skrin. Jadi OT kekal sebagai tab pertama (key in setiap hari), dinamakan semula daripada *Kerja* kepada **OT**. Nilai OT masih dipaparkan di jubin Poket dan dalam lejar Transaksi. Menekan "Isi OT" dari Transaksi membuka helaian papan nombor yang sama.

## Animasi gaya iPhone
- **Gerak.java** (Java): lengkung cubic-bezier UIKit, ease-out-back, lantunan, stagger dan rumus getah iOS. Dipanggil dari Kotlin/Compose.
- **Motion.kt**: `iosScroll` = fling licin (geseran rendah) + lantunan getah bila tarik melepasi atas/bawah; "stretch" Android dimatikan.
- Tukar tab **meluncur perlahan ikut arah** (tab di kanan masuk dari kanan, tab di kiri masuk dari kiri) + pudar; helaian naik dengan spring; butang kecut & melantun bila ditekan.
- **Kapsul tab bawah**: latar cyan lembut di belakang ikon tab aktif, meluncur dengan spring bila tukar tab; warna ikon bertukar beransur.
- **Ingat skrol setiap tab**: balik ke tab = kekal di tempat tadi. **Tekan tab yang sedang dibuka sekali lagi** → naik ke atas dengan licin (macam iPhone).
- **Butang Transaksi mengecil** jadi bulat (+) bila skrol ke bawah, kembang semula bila skrol ke atas atau sampai ke atas.
- **Tarik helaian ke bawah untuk tutup**: tarik pemegang di atas helaian; lepas melebihi ~120dp (atau leret laju) = tutup, kurang = melantun balik. Latar gelap pudar ikut tarikan.
- **Getaran sentuh ringan** (`rememberTick` dalam Motion.kt): tab bawah, Seg, tab jenis transaksi, suis, butang utama, grid kategori/poket, papan nombor, Simpan / Teruskan. Ikut tetapan *Getaran sentuh* telefon — matikan di situ kalau tak suka.
- Teks konteks bar atas bertukar dengan pudar + luncur; toast boleh ditekan untuk tutup; palang kemajuan & jumlah wang beranimasi dengan lengkung iOS.
- Pie: berpusing masuk, potongan pop satu-satu dengan lantunan, label pudar & meluncur masuk, potongan ditekan melantun keluar.

## Dibuang
**Clock in / clock out sepenuhnya**: butang check-in/out, geofence kilang, check-in automatik, amaran lupa check-in, cap jari/muka, mood, jurulatih disiplin, eksport CSV kehadiran. Izin lokasi, lokasi latar, biometrik dan penggera tepat dibuang dari manifest. Kali pertama app versi ini dibuka, geofence & penggera lama dibatalkan sendiri (`Cleanup` dalam `system/Notif.kt`). Data kehadiran lama kekal dalam fail salinan tetapi tidak dipakai lagi. Jadual shift kekal (untuk jenis hari lalai dalam log OT).

Pelan bertolak (cuaca Open-Meteo sepanjang laluan, trafik Google Routes / TomTom, notifikasi masa bertolak) dan lokasi rumah telah dibuang. Penggera dan kerja latar bertolak dari versi lama dibatalkan sendiri. Amaran lupa check-in dan check-in automatik (geofence kilang) kekal.

## Kongsi dengan isteri (Firebase)
App ini bersambung ke projek Firebase `duitku-isteri-1a996` yang sama dengan app **Duitku Isteri** (`app/google-services.json` mengandungi kedua-dua app).

| Ciri | Di mana |
|---|---|
| Barang dapur dikongsi: jadual No / Jenis barang / Unit / Harga / Jumlah, MyKasih diasingkan daripada bayar sendiri, tick → rekod belanja (MyKasih tidak direkod) | **Menu → Barang dapur** |
| **Hantar nafkah**: dicatat sebagai Keluar dari poket kau, isteri tekan *Terima* dalam app dia | **Bayaran → Komitmen** (bawah) |
| Sambung ke rumah isteri guna kod 6 aksara | **Tetapan → Kongsi dengan isteri** |

Poket, transaksi, OT dan kehadiran kau kekal dalam telefon kau sahaja. Peraturan Firestore: `firestore.rules` (sama untuk kedua-dua app).

## Dua app dari satu kod: Duitku (suami) & Duitku Isteri

| | Duitku (suami) | Duitku Isteri |
|---|---|---|
| Bina | `./gradlew assembleRelease` | `./gradlew assembleRelease -Papp=isteri` |
| Pakej | `com.asyraf.hadirku` | `com.asyraf.duitkuisteri` (sama seperti app isteri lama → update terus, data kekal) |
| APK dalam release | `Duitku-v2.0.N.apk` | `DuitkuIsteri-v2.0.N.apk` |
| OT, gaji, kitaran kerja | Ada | Tiada (menu OT & Ramalan gaji, tetapan Gaji & OT, OT dalam lejar/laporan/ramalan/fail CFO disorok) |
| Nafkah | Hantar | Terima → duit masuk ke Belum Agih (kad *Nafkah* di Utama, senarai di Bayaran → Komitmen) |
| Barang dapur | Dikongsi live | Dikongsi live |

- `BuildConfig.ISTERI` menentukan versi. Logik pengiraan sama; versi isteri hanya kosongkan tetapan gaji tersembunyi (`pg/Isteri.kt`) supaya ramalan tidak menjangka gaji yang tiada.
- Kali pertama app isteri baharu bersambung, bil kongsi dari app isteri lama (`rumah/{id}/bil`) dipindah sekali ke **Komitmen** (nama yang sudah ada dilangkau). Data Firebase lama tidak dipadam. Projek lama kekal dalam Firebase tetapi tidak dipaparkan.
- Fail CFO versi isteri (`PgCfo.Opts.rumahTangga`): tiada gaji/OT; duit masuk = nafkah & duit belanja.

## Live antara app suami & isteri (Firebase)

| Ciri | App suami (Duitku) | App isteri (Duitku Isteri) | Di mana |
|---|---|---|---|
| Duit dapur | **Hantar duit dapur** (keluar, kategori Barang dapur). Nampak guna & baki live. Baki yang isteri pulangkan → **Rekod** = duit dipulangkan (kurangkan belanja dapur). | **Terima** → duit masuk. Belanja kategori Barang dapur sejak terima dikira automatik (guna/baki live, jadi had troli). **Pulangkan baki** → keluar & tutup. | Bayaran → Komitmen; Barang dapur; notis di Utama |
| Minta duit | Notis di Utama → **Lulus** (rekod keluar & hantar) atau Tolak | **Minta duit**: jumlah, untuk keperluan / duit dapur, sebab | Bayaran → Komitmen; Utama |
| Nafkah bulanan | Tetapkan jumlah & tarikh. Notis di Utama bila sampai tarikh & belum hantar → **Hantar** | Ramalan baki menjangka nafkah ini (kecuali sudah diterima bulan itu) | Bayaran → Komitmen |
| Tabung bersama | Simpan / keluarkan = pindah ke poket tabung sendiri | Sama | Kewangan → Matlamat |

- Firestore: `rumah/{id}/nafkah` (medan baharu `jenis`, `minta`, `peminta`, `diterimaTarikh`, `guna`, `pulang`, `pulangTx`, `pulangDiterima`, `selesai` — dokumen lama kekal sah), `rumah/{id}/tetapan/nafkah`, `rumah/{id}/tabung`. Peraturan `firestore.rules` sedia ada sudah membenarkan (ahli rumah boleh baca/tulis semua koleksi rumah).
- Kiraan tanpa Firebase dalam `kongsi/KongsiData.kt` (`Rumahtangga.gunaDapur`, `bakiDapur`, `perluHantarNafkah`) dan `PgSettings.nafkahTetap` + `ForecastEngine` (ujian: `RumahtanggaTest`).
- Data contoh tidak dihantar ke pasangan. Poket & transaksi peribadi kekal dalam telefon masing-masing; yang dihantar hanya jumlah guna duit dapur dan baki poket tabung.
