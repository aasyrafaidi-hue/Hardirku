# Enjin Kewangan Duitku — Audit, Pelan & Status

Dokumen ini mengikut `POKETGAJI_CLAUDE_FULL_ENGINE_SPEC.md`. Bahagian 1–2 ditulis **sebelum** sebarang fail app diubah.

---

## 1. Audit projek (Fasa A)

**Sumber:** `aasyrafaidi-hue/Hardirku` → `HadirKu-LejarModen.zip` (commit `702abb0`, build #33 lulus, APK v2.0.33).

### 1.1 Binaan
| Perkara | Nilai |
|---|---|
| Gradle / AGP / Kotlin | wrapper 8.11.1, AGP 8.7.3, Kotlin 2.0.21, JDK 17 |
| SDK | compileSdk 35, minSdk 26, targetSdk 35 |
| UI | Jetpack Compose (BOM 2024.12.01), satu `MainActivity` + `HadirApp` |
| Pergantungan | AndroidX core/appcompat/activity/fragment/lifecycle, WorkManager 2.9.1, Play Services Location, Coroutines, Firebase Firestore + Auth |
| DI / DB | **Tiada DI framework, tiada Room/SQLite.** |
| Ujian | **Tiada** `src/test` / `src/androidTest`, tiada pergantungan ujian |
| Arahan build | `./gradlew assembleRelease` (GitHub Actions), R8 aktif (`-dontobfuscate`) |

### 1.2 Lapisan data (persistence)
- `data/Repo.kt` — singleton. Tiga fail JSON melalui `AtomicFile` dalam `filesDir`:
  `records.json` (kehadiran), `settings.json` (tetapan app), **`pg.json`** (semua data kewangan).
- Tetapan kecil dalam `SharedPreferences("hadirku")` (kunci AI, bendera notifikasi, dll.).
- `Repo.updatePg { }` — tulis semula seluruh `PgState` secara atomik (copy-on-write + `synchronized`).
- Salinan (backup) JSON & pulih: `Repo.backupJson()` / `parseBackup()` / `applyImport()`.
- Firestore hanya untuk data rumah tangga dikongsi (barang, nafkah, projek) — **bukan** data kewangan peribadi.

### 1.3 Model domain (`pg/PgModel.kt`, wang dalam `Double` RM)
`PgState { settings, pockets, transactions, commitments, debts, bankChecks, ot }`
- `Pocket` — sampul/poket; `dompet` = luar bank (e-wallet), `tunai` = tunai fizikal; `sasaran` = sasaran RM.
- `Tx.jenis`: `masuk`, `keluar`, `pindah`, `pelarasan+`, `pelarasan-`, `baki-awal`, `kad` (beli guna kad kredit), `tunai-kad` (pengeluaran tunai kad + `fee`).
  Pautan: `komitmenId`, `hutangId` (bayar hutang), `kadId`; `otBayar` (bahagian OT dalam gaji); `kategori`/`katAuto`; `dibuat` (epoch ms).
- `Commitment` — bil/komitmen bulanan, `kitaran` gaji 15/30, `tempo` (hari jatuh tempo 1–31, 29–31 → hari akhir bulan), `manual` (tanda sudah bayar per tempoh).
- `Debt` — `kad`/`pinjaman`/`bnpl`/`lain`, `kadar`, minimum (peratus/RM), `log` (`penyata`, `faedah`, `caj`, …), `epp: List<Epp>` (pokok, tempoh, kadar rata, ansuran, mula).
- `BankCheck` — baki bank sebenar untuk dibanding.

### 1.4 Logik kewangan sedia ada (`pg/PgCore.kt`, `object PG`, port core.js PoketGaji)
- Baki poket: `balances()`, `total()` (bank), `totalDompet()`, `totalTunai()` — kiraan `flows(tx)`.
- Komitmen: `commitmentPeriod`, `commitmentStatus` (sudah/separuh/belum), `tempoDate`.
- Hutang: `debtEvents` (baki hutang daripada log + transaksi + ansuran EPP dibil), `debtStatus`, minimum, `debtPlan`/`simulateDebts` (avalanche/snowball), `eppInfo`/`eppSchedule` (kaedah rata).
- OT: kitaran hari ke-22, `otSummary`, `otSettlements`.
- Laporan: `periodReport`, `trendPeriods`, `dailySummary`. Ramalan baki (`pg/Ramalan.kt`), kekayaan bersih (`pg/Kekayaan.kt`), eksport CFO (`pg/PgCfo.kt`).

### 1.5 Titik masuk UI (dibekukan — tidak disentuh)
Tab: Utama (`PoketScreen`), Transaksi/Lejar (`TransaksiScreen`), Bayaran (`BayaranScreen`: Ringkasan/Komitmen/Hutang/Projek), Laporan (`LaporanScreen`, `RamalanScreen`), Tetapan (`TetapanScreen`), OT (`KerjaScreen`/`OtSheet`), lembaran (`SheetTx`, `SheetsMoney`, `MenuSheets`). Semua tindakan melalui `MainViewModel` (`saveTx`, `delTx`, `payDebt`, `saveK`, `saveH`, `saveEpp`, …).

### 1.6 AI, notifikasi, latar
- `ai/Ai.kt` — Anthropic Messages API **terus dari telefon** dengan kunci yang pengguna isi sendiri (disimpan dalam SharedPreferences, tidak dalam APK, tidak masuk salinan). Imbas resit (`readReceipt`, skema `rekod_resit`), kategori automatik (`kategorikan`). Gambar sudah dikecilkan & dimampat dalam `MainViewModel` sebelum dihantar.
- `rumah/Peringatan.kt` — WorkManager harian ~8 pagi; notifikasi komitmen H-3 & H-1; **sudah ada dedup** melalui kunci `komitmen.notis.<id>.<tarikh>.<n>`.
- `system/Jaga.kt` — pengawas ANR/ranap.

---

## 2. Analisis jurang & pelan (sebelum ubah fail)

### 2.1 Keputusan seni bina
1. **Tiada perubahan UI, tiada perubahan `pg.json`.** Enjin baharu ialah modul Kotlin tulen dalam pakej `com.asyraf.hadirku.engine` yang **membaca** `PgState` melalui adapter. Data sedia ada kekal sumber rekod; tiada migrasi destruktif.
2. **Wang = `Long` sen** (`engine/core/Money`) dengan semakan limpahan (`Math.addExact`). `Double` RM hanya ditukar di sempadan adapter (`BigDecimal.valueOf(x).setScale(2, HALF_UP)`).
3. **Tarikh = `LocalDate` tempatan + zon `Asia/Kuala_Lumpur`; masa cipta = `Instant` UTC.** Polisi hari 29–31 dinyatakan jelas (`DueDayPolicy`).
4. **Tiada Room.** Spesifikasi kata "guna Room hanya jika sudah ada atau migrasi wajar". Data enjin baharu yang perlu disimpan (peraturan kategori, bajet, matlamat, log notifikasi, kunci idempotensi, log audit) masuk **fail berasingan `engine.json`** berversi, dengan backup sebelum migrasi. `pg.json` tidak pernah ditulis oleh enjin.
5. **Tiada DI framework** → `EngineHub` (fasad malas) mencipta enjin; antara muka boleh diganti dalam ujian.
6. **Ujian**: JUnit 4 dalam `app/src/test/java` (tambah `testImplementation("junit:junit:4.13.2")`). Enjin & ujian tidak guna `android.*`/`org.json` supaya boleh dijalankan pada JVM biasa.

### 2.2 Status kebolehlaksanaan setiap enjin

| # | Enjin | Boleh tanpa ubah UI? | Pelan |
|---|---|---|---|
| 0 | Lejar Transaksi | Ya (headless) | Domain akaun/catatan, adapter `PgState → Ledger`, pindahan berpasangan, pembalikan/refund, idempotensi, audit, semakan integriti, baki deterministik + ujian pariti dengan `PG.balances` |
| 1 | Resit AI | Sebahagian | Antara muka `ReceiptExtractionProvider`, skema JSON v1 ketat + provenans, semakan jumlah deterministik, pendua tepat/kabur, polisi simpan gambar. Adapter Claude/OpenAI **melalui backend** — *tiada backend wujud → dilumpuhkan*. Imbasan sedia ada (kunci dalam telefon) **tidak diubah**; disediakan pemeta hasil lama → draf baharu |
| 2 | Aliran Tunai | Ya (headless) | Sebenar/tertangguh/berjadual, boleh-belanja, baki akaun, ringkasan tempoh |
| 3 | Kategori Pintar | Ya (headless) | Override pengguna → peraturan → sejarah → kata kunci terbina → cadangan AI (pilihan); provenans; tiada ubah sejarah senyap; item vs transaksi |
| 4 | Bil & Komitmen | Ya (headless) | Jadual berulang, polisi hari 31, status bayar/separa, jadual peringatan, pendua |
| 5 | Hutang & EPP | Ya (headless) | Prinsipal, baki pembukaan, APR/rata, ansuran dibayar/baki, fi, selesai awal, bayaran separa, EPP separuh jalan |
| 6 | Ramalan | Ya (headless) | Harian/bulanan, gaji tetap vs OT tidak tetap (konservatif/asas/optimis), andaian dalam output |
| 7 | Risiko | Ya (headless) | Kod amaran + parameter (tiada teks baharu), ambang boleh tetap |
| 8 | Matlamat Simpanan | Ya (headless) | Sasaran/tarikh, sumbangan/pengeluaran sebagai *earmark*, kemajuan, sumbangan bulanan perlu, kebolehcapaian |
| 9 | Penyesuaian (CSV) | Ya (headless) | Parse CSV bank, normalisasi, padanan tepat/kabur, pendua, tiada gabung automatik |
| 10 | Bajet | Ya (headless) | Bajet kategori/tempoh, rancang vs sebenar, carryover, cadangan sahaja |
| 11 | Pembantu AI | Ya (headless) | Ringkasan bersih baca-sahaja + rujukan ID; jawapan deterministik; AI pilihan via backend |
| 12 | Notifikasi | Ya (headless) | Pencetus berpusat, dedup, kebenaran, waktu senyap, zon masa. **Notifikasi sedia ada tidak diubah** (teks baharu perlu kelulusan) |

### 2.3 Perkara yang memerlukan keputusan pemilik (tidak dibuat)
- Sebarang skrin/butang/teks baharu untuk memaparkan enjin (bajet, matlamat, import CSV, amaran risiko, pembantu).
- Backend selamat untuk AI (Claude/OpenAI) — URL, pengesahan, had kadar, kos.
- Menukar aliran simpan transaksi sedia ada supaya menulis melalui enjin lejar (akan mengubah tingkah laku; kekal headless buat masa ini).
