# Enjin Kewangan Duitku — Audit, Pelan & Status

Dokumen ini mengikut `POKETGAJI_CLAUDE_FULL_ENGINE_SPEC.md`. Bahagian 1–2 ditulis **sebelum** sebarang fail app diubah.

---

## 1. Audit projek (Fasa A)

**Sumber:** `aasyrafaidi-hue/Hardirku` → `HadirKu-LejarModen.zip` (commit `702abb0`, build #33 lulus, APK v2.0.33).

### 1.1 Binaan
| Perkara | Nilai |
|---|---|
| Gradle / AGP / Kotlin | wrapper 8.11.1, AGP 8.7.3, Kotlin 2.0.21, JDK 17 |
| SDK | compileSdk 35, minSdk 26, targetSdk 35 |
| UI | Jetpack Compose (BOM 2024.12.01), satu `MainActivity` + `HadirApp` |
| Pergantungan | AndroidX core/appcompat/activity/fragment/lifecycle, WorkManager 2.9.1, Play Services Location, Coroutines, Firebase Firestore + Auth |
| DI / DB | **Tiada DI framework, tiada Room/SQLite.** |
| Ujian | **Tiada** `src/test` / `src/androidTest`, tiada pergantungan ujian |
| Arahan build | `./gradlew assembleRelease` (GitHub Actions), R8 aktif (`-dontobfuscate`) |

### 1.2 Lapisan data (persistence)
- `data/Repo.kt` — singleton. Tiga fail JSON melalui `AtomicFile` dalam `filesDir`:
  `records.json` (kehadiran), `settings.json` (tetapan app), **`pg.json`** (semua data kewangan).
- Tetapan kecil dalam `SharedPreferences("hadirku")` (kunci AI, bendera notifikasi, dll.).
- `Repo.updatePg { }` — tulis semula seluruh `PgState` secara atomik (copy-on-write + `synchronized`).
- Salinan (backup) JSON & pulih: `Repo.backupJson()` / `parseBackup()` / `applyImport()`.
- Firestore hanya untuk data rumah tangga dikongsi (barang, nafkah, projek) — **bukan** data kewangan peribadi.

### 1.3 Model domain (`pg/PgModel.kt`, wang dalam `Double` RM)
`PgState { settings, pockets, transactions, commitments, debts, bankChecks, ot }`
- `Pocket` — sampul/poket; `dompet` = luar bank (e-wallet), `tunai` = tunai fizikal; `sasaran` = sasaran RM.
- `Tx.jenis`: `masuk`, `keluar`, `pindah`, `pelarasan+`, `pelarasan-`, `baki-awal`, `kad` (beli guna kad kredit), `tunai-kad` (pengeluaran tunai kad + `fee`).
  Pautan: `komitmenId`, `hutangId` (bayar hutang), `kadId`; `otBayar` (bahagian OT dalam gaji); `kategori`/`katAuto`; `dibuat` (epoch ms).
- `Commitment` — bil/komitmen bulanan, `kitaran` gaji 15/30, `tempo` (hari jatuh tempo 1–31, 29–31 → hari akhir bulan), `manual` (tanda sudah bayar per tempoh).
- `Debt` — `kad`/`pinjaman`/`bnpl`/`lain`, `kadar`, minimum (peratus/RM), `log` (`penyata`, `faedah`, `caj`, …), `epp: List<Epp>` (pokok, tempoh, kadar rata, ansuran, mula).
- `BankCheck` — baki bank sebenar untuk dibanding.

### 1.4 Logik kewangan sedia ada (`pg/PgCore.kt`, `object PG`, port core.js PoketGaji)
- Baki poket: `balances()`, `total()` (bank), `totalDompet()`, `totalTunai()` — kiraan `flows(tx)`.
- Komitmen: `commitmentPeriod`, `commitmentStatus` (sudah/separuh/belum), `tempoDate`.
- Hutang: `debtEvents` (baki hutang daripada log + transaksi + ansuran EPP dibil), `debtStatus`, minimum, `debtPlan`/`simulateDebts` (avalanche/snowball), `eppInfo`/`eppSchedule` (kaedah rata).
- OT: kitaran hari ke-22, `otSummary`, `otSettlements`.
- Laporan: `periodReport`, `trendPeriods`, `dailySummary`. Ramalan baki (`pg/Ramalan.kt`), kekayaan bersih (`pg/Kekayaan.kt`), eksport CFO (`pg/PgCfo.kt`).

### 1.5 Titik masuk UI (dibekukan — tidak disentuh)
Tab: Utama (`PoketScreen`), Transaksi/Lejar (`TransaksiScreen`), Bayaran (`BayaranScreen`: Ringkasan/Komitmen/Hutang/Projek), Laporan (`LaporanScreen`, `RamalanScreen`), Tetapan (`TetapanScreen`), OT (`KerjaScreen`/`OtSheet`), lembaran (`SheetTx`, `SheetsMoney`, `MenuSheets`). Semua tindakan melalui `MainViewModel` (`saveTx`, `delTx`, `payDebt`, `saveK`, `saveH`, `saveEpp`, …).

### 1.6 AI, notifikasi, latar
- `ai/Ai.kt` — Anthropic Messages API **terus dari telefon** dengan kunci yang pengguna isi sendiri (disimpan dalam SharedPreferences, tidak dalam APK, tidak masuk salinan). Imbas resit (`readReceipt`, skema `rekod_resit`), kategori automatik (`kategorikan`). Gambar sudah dikecilkan & dimampat dalam `MainViewModel` sebelum dihantar.
- `rumah/Peringatan.kt` — WorkManager harian ~8 pagi; notifikasi komitmen H-3 & H-1; **sudah ada dedup** melalui kunci `komitmen.notis.<id>.<tarikh>.<n>`.
- `system/Jaga.kt` — pengawas ANR/ranap.

---

## 2. Analisis jurang & pelan (sebelum ubah fail)

### 2.1 Keputusan seni bina
1. **Tiada perubahan UI, tiada perubahan `pg.json`.** Enjin baharu ialah modul Kotlin tulen dalam pakej `com.asyraf.hadirku.engine` yang **membaca** `PgState` melalui adapter. Data sedia ada kekal sumber rekod; tiada migrasi destruktif.
2. **Wang = `Long` sen** (`engine/core/Money`) dengan semakan limpahan (`Math.addExact`). `Double` RM hanya ditukar di sempadan adapter (`BigDecimal.valueOf(x).setScale(2, HALF_UP)`).
3. **Tarikh = `LocalDate` tempatan + zon `Asia/Kuala_Lumpur`; masa cipta = `Instant` UTC.** Polisi hari 29–31 dinyatakan jelas (`DueDayPolicy`).
4. **Tiada Room.** Spesifikasi kata "guna Room hanya jika sudah ada atau migrasi wajar". Data enjin baharu yang perlu disimpan (peraturan kategori, bajet, matlamat, log notifikasi, kunci idempotensi, log audit) masuk **fail berasingan `engine.json`** berversi, dengan backup sebelum migrasi. `pg.json` tidak pernah ditulis oleh enjin.
5. **Tiada DI framework** → `EngineHub` (fasad malas) mencipta enjin; antara muka boleh diganti dalam ujian.
6. **Ujian**: JUnit 4 dalam `app/src/test/java` (tambah `testImplementation("junit:junit:4.13.2")`). Enjin & ujian tidak guna `android.*`/`org.json` supaya boleh dijalankan pada JVM biasa.

### 2.2 Status kebolehlaksanaan setiap enjin

| # | Enjin | Boleh tanpa ubah UI? | Pelan |
|---|---|---|---|
| 0 | Lejar Transaksi | Ya (headless) | Domain akaun/catatan, adapter `PgState → Ledger`, pindahan berpasangan, pembalikan/refund, idempotensi, audit, semakan integriti, baki deterministik + ujian pariti dengan `PG.balances` |
| 1 | Resit AI | Sebahagian | Antara muka `ReceiptExtractionProvider`, skema JSON v1 ketat + provenans, semakan jumlah deterministik, pendua tepat/kabur, polisi simpan gambar. Adapter Claude/OpenAI **melalui backend** — *tiada backend wujud → dilumpuhkan*. Imbasan sedia ada (kunci dalam telefon) **tidak diubah**; disediakan pemeta hasil lama → draf baharu |
| 2 | Aliran Tunai | Ya (headless) | Sebenar/tertangguh/berjadual, boleh-belanja, baki akaun, ringkasan tempoh |
| 3 | Kategori Pintar | Ya (headless) | Override pengguna → peraturan → sejarah → kata kunci terbina → cadangan AI (pilihan); provenans; tiada ubah sejarah senyap; item vs transaksi |
| 4 | Bil & Komitmen | Ya (headless) | Jadual berulang, polisi hari 31, status bayar/separa, jadual peringatan, pendua |
| 5 | Hutang & EPP | Ya (headless) | Prinsipal, baki pembukaan, APR/rata, ansuran dibayar/baki, fi, selesai awal, bayaran separa, EPP separuh jalan |
| 6 | Ramalan | Ya (headless) | Harian/bulanan, gaji tetap vs OT tidak tetap (konservatif/asas/optimis), andaian dalam output |
| 7 | Risiko | Ya (headless) | Kod amaran + parameter (tiada teks baharu), ambang boleh tetap |
| 8 | Matlamat Simpanan | Ya (headless) | Sasaran/tarikh, sumbangan/pengeluaran sebagai *earmark*, kemajuan, sumbangan bulanan perlu, kebolehcapaian |
| 9 | Penyesuaian (CSV) | Ya (headless) | Parse CSV bank, normalisasi, padanan tepat/kabur, pendua, tiada gabung automatik |
| 10 | Bajet | Ya (headless) | Bajet kategori/tempoh, rancang vs sebenar, carryover, cadangan sahaja |
| 11 | Pembantu AI | Ya (headless) | Ringkasan bersih baca-sahaja + rujukan ID; jawapan deterministik; AI pilihan via backend |
| 12 | Notifikasi | Ya (headless) | Pencetus berpusat, dedup, kebenaran, waktu senyap, zon masa. **Notifikasi sedia ada tidak diubah** (teks baharu perlu kelulusan) |

### 2.3 Perkara yang memerlukan keputusan pemilik (tidak dibuat)
- Sebarang skrin/butang/teks baharu untuk memaparkan enjin (bajet, matlamat, import CSV, amaran risiko, pembantu).
- Backend selamat untuk AI (Claude/OpenAI) — URL, pengesahan, had kadar, kos.
- Menukar aliran simpan transaksi sedia ada supaya menulis melalui enjin lejar (akan mengubah tingkah laku; kekal headless buat masa ini).

---

## 3. Inventori enjin & status

Semua enjin dalam `app/src/main/java/com/asyraf/hadirku/engine/` (≈3,400 baris). **Tiada skrin, butang, teks, sumber atau navigasi diubah**; tiada kod sedia ada memanggil enjin (R8 membuang kelas yang tidak dipakai daripada APK release).

| # | Enjin | Fail | Status | Diuji |
|---|---|---|---|---|
| — | Wang & masa | `core/Money.kt`, `core/Time.kt`, `core/MiniJson.kt` | Siap | Ya |
| 0 | Lejar Transaksi | `ledger/Ledger.kt`, `ledger/PgLedgerAdapter.kt` | Siap (headless, projeksi baca-sahaja) | Ya, termasuk **pariti tepat ke sen** dengan `PG.balances` / `PG.debtBalance` / pokok EPP |
| 1 | Resit AI | `receipt/ReceiptModel.kt`, `receipt/ReceiptEngine.kt`, `receipt/ReceiptProviders.kt`, `android/EngineHub.kt` (`ReceiptImagePrep`) | Siap kecuali **backend AI** (tiada) → pembekal *Unavailable* | Ya (semakan, pendua, skema, pembekal palsu). `ReceiptImagePrep` hanya disemak kompil |
| 2 | Aliran Tunai | `cashflow/CashFlowEngine.kt` | Siap | Ya |
| 3 | Kategori Pintar | `category/CategoryEngine.kt` | Siap; cadangan AI hanya melalui cangkuk pilihan | Ya |
| 4 | Bil & Komitmen | `bills/BillEngine.kt` | Siap | Ya (pariti dengan `PG.commitmentStatus`) |
| 5 | Hutang & EPP | `debt/DebtEngine.kt` | Siap | Ya (pariti dengan `PG.eppInfo`) |
| 6 | Ramalan | `forecast/ForecastEngine.kt` | Siap | Ya |
| 7 | Risiko | `risk/RiskEngine.kt` | Siap (kod + parameter, tiada teks) | Ya |
| 8 | Matlamat Simpanan | `savings/SavingsEngine.kt` | Siap (earmark, bukan pergerakan duit) | Ya |
| 9 | Penyesuaian CSV | `reconcile/ReconciliationEngine.kt` | Siap (fail CSV sahaja, tiada sambungan bank) | Ya |
| 10 | Bajet | `budget/BudgetEngine.kt` | Siap (cadangan sahaja) | Ya |
| 11 | Pembantu AI | `assistant/AssistantEngine.kt` | Siap untuk soalan biasa (deterministik); soalan terbuka perlukan **backend** | Ya |
| 12 | Notifikasi | `notify/NotificationEngine.kt` | Siap (peristiwa + dedup); **tiada penghantar Android** kerana perlu teks baharu | Ya |
| — | Storan enjin | `store/EngineStore.kt` | Siap (`engine.json`) | Ya |
| — | Sambungan Android | `android/EngineHub.kt` | Siap, belum dipanggil oleh mana-mana skrin | Kompil sahaja |

### Peraturan utama yang dilaksanakan
- **Wang**: `Money(sen: Long)`, semakan limpahan, tiada `Double` dalam enjin. Pembahagian ansuran: baki sen ke ansuran terakhir.
- **Lejar**: setiap catatan bergerak *dari* satu akaun *ke* akaun lain; pindahan antara akaun sendiri tidak mengubah kekayaan bersih atau jumlah belanja; bayaran hutang ≠ belanja; faedah/fi = `CHARGE` yang boleh dikenal pasti; pembelian EPP tidak dikira belanja dua kali (pokok dipindah kad ← EPP); refund menolak kategori asal; pembalikan kekal untuk audit; kunci idempotensi menghalang import berganda; kelompok atomik.
- **Tarikh**: `LocalDate` tempatan + `Asia/Kuala_Lumpur`; `Instant` UTC untuk masa cipta; `DueDayPolicy` jelas untuk hari 29–31 (lalai = sama dengan app sedia ada: hari akhir bulan).
- **AI tidak pernah menentukan baki** — jumlah resit dikira semula dan percanggahan hanya *ditanda*.

## 4. Ujian & keputusan

Arahan Android Studio / Gradle: `./gradlew testDebugUnitTest` (laporan: `app/build/reports/tests/`).

| Fail ujian | Ujian | Merangkumi senario spec |
|---|---|---|
| `LedgerTest.kt` (`MoneyTest`, `LedgerTest`) | 13 | 1, 2, 6, 9 + atomik, peraturan, susunan |
| `AdapterTest.kt` | 5 | pariti data sedia ada, 3, 4, data tidak diubah |
| `PhaseCTest.kt` (bil, hutang, aliran tunai, simpanan, bajet) | 16 | 8, 4 |
| `PhaseDTest.kt` (ramalan, risiko, kategori, CSV, notifikasi, data contoh) | 12 | 10, 11 (kategori), 13 |
| `PhaseETest.kt` (resit, pembekal, pembantu) | 11 | 5, 6, 7, 11 |
| `StoreTest.kt` | 4 | 12 |
| **Jumlah** | **61** | 1–13 |

Keputusan sebenar dijalankan:
- **Workspace Claude** (JUnit 4.13.2, Kotlin 2.0.21, JVM 17): **61/61 lulus**.
- **GitHub Actions** (cabang `enjin-kewangan`): lihat bahagian 7.

Senario **14** (skrin sebelum/selepas sama) **tidak dapat diuji** — tiada emulator/peranti di sini. Ganti: `diff -r` antara projek asal dan projek baharu menunjukkan hanya 4 perbezaan: `app/build.gradle.kts` (+`testImplementation`), pakej baharu `engine/`, folder baharu `app/src/test/`, folder baharu `docs/`. Tiada fail di `ui/`, `res/`, `AndroidManifest.xml`, `MainViewModel.kt`, `pg/`, `data/` berubah.

## 5. Nota migrasi & data
- `pg.json` (data sedia ada) **tidak pernah ditulis** oleh enjin. Lejar ialah projeksi baca-sahaja; tiada migrasi skema untuk data sedia ada diperlukan.
- `engine.json` (baharu, `filesDir`): `version = 1`. Fail versi lebih lama → disalin ke `engine.json.bak-v<n>-<tarikh>` sebelum dimigrasi. Fail versi lebih baru → dibuka baca-sahaja, tidak ditulis ganti. Fail rosak → disalin ke `engine.json.bak-corrupt-<tarikh>`. Kunci yang tidak dikenali disimpan semula.
- *Rollback*: padam `engine.json` (enjin bermula kosong) atau pulihkan salah satu fail `.bak-*`. Data kewangan utama tidak terjejas.
- Salinan sandaran sedia ada (`Repo.backupJson`) **belum** merangkumi `engine.json` — perlu keputusan pemilik (mengubah format salinan).

## 6. Persediaan backend AI (belum wujud — perlu keputusan pemilik)
Kontrak penuh dalam `receipt/ReceiptProviders.kt`. Ringkas:
- `POST https://<backend>/v1/receipts/extract`, `Authorization: Bearer <token peranti>` (bukan kunci OpenAI/Anthropic), badan JSON `{vendor, schema_version: 1, mime, locale, request_id, image_base64}`, balasan = JSON skema v1.
- Backend menyimpan kunci pembekal, mengesahkan peranti, menghadkan kadar & kos, tidak menyimpan gambar kecuali ada persetujuan, dan memulangkan medan `null` bila tidak pasti.
- App: `BackendConfig(baseUrl, deviceToken)` — hanya `https://`. Tanpa konfigurasi → `Unavailable`; aliran manual & imbasan resit sedia ada tidak berubah.
- Pembantu: `AssistantProvider` menerima **hanya** `FinancialSnapshot.toProviderJson()` (tiada memo, nota, nama akaun, nombor akaun atau ID catatan).

## 7. Status binaan GitHub
Cabang `enjin-kewangan` dalam repo `Hardirku` (workflow dengan langkah `testDebugUnitTest` + `assembleRelease`; Release hanya dari `main`).
- **Run #34**: `testDebugUnitTest` ✅ (`compileDebugUnitTestKotlin` + `testDebugUnitTest` dijalankan), `assembleRelease` ✅, APK disimpan sebagai artifact (tiada Release dibuat).
- **Run #35**: ✅ semua langkah. Log ujian: **61 PASSED, 0 FAILED, 0 ujian dilangkau** (AdapterTest 5, AssistantTest 2, BillEngineTest 4, BudgetTest 2, CashFlowTest 2, CategoryTest 3, DebtEngineTest 5, ForecastTest 2, LedgerTest 8, MoneyTest 5, NotificationTest 2, ReceiptProviderTest 3, ReceiptTest 6, ReconciliationTest 2, RiskTest 2, SampleDataSmokeTest 1, SavingsTest 3, StoreTest 4). `assembleRelease` ✅ (APK v2.0.35 artifact, tandatangan kunci asal).
- Tidak diuji: kod `engine/android/` pada peranti sebenar (hanya dikompil), dan skrin (tiada emulator).

## 8. Keupayaan yang tersekat (perlu keputusan pemilik)
1. **Skrin/teks baharu** untuk memaparkan: bajet, matlamat simpanan, amaran risiko, laporan aliran tunai, import CSV, pembantu, semakan draf resit baharu.
2. **Backend AI** (Claude/OpenAI) untuk Enjin 1 & 11 — URL, pengesahan, kos.
3. **Notifikasi baharu** (bajet, risiko, matlamat): perlukan teks notifikasi yang diluluskan + penghantar Android (`NotificationSink`). Peringatan komitmen sedia ada tidak diubah.
4. **Menulis melalui lejar**: aliran simpan sedia ada (`MainViewModel.saveTx`, dll.) masih menulis `pg.json` terus. Menukarnya kepada lejar sebagai sumber rekod akan mengubah tingkah laku — tidak dibuat.
5. **Salinan sandaran** merangkumi `engine.json` (ubah format salinan).
6. **Ujian visual/skrin** — perlukan peranti/emulator (Android Studio: Compose Preview / screenshot test).

## 9. Fasa F — Enjin disambung ke UI (pemilik benarkan ubah UI)

| Tempat | Apa | Enjin |
|---|---|---|
| Utama | Kad **Boleh belanja sampai gaji** (≈ sehari, hari lagi) menggantikan kad ramalan ringkas lama; amaran WARNING/CAUTION | CashFlow, Savings, Risk |
| Utama → akses pantas | Butang **Kewangan** (ganti "Ramalan"; ramalan gaji lama kekal di Laporan → Ramalan) | — |
| Skrin baru **Pusat Kewangan** (`tab = "kewangan"`) | Belanja: cara dikira, item sebelum gaji, semua amaran, alat | CashFlow, Risk |
| | Ramalan: 3 senario + carta + jadual bulanan + andaian | Forecast |
| | Bajet: baris bulanan, lebih/baki, bawaan, cadangan (hanya bila tekan **Guna**) | Budget |
| | Matlamat: poket simpanan bersasaran (baca sahaja) + matlamat sendiri, asingkan/lepaskan | Savings |
| Helaian | Bajet, Matlamat, Asing/Lepas, **Semak penyata bank (CSV)**, **Tanya Duitku** | Budget, Savings, Reconciliation, Assistant |
| Borang transaksi | Kategori: sejarah → kamus pedagang Malaysia → AI | Category |
| Imbas resit | Amaran "mungkin sudah direkod" (tidak menghalang simpan) | Receipt |
| EPP | Anggaran langsai awal + faedah dijimatkan | Debt |
| Notifikasi | Saluran baru `kewangan`: bajet terlebih, amaran WARNING (sekali sebulan), matlamat 50%/100%; suis dalam Tetapan | Notification |
| Salinan data | Fail salinan kini ada blok `"enjin"` (bajet, matlamat, kunci import…). Fail lama tanpa blok → data enjin semasa dikekalkan; sebelum pulih, `engine.json.bak-sebelum-pulih-<tarikh>` disimpan | Store |

Lapisan baru `engine/app/AppFacade.kt` (tulen, tiada Android) menghimpun enjin untuk skrin dan mengandungi teks BM amaran/jawapan; diuji dalam `AppFacadeTest` (7 ujian). UI hanya melukis hasil fasad.

**Belum diuji pada telefon sebenar:** paparan Compose skrin baru (hanya dikompil di CI), pemilih fail CSV pada pelbagai bank, notifikasi kewangan harian. Format CSV bank Malaysia sebenar perlu dicuba oleh pemilik.

## 10. Duit dipulangkan (pulangan)

Borang **Masuk** ada pilihan *Pendapatan* / *Duit dipulangkan*. Pulangan wajib ada kategori belanja.

- Model: `Tx.pulangan = true` (JSON `"pulangan": true`). Data lama tanpa medan ini kekal duit masuk biasa; pulangan tanpa kategori sah dibaca sebagai Masuk biasa.
- Lejar: `REFUND` peringkat kategori (tanpa `refundOf`) ke poket — baki bertambah, belanja kategori berkurang, bukan pendapatan. `LedgerOps.validate` membenarkan REFUND tanpa pautan jika ada kategori.
- Laporan lama (`PG.periodReport`, baris harian): pulangan ditolak daripada keluar/belanja harian & kategori; tidak masuk `masuk`/pendapatan. `bersih` tidak berubah.
- Bajet, ramalan (belanja harian), amaran belanja luar biasa, Tanya Duitku dan semak penyata bank semua guna nilai bersih.
- Ujian: `PulanganTest` (6) — kes isteri RM250 → pulang RM100 → beli RM100: belanja dapur RM250, pendapatan RM0, penyata bank 3/3 sepadan.

## 11. Kad kredit: kaedah ansuran (0%, rata, baki berkurang, tetap)

Dilaksanakan ikut dokumen kajian "Kajian lejar kad kredit & EPP (RHB)".

- `Epp` + `kaedah` ("rata" lalai | "baki" | "tetap"), `kadarNominal`, `semak: List<EppSemak>`. JSON tulis medan baru hanya bila bukan lalai; rekod lama tidak berubah.
- `PG.eppInfo` kekal sumber tunggal: "baki" → jadual annuity berpaut pada penyata terkini (`eppKadarDariPenyata`, `eppJadualBaki`); "tetap" → pecahan tidak diketahui (`pokokTahu=false`, tiada CHARGE faedah).
- Masuk separuh jalan: "Ansuran ke berapa sekarang" + tarikh penyata → `eppMulaDariKe`.
- `DebtStat.jumlah` = baki kad + pokok EPP belum dibil (faedah akan datang bukan hutang); penggunaan had ikut nilai ini.
- UI: helaian kad dengan jadual (Hutang / Bulan ini / Ansuran bulanan), senarai ansuran berjadual, borang 4 jenis pelan dengan ringkasan jadual.
- Ujian: `EppKaedahTest` (12) guna data penyata RHB Nov 2026 — kadar 7.285% / 7.478%, baki pokok 2,707.02 / 1,447.18, jumlah portfolio 256.40 / 5,030.42 / 4,703.20.

## 12. Kelajuan, komitmen auto ke bulan depan & troli dapur

**Punca app berat (dijumpai & dibaiki)**

| Punca | Kesan | Pembaikan |
|---|---|---|
| `LedgerIntegrity.check` salin senarai entri untuk setiap entri (O(n²)) | Bina lejar 4,229 transaksi ambil ~192 ms, berulang setiap kali data berubah di Utama | Ulang tayang linear (`Replay`: HashMap id, set reversed, peta refund) — kini ~8 ms. `IntegrityEquivalenceTest` sahkan keputusan sama dengan algoritma lama |
| `AppFacade.summary` dikira dalam thread UI | Skrol tersekat bila buka Utama / Kewangan | `produceState` + `Dispatchers.Default`, cache ikut versi data (`CacheEnjin`); papar "Mengira…" sementara |
| `pg.json` ditulis serentak dalam thread UI setiap simpan | Tekan simpan terasa lambat bila data besar | Penulis latar satu-thread (`pg-simpan`), hanya keadaan terkini ditulis; `Repo.flushPg()` dalam `onStop` supaya data tidak hilang |

**Komitmen auto ke bulan depan**: `PG.commitmentViewDate` — bila semua komitmen tempoh semasa berstatus "sudah", paparan Ringkasan, Bil Bulanan dan tile Utama bertukar ke tempoh seterusnya (unjuran bulan depan). Bayaran awal (lebih daripada jumlah bulan lalu) dibawa ke bulan depan, jadi tidak dikira dua kali. Data tidak diubah — hanya tarikh paparan. Ujian: `KomitmenAlihTest`.

**Troli dapur ringkas**: skrin Barang Dapur kini troli untuk di kedai — "Ambil barang" terus masuk troli dengan harga, jumlah troli (duit sendiri) dibanding had (had sendiri dalam telefon, atau baki bajet kategori "dapur" bulan ini). Bar merah + "Melebihi had RM x" bila terlebih, dan borang tunjuk jumlah troli selepas barang itu sebelum disimpan. MyKasih kekal: dikira berasingan (boleh isi baki MyKasih), tidak masuk had dan tidak direkod sebagai belanja poket. Senarai "Belum ambil" (dirancang isteri) kekal dikongsi. "Selesai · rekod belanja" merekod satu transaksi keluar dengan kategori `dapur`. Ujian: `DapurTest.troliSelepasDanBakiHad`.

## 13. Barang dapur: isi guna AI & Enter ke medan seterusnya

- **Snap tanda harga** (borang Ambil barang): gambar tanda harga / barang → AI (`Ai.bacaBarang`, alat `barang_dapur`) isi nama, harga seunit, unit & MyKasih. Lebih satu barang (cth resit) → terus ke Isi pantas untuk disemak.
- **Isi pantas (AI)**: tulis atau sebut (mikrofon papan kekunci) senarai, atau snap / pilih gambar resit, tanda harga, senarai tulisan tangan. Hasil dipapar dahulu dengan kotak pilih, jumlah troli selepas ditambah dan baki had — tiada apa disimpan sebelum tekan "Tambah barang dipilih".
- Harga kosong diisi harga pembelian lepas (`Dapur.lengkapkan`) dan ditanda "harga lepas".
- Tanpa kunci AI atau tiada internet: teks dihurai di telefon (`Dapur.huraiTeks`, format "nama harga", "2 x 7.50", "7.50 x2", "mykasih"). Snap gambar perlukan kunci AI.
- **Enter**: Barang → Harga → Unit; Enter pada Unit = simpan dan sedia barang seterusnya (barang baru) atau simpan & tutup (ubah). `FieldText` kini terima `ime`/`onEnter` (lalai tidak berubah untuk borang lain).
- Ujian: `DapurTest.huraiTeksTanpaAi`, `cadangDibersihkan`, `lengkapkanHargaLepas`.
