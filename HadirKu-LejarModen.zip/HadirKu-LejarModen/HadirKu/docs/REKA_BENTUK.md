# Reka bentuk Duitku — Soft Violet

Ikut templat DuitkuIsteri (Soft Violet) dan pek ikon DuitkuIsteri. Logik kewangan, data dan sinkronisasi tidak berubah.

## Token
| Token | Cerah | Gelap | Guna |
|---|---|---|---|
| accent | #7840CE | #BB8EF3 | pautan, ikon aktif, tab |
| gradien utama | #B77AF0 → #7840CE | #9A66E4 → #6B3CC0 | butang utama, + tengah, tab aktif (`violetBrush`) |
| latar halaman | #FAF7FF → #EEE6FA | #1E1830 → #17122A | `pageBrush` |
| ink | #21183D | #F5EFFF | teks |
| masuk / keluar | #00865D / #C63A56 | #6FD3A8 / #F4909F | jumlah, jubin ikon |
| accentSoft | #EDE3FC | #3B2D5E | jubin ikon, kapsul tab |

Semua token dalam `ui/PgTheme.kt` (`LightPal`, `DarkPal`). Tiada kuning terang; warna amaran = oren-perang lembut (#B85B16).

## Fon
Inter (lesen OFL, `assets/lesen/Inter-OFL.txt`): 4 berat statik subset Latin dalam `res/font` (~220 KB). Glyph tiada (✔, emoji) guna fon sistem.

## Ikon
`ui/Ico.kt`: path SVG pek ikon (grid 24, garis 1.8, hujung bulat) dalam peta `PEK`; ikon tanpa padanan (OT, kalkulator, cap jari) kekal lukisan tangan dalam gaya sama. Jubin kategori ikut warna pek (`pekTint`): makanan/utiliti oren, dapur/percutian biru, masuk/kesihatan hijau, keluar/petrol merah jambu, lain ungu.

## Komponen
- Kad: bucu 20dp, bayang ungu lembut, garis tepi lavender (`lejarCard`).
- Butang utama: gradien ungu; butang biasa putih bergaris lavender.
- Tab segmen: kapsul putih lut, penunjuk gradien ungu, teks putih.
- Bar kemajuan: gradien ungu, 8dp.
- Kad kredit / SPayLater: kad gradien ungu (`KadVisual`).

## Skrin Utama
Ilustrasi senja ungu (`res/drawable-nodpi/hero_ungu.webp`, dari templat) di bawah bar status dengan menu, nama app, loceng dan sapaan; kad baki bertindih separuh di atas ilustrasi; 5 butang tindakan pantas berjubin.

## Navigasi
Bar bawah: Utama · Lejar · (+) · Bayaran · Lain-lain. Butang + tengah ikut skrin (Tambah / Key in OT / Ambil barang / Bayar). "Lain-lain" buka menu semua bahagian (Laporan, Kewangan, Barang Dapur, OT, Tetapan, …).

## Semakan visual
Workflow `tangkap-skrin` (cabang `reka-*`) bina APK, jalankan emulator Pixel 6 dengan data contoh dan simpan tangkapan skrin (cerah & gelap) ke cabang `skrin-reka`. Pautan terus tab untuk ujian: intent extra `buka=tab:<id>` atau `buka=menu`.
