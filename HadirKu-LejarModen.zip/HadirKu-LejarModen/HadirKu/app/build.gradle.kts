plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    // Firebase: kongsi senarai barang dapur & nafkah antara app suami (Duitku) dan isteri (Duitku Isteri)
    id("com.google.gms.google-services")
}

// Nombor versi naik automatik setiap kali GitHub Actions build (run number).
val buildNumber = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 1

// Satu kod sumber, dua app:
//   ./gradlew assembleRelease              → Duitku (suami)          com.asyraf.hadirku
//   ./gradlew assembleRelease -Papp=isteri → Duitku Isteri (isteri)  com.asyraf.duitkuisteri
// Versi isteri: tiada OT, gaji & kerja; kongsi barang dapur & nafkah dengan app suami melalui Firebase.
val appIsteri = (findProperty("app") as String?)?.trim()?.lowercase() == "isteri"

android {
    namespace = "com.asyraf.hadirku"
    compileSdk = 35

    defaultConfig {
        applicationId = if (appIsteri) "com.asyraf.duitkuisteri" else "com.asyraf.hadirku"
        minSdk = 26
        targetSdk = 35
        versionCode = buildNumber
        versionName = "2.0.$buildNumber"
        buildConfigField("boolean", "ISTERI", appIsteri.toString())
        manifestPlaceholders["appLabel"] = if (appIsteri) "Duitku Isteri" else "@string/app_name"
    }

    // Kunci tandatangan TETAP supaya APK baru boleh "update" atas APK lama tanpa padam data.
    // Simpan repo ni sebagai PRIVATE. Boleh override kata laluan melalui GitHub Secrets.
    signingConfigs {
        create("hadirku") {
            storeFile = file("hadirku-release.jks")
            storePassword = System.getenv("HADIRKU_STORE_PASSWORD") ?: "uiBPfaqLSl9D1qvDsBpf"
            keyAlias = "hadirku"
            keyPassword = System.getenv("HADIRKU_STORE_PASSWORD") ?: "uiBPfaqLSl9D1qvDsBpf"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("hadirku")
        }
        debug {
            signingConfig = signingConfigs.getByName("hadirku")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui-tooling-preview")
    debugImplementation("androidx.compose.ui:ui-tooling")

    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.fragment:fragment-ktx:1.8.5")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.7")
    implementation("androidx.work:work-runtime-ktx:2.9.1")
    implementation("com.google.android.gms:play-services-location:21.3.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // Kongsi dengan isteri (Firebase projek duitku-isteri)
    implementation(platform("com.google.firebase:firebase-bom:33.7.0"))
    implementation("com.google.firebase:firebase-firestore")
    implementation("com.google.firebase:firebase-auth")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.8.1")

    // Ujian unit enjin kewangan (JVM, tanpa Android): ./gradlew testDebugUnitTest
    testImplementation("junit:junit:4.13.2")
}

// Cetak setiap ujian unit dalam log build (supaya keputusan boleh disemak terus dari log GitHub Actions)
tasks.withType<Test>().configureEach {
    testLogging { events("passed", "skipped", "failed") }
}
