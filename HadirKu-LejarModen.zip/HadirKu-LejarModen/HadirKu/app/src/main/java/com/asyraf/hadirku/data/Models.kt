package com.asyraf.hadirku.data

import java.time.DayOfWeek
import java.time.LocalDate

/** Status rekod harian yang ditetapkan pengguna. */
enum class RecordStatus { HADIR, CUTI, MC }

/**
 * Satu rekod untuk satu "tarikh shift".
 * Untuk shift malam, tarikh ialah hari check-in walaupun check-out jatuh hari esok.
 * Masa disimpan sebagai epoch millis.
 */
data class DayRecord(
    val date: LocalDate,
    val checkIn: Long? = null,
    val checkOut: Long? = null,
    val status: RecordStatus = RecordStatus.HADIR,
    val method: String = "manual",
    val mood: Int = 0,
    val note: String = "",
)

/**
 * Tetapan kehadiran (HadirKu). Gaji, jam normal, had OT dan hari mula kitaran OT kini
 * disimpan dalam tetapan PoketGaji (satu sumber sahaja). Masa shift = minit dari tengah malam.
 */
data class AppSettings(
    val name: String = "",
    // Jadual shift berpusing
    val morningStart: Int = 7 * 60,
    val nightStart: Int = 19 * 60,
    val rotationAnchor: LocalDate = LocalDate.now().with(DayOfWeek.MONDAY),
    val weeksPerBlock: Int = 2,
    val workDays: Set<Int> = setOf(1, 2, 3, 4, 5), // DayOfWeek.value: 1 = Isnin ... 7 = Ahad
    val restDay: Int = 7,
    val graceMinutes: Int = 0,
    /** Jam di tempat kerja dibundarkan ke bawah (minit) sebelum masuk log OT. */
    val otRounding: Int = 30,
    /** Isi log OT PoketGaji terus daripada check-in / check-out. */
    val syncOt: Boolean = true,
    // Lokasi
    val workLat: Double? = null,
    val workLng: Double? = null,
    val workRadius: Int = 200,
    val autoCheckIn: Boolean = false,
    // Keselamatan & peringatan
    val useBiometric: Boolean = true,
    /** amaran kalau belum check-in selepas shift mula */
    val remindersOn: Boolean = true,
    // API pilihan (tidak dimasukkan dalam fail salinan)
    val calendarificKey: String = "",
    val stateName: String = "Penang",
    // Paparan: 0 ikut sistem, 1 cerah, 2 gelap, 3 gelap bila minggu shift malam
    val themeMode: Int = 0,
    val holidays: Set<LocalDate> = emptySet(),
    val trackingStart: LocalDate? = null,
) {
    val hasWorkLocation: Boolean get() = workLat != null && workLng != null
}

/** Nilai daripada tetapan HadirKu versi lama (sebelum digabung dengan PoketGaji). */
data class Legacy(
    val basicSalary: Double = 0.0,
    val cycleStartDay: Int = 0,
    val normalHours: Double = 0.0,
    val claudeKey: String = "",
    val claudeModel: String = "",
)
