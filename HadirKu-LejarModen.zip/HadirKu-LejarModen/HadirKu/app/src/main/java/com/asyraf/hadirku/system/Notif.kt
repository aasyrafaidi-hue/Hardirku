package com.asyraf.hadirku.system

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.asyraf.hadirku.data.Repo
import com.google.android.gms.location.LocationServices

object Notif {
    fun canPost(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    /** Saluran notifikasi kehadiran (check-in / geofence) telah dibuang. */
    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        listOf("peringatan", "lokasi").forEach { runCatching { nm.deleteNotificationChannel(it) } }
    }
}

/**
 * Bersihkan sisa fungsi clock in / clock out daripada versi lama (sekali sahaja):
 * geofence kilang, penggera "lupa check-in" dan notifikasi lama.
 */
object Cleanup {
    private const val KEY = "cleanup.hadir.v1"

    fun lama(ctx: Context) {
        if (Repo.getBool(KEY, false)) return
        try { LocationServices.getGeofencingClient(ctx).removeGeofences(listOf("kilang")) } catch (e: Exception) { }
        val am = ctx.getSystemService(AlarmManager::class.java)
        listOf(101 to "depart", 102 to "missed").forEach { (rc, type) ->
            try {
                val i = Intent().setComponent(ComponentName(ctx.packageName, "com.asyraf.hadirku.system.ReminderReceiver")).putExtra("type", type)
                val pi = PendingIntent.getBroadcast(ctx, rc, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_NO_CREATE)
                if (pi != null) { am?.cancel(pi); pi.cancel() }
            } catch (e: Exception) { }
        }
        val nmc = NotificationManagerCompat.from(ctx)
        listOf(1001, 1002, 1003, 1004).forEach { nmc.cancel(it) }
        Notif.createChannels(ctx)
        Repo.putBool(KEY, true)
    }
}
