package com.asyraf.hadirku.ui

import com.asyraf.hadirku.i18n.tr
import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.asyraf.hadirku.MainViewModel
import com.asyraf.hadirku.Sheet
import com.asyraf.hadirku.ai.Ai
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.Tx
import kotlinx.coroutines.launch
import org.json.JSONObject

/** Pilih isi helaian ikut jenis. */
@Composable
fun SheetContent(vm: MainViewModel, s: Sheet) {
    when (s) {
        is Sheet.TxForm -> TxFormSheet(vm, s)
        is Sheet.PocketMenu -> PocketMenuSheet(vm, s.id)
        is Sheet.PocketForm -> PocketFormSheet(vm, s.id)
        is Sheet.Bank -> BankSheet(vm)
        is Sheet.KMenu -> KMenuSheet(vm, s.id)
        is Sheet.KForm -> KFormSheet(vm, s.id)
        is Sheet.HMenu -> HMenuSheet(vm, s.id)
        is Sheet.HForm -> HFormSheet(vm, s.id)
        is Sheet.CardPay -> CardPaySheet(vm, s.id)
        is Sheet.EppList -> EppListSheet(vm, s.id)
        is Sheet.EppForm -> EppFormSheet(vm, s.debtId, s.planId)
        is Sheet.HLog -> HLogSheet(vm, s.id, s.jenis)
        is Sheet.HHist -> HHistSheet(vm, s.id)
        is Sheet.PlanForm -> PlanFormSheet(vm)
        is Sheet.OtDay -> OtDaySheet(vm, s.date)
        is Sheet.Tunai -> TunaiSheet(vm, s)
        is Sheet.Day -> DaySheet(vm, s.date)
        is Sheet.KatList -> KatListSheet(vm, s.k)
        is Sheet.PoketList -> PoketListSheet(vm, s.id)
        is Sheet.Cfo -> CfoSheet(vm)
        is Sheet.TextOut -> TextOutSheet(vm, s.title, s.text)
        is Sheet.Confirm -> ConfirmSheet(vm, s)
        is Sheet.BackupMenu -> BackupSheet(vm)
        is Sheet.ImportAsk -> ImportSheet(vm, s)
        is Sheet.KiraTunai -> KiraTunaiSheet(vm, s.id)
        is Sheet.BarangForm -> BarangFormSheet(vm, s.id, s.troli)
        is Sheet.DapurHad -> DapurHadSheet(vm)
        is Sheet.DapurAi -> DapurAiSheet(vm, s.awal, s.nota)
        is Sheet.Aset -> AsetSheet(vm, s.id)
        is Sheet.Menu -> MenuSheet(vm)
        is Sheet.Notis -> NotisSheet(vm)
        is Sheet.BajetForm -> BajetFormSheet(vm, s.id, s.kat)
        is Sheet.MatlamatForm -> MatlamatFormSheet(vm, s.id)
        is Sheet.MatlamatGerak -> MatlamatGerakSheet(vm, s.id)
        is Sheet.CsvSemak -> CsvSemakSheet(vm)
        is Sheet.Tanya -> TanyaSheet(vm)
    }
}

private fun legendFor(j: String) = when (j) {
    "kad" -> "Belanja untuk poket (bajet)"
    "masuk", "baki-awal", "pelarasan+" -> "Ke poket"
    else -> "Dari poket"
}

private fun numAi(v: Any?): Double = when (v) {
    is Number -> v.toDouble()
    is String -> v.replace(Regex("[^0-9.,\\-]"), "").replaceFirst(',', '.').toDoubleOrNull() ?: Double.NaN
    else -> Double.NaN
}

private fun okDate(s: String): Boolean = Regex("^\\d{4}-\\d{2}-\\d{2}$").matches(s) && runCatching { PG.addDays(s, 0) == s }.getOrDefault(false)

/** Paparan hasil imbasan resit. */
private class ScanView(
    val busy: Boolean = false,
    val thumb: Bitmap? = null,
    val pdf: Boolean = false,
    val title: String = "",
    val lines: List<String> = emptyList(),
    val warns: List<String> = emptyList(),
    val items: List<Pair<String, Double>> = emptyList(),
    val needKey: Boolean = false,
    val kadBtn: Boolean = false,
)

@Composable
private fun TxFormSheet(vm: MainViewModel, sh: Sheet.TxForm) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val la = launch()
    val scope = rememberCoroutineScope()
    val base = sh.base
    val isEdit = sh.editId != null
    val kads = s.debts.filter { it.jenis == "kad" }
    val jenisList = PG.JENIS.filter { it.id != "tunai-kad" && (it.id != "kad" || kads.isNotEmpty() || base.jenis == "kad") }
    var jenis by remember { mutableStateOf(base.jenis) }
    var tarikh by remember { mutableStateOf(base.tarikh.ifEmpty { vm.today() }) }
    var poket by remember { mutableStateOf(base.poket) }
    var ke by remember { mutableStateOf(base.ke) }
    var kadId by remember { mutableStateOf(if (base.jenis == "kad" && base.kadId.isEmpty() && kads.size == 1) kads[0].id else base.kadId) }
    var jumlah by remember { mutableStateOf(if (base.jumlah.isNaN()) "" else PG.toFixed(base.jumlah, 2)) }
    var perkara by remember { mutableStateOf(base.perkara) }
    var untuk by remember { mutableStateOf(if (base.komitmenId.isNotEmpty()) "k:" + base.komitmenId else if (base.hutangId.isNotEmpty()) "h:" + base.hutangId else "") }
    var catatan by remember { mutableStateOf(base.catatan) }
    var otRaw by remember { mutableStateOf(base.otBayar?.let { PG.toFixed(it, 2) } ?: "") }
    var kat by remember { mutableStateOf(if (PG.katValid(base.kategori)) base.kategori ?: "" else "") }
    var katSrc by remember { mutableStateOf(if (PG.katValid(base.kategori)) (if (base.katAuto) "ai" else "user") else "") }
    var pulangan by remember { mutableStateOf(base.jenis == "masuk" && base.pulangan) }
    var err by remember { mutableStateOf("") }
    var scan by remember { mutableStateOf<ScanView?>(null) }
    var marks by remember { mutableStateOf(setOf<String>()) }

    val hist = remember(s) { PG.kategoriSejarah(s) }
    val pulangOn = jenis == "masuk" && pulangan
    val auto = !pulangOn && (katSrc == "" || katSrc == "sejarah")
    val effKat = if (auto) hist[PG.normNama(perkara)] ?: "" else kat
    val effSrc = if (auto) (if (effKat.isNotEmpty()) "sejarah" else "") else katSrc
    val untukHutang = jenis == "keluar" && untuk.startsWith("h:")
    val katShown = jenis == "kad" || (jenis == "keluar" && !untukHutang) || pulangOn
    val otShown = jenis == "masuk" && !pulangan && akruanOn(s)
    val dompet = s.pockets.filter { it.dompet }.map { it.id }.toSet()
    fun unmark(k: String) { if (k in marks) marks = marks - k }

    /* isi borang daripada jawapan AI */
    fun applyScan(d: JSONObject, thumb: Bitmap?, pdf: Boolean, usd: Double, secs: String) {
        if (d.has("boleh_baca") && !d.optBoolean("boleh_baca", true)) {
            scan = ScanView(thumb = thumb, pdf = pdf, title = "Tak dapat baca resit", warns = listOf(d.optString("nota").ifEmpty { "Gambar ini bukan resit atau terlalu kabur. Cuba ambil gambar semula dengan cahaya terang." }))
            return
        }
        val notes = ArrayList<String>()
        val mk = HashSet(marks)
        if (jenis != "keluar" && jenis != "kad") jenis = "keluar"
        val amt = numAi(d.opt("jumlah"))
        if (amt.isFinite() && amt > 0) { jumlah = PG.toFixed(Math.round(amt * 100) / 100.0, 2); mk.add("jumlah") } else notes.add("Jumlah tak dapat dibaca. Isi sendiri.")
        val tg = d.optString("tarikh").trim()
        val today = vm.today()
        if (okDate(tg) && tg <= today && tg >= PG.addDays(today, -366)) { tarikh = tg; mk.add("tarikh") }
        else if (tg.isNotEmpty()) notes.add("Tarikh dibaca ($tg) nampak pelik, jadi tarikh hari ini digunakan. Semak.")
        val kedai = d.optString("kedai").trim().take(80)
        if (kedai.isNotEmpty()) { perkara = kedai; mk.add("perkara") }
        val ring = d.optString("ringkasan").trim().take(120)
        if (ring.isNotEmpty()) { catatan = ring; mk.add("catatan") }
        val hk0 = Ai.kedaiPoket(s)[PG.normNama(kedai)]
        val bayar = d.optString("cara_bayar").ifEmpty { "tak_pasti" }
        val dwl = s.pockets.filter { it.dompet && !it.tunai }
        val tnl = s.pockets.filter { it.tunai }
        var pid = ""
        var dari = ""
        if (bayar == "ewallet" && dwl.isNotEmpty()) { pid = if (hk0 != null && dwl.any { it.id == hk0.poket }) hk0.poket else dwl[0].id; dari = "ewallet" }
        else if (bayar == "tunai" && tnl.isNotEmpty()) { pid = if (hk0 != null && tnl.any { it.id == hk0.poket }) hk0.poket else tnl[0].id; dari = "tunai" }
        else if (hk0 != null && s.pockets.any { it.id == hk0.poket } && (hk0.poket !in dompet || bayar == "tak_pasti" || bayar == "lain")) { pid = hk0.poket; dari = "sejarah" }
        else { val pAi = s.pockets.find { it.nama.equals(d.optString("poket"), ignoreCase = true) }; if (pAi != null) { pid = pAi.id; dari = "ai" } }
        if (pid.isNotEmpty()) { poket = pid; mk.add("poket") }
        var kk = ""
        var kd = ""
        if (katSrc != "user") {
            val hk = hist[PG.normNama(kedai)]
            if (hk != null) { kk = hk; kd = "sejarah" } else if (PG.katValid(d.optString("kategori"))) { kk = d.optString("kategori"); kd = "ai" }
            if (kk.isNotEmpty()) { kat = kk; katSrc = kd; mk.add("kat") }
        }
        val yakin = d.optString("keyakinan").ifEmpty { "sederhana" }
        // enjin resit: amaran jika belanja sama (jumlah & tarikh ±1 hari, kedai sama) sudah ada dalam lejar — tidak menghalang simpan
        val dupN = resitBerganda(s, d.toString(), vm.today(), sh.editId)
        if (dupN > 0) notes.add(0, "Mungkin sudah direkod: ada belanja sama jumlah dan kedai pada tarikh hampir sama. Semak Lejar sebelum simpan.")
        if (yakin == "rendah") notes.add("Keyakinan rendah: semak semua maklumat dengan teliti.")
        if (d.optString("nota").isNotEmpty() && yakin != "tinggi") notes.add(d.optString("nota").take(200))
        val items = ArrayList<Pair<String, Double>>()
        val arr = d.optJSONArray("item")
        if (arr != null) for (i in 0 until minOf(arr.length(), 15)) {
            val it = arr.optJSONObject(i) ?: continue
            val v = numAi(it.opt("jumlah"))
            if (it.optString("nama").isNotEmpty() && v.isFinite()) items.add(it.optString("nama").take(60) to v)
        }
        marks = mk
        val lines = ArrayList<String>()
        lines.add("Dibaca AI · keyakinan " + yakin + " · " + secs + " s" + if (usd > 0) " · ~US$" + String.format(java.util.Locale.US, "%.4f", usd) else "")
        if (kk.isNotEmpty()) lines.add("Kategori: " + PG.katLabel(kk) + if (kd == "sejarah") " (ikut rekod lepas)" else "")
        lines.add((if (dari == "sejarah") "Poket ikut pilihan awak sebelum ini. " else if (dari == "ewallet") "Poket e-wallet sebab resit dibayar guna e-wallet. " else if (dari == "tunai") "Dompet tunai sebab resit dibayar tunai. " else "") + "Semak jumlah, tarikh dan poket sebelum simpan.")
        scan = ScanView(
            thumb = thumb, pdf = pdf, title = kedai.ifEmpty { "Resit" } + if (amt.isFinite() && amt > 0) " · " + M(amt) else "",
            lines = lines, warns = notes, items = items, kadBtn = bayar == "kad_kredit" && kads.isNotEmpty() && jenis != "kad",
        )
    }

    fun startScan(uri: android.net.Uri) {
        if (scan?.busy == true) return
        scan = ScanView(busy = true, title = "Membaca resit…", lines = listOf("Biasanya beberapa saat."))
        val t0 = System.currentTimeMillis()
        scope.launch {
            try {
                val prep = vm.prepFile(uri)
                scan = ScanView(busy = true, thumb = prep.thumb, pdf = prep.pdf, title = "Membaca resit…", lines = listOf("Biasanya beberapa saat."))
                val out = Ai.readReceipt(vm.pg.value, prep.block, prep.pdf, vm.today())
                applyScan(out.data, prep.thumb, prep.pdf, out.usd, PG.toFixed((System.currentTimeMillis() - t0) / 1000.0, 1))
            } catch (e: Exception) {
                val msg = e.message ?: "Ralat tidak diketahui."
                scan = ScanView(thumb = scan?.thumb, pdf = scan?.pdf ?: false, title = "Tak dapat baca resit", warns = listOf(msg), needKey = Regex("kunci api", RegexOption.IGNORE_CASE).containsMatchIn(msg))
            }
        }
    }

    /* ---------- aliran medan: Enter / pilih → medan seterusnya ---------- */
    val ctx = LocalContext.current
    val focus = LocalFocusManager.current
    val kb = LocalSoftwareKeyboardController.current
    val frPerkara = remember { FocusRequester() }
    val frOt = remember { FocusRequester() }
    val frCatatan = remember { FocusRequester() }
    // jumlah kosong → papan nombor; jumlah dah ada tapi poket belum → terus pilih poket
    var panel by remember {
        mutableStateOf(
            if (!isEdit && jumlah.isEmpty()) "jumlah"
            else if (!isEdit && poket.isEmpty() && (jenis == "keluar" || jenis == "masuk" || jenis == "pindah")) "poket"
            else "",
        )
    }
    var typing by remember { mutableStateOf("") }
    var fresh by remember { mutableStateOf(true) }
    var calc by remember { mutableStateOf(false) }
    val jc = when (jenis) { "keluar", "pelarasan-", "kad" -> pal.out; "masuk", "pelarasan+", "baki-awal" -> pal.inn; else -> pal.accent }
    val untukShown = jenis == "keluar" && (s.commitments.isNotEmpty() || s.debts.isNotEmpty())

    fun flow(): List<String> = buildList {
        add("jumlah")
        if (jenis == "kad") add("kad")
        if (katShown) add("kat")
        add("poket")
        if (jenis == "pindah") add("ke")
        add("perkara")
        if (otShown) add("ot")
        add("catatan")
    }
    fun openField(f: String?) {
        when (f) {
            null -> { panel = ""; focus.clearFocus(); kb?.hide() }
            "perkara" -> { panel = ""; runCatching { frPerkara.requestFocus() } }
            "ot" -> { panel = ""; runCatching { frOt.requestFocus() } }
            "catatan" -> { panel = ""; runCatching { frCatatan.requestFocus() } }
            else -> { focus.clearFocus(); kb?.hide(); if (f == "jumlah") fresh = true; panel = f }
        }
    }
    fun goNext(from: String) { val o = flow(); openField(o.getOrNull(o.indexOf(from) + 1)) }

    fun amtStr(): String = evalExpr(jumlah)?.let { PG.toFixed(it, 2) } ?: jumlah
    fun doSave(): String {
        val j = amtStr()
        jumlah = j
        val e = vm.saveTx(sh.editId, MainViewModel.TxInput(
            jenis, tarikh, poket, ke, kadId, j, perkara, untuk, catatan, otShown, otRaw, katShown, effKat, effSrc,
            pulangan = pulangOn,
        ))
        err = e
        return e
    }
    fun saveCont() {
        val j = jenis; val t = tarikh; val p = poket; val k = kadId
        if (doSave().isEmpty()) vm.newTx(Tx(jenis = j, tarikh = t, poket = p, kadId = if (j == "kad") k else ""))
    }
    fun key(k0: String) {
        var k = k0
        if (k == "C") { jumlah = ""; fresh = false; unmark("jumlah"); return }
        if (k == "=") { evalExpr(jumlah)?.let { jumlah = PG.toFixed(it, 2) }; fresh = true; unmark("jumlah"); return }
        var cur = if (fresh && (k[0].isDigit() || k == ".")) "" else jumlah
        fresh = false
        val lastNum = cur.split('+', '−', '×', '÷').last()
        when (k) {
            "⌫" -> cur = cur.dropLast(1)
            "+", "−", "×", "÷" -> {
                if (cur.isEmpty()) return
                if (cur.last() in CALC_OPS) cur = cur.dropLast(1)
                cur += k
            }
            "." -> if (!lastNum.contains('.')) cur += if (lastNum.isEmpty()) "0." else "."
            else -> {
                if (lastNum.isEmpty() && k == "00") k = "0"
                when {
                    lastNum.contains('.') && lastNum.substringAfter('.').length + k.length > 2 -> {}
                    lastNum == "0" -> cur = cur.dropLast(1) + (if (k == "00") "0" else k)
                    else -> cur += k
                }
            }
        }
        if (cur.length <= 24) jumlah = cur
        unmark("jumlah")
    }
    val active = if (panel.isNotEmpty()) panel else typing

    BackHandler(enabled = panel.isNotEmpty()) { panel = "" }

    Column(Modifier.fillMaxSize()) {
        // ---------- bar atas ----------
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(48.dp).pressable({ vm.close() }, scaleTo = 0.85f), contentAlignment = Alignment.Center) { Txt("←", size = 24f) }
            Txt(sh.title ?: if (isEdit) "Edit " + jenisLabel(jenis).lowercase() else jenisLabel(jenis), Modifier.weight(1f), size = 20f, weight = FontWeight.SemiBold, maxLines = 1)
        }
        Column(Modifier.weight(1f).iosScroll(rememberScrollState())) {
            // ---------- jenis ----------
            val main = listOf("masuk", "keluar", "pindah").filter { id -> jenisList.any { it.id == id } }
            val more = jenisList.filter { it.id !in main }
            var moreOpen by remember { mutableStateOf(false) }
            fun pickJenis(j: String) {
                jenis = j
                if (j == "kad" && kadId.isEmpty() && kads.size == 1) kadId = kads[0].id
                if (j == "kad" && poket in dompet) poket = ""
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = GL, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                main.forEach { id ->
                    JBox(jenisLabel(id), id == jenis, colorFor(id, pal), Modifier.weight(1f)) { pickJenis(id) }
                }
                if (more.isNotEmpty()) Box(Modifier.weight(if (jenis in main) 0.8f else 1.3f)) {
                    val on = jenis !in main
                    JBox(if (on) jenisLabel(jenis) + " ▾" else "Lain ▾", on, colorFor(jenis, pal), Modifier.fillMaxWidth()) { moreOpen = true }
                    DropdownMenu(expanded = moreOpen, onDismissRequest = { moreOpen = false }) {
                        more.forEach { o ->
                            DropdownMenuItem(text = { Txt(o.label, size = 15f, weight = if (o.id == jenis) FontWeight.SemiBold else FontWeight.Normal) }, onClick = { moreOpen = false; pickJenis(o.id) })
                        }
                    }
                }
            }
            // ---------- baris medan ----------
            EntryRow("Tarikh", false, jc, "tarikh" in marks, {
                openField(null)
                val p = runCatching { PG.parse(tarikh) }.getOrNull() ?: PG.parse(vm.today())
                android.app.DatePickerDialog(ctx, { _, y, m, d -> tarikh = PG.iso(y, m + 1, d); unmark("tarikh") }, p.y, p.m - 1, p.d).show()
            }) {
                val p = runCatching { PG.parse(tarikh) }.getOrNull()
                Txt(if (p != null) PG.pad(p.d) + "/" + PG.pad(p.m) + "/" + p.y + " (" + PG.HARI[PG.weekday(tarikh)] + ")" else tarikh, size = 16f, num = true)
            }
            EntryRow("Jumlah", active == "jumlah", jc, "jumlah" in marks, { openField("jumlah") }) {
                val hasOp = jumlah.any { it in CALC_OPS }
                val prev = if (hasOp) evalExpr(jumlah) else null
                Column {
                    Txt(if (jumlah.isEmpty()) "" else if (hasOp) jumlah else "RM " + jumlah, size = 20f, weight = FontWeight.SemiBold, num = true, maxLines = 1,
                        color = if (active == "jumlah" && fresh && jumlah.isNotEmpty()) pal.muted else pal.ink)
                    if (prev != null) Txt("= RM " + PG.toFixed(prev, 2), size = 13.5f, color = pal.muted, num = true, maxLines = 1)
                }
            }
            if (jenis == "masuk") {
                Box(Modifier.fillMaxWidth().padding(horizontal = GL).padding(top = 10.dp, bottom = 2.dp)) {
                    Chips(listOf("pend" to "Pendapatan", "pulang" to "Duit dipulangkan"), if (pulangan) "pulang" else "pend", { v -> pulangan = v == "pulang" })
                }
                if (pulangan) RowNote(rich("Bukan pendapatan. Belanja kategori yang dipilih akan **dikurangkan** — contoh: isteri pulangkan duit dapur, refund kedai, kawan bayar balik."))
            }
            if (jenis == "kad") {
                val kd = kads.find { it.id == kadId }
                EntryRow("Kad", active == "kad", jc, false, { openField("kad") }) { Txt(kd?.nama ?: "", size = 16f, maxLines = 1) }
                if (kd != null) RowNote(rich("Duit belum keluar dari bank. Baki " + kd.nama + " bertambah, dan jumlah ini dipindah ke poket **" + pname(s, kd.poket) + "**."))
            }
            if (katShown) {
                EntryRow("Kategori", active == "kat", jc, "kat" in marks, { openField("kat") }) {
                    if (effKat.isNotEmpty()) Txt(katEmoji(effKat) + "  " + PG.katLabel(effKat), size = 16f, maxLines = 1)
                    else Txt(if (pulangOn) "Pilih kategori yang dipulangkan" else if (Ai.ready() && Ai.autoKat()) "Auto (AI pilih selepas simpan)" else "", size = 15f, color = pal.muted, maxLines = 1)
                }
                if (effSrc == "sejarah" && effKat.isNotEmpty()) RowNote(rich("Ikut rekod lepas dengan nama sama."))
                else if (effSrc == "ai") RowNote(rich("Dipilih AI. Tukar jika salah."))
            }
            val nota = aliranNota(s, jenis, poket, ke)
            EntryRow(if (jenis == "pindah") "Dari poket" else legendFor(jenis).let { if (it == "Ke poket") "Ke poket" else "Poket" }, active == "poket", jc, "poket" in marks, { openField("poket") }) {
                Txt(if (poket.isEmpty()) "" else pname(s, poket), size = 16f, maxLines = 1)
            }
            if (jenis == "pindah") EntryRow("Ke poket", active == "ke", jc, false, { openField("ke") }) {
                Txt(if (ke.isEmpty()) "" else pname(s, ke), size = 16f, maxLines = 1)
            }
            if (nota != null) RowNote(AnnotatedString(tr(nota)))
            EntryRow("Perkara", active == "perkara", jc, "perkara" in marks, { openField("perkara") }) {
                InlineField(perkara, { if (it.length <= 80) { perkara = it; unmark("perkara") } }, "cth: Barang dapur", frPerkara, ImeAction.Next,
                    onFocus = { f -> if (f) { panel = ""; typing = "perkara" } else if (typing == "perkara") typing = "" }) { goNext("perkara") }
            }
            if (untukShown) {
                val lbl = when {
                    untuk.startsWith("k:") -> s.commitments.find { it.id == untuk.substring(2) }?.nama ?: ""
                    untuk.startsWith("h:") -> s.debts.find { it.id == untuk.substring(2) }?.nama ?: ""
                    else -> ""
                }
                EntryRow("Bayaran untuk", active == "untuk", jc, false, { openField("untuk") }) {
                    Txt(lbl.ifEmpty { "Tiada" }, size = 16f, color = if (lbl.isEmpty()) pal.muted else pal.ink, maxLines = 1)
                }
            }
            if (otShown) {
                val info = remember(s, tarikh, perkara, jumlah, sh.editId) {
                    PG.otAutoFor(s, Tx(id = sh.editId ?: "", jenis = "masuk", tarikh = tarikh, perkara = perkara, jumlah = vm.parseAmt(amtStr())))
                }
                EntryRow("Termasuk OT", active == "ot", jc, false, { openField("ot") }) {
                    InlineField(otRaw, { otRaw = it }, if (info != null && info.auto > 0) "Auto " + PG.toFixed(info.auto, 2) else "0.00", frOt, ImeAction.Next, KeyboardType.Decimal,
                        onFocus = { f -> if (f) { panel = ""; typing = "ot" } else if (typing == "ot") typing = "" }) { goNext("ot") }
                }
                val note = if (info == null) "" else {
                    val cyc = PG.fmtShort(info.cycle.start) + " – " + PG.fmtShort(info.cycle.end)
                    val sudah = info.sudah
                    when {
                        otRaw.trim().isNotEmpty() -> "Bahagian OT ini tak dikira pendapatan lagi kerana OT sudah dikira ikut kitaran OT. Kosongkan untuk kiraan auto."
                        info.auto > 0 -> "Auto: gaji ini termasuk OT $cyc (" + M(info.nilai) + "). Isi 0 kalau gaji ini tiada OT."
                        info.gaji && sudah != null -> "OT $cyc sudah ditolak dalam duit masuk " + PG.fmtDate(sudah.tarikh) + "."
                        info.gaji -> "Tiada OT direkod untuk $cyc."
                        else -> "Isi kalau duit masuk ini termasuk bayaran OT, contohnya gaji."
                    }
                }
                if (note.isNotEmpty()) RowNote(AnnotatedString(tr(note)))
            }

            // ---------- catatan + imbas resit ----------
            Spacer(Modifier.height(10.dp))
            Box(Modifier.fillMaxWidth().height(8.dp).background(pal.bg))
            val canScan = !isEdit && (jenis == "keluar" || jenis == "kad")
            Row(Modifier.fillMaxWidth().padding(horizontal = GL).padding(top = 8.dp).hairlines(if (active == "catatan") jc else pal.line), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) {
                    InlineField(catatan, { if (it.length <= 120) { catatan = it; unmark("catatan") } }, "Catatan", frCatatan, ImeAction.Done,
                        onFocus = { f -> if (f) { panel = ""; typing = "catatan" } else if (typing == "catatan") typing = "" }) { focus.clearFocus(); kb?.hide() }
                }
                if ("catatan" in marks) AiTag()
                if (canScan) {
                    fun needKey() { scan = ScanView(title = "Perlu kunci API dulu", lines = listOf("Imbas resit guna AI Claude dengan kunci API awak sendiri (anggaran kurang 1 sen setiap imbasan)."), needKey = true) }
                    Txt("Galeri", Modifier.clickable { if (!Ai.ready()) needKey() else la.pickScan { startScan(it) } }.padding(horizontal = 8.dp, vertical = 10.dp), size = 13f, weight = FontWeight.SemiBold, color = pal.accentStrong)
                    Box(Modifier.size(44.dp).pressable({ if (!Ai.ready()) needKey() else la.takePhoto { startScan(it) } }, scaleTo = 0.85f), contentAlignment = Alignment.Center) {
                        Ico(Ic.CAMERA, pal.muted, 24.dp, stroke = 1.7f)
                    }
                }
            }
            val sv = scan
            if (canScan && sv != null) {
                Spacer(Modifier.height(8.dp))
                ScanBox(vm, sv) {
                    jenis = "kad"
                    if (kadId.isEmpty() && kads.size == 1) kadId = kads[0].id
                    if (poket in dompet) poket = ""
                    scan = ScanView(sv.busy, sv.thumb, sv.pdf, sv.title, sv.lines, sv.warns, sv.items, sv.needKey, false)
                }
            }
            Box(Modifier.padding(horizontal = GL)) { FormError(err) }

            // ---------- butang ----------
            Row(Modifier.fillMaxWidth().padding(horizontal = GL, vertical = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                val shape = RoundedCornerShape(8.dp)
                Box(
                    Modifier.weight(if (isEdit) 1f else 1.8f).height(52.dp).background(jc, shape).pressable({ doSave() }, scaleTo = 0.96f, haptic = true),
                    contentAlignment = Alignment.Center,
                ) { Txt("Simpan", size = 16f, weight = FontWeight.SemiBold, color = inkOn(jc)) }
                if (!isEdit) Box(
                    Modifier.weight(1f).height(52.dp).border(1.dp, pal.lineStrong, shape).pressable({ saveCont() }, scaleTo = 0.96f, haptic = true),
                    contentAlignment = Alignment.Center,
                ) { Txt("Teruskan", size = 16f, weight = FontWeight.Medium) }
            }
            if (!isEdit) Txt("Teruskan = simpan dan terus isi transaksi baru.", Modifier.padding(horizontal = GL), size = 12f, color = pal.muted)
            if (isEdit) DelZone("Padam transaksi ini", "Padam transaksi ini? Baki poket akan dikira semula.", { vm.delTx(sh.editId ?: "") })
            Spacer(Modifier.height(16.dp))
        }

        // ---------- panel bawah (papan nombor / pilihan) ----------
        AnimatedVisibility(
            visible = panel.isNotEmpty(),
            enter = expandVertically(spring(dampingRatio = 0.8f, stiffness = 420f)) + fadeIn(tween(160)),
            exit = shrinkVertically(tween(220, easing = IosEase)) + fadeOut(tween(150)),
        ) {
            var lastPanel by remember { mutableStateOf(panel) }
            if (panel.isNotEmpty()) lastPanel = panel
            val pn = lastPanel
            Column(Modifier.fillMaxWidth().background(pal.surface)) {
                Row(Modifier.fillMaxWidth().background(pal.surface2).hairlines(pal.line, top = true).padding(start = GL), verticalAlignment = Alignment.CenterVertically) {
                    Txt(when (pn) { "jumlah" -> "Jumlah"; "kat" -> "Kategori"; "poket" -> if (jenis == "pindah") "Dari poket" else "Poket"; "ke" -> "Ke poket"; "kad" -> "Kad kredit"; else -> "Bayaran untuk" },
                        Modifier.weight(1f), size = 16f, weight = FontWeight.Medium, color = pal.muted)
                    Box(Modifier.size(48.dp).clickable { panel = "" }, contentAlignment = Alignment.Center) { Txt("✕", size = 18f, color = pal.muted) }
                }
                when (pn) {
                    "jumlah" -> Keypad(jc, calc, { calc = !calc }, { key(it) }) {
                        val v = evalExpr(jumlah)
                        if (v != null) jumlah = PG.toFixed(v, 2)
                        goNext("jumlah")
                    }
                    "kat" -> PickGrid(
                        PG.KATEGORI.map { GridOpt(it.id, katEmoji(it.id) + "  " + it.label) } + (if (pulangOn) emptyList() else listOf(GridOpt("", if (Ai.ready() && Ai.autoKat()) "✨  Auto (AI)" else "Tiada"))),
                        effKat,
                    ) { v -> kat = v; katSrc = if (v.isNotEmpty()) "user" else "kosong"; unmark("kat"); goNext("kat") }
                    "poket" -> PickGrid(pocketOpts(s.pockets.filter { !(jenis == "kad" && it.dompet) }), poket) { poket = it; unmark("poket"); goNext("poket") }
                    "ke" -> PickGrid(pocketOpts(s.pockets), ke) { ke = it; goNext("ke") }
                    "kad" -> PickGrid(kads.map { GridOpt(it.id, it.nama) }, kadId) { kadId = it; goNext("kad") }
                    else -> {
                        val opts = ArrayList<GridOpt>()
                        opts.add(GridOpt("", "Tiada"))
                        s.commitments.forEach { opts.add(GridOpt("k:" + it.id, it.nama, M(it.jumlah))) }
                        s.debts.forEach { opts.add(GridOpt("h:" + it.id, it.nama, "hutang")) }
                        PickGrid(opts, untuk) { uv ->
                            untuk = uv
                            var amt = 0.0
                            var nm = ""
                            var pk = ""
                            if (uv.startsWith("k:")) {
                                val c = PG.commitmentStatus(s, PG.commitmentViewDate(s, vm.today())).find { it.id == uv.substring(2) }
                                if (c != null) { amt = if (c.baki > 0) c.baki else c.jumlah; nm = c.nama; pk = c.poket }
                            } else if (uv.startsWith("h:")) {
                                val c = PG.debtStatus(s, vm.today()).find { it.id == uv.substring(2) }
                                if (c != null) { amt = (if (c.pelanBaki > 0.004) c.pelanBaki else c.bakiBayar).takeIf { it > 0 } ?: c.sasaran; nm = "Bayar " + c.nama; pk = c.poket }
                            }
                            if (nm.isNotEmpty()) {
                                if (jumlah.isEmpty() && amt > 0) jumlah = PG.toFixed(amt, 2)
                                if (perkara.isEmpty()) perkara = nm
                                if (poket.isEmpty()) poket = pk
                            }
                            panel = ""
                        }
                    }
                }
            }
        }
    }
}

/* ================= komponen borang transaksi ================= */

private fun colorFor(j: String, pal: Pal): Color = when (j) {
    "keluar", "pelarasan-", "kad" -> pal.out
    "masuk", "pelarasan+", "baki-awal" -> pal.inn
    else -> pal.accent
}

/** Emoji kecil untuk setiap kategori belanja. */
fun katEmoji(id: String): String = when (id) {
    "makan" -> "🍜"; "dapur" -> "🛒"; "rumah" -> "🏠"; "bil" -> "💡"; "minyak" -> "⛽"; "kenderaan" -> "🚗"
    "kesihatan" -> "💊"; "keluarga" -> "👪"; "diri" -> "👕"; "hiburan" -> "🎬"; "sedekah" -> "🎁"; "lain" -> "📦"
    "hutang" -> "💳"; else -> "•"
}

/** Operator kalkulator pada papan nombor. */
private const val CALC_OPS = "+−×÷"

/** Kira ungkapan papan nombor (cth "12.50+3×2−1"); × dan ÷ dikira dulu. Null jika tak sah. */
private fun evalExpr(s: String): Double? {
    val t = s.replace(',', '.').replace(" ", "")
    if (t.isEmpty()) return null
    val nums = ArrayList<Double>()
    val ops = ArrayList<Char>()
    val num = StringBuilder()
    for (ch in t) {
        when {
            ch.isDigit() || ch == '.' -> num.append(ch)
            ch == '+' || ch == '−' || ch == '-' || ch == '×' || ch == '*' || ch == '÷' || ch == '/' -> {
                if (num.isEmpty()) {
                    if (nums.isEmpty() && (ch == '−' || ch == '-')) { num.append('-'); continue }
                    return null
                }
                nums.add(num.toString().toDoubleOrNull() ?: return null)
                num.setLength(0)
                ops.add(when (ch) { '−', '-' -> '-'; '×', '*' -> '*'; '÷', '/' -> '/'; else -> '+' })
            }
            else -> return null
        }
    }
    if (num.isEmpty()) { if (ops.isNotEmpty()) ops.removeAt(ops.size - 1) else return null }
    else nums.add(num.toString().toDoubleOrNull() ?: return null)
    if (nums.isEmpty() || nums.size != ops.size + 1) return null
    // × ÷ dulu, kemudian + −
    val n2 = ArrayList<Double>()
    val o2 = ArrayList<Char>()
    n2.add(nums[0])
    for (i in ops.indices) {
        val b = nums[i + 1]
        when (ops[i]) {
            '*' -> n2[n2.size - 1] = n2[n2.size - 1] * b
            '/' -> { if (b == 0.0) return null; n2[n2.size - 1] = n2[n2.size - 1] / b }
            else -> { o2.add(ops[i]); n2.add(b) }
        }
    }
    var r = n2[0]
    for (i in o2.indices) r = if (o2[i] == '+') r + n2[i + 1] else r - n2[i + 1]
    return if (r.isFinite()) Math.round(r * 100) / 100.0 else null
}

@Composable
private fun JBox(label: String, on: Boolean, color: Color, modifier: Modifier, onClick: () -> Unit) {
    val pal = LocalPal.current
    val shape = RoundedCornerShape(8.dp)
    Box(
        modifier.height(44.dp).background(if (on) pal.surface else pal.surface2, shape)
            .border(if (on) 1.5.dp else 1.dp, if (on) color else pal.line, shape)
            .pressable(onClick, scaleTo = 0.94f).padding(horizontal = 6.dp),
        contentAlignment = Alignment.Center,
    ) { Txt(label, size = 15f, weight = if (on) FontWeight.SemiBold else FontWeight.Medium, color = if (on) color else pal.muted, maxLines = 1) }
}

/** Satu baris borang: label kiri, nilai kanan dengan garis bawah (berwarna bila aktif). */
@Composable
private fun EntryRow(label: String, active: Boolean, color: Color, ai: Boolean, onClick: () -> Unit, content: @Composable () -> Unit) {
    val pal = LocalPal.current
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(start = GL, end = GL).heightIn(min = 54.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Row(Modifier.width(104.dp), verticalAlignment = Alignment.CenterVertically) {
            Txt(label, size = 15f, color = pal.muted, maxLines = 1)
            if (ai) { Spacer(Modifier.width(4.dp)); AiTag() }
        }
        Box(
            Modifier.weight(1f).heightIn(min = 54.dp).drawBehind {
                val w = if (active) 2.dp.toPx() else 1.dp.toPx()
                drawLine(if (active) color else pal.line, Offset(0f, size.height - w / 2), Offset(size.width, size.height - w / 2), strokeWidth = w)
            }.padding(vertical = 10.dp),
            contentAlignment = Alignment.CenterStart,
        ) { content() }
    }
}

@Composable
private fun RowNote(t: AnnotatedString) {
    val pal = LocalPal.current
    Txt(t, Modifier.padding(start = GL + 104.dp, end = GL, top = 4.dp, bottom = 2.dp), size = 12f, color = pal.muted)
}

@Composable
private fun AiTag() {
    val pal = LocalPal.current
    Box(Modifier.background(pal.accentSoft, RoundedCornerShape(3.dp)).padding(horizontal = 4.dp, vertical = 1.dp)) {
        Txt("AI", size = 10.5f, weight = FontWeight.Bold, color = pal.accentStrong)
    }
}

/** Medan teks dalam baris; Enter (Next/Done) memanggil onEnter. */
@Composable
private fun InlineField(
    value: String, onChange: (String) -> Unit, placeholder: String, fr: FocusRequester, ime: ImeAction,
    kbType: KeyboardType = KeyboardType.Text, onFocus: (Boolean) -> Unit, onEnter: () -> Unit,
) {
    val pal = LocalPal.current
    val ts = TextStyle(fontSize = 16.sp, color = pal.ink, fontFeatureSettings = "tnum")
    BasicTextField(
        value = value, onValueChange = onChange,
        modifier = Modifier.fillMaxWidth().focusRequester(fr).onFocusChanged { onFocus(it.isFocused) },
        textStyle = ts, singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = kbType, imeAction = ime, capitalization = if (kbType == KeyboardType.Text) KeyboardCapitalization.Sentences else KeyboardCapitalization.None),
        keyboardActions = KeyboardActions(onNext = { onEnter() }, onDone = { onEnter() }),
        cursorBrush = SolidColor(pal.accent),
        decorationBox = { inner ->
            Box(Modifier.fillMaxWidth().padding(vertical = 6.dp), contentAlignment = Alignment.CenterStart) {
                if (value.isEmpty()) Text(tr(placeholder), style = ts.copy(color = pal.muted.copy(alpha = 0.7f)), maxLines = 1)
                inner()
            }
        },
    )
}

/**
 * Papan nombor: 1–9, 00, 0, titik, padam, tolak, ikon kalkulator dan Selesai.
 * Ikon kalkulator buka baris kalkulator (C ÷ × + =); Selesai kira jawapan dan ke medan seterusnya.
 */
@Composable
private fun Keypad(accent: Color, calc: Boolean, onCalc: () -> Unit, onKey: (String) -> Unit, onDone: () -> Unit) {
    val pal = LocalPal.current
    val rows = listOf(
        listOf("1", "2", "3", "⌫"),
        listOf("4", "5", "6", "−"),
        listOf("7", "8", "9", "CALC"),
        listOf("00", "0", ".", "Selesai"),
    )
    Column(Modifier.fillMaxWidth().background(pal.line).padding(top = 1.dp), verticalArrangement = Arrangement.spacedBy(1.dp)) {
        AnimatedVisibility(
            visible = calc,
            enter = expandVertically(spring(dampingRatio = 0.75f, stiffness = 500f)) + fadeIn(tween(140)),
            exit = shrinkVertically(tween(180, easing = IosEase)) + fadeOut(tween(120)),
        ) {
            Row(Modifier.fillMaxWidth().padding(bottom = 1.dp), horizontalArrangement = Arrangement.spacedBy(1.dp)) {
                listOf("C", "÷", "×", "+", "=").forEach { k ->
                    val eq = k == "="
                    Box(
                        Modifier.weight(1f).height(54.dp).background(if (eq) accent.copy(alpha = 0.18f) else pal.surface2)
                            .pressable({ onKey(k) }, scaleTo = 0.84f, haptic = true),
                        contentAlignment = Alignment.Center,
                    ) {
                        Txt(k, size = 22f, weight = FontWeight.Medium, color = if (eq) accent else if (k == "C") pal.bad else pal.ink)
                    }
                }
            }
        }
        rows.forEach { r ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(1.dp)) {
                r.forEach { k ->
                    val done = k == "Selesai"
                    val isCalc = k == "CALC"
                    Box(
                        Modifier.weight(1f).height(62.dp)
                            .background(if (done) accent else if (isCalc && calc) pal.accentSoft else pal.surface)
                            .pressable({ if (done) onDone() else if (isCalc) onCalc() else onKey(k) }, scaleTo = 0.86f, haptic = true),
                        contentAlignment = Alignment.Center,
                    ) {
                        if (isCalc) Ico(Ic.CALC, if (calc) pal.accentStrong else pal.muted, 28.dp, stroke = 1.7f)
                        else Txt(k, size = if (done) 17f else 24f, weight = if (done) FontWeight.SemiBold else FontWeight.Normal,
                            color = if (done) inkOn(accent) else if (k == "⌫" || k == "−") pal.muted else pal.ink)
                    }
                }
            }
        }
    }
}

/** Grid pilihan 3 lajur dengan garis halus (kategori, poket, kad). */
@Composable
private fun PickGrid(options: List<GridOpt>, selected: String, onPick: (String) -> Unit) {
    val pal = LocalPal.current
    Column(
        Modifier.fillMaxWidth().heightIn(max = 320.dp).verticalScroll(rememberScrollState()).background(pal.line).padding(vertical = 1.dp),
        verticalArrangement = Arrangement.spacedBy(1.dp),
    ) {
        options.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(1.dp)) {
                row.forEach { o ->
                    val on = o.id == selected
                    Column(
                        Modifier.weight(1f).fillMaxHeight().defaultMinSize(minHeight = 58.dp).background(if (on) pal.accentSoft else pal.surface)
                            .pressable({ onPick(o.id) }, scaleTo = 0.9f, haptic = true).padding(horizontal = 6.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Txt(o.label, size = 14.5f, weight = if (on) FontWeight.SemiBold else FontWeight.Normal, color = if (on) pal.accentStrong else pal.ink, align = TextAlign.Center, maxLines = 2, lh = 19f)
                        val sub = o.sub
                        if (sub != null) Txt(sub, size = 11f, color = pal.muted, align = TextAlign.Center, maxLines = 1)
                    }
                }
                repeat(3 - row.size) { Box(Modifier.weight(1f).fillMaxHeight().background(pal.surface)) }
            }
        }
    }
}

@Composable
private fun ScanBox(vm: MainViewModel, sv: ScanView, onKad: () -> Unit) {
    val pal = LocalPal.current
    var showItems by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().background(pal.surface2).hairlines(pal.line).padding(horizontal = GL, vertical = 10.dp), verticalAlignment = Alignment.Top) {
        val th = sv.thumb
        if (th != null) {
            Image(th.asImageBitmap(), contentDescription = "Gambar yang diimbas", modifier = Modifier.size(60.dp, 80.dp).border(1.dp, pal.line, RoundedCornerShape(4.dp)), contentScale = ContentScale.Crop)
            Spacer(Modifier.width(12.dp))
        } else if (sv.pdf) {
            Box(Modifier.size(60.dp, 80.dp).background(pal.surface, RoundedCornerShape(4.dp)).border(1.dp, pal.line, RoundedCornerShape(4.dp)), contentAlignment = Alignment.Center) {
                Txt("PDF", size = 13f, weight = FontWeight.Bold, color = pal.bad)
            }
            Spacer(Modifier.width(12.dp))
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Txt((if (sv.busy) "⏳ " else "") + sv.title, size = 13.5f, weight = FontWeight.SemiBold, color = if (sv.warns.isNotEmpty() && sv.lines.isEmpty()) pal.bad else pal.ink)
            sv.lines.forEach { Txt(it, size = 12.5f, color = pal.muted) }
            sv.warns.forEach { Txt(it, size = 12.5f, color = pal.bad) }
            if (sv.needKey) Btn("Ke Tetapan AI", { vm.aiSetup() }, kind = BtnKind.SMALL, color = pal.accentStrong)
            if (sv.kadBtn) Btn("Guna kad kredit? Tukar", onKad, kind = BtnKind.SMALL, color = pal.accentStrong)
            if (sv.items.isNotEmpty()) {
                LinkBtn((if (showItems) "▾ " else "▸ ") + sv.items.size + " item dibaca", { showItems = !showItems }, size = 12.5f)
                if (showItems) sv.items.forEach { (n, v) ->
                    Row(Modifier.fillMaxWidth().hairlines(pal.line).padding(vertical = 2.dp)) {
                        Txt(n, Modifier.weight(1f), size = 12.5f)
                        Txt(M(v), size = 12.5f, num = true)
                    }
                }
            }
        }
    }
}


/** Bilangan belanja dalam lejar yang mungkin resit yang sama (enjin resit; amaran sahaja). */
private fun resitBerganda(s: com.asyraf.hadirku.pg.PgState, legacyJson: String, today: String, editId: String?): Int = try {
    val p = com.asyraf.hadirku.engine.receipt.ReceiptJson.fromLegacy(legacyJson)
    if (p !is com.asyraf.hadirku.engine.receipt.ReceiptParse.Ok) 0 else {
        val book = com.asyraf.hadirku.engine.ledger.PgLedgerAdapter.build(s, java.time.LocalDate.parse(today)).book
        com.asyraf.hadirku.engine.receipt.ReceiptEngine.duplicates(p.data, emptyList(), book)
            .count { it.kind == com.asyraf.hadirku.engine.receipt.DuplicateKind.LEDGER_ENTRY && (editId == null || !it.refId.startsWith("t:" + editId)) }
    }
} catch (e: Exception) { 0 }
