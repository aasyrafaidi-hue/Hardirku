package com.asyraf.hadirku.ui

import com.asyraf.hadirku.BuildConfig
import com.asyraf.hadirku.i18n.tr
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.asyraf.hadirku.MainViewModel
import com.asyraf.hadirku.Sheet
import com.asyraf.hadirku.ai.Ai
import com.asyraf.hadirku.engine.app.AppFacade
import com.asyraf.hadirku.engine.app.EngineSummary
import com.asyraf.hadirku.engine.app.rm
import com.asyraf.hadirku.engine.budget.BudgetEngine
import com.asyraf.hadirku.engine.budget.BudgetLine
import com.asyraf.hadirku.engine.budget.CarryOver
import com.asyraf.hadirku.engine.budget.SuggestionKind
import com.asyraf.hadirku.engine.forecast.ForecastEngine
import com.asyraf.hadirku.engine.forecast.ForecastResult
import com.asyraf.hadirku.engine.forecast.Scenario
import com.asyraf.hadirku.engine.ledger.PgLedgerAdapter
import com.asyraf.hadirku.engine.reconcile.MatchRow
import com.asyraf.hadirku.engine.reconcile.MatchStatus
import com.asyraf.hadirku.engine.risk.Severity
import com.asyraf.hadirku.engine.savings.Feasibility
import com.asyraf.hadirku.engine.savings.GoalProgress
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.PgState
import java.time.LocalDate
import java.time.YearMonth

/* =====================================================================
 * Pusat Kewangan — skrin enjin kewangan (aliran tunai, ramalan 3 senario, bajet, matlamat,
 * semak penyata bank, tanya Duitku). Semua nombor datang daripada enjin (Money/sen);
 * skrin ini hanya melukis. Tiada BoxWithConstraints/Lazy dalam Row IntrinsicSize di sini.
 * ===================================================================== */

/** Keputusan terakhir (supaya kad tidak berkelip bila tukar tab); dikunci ikut identiti data. */
private object CacheEnjin {
    @Volatile var s: PgState? = null
    @Volatile var eng: com.asyraf.hadirku.engine.store.EngineData? = null
    @Volatile var today: String = ""
    @Volatile var v: EngineSummary? = null
}

/**
 * Ringkasan enjin untuk data semasa, dikira di LATAR BELAKANG (Dispatchers.Default) supaya skrin tidak tersekat
 * bila data berubah. Nilai lama dipapar sementara kiraan baru berjalan. null = belum siap / pengiraan gagal.
 */
@Composable
fun rememberRingkasanEnjin(vm: MainViewModel, s: PgState): EngineSummary? {
    val eng = vm.engine
    val today = vm.today()
    val st = androidx.compose.runtime.produceState(CacheEnjin.v, s, eng, today) {
        if (CacheEnjin.s === s && CacheEnjin.eng === eng && CacheEnjin.today == today && CacheEnjin.v != null) { value = CacheEnjin.v; return@produceState }
        val r = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) { runCatching { AppFacade.summary(s, eng, LocalDate.parse(today)) }.getOrNull() }
        if (r != null) { CacheEnjin.s = s; CacheEnjin.eng = eng; CacheEnjin.today = today; CacheEnjin.v = r }
        value = r
    }
    return st.value
}

private fun toneOf(sv: Severity): Tone = when (sv) { Severity.WARNING -> Tone.BAD; Severity.CAUTION -> Tone.WARN; Severity.INFO -> Tone.INFO }

private fun tgl(d: LocalDate?): String = d?.let { PG.fmtShort(it.toString()) } ?: "Tiada tarikh tetap"

/* ================= kad di Utama ================= */

@Composable
fun BolehBelanjaCard(vm: MainViewModel, sum: EngineSummary, hide: Boolean) {
    val pal = LocalPal.current
    val av = sum.cash.availableToSpend.rm()
    val ada = av > 0.004
    Block(Modifier.pressable({ vm.setKewSegMode("belanja"); vm.go("kewangan") }, scaleTo = 0.98f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconTile(Ic.WALLET, if (ada) pal.accent else pal.bad, size = 40.dp, icon = 21.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Txt(if (BuildConfig.ISTERI) "Boleh belanja sampai hujung bulan" else "Boleh belanja sampai gaji", size = 12.5f, color = pal.muted)
                AutoMoney(Mh(av, hide), 22f, Modifier.fillMaxWidth(), color = if (av < -0.004) pal.bad else Color.Unspecified)
                Txt(
                    if (ada) "≈ " + Mh(sum.perDay.rm(), hide) + " sehari · " + sum.daysToPay + " hari lagi" else "Bil & hutang sebelum gaji melebihi baki",
                    size = 12.5f, color = if (ada) pal.muted else pal.bad,
                )
            }
            Ico(Ic.CHEVRON, pal.muted, 18.dp, stroke = 2f)
        }
        Spacer(Modifier.height(10.dp))
        Bar(AppFacade.spendFrac(sum.cash), over = av < -0.004, warn = ada && sum.perDay.rm() < 10.0)
    }
}

/** Amaran penting (WARNING/CAUTION) di Utama. Amaran INFO hanya dalam Pusat Kewangan. */
@Composable
fun PerhatianUtama(vm: MainViewModel, s: PgState, sum: EngineSummary) {
    val list = remember(sum) { AppFacade.distinctRisks(sum.risks).filter { it.severity != Severity.INFO } }
    if (list.isEmpty()) return
    val a = list[0]
    val t = AppFacade.riskText(a, s)
    Notice(
        rich("**" + t.title + "**\n" + t.body),
        toneOf(a.severity),
        "Lihat",
    ) { vm.setKewSegMode("belanja"); vm.go("kewangan") }
}

/* ================= skrin ================= */

@Composable
fun KewanganScreen(vm: MainViewModel) {
    val s by vm.pg.collectAsState()
    val seg = vm.kewSeg.takeIf { it in setOf("belanja", "ramalan", "bajet", "matlamat") } ?: "belanja"
    Seg(listOf("belanja" to "Belanja", "ramalan" to "Ramalan", "bajet" to "Bajet", "matlamat" to "Matlamat"), seg) { vm.setKewSegMode(it) }
    if (vm.engineReadOnly) Notice(rich("Data enjin datang daripada versi app lebih baru. Paparan sahaja — kemas kini app untuk ubah bajet atau matlamat."), Tone.WARN)
    val sum = rememberRingkasanEnjin(vm, s)
    if (sum == null) { Txt("Mengira…", Modifier.padding(horizontal = GL), size = 13f, color = LocalPal.current.muted); return }
    when (seg) {
        "ramalan" -> RamalanEnjinView(s, sum)
        "bajet" -> BajetView(vm, sum)
        "matlamat" -> MatlamatView(vm, sum)
        else -> BelanjaView(vm, s, sum)
    }
}

/* ---------- Belanja: aliran tunai & amaran ---------- */

@Composable
private fun BelanjaView(vm: MainViewModel, s: PgState, sum: EngineSummary) {
    val pal = LocalPal.current
    val hide = UiState.sorok
    val la = launch()
    val r = sum.cash
    val av = r.availableToSpend.rm()
    Block {
        Txt("Gaji seterusnya " + PG.fmtShort(sum.nextPay.toString()) + " · " + sum.daysToPay + " hari lagi", size = 12f, color = pal.muted)
        Spacer(Modifier.height(4.dp))
        Txt(if (BuildConfig.ISTERI) "Boleh belanja sampai hujung bulan" else "Boleh belanja sampai gaji", size = 14f, weight = FontWeight.SemiBold)
        if (hide) Txt(Mh(av, true), size = 30f, weight = FontWeight.SemiBold) else MoneyAnim(av, 30f, color = if (av < -0.004) pal.bad else pal.ink)
        Txt(
            if (av > 0.004) "≈ " + Mh(sum.perDay.rm(), hide) + " sehari" else "Tiada baki boleh belanja — bil & hutang sebelum gaji melebihi baki",
            size = 13f, color = if (av > 0.004) pal.muted else pal.bad,
        )
        Spacer(Modifier.height(10.dp))
        Bar(AppFacade.spendFrac(r), over = av < -0.004, warn = av > 0.004 && sum.perDay.rm() < 10.0)
    }

    SecHead("Cara dikira")
    Block {
        val rows = ArrayList<Triple<AnnotatedString, String, Color?>>()
        rows += Triple(rich("Baki bank, e-wallet & tunai"), Mh(r.liquid.rm(), hide), null)
        val pend = r.pending.netLiquid
        if (!pend.isZero) rows += Triple(rich("Transaksi bertarikh hadapan"), Mh(pend.rm(), hide, plus = true), null)
        val out = AppFacade.scheduledOut(r)
        rows += Triple(rich("Bil & hutang belum bayar sebelum gaji"), Mh(-out.rm(), hide), if (out.isPositive) pal.out else null)
        if (r.earmarked.isPositive) rows += Triple(rich("Diasingkan untuk matlamat"), Mh(-r.earmarked.rm(), hide), pal.out)
        rows += Triple(rich("Boleh belanja"), Mh(av, hide), if (av < -0.004) pal.bad else pal.inn)
        Kvl(rows, strongIdx = setOf(rows.size - 1))
        Spacer(Modifier.height(4.dp))
        Txt("Gaji yang dijangka tidak ditambah — angka ini kekal selamat walaupun gaji lewat.", size = 12.5f, color = pal.muted)
    }

    val items = remember(r) { AppFacade.scheduledText(s, r.scheduled).sortedBy { it.date ?: LocalDate.MAX } }
    if (items.isNotEmpty()) {
        SecHead("Sebelum gaji")
        Block {
            items.forEachIndexed { i, x ->
                TRow(
                    x.name, (if (x.inflow) "+" else "−") + Mh(x.amount.rm(), hide),
                    sub = tgl(x.date) + if (x.estimate) " · anggaran, tidak dikira" else "",
                    color = if (x.inflow) pal.inn else null, garis = i > 0,
                )
            }
        }
    }

    val risks = remember(sum) { AppFacade.distinctRisks(sum.risks) }
    SecHead("Perhatian")
    if (risks.isEmpty()) Empty(rich("✔ Tiada amaran. Aliran tunai nampak selamat untuk 30 hari akan datang."))
    else risks.forEach { a ->
        val t = AppFacade.riskText(a, s)
        Notice(rich("**" + t.title + "**\n" + t.body), toneOf(a.severity))
    }

    SecHead("Alat")
    Row(Modifier.fillMaxWidth().padding(horizontal = GL), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Btn("Semak penyata bank", { la.pickText { u -> vm.csvPick(u) } }, Modifier.weight(1f))
        Btn("Tanya Duitku", { vm.open(Sheet.Tanya) }, Modifier.weight(1f))
    }
    Note("Penyata CSV dibaca dalam telefon sahaja. Baris yang tiada dalam Duitku hanya direkod selepas anda sahkan.")
}

/* ---------- Ramalan 3 senario ---------- */

private fun scLabel(sc: Scenario): String = when (sc) { Scenario.CONSERVATIVE -> "Berhati-hati"; Scenario.BASE -> "Biasa"; Scenario.OPTIMISTIC -> "Optimis" }

@Composable
private fun RamalanEnjinView(s: PgState, sum: EngineSummary) {
    val pal = LocalPal.current
    val hide = UiState.sorok
    var pilih by remember { mutableStateOf(Scenario.BASE.name) }
    // 3 ramalan 90 hari dikira di latar belakang
    val allSt = androidx.compose.runtime.produceState<Map<Scenario, ForecastResult>?>(null, s, sum) {
        value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) {
            runCatching { Scenario.entries.associateWith { ForecastEngine.project(s, sum.book, sum.today, 90, it) } }.getOrNull()
        }
    }
    val all = allSt.value
    if (all == null) { Txt("Mengira ramalan…", Modifier.padding(horizontal = GL), size = 13f, color = pal.muted); return }
    val sc = Scenario.valueOf(pilih)
    val f = all.getValue(sc)
    Box(Modifier.padding(horizontal = GL)) {
        Chips(Scenario.entries.map { it.name to scLabel(it) }, pilih, { pilih = it })
    }
    val low = f.lowest.balance.rm()
    Block {
        Txt("Baki terendah dalam 90 hari · " + scLabel(sc), size = 12.5f, color = pal.muted)
        Spacer(Modifier.height(4.dp))
        if (hide) Txt(Mh(low, true), size = 28f, weight = FontWeight.SemiBold) else MoneyAnim(low, 28f, color = if (low < -0.004) pal.bad else pal.ink)
        Txt("sekitar " + PG.fmtShort(f.lowest.date.toString()), size = 12.5f, color = if (low < -0.004) pal.bad else pal.muted)
    }

    // carta: 14 hari lepas + 90 hari ramalan, setiap 2 hari (garis bagi setiap senario)
    val from = sum.today.minusDays(14)
    val idx = remember(f) { f.points.indices.filter { !f.points[it].date.isBefore(from) }.filterIndexed { k, _ -> k % 2 == 0 } }
    if (idx.size >= 3) ChartBlock("Baki dijangka", "Tiga senario · garis bermula 14 hari lepas") {
        val titles = idx.map { PG.fmtShort(f.points[it].date.toString()) }
        val ticks = idx.mapIndexedNotNull { k, i -> val d = f.points[i].date; if (k == 0 || d.dayOfMonth <= 2) k to PG.fmtShort(d.toString()) else null }
        val warna = mapOf(Scenario.CONSERVATIVE to pal.bad, Scenario.BASE to pal.c1, Scenario.OPTIMISTIC to pal.c2)
        LineChart(Scenario.entries.map { x -> val fx = all.getValue(x); LSeries(scLabel(x), warna.getValue(x), idx.map { i -> fx.points.getOrNull(i)?.balance?.rm() ?: 0.0 }) }, titles, ticks)
        Legend(Scenario.entries.map { LegItem(scLabel(it), warna.getValue(it), true) })
    }

    SecHead("Andaian " + scLabel(sc))
    Block {
        Kvl(listOfNotNull(
            Triple(rich("Baki hari ini"), Mh(f.startBalance.rm(), hide), null),
            if (BuildConfig.ISTERI) null else Triple(rich("Gaji pasti (90 hari)"), Mh(f.guaranteedIncome.rm(), hide), pal.inn),
            if (BuildConfig.ISTERI) null else Triple(rich("OT dijangka (anggaran)"), Mh(f.overtimeIncome.rm(), hide), pal.inn),
            Triple(rich("Belanja harian purata"), Mh(f.dailyDiscretionary.rm(), hide) + " sehari", pal.out),
        ))
        Spacer(Modifier.height(4.dp))
        Txt(
            when (sc) {
                Scenario.CONSERVATIVE -> if (BuildConfig.ISTERI) "Berhati-hati: belanja harian +10%." else "Berhati-hati: belanja harian +10%, OT ikut yang sudah direkod sahaja."
                Scenario.BASE -> "Biasa: belanja harian ikut purata " + (f.assumptions.find { it.code == "discretionary_history_days" }?.value ?: "60") + " hari lepas" + (if (BuildConfig.ISTERI) "." else ", OT ikut purata kitaran lepas.")
                Scenario.OPTIMISTIC -> if (BuildConfig.ISTERI) "Optimis: belanja harian −10%." else "Optimis: belanja harian −10%, OT ikut kadar harian terbaik 3 kitaran lepas."
            },
            size = 12.5f, color = pal.muted,
        )
        Spacer(Modifier.height(6.dp))
        TableView(
            listOf("Bulan", "Masuk", "Keluar", "Baki akhir"),
            f.months.map { m -> listOf(PG.fmtMonth(m.month.toString()), Mh(m.inflow.rm(), hide), Mh(m.outflow.rm(), hide), Mh(m.endBalance.rm(), hide)) },
        )
    }
    Note(if (BuildConfig.ISTERI) "Nafkah dan duit masuk lain belum dijangka dalam ramalan; ia dikira bila diterima. Ramalan ini anggaran — bukan nasihat kewangan."
        else "OT bukan pendapatan pasti. Ramalan ini anggaran — bukan nasihat kewangan.")
}

/* ---------- Bajet ---------- */

@Composable
private fun BajetView(vm: MainViewModel, sum: EngineSummary) {
    val pal = LocalPal.current
    val hide = UiState.sorok
    val month = YearMonth.from(sum.today)
    SecHeadLinks("Bajet " + PG.fmtMonth(month.toString()), listOf("+ Bajet" to { vm.open(Sheet.BajetForm(null)) }))
    if (sum.budgets.isEmpty()) {
        Empty(rich("Belum ada bajet. Tetapkan had belanja sebulan ikut kategori — contoh **Makan & minum RM400**. Belanja dikira sendiri daripada transaksi."))
    } else {
        val planned = sum.budgets.fold(com.asyraf.hadirku.engine.core.Money.ZERO) { a, l -> a + l.planned }
        val actual = sum.budgets.fold(com.asyraf.hadirku.engine.core.Money.ZERO) { a, l -> a + l.actual }
        Block {
            Kvl(listOf(
                Triple(rich("Jumlah bajet"), Mh(planned.rm(), hide), null),
                Triple(rich("Sudah dibelanja"), Mh(actual.rm(), hide), pal.out),
                Triple(rich(if (actual > planned) "Lebih bajet" else "Baki bajet"), Mh((planned - actual).abs().rm(), hide), if (actual > planned) pal.bad else pal.inn),
            ), strongIdx = setOf(2))
        }
        ListBlock { sum.budgets.sortedByDescending { it.usedBp }.forEach { BajetRow(vm, it, hide) } }
    }
    val eng = vm.engine
    val sug = remember(sum, eng) {
        runCatching { BudgetEngine.suggestions(sum.book, eng.budgets, month) }.getOrDefault(emptyList()).filter { it.kind != SuggestionKind.KEEP }
    }
    if (sug.isNotEmpty()) {
        SecHead("Cadangan ikut purata " + sug.maxOf { it.months } + " bulan")
        ListBlock {
            sug.take(6).forEach { g ->
                Row(Modifier.fillMaxWidth().hairlines(pal.line).padding(horizontal = GL, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Txt(PG.katLabel(g.category), size = 14.5f, weight = FontWeight.Medium)
                        Txt(AppFacade.suggestionText(g), size = 12.5f, color = pal.muted)
                    }
                    Spacer(Modifier.width(10.dp))
                    Btn("Guna", { vm.gunaCadangan(g) }, kind = BtnKind.SMALL, color = pal.accentStrong)
                }
            }
        }
        Note("Cadangan tidak digunakan sendiri — tekan Guna jika setuju. Kategori keperluan asas tidak dicadang turun.")
    }
}

@Composable
private fun BajetRow(vm: MainViewModel, l: BudgetLine, hide: Boolean) {
    val pal = LocalPal.current
    val over = l.over.isPositive
    Column(Modifier.fillMaxWidth().hairlines(pal.line).clickable { vm.open(Sheet.BajetForm(l.budget.id)) }.padding(horizontal = GL, vertical = 11.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Txt(PG.katLabel(l.budget.category), Modifier.weight(1f), size = 15f, weight = FontWeight.Medium, maxLines = 1)
            Txt(Mh(l.actual.rm(), hide) + " / " + Mh(l.planned.rm(), hide), size = 13.5f, num = true, color = if (over) pal.bad else pal.ink)
        }
        Spacer(Modifier.height(6.dp))
        Bar(l.usedBp / 10000.0, over = over, warn = !over && l.usedBp >= 8000)
        Spacer(Modifier.height(4.dp))
        Txt(
            (if (over) "Lebih " + Mh(l.over.rm(), hide) else "Baki " + Mh(l.remaining.rm(), hide)) +
                (if (!l.carryIn.isZero) " · termasuk bawaan " + Mh(l.carryIn.rm(), hide, plus = true) else "") +
                (if (l.budget.essential) " · keperluan asas" else ""),
            size = 12.5f, color = if (over) pal.bad else pal.muted,
        )
    }
}

/* ---------- Matlamat simpanan ---------- */

@Composable
private fun MatlamatView(vm: MainViewModel, sum: EngineSummary) {
    val pal = LocalPal.current
    val hide = UiState.sorok
    SecHeadLinks("Matlamat simpanan", listOf("+ Matlamat" to { vm.open(Sheet.MatlamatForm(null)) }))
    if (sum.goals.isEmpty()) {
        Empty(rich("Belum ada matlamat. Asingkan duit untuk tujuan tertentu (cth: duit raya, servis motor). Duit **kekal dalam poket** — cuma tidak dikira boleh belanja."))
        return
    }
    Block {
        Kvl(listOf(
            Triple(rich("Jumlah diasingkan"), Mh(sum.earmarked.rm(), hide), pal.inn),
            Triple(rich("Jumlah sasaran"), Mh(sum.goals.fold(com.asyraf.hadirku.engine.core.Money.ZERO) { a, p -> a + p.goal.target }.rm(), hide), null),
        ))
    }
    ListBlock { sum.goals.forEach { MatlamatRow(vm, it, hide) } }
    Note("Poket simpanan yang ada sasaran dipaparkan sendiri (ikut baki poket). Matlamat lain diasingkan daripada baki sebenar — tidak boleh melebihi duit yang ada.")
}

@Composable
private fun MatlamatRow(vm: MainViewModel, p: GoalProgress, hide: Boolean) {
    val pal = LocalPal.current
    val g = p.goal
    val susah = p.feasibility == Feasibility.TIGHT || p.feasibility == Feasibility.NOT_FEASIBLE || p.feasibility == Feasibility.PAST_DUE
    Column(
        Modifier.fillMaxWidth().hairlines(pal.line).clickable {
            if (g.fromPocket) vm.open(Sheet.PocketMenu(g.id.removePrefix("pocket:"))) else vm.open(Sheet.MatlamatGerak(g.id))
        }.padding(horizontal = GL, vertical = 11.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Txt(g.name, Modifier.weight(1f), size = 15f, weight = FontWeight.Medium, maxLines = 1)
            if (g.fromPocket) { Pill("poket", Tone.NEUTRAL); Spacer(Modifier.width(8.dp)) }
            Txt(Mh(p.allocated.rm(), hide) + " / " + Mh(g.target.rm(), hide), size = 13.5f, num = true)
        }
        Spacer(Modifier.height(6.dp))
        Bar(p.progressBp / 10000.0, warn = susah)
        Spacer(Modifier.height(4.dp))
        Txt(
            AppFacade.feasibilityText(p) +
                (g.targetDate?.let { " · tarikh sasaran " + PG.fmtDate(it.toString()) } ?: "") +
                (if (p.cappedByBalance) " · terhad kepada baki sebenar" else ""),
            size = 12.5f, color = if (susah) pal.warn else pal.muted,
        )
    }
}

/* ================= helaian ================= */

@Composable
fun BajetFormSheet(vm: MainViewModel, id: String?, katAwal: String?) {
    val b = remember(id) { vm.engine.budgets.find { it.id == id } }
    var kat by remember { mutableStateOf(b?.category ?: katAwal ?: "") }
    var jumlah by remember { mutableStateOf(b?.amount?.let { PG.toFixed(it.rm(), 2) } ?: "") }
    var carry by remember { mutableStateOf((b?.carryOver ?: CarryOver.NONE).name) }
    var asas by remember { mutableStateOf(if (b?.essential ?: (kat in BudgetEngine.DEFAULT_ESSENTIALS)) "asas" else "pilihan") }
    var err by remember { mutableStateOf("") }
    val dipakai = vm.engine.budgets.filter { it.id != id }.map { it.category }.toSet()
    val opsyen = PG.KATEGORI.filter { it.id != "belum" && it.id !in dipakai }.map { it.id to it.label }
    SheetBody(actions = { SheetActions("Simpan", { err = vm.simpanBajet(b?.id, kat, jumlah, CarryOver.valueOf(carry), asas == "asas") }, { vm.close() }) }) {
        SheetTitle(
            if (b != null) "Ubah bajet " + PG.katLabel(b.category) else "Bajet baru",
            rich("Had belanja **sebulan** untuk satu kategori. Belanja dikira daripada transaksi yang sudah dikategorikan."),
        )
        Form {
            FieldChips("Kategori", opsyen, kat, { kat = it; if (b == null) asas = if (it in BudgetEngine.DEFAULT_ESSENTIALS) "asas" else "pilihan" })
            FieldText("Jumlah sebulan (RM)", jumlah, { jumlah = it }, placeholder = "0.00", kb = KeyboardType.Decimal, big = true)
            FieldChips(
                "Baki bulan lepas",
                listOf(CarryOver.NONE.name to "Tidak dibawa", CarryOver.UNDERSPEND_ONLY.name to "Bawa lebihan", CarryOver.BOTH.name to "Bawa lebihan & kurangan"),
                carry, { carry = it },
            )
            FieldChips("Jenis", listOf("asas" to "Keperluan asas", "pilihan" to "Pilihan"), asas, { asas = it })
        }
        Box(Modifier.padding(horizontal = GL)) { FormError(err) }
        if (b != null) { Spacer(Modifier.height(8.dp)); DelZone("Padam bajet", "Padam bajet " + PG.katLabel(b.category) + "? Transaksi tidak terjejas.", { vm.padamBajet(b.id) }) }
    }
}

@Composable
fun MatlamatFormSheet(vm: MainViewModel, id: String?) {
    val s by vm.pg.collectAsState()
    val g = remember(id) { vm.engine.goals.find { it.id == id } }
    val today = vm.hariIni()
    var nama by remember { mutableStateOf(g?.name ?: "") }
    var sasaran by remember { mutableStateOf(g?.target?.let { PG.toFixed(it.rm(), 2) } ?: "") }
    var tempoh by remember { mutableStateOf(if (g?.targetDate != null) "kekal" else "") }
    var poket by remember { mutableStateOf(g?.accountId?.removePrefix("p:") ?: "") }
    var err by remember { mutableStateOf("") }
    val fr = autoFocus(g == null)
    fun tarikh(): String = when (tempoh) {
        "kekal" -> g?.targetDate?.toString() ?: ""
        "" -> ""
        else -> YearMonth.from(today).plusMonths(tempoh.toLong()).atEndOfMonth().toString()
    }
    val tempohOps = (g?.targetDate?.let { listOf("kekal" to PG.fmtDate(it.toString())) } ?: emptyList()) +
        listOf("" to "Tiada", "3" to "3 bulan", "6" to "6 bulan", "12" to "12 bulan", "24" to "24 bulan")
    val poketOps = listOf("" to "Semua baki") + s.pockets.filter { it.id != PG.BELUM_AGIH }.map { it.id to it.nama }
    SheetBody(actions = { SheetActions("Simpan", { err = vm.simpanMatlamat(g?.id, nama, sasaran, tarikh(), poket) }, { vm.close() }) }) {
        SheetTitle(if (g != null) "Ubah matlamat" else "Matlamat baru", rich("Duit tidak dipindah. Jumlah yang anda **asingkan** cuma tidak dikira dalam boleh belanja."))
        Form {
            FieldText("Nama", nama, { nama = it }, placeholder = "cth: Duit raya", maxLen = 40, fr = fr)
            FieldText("Sasaran (RM)", sasaran, { sasaran = it }, placeholder = "0.00", kb = KeyboardType.Decimal, big = true)
            FieldChips("Capai dalam", tempohOps, tempoh, { tempoh = it })
            FieldChips("Duit disimpan dalam", poketOps, poket, { poket = it })
        }
        Box(Modifier.padding(horizontal = GL)) { FormError(err) }
        if (g != null) { Spacer(Modifier.height(8.dp)); DelZone("Padam matlamat", "Padam " + g.name + "? Duit dalam poket tidak berubah.", { vm.padamMatlamat(g.id) }) }
    }
}

@Composable
fun MatlamatGerakSheet(vm: MainViewModel, id: String) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val sum = rememberRingkasanEnjin(vm, s)
    if (sum == null) { Txt("Mengira…", Modifier.padding(GL), size = 13f, color = pal.muted); return }
    val p = sum.goals.find { it.goal.id == id }
    if (p == null) { Empty(rich("Matlamat tidak dijumpai.")); return }
    var arah by remember { mutableStateOf("asing") }
    var jumlah by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    val moves = vm.engine.goalMoves.filter { it.goalId == id }.sortedByDescending { it.date }
    SheetBody(actions = {
        SheetActions("Simpan", { err = vm.gerakMatlamat(id, jumlah, arah == "lepas") }, { vm.close() }, extra = "Ubah", onExtra = { vm.open(Sheet.MatlamatForm(id)) })
    }) {
        SheetTitle(p.goal.name, rich("Diasingkan **" + M(p.allocated.rm()) + "** / " + M(p.goal.target.rm())))
        Box(Modifier.padding(horizontal = GL)) { Bar(p.progressBp / 10000.0) }
        Note(AppFacade.feasibilityText(p), Modifier.padding(top = 6.dp, bottom = 6.dp))
        Form {
            FieldChips("Tindakan", listOf("asing" to "Asingkan", "lepas" to "Lepaskan"), arah, { arah = it })
            FieldText("Jumlah (RM)", jumlah, { jumlah = it }, placeholder = "0.00", kb = KeyboardType.Decimal, big = true)
        }
        Box(Modifier.padding(horizontal = GL)) { FormError(err) }
        Note("Duit kekal dalam poket/bank. Asingkan = ditanda untuk matlamat ini; Lepaskan = boleh dibelanja semula.")
        if (moves.isNotEmpty()) {
            SecHead("Sejarah")
            Block {
                moves.take(10).forEachIndexed { i, m ->
                    TRow(PG.fmtDate(m.date.toString()), (if (m.amount.isNegative) "−" else "+") + M(m.amount.abs().rm()), color = if (m.amount.isNegative) pal.out else pal.inn, garis = i > 0)
                }
            }
        }
    }
}

@Composable
fun CsvSemakSheet(vm: MainViewModel) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val lap = vm.csvLapor
    if (lap == null) { Empty(rich("Tiada penyata dibuka.")); return }
    val book = remember(s, lap) { runCatching { PgLedgerAdapter.build(s, vm.hariIni()).book }.getOrNull() }
    val rep = lap.report
    var tapis by remember { mutableStateOf(MatchStatus.UNMATCHED_BANK.name) }
    val lbl = mapOf(
        MatchStatus.UNMATCHED_BANK to "Tiada dalam Duitku",
        MatchStatus.FUZZY_REVIEW to "Perlu semak",
        MatchStatus.EXACT to "Sepadan",
        MatchStatus.UNMATCHED_LEDGER to "Duitku sahaja",
        MatchStatus.ALREADY_IMPORTED to "Sudah ditanda",
    )
    SheetBody(actions = { SheetActions("", {}, { vm.close() }, cancel = "Tutup") }) {
        SheetTitle(
            "Semak penyata bank",
            rich(lap.nama + " · " + lap.parse.lines.size + " transaksi · " + PG.fmtShort(rep.range.start.toString()) + " – " + PG.fmtShort(rep.range.lastDay.toString())),
        )
        Box(Modifier.padding(horizontal = GL)) {
            Chips(lbl.entries.map { (k, v) -> k.name to (tr(v) + " (" + rep.count(k) + ")") }, tapis, { tapis = it })
        }
        if (lap.parse.errors.isNotEmpty()) Note(lap.parse.errors.size.toString() + " baris tidak dapat dibaca (tarikh atau jumlah).", Modifier.padding(top = 6.dp))
        if (lap.parse.lines.any { it.possibleDuplicate }) Note("Ada baris berulang dalam fail (tarikh, jumlah & keterangan sama) — ditanda ⚠.", Modifier.padding(top = 4.dp))
        Spacer(Modifier.height(8.dp))
        val rows = rep.rows.filter { it.status.name == tapis }
        if (rows.isEmpty()) Empty(rich("Tiada baris dalam kumpulan ini."))
        else ListBlock { rows.take(80).forEach { CsvBaris(vm, it, book) } }
        if (rows.size > 80) Note("Dipaparkan 80 baris pertama.")
        Note("Tiada apa-apa digabung sendiri. Rekod membuka borang transaksi biasa; Abaikan hanya menanda baris supaya tidak ditanya lagi.", Modifier.padding(top = 8.dp))
    }
}

@Composable
private fun CsvBaris(vm: MainViewModel, r: MatchRow, book: com.asyraf.hadirku.engine.ledger.LedgerBook?) {
    val pal = LocalPal.current
    val l = r.line
    val e = r.entryId?.let { book?.entry(it) }
    Column(Modifier.fillMaxWidth().hairlines(pal.line).padding(horizontal = GL, vertical = 10.dp)) {
        if (l != null) {
            Row(verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f)) {
                    Txt((if (l.possibleDuplicate) "⚠ " else "") + l.description.ifBlank { "(tiada keterangan)" }, size = 14f, maxLines = 2)
                    Txt(PG.fmtDate(l.date.toString()), size = 12f, color = pal.muted, num = true)
                }
                Spacer(Modifier.width(10.dp))
                Txt((if (l.amount.isNegative) "−" else "+") + M(l.amount.abs().rm()), size = 14f, num = true, color = if (l.amount.isNegative) pal.out else pal.inn)
            }
        } else if (e != null) {
            Row(verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f)) {
                    Txt(e.memo.ifBlank { "(tiada perkara)" }, size = 14f, maxLines = 2)
                    Txt(PG.fmtDate(e.date.toString()) + " · ada dalam Duitku, tiada dalam penyata", size = 12f, color = pal.muted)
                }
                Spacer(Modifier.width(10.dp))
                Txt(M(e.amount.rm()), size = 14f, num = true)
            }
        }
        if (r.status == MatchStatus.FUZZY_REVIEW && e != null) {
            Txt("Mungkin sama dengan: " + e.memo.ifBlank { "transaksi" } + " (" + PG.fmtShort(e.date.toString()) + ")" +
                (r.dateDiffDays?.takeIf { it != 0L }?.let { " · beza tarikh " + kotlin.math.abs(it) + " hari" } ?: ""), size = 12.5f, color = pal.warn)
        }
        if (l != null && r.status == MatchStatus.UNMATCHED_BANK) {
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Btn("Rekod", { vm.csvRekod(l) }, kind = BtnKind.SMALL, color = pal.accentStrong)
                Btn("Abaikan", { vm.csvAbai(l) }, kind = BtnKind.SMALL)
            }
        }
        if (l != null && r.status == MatchStatus.ALREADY_IMPORTED && vm.engine.importKeys[l.key] == "abai") {
            Spacer(Modifier.height(6.dp))
            Btn("Batal abai", { vm.csvBatalAbai(l) }, kind = BtnKind.SMALL)
        }
    }
}

@Composable
fun TanyaSheet(vm: MainViewModel) {
    val pal = LocalPal.current
    var q by remember { mutableStateOf("") }
    val cepat = listOf("Berapa jumlah hutang saya?", "Bil 2 minggu ini?", "Baki saya sekarang?", if (BuildConfig.ISTERI) "Duit masuk bulan ini?" else "Gaji & OT bulan ini?", "Belanja makan bulan ini?")
    SheetBody(actions = {
        SheetActions(if (vm.tanyaBusy) "Sedang fikir…" else "Tanya", { if (!vm.tanyaBusy) { vm.tanya(q); q = "" } }, { vm.close() }, cancel = "Tutup")
    }) {
        SheetTitle(
            "Tanya Duitku",
            rich("Jawapan dikira terus daripada data dalam telefon. " +
                if (Ai.ready()) "Soalan lain dijawab AI guna ringkasan **tanpa nama** poket atau perkara." else "Soalan terbuka perlukan kunci AI dalam Tetapan."),
        )
        Box(Modifier.padding(horizontal = GL)) { Chips(cepat.map { it to it }, "", { if (!vm.tanyaBusy) vm.tanya(it) }) }
        Spacer(Modifier.height(8.dp))
        Form { FieldText("Soalan", q, { q = it }, placeholder = "cth: belanja minyak bulan ini?", maxLen = 200) }
        vm.tanyaLog.reversed().forEach { (soal, jawab) ->
            Spacer(Modifier.height(8.dp))
            Block {
                Txt(soal, size = 13f, weight = FontWeight.SemiBold, color = pal.muted)
                Spacer(Modifier.height(4.dp))
                Txt(jawab, size = 14.5f)
            }
        }
        Note("Jawapan ialah maklumat, bukan nasihat kewangan.", Modifier.padding(top = 8.dp))
    }
}
