package com.asyraf.hadirku.engine.bills

import com.asyraf.hadirku.engine.core.DateRange
import com.asyraf.hadirku.engine.core.Dates
import com.asyraf.hadirku.engine.core.DueDayPolicy
import com.asyraf.hadirku.engine.core.Money
import com.asyraf.hadirku.engine.ledger.EntryType
import com.asyraf.hadirku.engine.ledger.LedgerBook
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.PgState
import java.time.LocalDate
import java.time.YearMonth

/* =====================================================================
 * Engine 4 — Bills & Commitments
 * Recurring bills come from the existing `commitments`. Payment status is read from the ledger
 * (EXPENSE entries linked to the commitment, reversed ones excluded) plus the existing manual
 * "mark as paid" flag, which matches PG.commitmentStatus.
 * ===================================================================== */

data class Bill(
    val id: String,
    val name: String,
    val amount: Money,
    /** due day 1..31, null = no fixed due date (paid by pay cycle) */
    val dueDay: Int?,
    /** "15" (advance) or "30" (month-end salary) — which salary pays this bill */
    val payCycle: String,
    val pocketId: String,
    /** amount may differ month to month (estimated) — no such flag exists in current data, defaults false */
    val variable: Boolean = false,
)

enum class BillStatus { PAID, MARKED_PAID, PARTIAL, UNPAID }

data class BillOccurrence(
    val bill: Bill,
    val period: DateRange,
    val periodKey: String,
    val dueDate: LocalDate?,
    val amount: Money,
    val paid: Money,
    val remaining: Money,
    val status: BillStatus,
    val paymentEntryIds: List<String>,
) {
    fun overdue(today: LocalDate): Boolean = dueDate != null && today.isAfter(dueDate) && remaining.isPositive
    fun daysUntilDue(today: LocalDate): Long? = dueDate?.let { Dates.daysBetween(today, it) }
}

data class BillReminder(val billId: String, val dueDate: LocalDate, val daysBefore: Int, val fireDate: LocalDate, val remaining: Money) {
    /** Stable de-duplication key — same format idea as the existing `komitmen.notis.<id>.<date>.<n>` */
    val dedupKey: String get() = "bill:$billId:$dueDate:$daysBefore"
}

data class DuplicateBill(val a: String, val b: String, val reason: String)
data class DuplicatePayment(val billId: String, val periodKey: String, val entryIds: List<String>)

object BillEngine {

    fun bills(s: PgState): List<Bill> = s.commitments.mapNotNull { c ->
        val amt = Money.fromDoubleOrNull(c.jumlah) ?: return@mapNotNull null
        Bill(c.id, c.nama, amt, c.tempo.takeIf { it in 1..31 }, if (c.kitaran == "15") "15" else "30", c.poket)
    }

    /** Commitment period containing [ref], same rule as the existing app (start day from settings). */
    fun periodFor(s: PgState, ref: LocalDate): Pair<DateRange, String> {
        val p = PG.commitmentPeriod(ref.toString(), s.settings.komitmenMulaHari.takeIf { it > 0 } ?: 1)
        return DateRange(LocalDate.parse(p.start), LocalDate.parse(p.endExcl)) to p.key
    }

    /** Due date of [dueDay] that falls inside [period] (periods may span two calendar months). */
    fun dueIn(period: DateRange, dueDay: Int, policy: DueDayPolicy): LocalDate? {
        val first = YearMonth.from(period.start)
        for (k in 0L..1L) {
            val d = Dates.dueDate(first.plusMonths(k), dueDay, policy)
            if (d in period) return d
        }
        return null
    }

    fun occurrences(
        s: PgState, book: LedgerBook, ref: LocalDate,
        policy: DueDayPolicy = DueDayPolicy.CLAMP_TO_MONTH_END,
    ): List<BillOccurrence> {
        val (period, key) = periodFor(s, ref)
        val linked = book.effective().filter { it.type == EntryType.EXPENSE && it.commitmentId != null && it.date in period }
            .groupBy { it.commitmentId!! }
        return bills(s).map { b ->
            val pays = linked[b.id].orEmpty()
            val paidTx = Money.sum(pays.map { it.amount })
            val manual = s.commitments.find { it.id == b.id }?.manual?.get(key) == true
            val paid = if (manual) paidTx.max(b.amount) else paidTx
            val remaining = (b.amount - paid).coerceAtLeast(Money.ZERO)
            val status = when {
                manual && paidTx < b.amount -> BillStatus.MARKED_PAID
                !remaining.isPositive -> BillStatus.PAID
                paid.isPositive -> BillStatus.PARTIAL
                else -> BillStatus.UNPAID
            }
            BillOccurrence(b, period, key, b.dueDay?.let { dueIn(period, it, policy) }, b.amount, paid, remaining, status, pays.map { it.id })
        }
    }

    /** Unpaid bills of the current and next period with a due date within [horizonDays]. */
    fun upcoming(s: PgState, book: LedgerBook, today: LocalDate, horizonDays: Long = 31, policy: DueDayPolicy = DueDayPolicy.CLAMP_TO_MONTH_END): List<BillOccurrence> {
        val cur = occurrences(s, book, today, policy)
        val next = occurrences(s, book, periodFor(s, today).first.endExclusive, policy)
        val end = today.plusDays(horizonDays)
        return (cur + next).filter { o -> o.remaining.isPositive && o.dueDate != null && !o.dueDate.isAfter(end) }
            .sortedWith(compareBy({ it.dueDate }, { it.bill.name }))
    }

    /** Reminders due to fire on [today] (default 3 days and 1 day before — the existing app's schedule). */
    fun remindersFor(s: PgState, book: LedgerBook, today: LocalDate, offsets: List<Int> = listOf(3, 1), policy: DueDayPolicy = DueDayPolicy.CLAMP_TO_MONTH_END): List<BillReminder> =
        upcoming(s, book, today, (offsets.maxOrNull() ?: 3).toLong() + 1, policy).flatMap { o ->
            offsets.mapNotNull { n ->
                val fire = o.dueDate!!.minusDays(n.toLong())
                if (fire == today) BillReminder(o.bill.id, o.dueDate, n, fire, o.remaining) else null
            }
        }

    /** Likely duplicate commitments: same normalised name, or same amount + due day + pocket. */
    fun duplicateBills(s: PgState): List<DuplicateBill> {
        val list = bills(s)
        val out = ArrayList<DuplicateBill>()
        for (i in list.indices) for (j in i + 1 until list.size) {
            val a = list[i]; val b = list[j]
            val na = PG.normNama(a.name); val nb = PG.normNama(b.name)
            when {
                na.isNotEmpty() && na == nb -> out += DuplicateBill(a.id, b.id, "same_name")
                a.amount == b.amount && a.dueDay != null && a.dueDay == b.dueDay && a.pocketId == b.pocketId -> out += DuplicateBill(a.id, b.id, "same_amount_due_pocket")
            }
        }
        return out
    }

    /** Two or more payments of the same amount to one bill within 3 days in a period — possible double payment. */
    fun duplicatePayments(s: PgState, book: LedgerBook, ref: LocalDate): List<DuplicatePayment> =
        occurrences(s, book, ref).mapNotNull { o ->
            val pays = o.paymentEntryIds.mapNotNull { book.entry(it) }.sortedBy { it.date }
            val dup = pays.filter { p -> pays.any { q -> q.id != p.id && q.amount == p.amount && kotlin.math.abs(Dates.daysBetween(p.date, q.date)) <= 3 } }
            if (dup.size >= 2) DuplicatePayment(o.bill.id, o.periodKey, dup.map { it.id }) else null
        }
}
