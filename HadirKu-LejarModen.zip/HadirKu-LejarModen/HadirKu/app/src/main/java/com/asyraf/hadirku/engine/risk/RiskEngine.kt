package com.asyraf.hadirku.engine.risk

import com.asyraf.hadirku.engine.bills.BillOccurrence
import com.asyraf.hadirku.engine.core.DateRange
import com.asyraf.hadirku.engine.core.Money
import com.asyraf.hadirku.engine.forecast.ForecastResult
import com.asyraf.hadirku.engine.forecast.PointKind
import com.asyraf.hadirku.engine.ledger.LedgerBook
import com.asyraf.hadirku.engine.ledger.LedgerReports
import java.time.LocalDate
import java.time.YearMonth

/* =====================================================================
 * Engine 7 — Financial Risk
 * Rule-based, configurable, neutral. Output is machine-readable codes + parameters only (no wording,
 * no advice). Presentation and phrasing are a UI decision for the owner.
 * ===================================================================== */

enum class RiskCode {
    NEGATIVE_PROJECTED_BALANCE, DUE_DATE_SHORTFALL, HIGH_FIXED_COMMITMENTS, UNUSUAL_SPENDING,
    LOW_EMERGENCY_RESERVE, HIGH_CREDIT_UTILISATION,
}
enum class Severity { INFO, CAUTION, WARNING }

data class RiskThresholds(
    val lookaheadDays: Int = 30,
    /** fixed commitments ÷ guaranteed monthly income, in basis points (5000 = 50%) */
    val fixedRatioCautionBp: Int = 5000,
    val fixedRatioWarningBp: Int = 7000,
    /** spending this month vs average of previous months (15000 = 150%) */
    val unusualFactorBp: Int = 15000,
    val unusualMinAmount: Money = Money.parse("50.00"),
    val unusualMinHistoryMonths: Int = 3,
    /** emergency reserve target in months of essential spending */
    val reserveMonths: Int = 3,
    val utilisationCautionBp: Int = 8000,
)

data class RiskAlert(
    val code: RiskCode,
    val severity: Severity,
    val date: LocalDate? = null,
    val amount: Money? = null,
    val subjectId: String? = null,
    val params: Map<String, String> = emptyMap(),
)

data class RiskInput(
    val asOf: LocalDate,
    val forecast: ForecastResult?,
    val liquidAvailable: Money,
    val nextIncomeDate: LocalDate?,
    val unpaidBills: List<BillOccurrence>,
    val monthlyGuaranteedIncome: Money,
    val monthlyFixedCommitments: Money,
    val book: LedgerBook,
    val emergencyReserve: Money,
    val monthlyEssentialSpend: Money,
    /** debtId → utilisation basis points */
    val cardUtilisation: Map<String, Int> = emptyMap(),
)

object RiskEngine {

    /** Build the input from existing data. [earmarked] money (savings goals) is not counted as available. */
    fun inputFrom(
        s: com.asyraf.hadirku.pg.PgState, book: LedgerBook, asOf: LocalDate, forecast: ForecastResult?,
        emergencyReserve: Money, earmarked: Money = Money.ZERO,
    ): RiskInput {
        val liquid = Money.sum(book.accounts.values.filter { it.kind == com.asyraf.hadirku.engine.ledger.AccountKind.ASSET }.map { book.balance(it.id, asOf) })
        val g = s.settings.gaji
        val guaranteed = Money.fromDouble(maxOf(0.0, g.basic + g.night + g.transport - g.potongan))
        val bills = com.asyraf.hadirku.engine.bills.BillEngine.bills(s)
        val debts = com.asyraf.hadirku.pg.PG.debtStatus(s, asOf.toString())
        val fixed = Money.sum(bills.map { it.amount }) + Money.sum(debts.map { Money.fromDouble(it.min) })
        val cur = YearMonth.from(asOf)
        val essentials = com.asyraf.hadirku.engine.budget.BudgetEngine.DEFAULT_ESSENTIALS
        // hanya bulan yang benar-benar direkod (bulan sebelum pengguna mula guna app bukan RM0 belanja)
        val mula = LedgerReports.activityStart(book)
        val ess3 = (1..3).map { cur.minusMonths(it.toLong()) }
            .filter { m -> mula != null && !mula.isAfter(m.atDay(com.asyraf.hadirku.engine.budget.BudgetEngine.GRACE_DAY)) }
            .map { m -> LedgerReports.expenseByCategory(book, DateRange.month(m)).filterKeys { it in essentials }.values.fold(Money.ZERO) { a, b -> a + b } }
        val essentialMonthly = (if (ess3.isEmpty()) Money.ZERO else Money.sum(ess3).div(ess3.size.toLong())) + Money.sum(bills.map { it.amount })
        return RiskInput(
            asOf, forecast, liquid - earmarked,
            runCatching { LocalDate.parse(com.asyraf.hadirku.pg.Ramalan.hariGajiSeterusnya(s, asOf.toString())) }.getOrNull(),
            com.asyraf.hadirku.engine.bills.BillEngine.upcoming(s, book, asOf, 45),
            guaranteed, fixed, book, emergencyReserve, essentialMonthly,
            debts.mapNotNull { d -> d.guna?.let { d.id to (it * 10000).toInt() } }.toMap(),
        )
    }

    fun evaluate(i: RiskInput, t: RiskThresholds = RiskThresholds()): List<RiskAlert> {
        val out = ArrayList<RiskAlert>()

        // 1) negative projected balance within the look-ahead
        i.forecast?.let { f ->
            val limit = i.asOf.plusDays(t.lookaheadDays.toLong())
            val neg = f.points.firstOrNull { it.kind == PointKind.FORECAST && !it.date.isAfter(limit) && it.balance.isNegative }
            if (neg != null) {
                val low = f.points.filter { it.kind == PointKind.FORECAST && !it.date.isAfter(limit) }.minBy { it.balance }
                out += RiskAlert(RiskCode.NEGATIVE_PROJECTED_BALANCE, Severity.WARNING, neg.date, low.balance,
                    params = mapOf("scenario" to f.scenario.name, "lowest_date" to low.date.toString()))
            }
        }

        // 2) bills due before the next income that the available money cannot cover (cumulative, by due date)
        var running = Money.ZERO
        i.unpaidBills.filter { it.dueDate != null && (i.nextIncomeDate == null || it.dueDate.isBefore(i.nextIncomeDate)) }
            .sortedBy { it.dueDate }.forEach { b ->
                running += b.remaining
                if (running > i.liquidAvailable) out += RiskAlert(RiskCode.DUE_DATE_SHORTFALL, Severity.CAUTION, b.dueDate,
                    running - i.liquidAvailable, b.bill.id, mapOf("cumulative_due" to running.toDecimal().toPlainString()))
            }

        // 3) fixed commitments vs guaranteed income
        if (i.monthlyGuaranteedIncome.isPositive) {
            val bp = (i.monthlyFixedCommitments.sen * 10000 / i.monthlyGuaranteedIncome.sen).toInt()
            val sev = when { bp >= t.fixedRatioWarningBp -> Severity.WARNING; bp >= t.fixedRatioCautionBp -> Severity.CAUTION; else -> null }
            if (sev != null) out += RiskAlert(RiskCode.HIGH_FIXED_COMMITMENTS, sev, amount = i.monthlyFixedCommitments, params = mapOf("ratio_bp" to bp.toString()))
        }

        // 4) unusual spending per category this month (pro-rated is NOT applied: month-to-date already above full-month average)
        val cur = YearMonth.from(i.asOf)
        val thisMonth = LedgerReports.expenseByCategory(i.book, DateRange(cur.atDay(1), i.asOf.plusDays(1)))
        val history = (1..6).map { LedgerReports.expenseByCategory(i.book, DateRange.month(cur.minusMonths(it.toLong()))) }
        thisMonth.forEach { (cat, amt) ->
            if (cat == null) return@forEach
            val past = history.mapNotNull { it[cat] }.filter { it.isPositive }
            if (past.size < t.unusualMinHistoryMonths) return@forEach
            val avg = Money.sum(past).div(past.size.toLong())
            if (amt.sen * 10000 > avg.sen * t.unusualFactorBp && amt - avg >= t.unusualMinAmount)
                out += RiskAlert(RiskCode.UNUSUAL_SPENDING, Severity.INFO, i.asOf, amt, cat,
                    mapOf("average" to avg.toDecimal().toPlainString(), "months" to past.size.toString()))
        }

        // 5) emergency reserve below target months of essential spending
        if (i.monthlyEssentialSpend.isPositive) {
            val target = i.monthlyEssentialSpend * t.reserveMonths
            if (i.emergencyReserve < target) {
                val sev = if (i.emergencyReserve < i.monthlyEssentialSpend) Severity.CAUTION else Severity.INFO
                out += RiskAlert(RiskCode.LOW_EMERGENCY_RESERVE, sev, amount = target - i.emergencyReserve,
                    params = mapOf("reserve" to i.emergencyReserve.toDecimal().toPlainString(), "target_months" to t.reserveMonths.toString()))
            }
        }

        // 6) credit utilisation
        i.cardUtilisation.forEach { (id, bp) ->
            if (bp >= t.utilisationCautionBp) out += RiskAlert(RiskCode.HIGH_CREDIT_UTILISATION, Severity.CAUTION, subjectId = id, params = mapOf("utilisation_bp" to bp.toString()))
        }
        return out
    }
}
