package com.asyraf.hadirku.ui

import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.asPaddingValues
import com.asyraf.hadirku.R
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.draw.drawWithContent
import com.asyraf.hadirku.BuildConfig
import com.asyraf.hadirku.MainViewModel
import com.asyraf.hadirku.Sheet
import com.asyraf.hadirku.i18n.tr
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.PgState
import com.asyraf.hadirku.pg.TrendRow
import kotlinx.coroutines.launch

/**
 * Tab Utama (id dalaman kekal "poket") — dashboard Lejar Moden.
 * Hierarki: Baki → Masuk/Keluar → Aliran tunai → Pintasan (OT, Hutang, EPP, Bil) → Poket.
 * Semua angka daripada PG (balances / total / periodReport / trendPeriods / otSummary / debtStatus / commitmentStatus).
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun PoketScreen(vm: MainViewModel) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val app by vm.settings.collectAsState()
    val today = vm.today()
    val hide = UiState.sorok
    val b = remember(s) { PG.balances(s) }
    val tot = remember(s) { PG.total(s) }
    val bs = remember(s) { PG.bankStatus(s) }
    val dw = s.pockets.filter { it.dompet && !it.tunai }
    val tn = s.pockets.filter { it.tunai }
    val tTunai = remember(s) { PG.totalTunai(s) }
    val tEw = remember(s) { PG.totalEwallet(s) }
    var susun by remember { mutableStateOf(false) }
    val per = PG.finPeriod(today, 1)
    val rep = remember(s, per) { PG.periodReport(s, per) }
    val ak = akruanOn(s)
    val scope = rememberCoroutineScope()
    val poketReq = remember { BringIntoViewRequester() }

    // ---------- hero baki (di atas ilustrasi Soft Violet) ----------
    val adaLuar = dw.isNotEmpty() || tn.isNotEmpty()
    val heroLines = ArrayList<String>()
    if (tn.isNotEmpty()) heroLines.add("Tunai dalam dompet " + Mh(tTunai, hide))
    if (dw.isNotEmpty()) heroLines.add("E-wallet " + Mh(tEw, hide))
    if (adaLuar) heroLines.add("Semua duit (bank" + (if (tn.isNotEmpty()) " + tunai" else "") + (if (dw.isNotEmpty()) " + e-wallet" else "") + ") " + Mh(PG.round2(tot + tTunai + tEw), hide))
    val bankTxt = when {
        bs == null -> "Belum semak dengan bank"
        Math.abs(bs.beza) < 0.005 -> "✔ Sama dengan bank · " + PG.fmtShort(bs.check.tarikh)
        else -> "Beza " + Mh(Math.abs(bs.beza), hide) + " dengan bank · " + PG.fmtShort(bs.check.tarikh)
    }
    val adaNotis = remember(s, today) { adaPeringatan(s, today) }
    HeroBaki(
        vm = vm, nama = app.name.trim(), adaNotis = adaNotis,
        label = if (adaLuar) "Baki dalam bank" else "Baki Semasa",
        amount = tot, hide = hide, lines = heroLines, bankTxt = bankTxt, bankBad = bs != null && Math.abs(bs.beza) >= 0.005,
        onBank = { vm.open(Sheet.Bank) },
        inLbl = if (ak) "Pendapatan bulan ini" else "Masuk bulan ini", inV = if (ak) rep.pend else rep.masuk,
        outLbl = if (ak) "Perbelanjaan bulan ini" else "Keluar bulan ini", outV = if (ak) rep.belanja else rep.keluar,
        perLbl = periodLabel(per),
    )

    val belum = b[PG.BELUM_AGIH] ?: 0.0
    if (belum > 0.004) Notice(rich("**" + Mh(belum, hide) + "** belum diagih ke poket."), Tone.WARN, "Agih") {
        vm.newTx(com.asyraf.hadirku.pg.Tx(jenis = "pindah", poket = PG.BELUM_AGIH), "Agih ke poket")
    }
    else if (belum < -0.004) Notice(rich("Belum Agih negatif **" + Mh(belum, hide) + "**. Semak transaksi Pindah."), Tone.BAD)

    // ---------- enjin kewangan: boleh belanja sampai gaji & amaran ----------
    val enj = rememberRingkasanEnjin(vm, s)
    if (enj != null && s.transactions.isNotEmpty()) {
        BolehBelanjaCard(vm, enj, hide)
        PerhatianUtama(vm, s, enj)
    }

    // ---------- aliran tunai bulanan ----------
    AliranTunaiCard(vm, s, today, ak, hide)

    // ---------- pintasan ----------
    val kvd = remember(s, today) { PG.commitmentViewDate(s, today) }
    val ks = remember(s, kvd) { PG.commitmentSummary(PG.commitmentStatus(s, kvd)) }
    val cyc = PG.otCycleOf(today, vm.otSd())
    val os = remember(s, cyc.start) { PG.otSummary(s, cyc) }
    val dl = remember(s, today) { PG.debtStatus(s, today) }
    val dsum = PG.debtSummary(dl)
    val nEpp = dl.sumOf { it.eppAktif }
    Column(Modifier.fillMaxWidth().padding(horizontal = GL), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ShortCard(
                Ic.KERJA, pal.accent, "OT", Mh(os.nilai, hide),
                "Kitaran OT " + PG.fmtShort(cyc.start) + " – " + PG.fmtShort(cyc.end), Modifier.weight(1f),
            ) { vm.kerjaSeg = "ot"; vm.go("kerja") }
            ShortCard(
                Ic.MONEYBAG, pal.amber, "Hutang", Mh(dsum.baki, hide),
                when {
                    dl.isEmpty() -> "Tiada hutang direkod"
                    dsum.baki <= 0.004 -> "✔ Semua langsai"
                    dsum.epp > 0.004 -> "Termasuk EPP " + Mh(dsum.epp, hide)
                    else -> "Baki belum selesai"
                },
                Modifier.weight(1f),
            ) { vm.setBayarSeg("hutang"); vm.go("bayaran") }
        }
        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ShortCard(
                Ic.LAYERS, pal.accent, "EPP", Mh(dsum.epp, hide),
                if (nEpp > 0) "Baki ($nEpp pelan aktif)" else "Tiada EPP aktif", Modifier.weight(1f),
            ) { vm.setBayarSeg("ringkasan"); vm.go("bayaran") }
            ShortCard(
                Ic.CALENDAR, pal.amber, if (kvd != today) "Bil Bulan Depan" else "Bil Bulan Ini", Mh(ks.baki, hide),
                when {
                    s.commitments.isEmpty() -> "Belum ada komitmen"
                    kvd != today && ks.belum > 0 -> "✔ Bulan ini selesai · ${ks.belum} akan datang"
                    ks.belum > 0 -> "${ks.belum} belum dibayar"
                    else -> "✔ Semua dah dibayar"
                },
                Modifier.weight(1f), warm = ks.belum > 0,
            ) { vm.setBayarSeg("ringkasan"); vm.go("bayaran") }
        }
    }

    // ---------- akses pantas: Poket, OT, Barang Dapur, Kewangan ----------
    Row(Modifier.fillMaxWidth().padding(horizontal = GL - 4.dp)) {
        QuickBtn(Ic.WALLET, "Poket", Modifier.weight(1f)) { scope.launch { poketReq.bringIntoView() } }
        QuickBtn(Ic.KERJA, "Isi OT", Modifier.weight(1f)) { vm.open(Sheet.OtDay(today)) }
        QuickBtn(Ic.P_GROCERY, "Barang Dapur", Modifier.weight(1f)) { vm.go("senarai") }
        QuickBtn(Ic.LAPORAN, "Laporan", Modifier.weight(1f)) { vm.setLapViewMode("ringkasan"); vm.go("laporan") }
        QuickBtn(Ic.SHIELD, "Kewangan", Modifier.weight(1f)) { vm.setKewSegMode("belanja"); vm.go("kewangan") }
    }

    DompetTunaiCard(vm, s, b, hide)
    // RamalanRingkas diganti BolehBelanjaCard (enjin aliran tunai) di atas; ramalan gaji lama kekal dalam Laporan → Ramalan

    val due = vm.backupDue()
    if (due != null) {
        Block {
            Row(verticalAlignment = Alignment.Top) {
                IconTile(Ic.DOWNLOAD, pal.accent, size = 44.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Txt(if (due.second) "Belum pernah simpan salinan" else "Salinan terakhir " + due.first + " hari lalu", size = 15f, weight = FontWeight.Bold)
                    Txt("Data hanya ada dalam telefon ini. Kalau telefon hilang atau rosak, salinan sahaja boleh pulihkan semuanya.", size = 13.5f, color = pal.muted)
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Btn("Nanti", { vm.snoozeBackup() }, Modifier.weight(1f))
                Btn("Simpan salinan", { vm.open(Sheet.BackupMenu) }, Modifier.weight(1f), kind = BtnKind.PRIMARY)
            }
        }
    }

    // ---------- poket (fungsi asal dikekalkan) ----------
    Column(Modifier.fillMaxWidth().bringIntoViewRequester(poketReq), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        SecHeadLinks("Poket", if (susun) listOf("Siap" to { susun = false; vm.lastMoved = null })
            else listOf("Susun" to { susun = true; vm.lastMoved = null }, "+ Poket" to { vm.open(Sheet.PocketForm(null)) }))
        if (susun) SusunPoketList(vm, s.pockets) { p -> Mh(b[p.id] ?: 0.0, hide) }
        else ListBlock {
            s.pockets.forEach { p ->
                val bal = b[p.id] ?: 0.0
                PRow(
                    p.nama, Mh(bal, hide), { vm.open(Sheet.PocketMenu(p.id)) }, tag = if (p.tunai) "tunai" else if (p.dompet) "e-wallet" else null, neg = bal < -0.004,
                    subs = if (p.id == PG.BELUM_AGIH) listOf("Gaji masuk ke sini dulu, kemudian diagih") else if (p.tunai) listOf("Duit tunai dalam dompet · tidak dikira dalam bank") else emptyList(),
                )
            }
        }
    }
}

/* ================= hero baki ================= */

/** Saiz tulisan supaya [text] muat dalam [maxW] (anggaran lebar aksara angka ≈ 0.6em). */
private fun fitSp(text: String, maxW: Dp, maxSp: Float, fontScale: Float, minSp: Float = 14f): Float {
    val perChar = 0.6f * fontScale
    val fit = maxW.value / (text.length.coerceAtLeast(1) * perChar)
    return fit.coerceIn(minSp, maxSp)
}

/**
 * Teks wang yang mengecil sendiri supaya tidak terpotong pada skrin 320dp / tulisan besar.
 * PENTING: jangan guna BoxWithConstraints di sini — AutoMoney dipakai dalam Row(height(IntrinsicSize.Min))
 * (kad pintasan Utama, Masuk/Keluar, DuaNilai) dan SubcomposeLayout tidak menyokong ukuran intrinsik
 * (app tertutup sebaik dibuka). Text biasa + onTextLayout selamat untuk ukuran intrinsik.
 */
@Composable
fun AutoMoney(text: String, maxSp: Float, modifier: Modifier = Modifier, weight: FontWeight = FontWeight.Bold, color: Color = Color.Unspecified) {
    val pal = LocalPal.current
    val minSp = 12f
    var sz by remember(text, maxSp) { androidx.compose.runtime.mutableFloatStateOf(maxSp) }
    var siap by remember(text, maxSp) { mutableStateOf(false) }
    androidx.compose.material3.Text(
        text = tr(text),
        modifier = modifier.drawWithContent { if (siap) drawContent() },
        fontSize = sz.sp, fontWeight = weight,
        color = if (color == Color.Unspecified) pal.ink else color,
        maxLines = 1, softWrap = false, lineHeight = (sz * 1.3f).sp, style = TNUM,
        onTextLayout = { r ->
            if (r.didOverflowWidth && sz > minSp) { sz = Math.max(minSp, sz - 1f) } else { siap = true }
        },
    )
}

@Composable
private fun HeroBaki(
    vm: MainViewModel, nama: String, adaNotis: Boolean,
    label: String, amount: Double, hide: Boolean, lines: List<String>, bankTxt: String, bankBad: Boolean, onBank: () -> Unit,
    inLbl: String, inV: Double, outLbl: String, outV: Double, perLbl: String,
) {
    val pal = LocalPal.current
    val fs = LocalDensity.current.fontScale
    val sb = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val heroH = sb + 214.dp
    Box(Modifier.fillMaxWidth()) {
        // ---- ilustrasi senja ungu (templat Soft Violet) di bawah bar status
        Box(Modifier.fillMaxWidth().height(heroH).clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))) {
            Image(painterResource(R.drawable.hero_ungu), contentDescription = null, modifier = Modifier.matchParentSize(), contentScale = ContentScale.Crop)
            Box(Modifier.matchParentSize().background(Brush.verticalGradient(listOf(Color(0x8C29204B), Color(0x1429204B), Color(0x4D29204B)))))
            if (pal.dark) Box(Modifier.matchParentSize().background(Color(0x40000000)))
            Column(Modifier.fillMaxWidth().padding(top = sb + 4.dp, start = 6.dp, end = 6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBtn(Ic.MENU, "Menu", { vm.open(Sheet.Menu) }, tint = Color.White)
                    Column(Modifier.weight(1f).padding(start = 2.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Txt("Duitku", size = 24f, weight = FontWeight.Bold, color = Color.White, maxLines = 1, lh = 29f)
                            if (BuildConfig.IS_DEV) {
                                Spacer(Modifier.width(8.dp))
                                Txt("DEV", Modifier.clip(RoundedCornerShape(8.dp)).background(Color.White.copy(alpha = 0.22f)).padding(horizontal = 7.dp, vertical = 2.dp),
                                    size = 11.5f, weight = FontWeight.Bold, color = Color.White, maxLines = 1)
                            }
                        }
                        Txt(if (BuildConfig.IS_DEV) "Versi ujian · data berasingan" else "Urus Duit · Capai Impian", size = 12.5f, color = Color.White.copy(alpha = 0.86f), maxLines = 1)
                    }
                    IconBtn(Ic.BELL, if (adaNotis) "Peringatan (ada bil hampir tempo)" else "Peringatan", { vm.open(Sheet.Notis) }, tint = Color.White, dot = adaNotis)
                }
                Spacer(Modifier.height(16.dp))
                Column(Modifier.padding(horizontal = 14.dp)) {
                    Txt("Assalamualaikum" + (if (nama.isNotBlank()) ", $nama" else ""), size = 16f, weight = FontWeight.SemiBold, color = Color.White, maxLines = 1)
                    Txt("Jom semak kewangan hari ini 👋", size = 14f, color = Color.White.copy(alpha = 0.9f), maxLines = 1)
                }
            }
        }
        // ---- kad baki: bertindih separuh di atas ilustrasi
        Column(
            Modifier.fillMaxWidth().padding(top = heroH - 60.dp).padding(horizontal = GL)
                .lejarCard(pal, radius = 24.dp, elevation = 10.dp).padding(12.dp),
        ) {
            Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 4.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Ico(Ic.CALENDAR, pal.accent, 18.dp, stroke = 1.9f)
                Spacer(Modifier.width(6.dp))
                Txt(perLbl, Modifier.weight(1f), size = 13.5f, weight = FontWeight.SemiBold, color = pal.ink, maxLines = 1)
            }
            // panel lavender "Baki Semasa"
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(if (pal.dark) pal.surface2 else pal.paperHead)
                    .padding(start = 14.dp, end = 4.dp, top = 12.dp, bottom = 12.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    BoxWithConstraints(Modifier.weight(1f)) {
                        val shown = if (hide) "RM ••••••" else M(amount)
                        // maxWidth mesti dibaca di sini (skop BoxWithConstraints), bukan di dalam Column
                        val sz = fitSp(shown, maxWidth, 30f, fs, 18f)
                        Column(Modifier.semantics(mergeDescendants = true) { contentDescription = tr(label) + " " + shown }) {
                            Txt(label, size = 13f, weight = FontWeight.Medium, color = pal.muted, maxLines = 1)
                            if (hide) Txt(shown, size = sz, weight = FontWeight.Bold, color = pal.ink, maxLines = 1)
                            else MoneyAnim(amount, sz, weight = FontWeight.Bold, color = if (amount < -0.004) pal.bad else pal.ink)
                        }
                    }
                    IconBtn(if (hide) Ic.EYE_OFF else Ic.EYE, if (hide) "Tunjuk baki" else "Sorok baki", { UiState.tukarSorok(!hide) }, tint = pal.accent)
                }
                if (lines.isNotEmpty()) {
                    Spacer(Modifier.height(4.dp))
                    lines.forEach { Txt(it, size = 12.5f, color = pal.muted, num = true) }
                }
                Spacer(Modifier.height(10.dp))
                Row(
                    Modifier.clip(RoundedCornerShape(50)).background(if (bankBad) pal.badSoft else pal.surface.copy(alpha = if (pal.dark) 0.5f else 0.85f))
                        .clickable(onClick = onBank).heightIn(min = 34.dp).padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Txt(bankTxt, size = 12.5f, weight = FontWeight.Medium, color = if (bankBad) pal.bad else pal.ink, maxLines = 1)
                    Spacer(Modifier.width(6.dp))
                    Txt("Semak", size = 12.5f, weight = FontWeight.Bold, color = if (bankBad) pal.bad else pal.accent)
                }
            }
            Row(
                Modifier.fillMaxWidth().height(IntrinsicSize.Min).padding(start = 4.dp, end = 4.dp, top = 12.dp, bottom = 2.dp)
                    .semantics(mergeDescendants = true) { contentDescription = tr(perLbl) },
            ) {
                FlowCell(Ic.P_INCOME, pal.inn, pal.goodSoft, inLbl, inV, hide, Modifier.weight(1f))
                Box(Modifier.width(1.dp).fillMaxHeight().padding(vertical = 4.dp).background(pal.line))
                FlowCell(Ic.P_EXPENSE, pal.out, pal.badSoft, outLbl, outV, hide, Modifier.weight(1f).padding(start = 12.dp))
            }
        }
    }
}

@Composable
private fun FlowCell(ic: Ic, fg: Color, bg: Color, lbl: String, v: Double, hide: Boolean, modifier: Modifier) {
    val pal = LocalPal.current
    Row(modifier.padding(end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        IconTile(ic, fg, size = 40.dp, icon = 22.dp)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Txt(lbl, size = 12.5f, color = pal.muted, maxLines = 2, lh = 16f)
            AutoMoney(Mh(v, hide), 17f, weight = FontWeight.Bold, color = fg)
        }
    }
}

/* ================= aliran tunai bulanan ================= */

@Composable
private fun AliranTunaiCard(vm: MainViewModel, s: PgState, today: String, ak: Boolean, hide: Boolean) {
    val pal = LocalPal.current
    val curYm = PG.ym(today)
    val selYm = UiState.dashYm?.takeIf { it <= curYm } ?: curYm
    val perSel = PG.finPeriod("$selYm-01", 1)
    val rows = remember(s, perSel.key) { PG.trendPeriods(s, perSel, 4, 1) }
    fun vIn(t: TrendRow) = if (ak) t.pend else t.masuk
    fun vOut(t: TrendRow) = if (ak) t.belanja else t.keluar
    fun vNet(t: TrendRow) = if (ak) t.lebihan else t.bersih
    val last = rows.lastOrNull()
    var open by remember { mutableStateOf(false) }
    Block {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Txt("Aliran Tunai Bulanan", size = 16f, weight = FontWeight.Bold, maxLines = 1)
                if (ak) Txt("Pendapatan & perbelanjaan · OT ikut kitaran gaji", size = 11.5f, color = pal.muted, maxLines = 2)
            }
            Box {
                Row(
                    Modifier.clip(RoundedCornerShape(12.dp)).clickable { open = true }.heightIn(min = 40.dp).padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    val p = PG.parse("$selYm-01")
                    Txt(PG.BULAN[p.m - 1] + " " + p.y, size = 13.5f, weight = FontWeight.SemiBold, color = pal.accent)
                    Spacer(Modifier.width(4.dp))
                    Ico(Ic.DOWN, pal.accent, 16.dp, stroke = 2.2f)
                }
                DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                    (0 until 12).forEach { i ->
                        val ym = PG.shiftYm(curYm, -i)
                        DropdownMenuItem(
                            text = { Txt(PG.fmtMonth(ym), size = 15f, weight = if (ym == selYm) FontWeight.SemiBold else FontWeight.Normal, color = if (ym == selYm) pal.accent else pal.ink) },
                            onClick = { open = false; UiState.dashYm = if (ym == curYm) null else ym },
                        )
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        val kosong = rows.all { vIn(it) == 0.0 && vOut(it) == 0.0 }
        if (kosong || last == null) {
            Txt("Belum ada transaksi untuk dipaparkan. Rekod duit masuk & keluar, dan carta akan muncul di sini.", size = 13f, color = pal.muted)
            return@Block
        }
        val labels = rows.map { PG.BULAN[PG.parse(it.start).m - 1] }
        AliranChart(labels, rows.map { vIn(it) }, rows.map { vOut(it) }, rows.size - 1, hide) { i ->
            val ym = PG.ym(rows[i].start)
            UiState.dashYm = if (ym == curYm) null else ym
        }
        Spacer(Modifier.height(10.dp))
        val inLbl = if (ak) "Pendapatan" else "Masuk"
        val outLbl = if (ak) "Perbelanjaan" else "Keluar"
        val net = vNet(last)
        val netLbl = (if (ak) (if (net >= 0) "Lebihan " else "Kurangan ") else "Baki ") + if (PG.ym(last.start) == curYm) "bulan ini" else PG.BULAN[PG.parse(last.start).m - 1]
        BoxWithConstraints(Modifier.fillMaxWidth()) {
            val narrow = maxWidth < 300.dp
            val leg: @Composable (Modifier) -> Unit = { m ->
                Row(m.height(IntrinsicSize.Min), verticalAlignment = Alignment.CenterVertically) {
                    LegendVal(pal.c1, inLbl, Mh(vIn(last), hide), Modifier.weight(1f))
                    Box(Modifier.width(1.dp).fillMaxHeight().padding(vertical = 2.dp).background(pal.line))
                    LegendVal(pal.c2, outLbl, Mh(vOut(last), hide), Modifier.weight(1f).padding(start = 10.dp))
                }
            }
            val netBox: @Composable (Modifier) -> Unit = { m ->
                val bad = net < -0.004
                Column(
                    m.clip(RoundedCornerShape(12.dp)).background(if (bad) pal.badSoft else pal.mintWash).border(1.dp, if (bad) pal.bad.copy(alpha = 0.18f) else pal.mint, RoundedCornerShape(12.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                ) {
                    Txt(netLbl, size = 11.5f, color = if (bad) pal.bad else pal.accentStrong, maxLines = 1)
                    Txt(Mh(net, hide, plus = true), size = 13.5f, weight = FontWeight.Bold, color = if (bad) pal.bad else pal.accentStrong, num = true, maxLines = 1)
                }
            }
            if (narrow) Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { leg(Modifier.fillMaxWidth()); netBox(Modifier.fillMaxWidth()) }
            else Row(verticalAlignment = Alignment.CenterVertically) { leg(Modifier.weight(1f)); Spacer(Modifier.width(8.dp)); netBox(Modifier) }
        }
    }
}

@Composable
private fun LegendVal(c: Color, lbl: String, v: String, modifier: Modifier) {
    val pal = LocalPal.current
    Column(modifier) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(10.dp).background(c, RoundedCornerShape(3.dp)))
            Spacer(Modifier.width(6.dp))
            Txt(lbl, size = 12f, color = pal.muted, maxLines = 1)
        }
        Txt(v, size = 13.5f, weight = FontWeight.SemiBold, num = true, maxLines = 1)
    }
}

/** Carta bar berkumpulan (masuk hijau, keluar merah lembut). Sentuh bulan → pilih bulan itu. */
@Composable
private fun AliranChart(labels: List<String>, ins: List<Double>, outs: List<Double>, sel: Int, hide: Boolean, onPick: (Int) -> Unit) {
    val pal = LocalPal.current
    val tm = rememberTextMeasurer()
    val grow = appear(ins.hashCode() * 31 + outs.hashCode(), 650)
    val desc = labels.mapIndexed { i, l -> l + ": " + (if (hide) "" else M(ins[i]) + " / " + M(outs[i])) }.joinToString("; ")
    Canvas(
        Modifier.fillMaxWidth().height(170.dp)
            .pointerInput(labels.size, hide) {
                detectTapGestures { o ->
                    val left = if (hide) 6.dp.toPx() else 44.dp.toPx()
                    val band = (size.width - left - 4.dp.toPx()) / labels.size
                    val i = ((o.x - left) / band).toInt()
                    if (i in labels.indices) onPick(i)
                }
            }
            .semantics { contentDescription = desc },
    ) {
        val L = if (hide) 6.dp.toPx() else 44.dp.toPx()
        val R = 4.dp.toPx(); val T = 8.dp.toPx(); val B = 30.dp.toPx()
        val pw = size.width - L - R
        val ph = size.height - T - B
        val mx = niceMax((ins + outs + 0.0).maxOrNull() ?: 0.0)
        val axis = TextStyle(fontFamily = AppFont, fontSize = 10.5.sp, color = pal.muted)
        for (k in 0..4) {
            val v = mx * k / 4
            val y = T + ph - (v / mx * ph).toFloat()
            drawLine(if (k == 0) pal.lineStrong else pal.grid, Offset(L, y), Offset(size.width - R, y), strokeWidth = 1.dp.toPx())
            if (!hide) {
                val lay = tm.measure(AnnotatedString(PG.money(v).replace("RM", "").substringBefore(".")), axis)
                drawText(lay, topLeft = Offset(L - 6.dp.toPx() - lay.size.width, y - lay.size.height / 2f))
            }
        }
        val n = labels.size
        val band = pw / n
        val bw = minOf(22.dp.toPx(), band * 0.27f)
        val gap = 5.dp.toPx()
        val r = 5.dp.toPx()
        labels.forEachIndexed { i, lbl ->
            val cx = L + band * i + band / 2
            listOf(Triple(ins[i], pal.c1, cx - gap / 2 - bw), Triple(outs[i], pal.c2, cx + gap / 2)).forEach { (v, col, x) ->
                if (v > 0) {
                    val h = maxOf(2f, (v / mx * ph).toFloat()) * grow.value
                    val rr = minOf(r, bw / 2, h)
                    val p = Path().apply {
                        addRoundRect(RoundRect(x, T + ph - h, x + bw, T + ph, CornerRadius(rr, rr), CornerRadius(rr, rr), CornerRadius.Zero, CornerRadius.Zero))
                    }
                    drawPath(p, col, alpha = if (i == sel) 1f else 0.82f)
                }
            }
            val on = i == sel
            val lay = tm.measure(AnnotatedString(lbl), TextStyle(fontFamily = AppFont, fontSize = 12.sp, color = if (on) pal.accentStrong else pal.muted, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal))
            val ly = size.height - B + 8.dp.toPx()
            if (on) {
                val pw2 = lay.size.width + 16.dp.toPx()
                drawRoundRect(pal.mint, topLeft = Offset(cx - pw2 / 2, ly - 3.dp.toPx()), size = Size(pw2, lay.size.height + 6.dp.toPx()), cornerRadius = CornerRadius(8.dp.toPx()))
            }
            drawText(lay, topLeft = Offset(cx - lay.size.width / 2f, ly))
        }
    }
}

/* ================= pintasan ================= */

@Composable
private fun ShortCard(ic: Ic, tint: Color, title: String, value: String, sub: String, modifier: Modifier, warm: Boolean = false, onClick: () -> Unit) {
    val pal = LocalPal.current
    Column(
        modifier.fillMaxHeight().pressable(onClick, scaleTo = 0.98f)
            .lejarCard(pal, bg = if (warm) pal.amberSoft else pal.surface)
            .then(if (warm) Modifier.border(1.dp, pal.amber.copy(alpha = 0.22f), RoundedCornerShape(R_CARD)) else Modifier)
            .semantics(mergeDescendants = true) { }
            .padding(horizontal = 12.dp, vertical = 12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconTile(ic, tint, size = 36.dp, icon = 20.dp, bg = if (warm) pal.surface.copy(alpha = 0.7f) else null)
            Spacer(Modifier.width(8.dp))
            Txt(title, Modifier.weight(1f), size = 15f, weight = FontWeight.Bold, color = if (warm) pal.amber else pal.ink, maxLines = 2, lh = 19f)
            Ico(Ic.CHEVRON, pal.muted, 16.dp, stroke = 2f)
        }
        Spacer(Modifier.height(8.dp))
        AutoMoney(value, 17f, Modifier.fillMaxWidth())
        Txt(sub, size = 12f, color = pal.muted, maxLines = 2, lh = 16f)
    }
}

@Composable
private fun QuickBtn(ic: Ic, label: String, modifier: Modifier, onClick: () -> Unit) {
    val pal = LocalPal.current
    Column(
        modifier.clip(RoundedCornerShape(12.dp)).pressable(onClick, scaleTo = 0.94f).heightIn(min = 84.dp).padding(horizontal = 1.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        // jubin putih berbayang dengan ikon ungu (butang tindakan templat)
        Box(Modifier.size(50.dp).lejarCard(pal, radius = 16.dp, elevation = 3.dp), contentAlignment = Alignment.Center) {
            IconTile(ic, pal.accent, size = 40.dp, icon = 22.dp, bg = pal.accentSoft, radius = 12.dp)
        }
        Txt(label, size = 11.5f, weight = FontWeight.Medium, align = TextAlign.Center, maxLines = 2, lh = 14f)
    }
}
