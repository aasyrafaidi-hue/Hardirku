package com.asyraf.hadirku.pg

import com.asyraf.hadirku.pg.PG.fmtDate
import com.asyraf.hadirku.pg.PG.fmtMonth
import com.asyraf.hadirku.pg.PG.fmtShort
import com.asyraf.hadirku.pg.PG.jsNum
import com.asyraf.hadirku.pg.PG.round2
import com.asyraf.hadirku.pg.PG.ym
import kotlin.math.max
import kotlin.math.min

/** Fail CFO: Markdown untuk dihantar kepada Claude sebagai CFO peribadi (port cfoMarkdown v0.9.3). */
object PgCfo {
    const val MATLAMAT_LALAI = "Kawal belanja, langsaikan hutang kad, bina dana kecemasan, kemudian mula simpan dan labur."
    private val STATUS_HUTANG = mapOf(
        "langsai" to "Langsai", "sudah" to "Sudah bayar bulan ini", "pelan" to "Pelan dibayar, belanja kad belum",
        "min" to "Minimum sahaja", "separuh" to "Separuh", "belum" to "Belum bayar",
    )

    fun mdSel(s: String?): String = (s ?: "").replace("|", "/").replace(Regex("[\\r\\n]+"), " ").trim()
    fun mdJadual(head: List<String>, rows: List<List<String>>, align: String): String {
        val al = head.mapIndexed { i, _ -> if (align.getOrNull(i) == 'r') "---:" else "---" }
        return "| " + head.joinToString(" | ") { mdSel(it) } + " |\n| " + al.joinToString(" | ") + " |\n" +
            rows.joinToString("\n") { r -> "| " + r.joinToString(" | ") { mdSel(it) } + " |" }
    }
    private fun tarikhPanjang(s: String): String { val p = PG.parse(s); return "${p.d} ${PG.BULAN_PENUH[p.m - 1]} ${p.y}" }

    data class Opts(val versi: String? = null, val matlamat: String? = null, val soalan: String? = null, val transaksi: Boolean = true)

    fun cfoMarkdown(state: PgState, today: String, opts: Opts = Opts()): String {
        val g = state.settings.gaji
        val sd = state.settings.otMulaHari.takeIf { it > 0 } ?: 22
        val bal = PG.balances(state)
        val dom = PG.dompetSet(state)
        val pkKec = PG.cariPoket(state, Regex("kecemasan|emergency|darurat", RegexOption.IGNORE_CASE))
        val akruan = state.settings.otPendapatan
        val adv = g.advance
        val L = ArrayList<String>()
        val okc = PG.otKitaranBulan(state, ym(today)).cycle
        val contohOt = PG.BULAN_PENUH[PG.parse(okc.bayarYm + "-01").m - 1] + " = OT " + fmtShort(okc.start) + " – " + fmtShort(okc.end)
        fun pn(id: String) = PG.pocketName(state, id)
        fun M(x: Double?) = PG.money(PG.num(x))
        fun h2(t: String) { L.add(""); L.add("## $t"); L.add("") }
        val tot = PG.total(state)
        val tdom = PG.totalDompet(state)
        val bs = PG.bankStatus(state)
        val adaDom = dom.isNotEmpty()
        val adaTunai = state.pockets.any { it.tunai }
        val adaEw = state.pockets.any { it.dompet && !it.tunai }
        val asas = round2(g.basic + g.night + g.transport)
        val bersih = round2(asas - g.potongan)
        val cs = PG.commitmentStatus(state, today)
        val komit = round2(cs.sumOf { it.jumlah })
        val dl = PG.debtStatus(state, today)
        val dsum = PG.debtSummary(dl)
        val minH = round2(dl.sumOf { if (it.status == "langsai") 0.0 else it.min })
        val wajib = round2(komit + minH)
        val jurang = round2(wajib - bersih)
        val kadarOt = round2(PG.hrp(g) * 1.5)
        val kini = PG.otCycleOf(today, sd)
        val otL = ArrayList<Double>()
        for (i in 1..3) { val so = PG.otSummary(state, PG.shiftCycle(kini, -i, sd)); if (so.hari > 0) otL.add(so.nilai) }
        val otPurata = if (otL.isNotEmpty()) round2(otL.sum() / otL.size) else 0.0
        val faedahKad = round2(dl.sumOf { if (it.jenis == "kad" && it.baki > 0) it.baki * it.kadar / 1200 else 0.0 })
        val d90 = PG.addDays(today, -89)
        var harian90 = 0.0
        var awal: String? = null
        state.transactions.forEach { t ->
            if (t.tarikh <= today && (awal == null || t.tarikh < awal!!)) awal = t.tarikh
            if (t.tarikh < d90 || t.tarikh > today) return@forEach
            if (t.jenis == "kad" || (t.jenis == "keluar" && t.komitmenId.isEmpty() && t.hutangId.isEmpty())) harian90 += t.jumlah
        }
        val aw = awal
        val hari90 = if (aw != null) max(7, min(90, PG.hariAntara(if (aw > d90) aw else d90, today) + 1)) else 90
        val sehari = round2(harian90 / hari90)

        L.add("# Fail CFO PoketGaji · " + tarikhPanjang(today))
        L.add("")
        L.add("Dijana oleh PoketGaji" + (if (opts.versi != null) " v" + opts.versi else "") + " pada " + fmtDate(today) +
            ". Semua angka dikira oleh app daripada rekod pemilik. Mata wang: Ringgit Malaysia (RM)." +
            (if (state.contoh) " **Perhatian: ini DATA CONTOH dalam app, bukan data sebenar.**" else ""))

        h2("1. Arahan untuk Claude (CFO)")
        L.addAll(listOf(
            "Kau ialah CFO peribadi aku. Aku pekerja kilang yang bergantung pada gaji tetap dan OT. Baca semua bahagian fail ini dulu, kemudian jawab.", "",
            "**Peraturan:**",
            "- Guna angka dalam fail ini. Kalau kau kira sendiri, tunjuk kiraan ringkas. Jangan reka angka atau transaksi.",
            "- Jujur dan terus terang. Kalau keadaan bahaya (contohnya bayaran wajib lebih besar daripada gaji tetap), kata terus.",
            "- Keutamaan asas: bayaran wajib tepat masa → hutang faedah tinggi → dana kecemasan → simpanan & pelaburan. Kalau matlamat aku (bahagian 2) lain, terangkan untung rugi setiap pilihan dengan angka.",
            "- Bahasa Melayu santai (aku/kau), ringkas tapi lengkap. Guna senarai dan jadual kecil bila membantu.",
            "- Ini bukan nasihat kewangan berlesen. Jangan cadang saham, kripto atau produk pelaburan khusus; boleh terangkan pilihan umum (KWSP, ASB, simpanan tetap, dana indeks) dan kesan angkanya.", "",
            "**Format jawapan:**",
            "1. Keadaan sekarang dalam 3 ayat.",
            "2. Tiga perkara paling penting, dengan angka dan sebab.",
            "3. Pelan 30 hari: tindakan ikut tarikh dan poket (contoh: \"30hb: pindah RMx ke poket Y\").",
            "4. Jawapan untuk soalan aku (bahagian 2), kalau ada.",
            "5. Data yang kurang atau nampak salah (bahagian 11), dan soalan untuk aku.",
        ))

        h2("2. Matlamat & soalan aku")
        L.add("**Matlamat kewangan:** " + mdSel(opts.matlamat?.takeIf { it.isNotEmpty() } ?: MATLAMAT_LALAI))
        L.add("")
        L.add("**Soalan kali ini:** " + (if (!opts.soalan.isNullOrBlank()) mdSel(opts.soalan) else "Tiada soalan khusus. Buat semakan bulanan penuh."))

        h2("3. Cara app mengira (penting untuk faham angka)")
        L.add("- Semua duit dalam satu akaun bank. Poket hanyalah pembahagian maya; jumlah semua poket (kecuali e-wallet" + (if (adaTunai) " dan dompet tunai" else "") + ") sama dengan baki bank.")
        L.add("- Duit masuk (gaji, advance) masuk ke poket **Belum Agih** dulu, kemudian dipindah ke poket lain.")
        L.add(if (adv > 0) "- Gaji dibayar dua kali: advance " + M(adv) + " pada 15hb dan baki gaji pada 30hb. Komitmen ditanda \"bayar guna gaji 15hb\" atau \"30hb\"." else "- Gaji dibayar sekali sebulan pada hujung bulan.")
        L.add("- OT dikira ikut kitaran " + sd + "hb hingga " + (if (sd - 1 != 0) sd - 1 else 30) + "hb dan dibayar dalam gaji 30hb bulan berikutnya. Kadar sejam (HRP) = (gaji asas + elaun) ÷ 26 ÷ 8 = " + M(PG.hrp(g)) +
            ". Hari biasa: jam selepas " + jsNum(if (g.jamNormal != 0.0 && !g.jamNormal.isNaN()) g.jamNormal else 9.0) + " jam = 1.5x; off day: semua jam 1.5x; rest day & cuti umum: jam normal 2.0x, lebihan 3.0x.")
        L.add(if (akruan) "- Laporan bulanan: pendapatan = duit masuk − bahagian OT dalam gaji + OT kitaran yang dibayar dalam gaji bulan itu (contoh " + contohOt + ", bukan 1hb hingga 30hb). Perbelanjaan = belanja harian (termasuk guna kad) + komitmen + ansuran pinjaman + faedah, caj & fee kad. Bayar kad = pindah ke kad, bukan belanja."
            else "- Laporan ikut duit masuk & keluar bank sahaja (lejar tunai).")
        L.add("- Guna kad kredit: dikira belanja pada hari beli; jumlah itu dipindah dari poket belanja ke poket bayaran kad supaya duit sudah diasingkan.")
        L.add("- Tunai dari kad (contoh tambah nilai Touch 'n Go guna kad): pinjaman, bukan pendapatan; hutang kad bertambah jumlah + fee, dan fee dikira perbelanjaan.")
        L.add("- Bayaran kad bulan ini = pelan (rancangan atau minimum) + belanja & tunai kad bulan ini; bayaran ditolak dari pelan dulu." + (if (adaEw || (adaDom && !adaTunai)) "\n- Poket e-wallet berada di luar bank dan tidak dikira dalam baki bank." else "") +
            (if (adaTunai) "\n- Poket dompet tunai ialah duit tunai fizikal dalam dompet, di luar bank. Ambil duit di ATM = pindah dari poket bank ke dompet tunai; belanja tunai = Keluar dari dompet tunai." else ""))

        h2("4. Gambaran ringkas")
        val rows4 = ArrayList<List<String>>()
        rows4.add(listOf("Baki bank (semua poket kecuali e-wallet" + (if (adaTunai) " & tunai" else "") + ")", M(tot)))
        if (adaTunai) {
            if (adaEw) rows4.add(listOf("E-wallet", M(PG.totalEwallet(state))))
            rows4.add(listOf("Tunai dalam dompet", M(PG.totalTunai(state))))
        } else if (adaDom) rows4.add(listOf("E-wallet", M(tdom)))
        rows4.add(listOf("Belum Agih (belum diagih ke poket)", M(bal[PG.BELUM_AGIH] ?: 0.0)))
        rows4.add(listOf("Semakan bank terakhir", if (bs != null) fmtDate(bs.check.tarikh) + (if (Math.abs(bs.beza) < 0.005) " · sama dengan app" else " · beza " + M(bs.beza)) else "Belum pernah"))
        rows4.add(listOf("Gaji tetap bersih sebulan (tanpa OT)", M(bersih) + (if (adv > 0) " (advance " + M(adv) + " + baki 30hb " + M(bersih - adv) + ")" else "")))
        rows4.add(listOf("Purata OT sebulan (" + otL.size + " kitaran lepas)", if (otL.isNotEmpty()) M(otPurata) else "Tiada log OT"))
        rows4.add(listOf("Komitmen sebulan", M(komit) + " (" + cs.size + " komitmen)"))
        rows4.add(listOf("Minimum hutang bulan ini", M(minH)))
        rows4.add(listOf("Bayaran wajib sebulan (komitmen + minimum hutang)", M(wajib)))
        rows4.add(listOf("Jurang gaji tetap berbanding bayaran wajib",
            if (jurang > 0.004) M(jurang) + (if (kadarOt > 0) " ≈ " + jsNum(PG.jsRound(jurang / kadarOt * 10) / 10) + " jam OT pada 1.5x (" + M(kadarOt) + " sejam)" else "")
            else "Tiada jurang (gaji tetap lebih " + M(-jurang) + ")"))
        rows4.add(listOf("Jumlah hutang", M(dsum.baki) + (if (dsum.epp > 0.004) " (termasuk EPP belum dibil " + M(dsum.epp) + ")" else "")))
        rows4.add(listOf("Anggaran faedah kad sebulan", M(faedahKad)))
        rows4.add(listOf("Dana kecemasan", if (pkKec.isNotEmpty()) M(bal[pkKec] ?: 0.0) + " dalam " + pn(pkKec) +
            (if (wajib > 0) " (≈ " + PG.toFixed((bal[pkKec] ?: 0.0) / wajib, 1) + " bulan bayaran wajib)" else "") else "Tiada poket bernama dana kecemasan"))
        rows4.add(listOf("Purata belanja harian ($hari90 hari)", M(sehari) + " sehari (≈ " + M(sehari * 30) + " sebulan)"))
        L.add(mdJadual(listOf("Perkara", "Nilai"), rows4, "lr"))

        h2("5. Gaji & OT")
        val hr = PG.hrp(g)
        L.add(mdJadual(listOf("Tetapan", "Nilai"), listOf(
            listOf("Gaji asas", M(g.basic)), listOf("Elaun shift malam", M(g.night)), listOf("Elaun transport", M(g.transport)),
            listOf("Anggaran potongan (KWSP, PERKESO, PCB, dll.)", M(g.potongan)),
            listOf("Advance 15hb", M(adv)), listOf("Jam normal sehari", jsNum(PG.num(g.jamNormal))), listOf("Had OT sebulan", jsNum(PG.num(g.hadOT)) + " jam"),
            listOf("Kadar sejam (HRP)", M(hr)), listOf("OT 1.5x / 2.0x / 3.0x sejam", M(hr * 1.5) + " / " + M(hr * 2) + " / " + M(hr * 3)),
        ), "lr"))
        L.add("")
        val otRows = ArrayList<List<String>>()
        for (k in 5 downTo 0) {
            val cy = PG.shiftCycle(kini, -k, sd)
            val s2 = PG.otSummary(state, cy)
            otRows.add(listOf(fmtShort(cy.start) + " – " + fmtShort(cy.end) + (if (k == 0) " (sedang berjalan)" else ""), fmtMonth(cy.bayarYm), s2.hari.toString(),
                jsNum(round2(s2.h15)), jsNum(round2(s2.h20)), jsNum(round2(s2.h30)), M(s2.nilai), M(s2.gaji30)))
        }
        L.add("**OT 6 kitaran** (hari = hari yang direkod dalam log OT):")
        L.add("")
        L.add(mdJadual(listOf("Kitaran", "Dibayar dalam gaji", "Hari", "Jam 1.5x", "Jam 2.0x", "Jam 3.0x", "Nilai OT", "Anggaran gaji 30hb"), otRows, "llrrrrrr"))

        h2("6. Poket")
        val per0 = PG.commitmentPeriod(today, 1)
        val rNow = PG.periodReport(state, per0)
        val rPrev = PG.periodReport(state, PG.shiftPeriod(per0, -1, 1))
        val ct = PG.targetsFromCommitments(state, today)
        L.add(mdJadual(listOf("Poket", "Baki", "Sasaran sebulan", "Belanja bulan ini", "Belanja bulan lepas", "Nota"), state.pockets.map { p ->
            val nota = ArrayList<String>()
            if (p.id == PG.BELUM_AGIH) nota.add("duit masuk sebelum diagih")
            if (p.tunai) nota.add("tunai dalam dompet, luar bank") else if (p.dompet) nota.add("e-wallet, luar bank")
            if (p.id == pkKec) nota.add("dana kecemasan")
            val tg = round2((ct[p.id] ?: 0.0) + p.sasaran)
            listOf(p.nama, M(bal[p.id] ?: 0.0), if (tg > 0) M(tg) else "–", M(rNow.poket[p.id] ?: 0.0), M(rPrev.poket[p.id] ?: 0.0), nota.joinToString(", "))
        }, "lrrrrl"))
        L.add("")
        L.add("Sasaran = tambahan sebulan + komitmen & bayaran hutang yang guna poket itu. Belanja = Keluar + Guna kad dari poket itu.")

        h2("7. Komitmen bulanan (" + fmtMonth(ym(today)) + ")")
        L.add(if (cs.isNotEmpty()) mdJadual(listOf("Komitmen", "Bayar guna gaji", "Jumlah", "Poket", "Status bulan ini"),
            cs.map { c -> listOf(c.nama, c.kitaran + "hb", M(c.jumlah), pn(c.poket), if (c.status == "sudah") "Sudah" else if (c.status == "separuh") "Separuh, baki " + M(c.baki) else "Belum") } +
                listOf(listOf("**Jumlah**", "", M(komit), "", "")), "llrll") else "Tiada komitmen direkod.")

        h2("8. Hutang & kad kredit")
        if (dl.isEmpty()) L.add("Tiada hutang direkod.")
        else {
            L.add(mdJadual(listOf("Hutang", "Jenis", "Baki", "Pokok EPP belum dibil", "Faedah EPP belum dibil", "Kadar setahun", "Had kredit", "Minimum bulan ini", "Pelan sebulan", "Dibayar bulan ini", "Status"), dl.map { d ->
                val jh = PG.JENIS_HUTANG.find { it.id == d.jenis }
                listOf(d.nama, jh?.label ?: d.jenis, M(d.baki), if (d.eppBaki > 0.004) M(d.eppPokok) else "–", if (d.eppBaki > 0.004) M(d.eppFaedah) else "–", jsNum(PG.num(d.kadar)) + "%",
                    if (d.d.hadKredit > 0) M(d.d.hadKredit) + " (guna " + PG.jsRound((d.guna ?: 0.0) * 100).toLong() + "%)" else "–",
                    M(d.min), M(d.sasaranAsal), M(d.dibayar), STATUS_HUTANG[d.status] ?: d.status)
            }, "llrrrrrrrrl"))
            val kadMin = dl.filter { it.jenis == "kad" && it.minInfo != null && it.min > 0.004 }
            if (kadMin.isNotEmpty()) L.add("")
            kadMin.forEach { d ->
                val mi = d.minInfo!!
                L.add("- Minimum " + d.nama + ": " + (if (mi.cara == "biasa") "ansuran EPP bulan ini penuh + " + jsNum(mi.peratus) + "% baki selebihnya"
                    else jsNum(mi.peratus) + "% × pokok (baki kad + pokok EPP belum dibil = " + M(mi.asas) + ")") + " → " + M(d.min) + ".")
            }
            val eppL = ArrayList<String>()
            dl.forEach { d -> d.d.epp.forEach { pl -> val e = PG.eppInfo(pl, today); if (e.aktif) eppL.add("- " + d.nama + " · " + mdSel(pl.nama.ifEmpty { "EPP" }) + ": ansuran " + M(e.ans) + " sebulan, baki " + e.bakiBulan + " bulan, berjadual " + M(e.baki) +
                (if (!e.pokokTahu) " (pecahan pokok/faedah tidak diketahui)" else " (pokok ansuran seterusnya " + M(e.pokokAns) + " + faedah " + M(e.faedahAns) + "; baki pokok " + M(e.pokokBaki) + " + faedah akan datang " + M(e.faedahBaki) + ")") +
                (if (e.kaedah == "baki") ", kaedah baki berkurang ≈" + PG.toFixed(e.kadarNominal ?: 0.0, 2) + "% setahun (anggaran)" else "") + ", tamat " + fmtMonth(ym(e.tamat)) + ".") } }
            if (eppL.isNotEmpty()) { L.add(""); L.add("**EPP aktif:**"); L.add(eppL.joinToString("\n")) }
            val bajet = state.settings.hutangBajet
            val strat = if (state.settings.hutangStrategi == "snowball") "snowball" else "avalanche"
            val pl2 = PG.debtPlan(state, bajet, strat, today)
            if (!pl2.kosong) {
                fun bila(n: Int, never: Boolean) = if (never) "tidak langsai (bayaran tak cukup tampung faedah)" else "langsai dalam $n bulan (" + fmtMonth(ym(PG.addMonths(today, n))) + ")"
                val a = pl2.asas!!
                L.add(""); L.add("**Unjuran:**"); L.add("- Bayar minimum sahaja: " + bila(a.bulan, a.never) + ", faedah anggaran " + M(a.faedah) + ".")
                if (pl2.cukup) L.add("- Ikut bajet hutang " + M(bajet) + " sebulan (" + strat + "): " + bila(pl2.bulan, pl2.never) + ", faedah anggaran " + M(pl2.faedah) + (if (pl2.jimatFaedah != null) ", jimat " + M(pl2.jimatFaedah) + " faedah" else "") + ".")
                else if (bajet > 0) L.add("- Bajet hutang " + M(bajet) + " sebulan kurang daripada jumlah minimum " + M(pl2.minimum) + ".")
            }
        }

        h2("9. Ringkasan 6 bulan")
        class Rep(val per: Period, val r: PeriodReport, val kini: Boolean)
        val mRows = ArrayList<List<String>>()
        var ada9 = false
        var tunaiAda = false
        val reps = ArrayList<Rep>()
        for (m in 5 downTo 0) { val pm = PG.shiftPeriod(per0, -m, 1); val r = PG.periodReport(state, pm); reps.add(Rep(pm, r, m == 0)); if (r.tunaiKad > 0) tunaiAda = true }
        reps.forEach { x ->
            val r = x.r
            if (!ada9 && !(r.masuk != 0.0 || r.keluar != 0.0 || r.kad != 0.0 || r.otEarned != 0.0)) return@forEach
            ada9 = true
            val row = arrayListOf(fmtMonth(ym(x.per.start)) + (if (x.kini) " (setakat " + fmtShort(today) + ")" else ""), M(r.masuk), M(r.otEarned), M(r.pend), M(r.harian), M(r.komitmen), M(r.bayarPinjaman), M(r.bayarKad), M(r.kadLog), M(r.belanja), M(r.lebihan))
            if (tunaiAda) row.add(4, M(r.tunaiKad))
            mRows.add(row)
        }
        val head9 = arrayListOf("Bulan", "Duit masuk", "OT kitaran bulan itu", "Pendapatan", "Belanja harian", "Komitmen", "Bayar pinjaman", "Bayar kad", "Faedah & caj kad", "Perbelanjaan", "Lebihan")
        if (tunaiAda) head9.add(4, "Tunai dari kad")
        L.add(if (mRows.isNotEmpty()) mdJadual(head9, mRows, "l" + "r".repeat(head9.size - 1)) else "Belum ada transaksi.")
        L.add("")
        L.add("OT kitaran bulan itu = OT yang dibayar dalam gaji bulan itu (contoh $contohOt). Pendapatan = duit masuk − bahagian OT dalam gaji + OT kitaran bulan itu. Belanja harian termasuk guna kad. Perbelanjaan = belanja harian + komitmen + bayar pinjaman + faedah & caj kad (bayar kad tidak dikira).")

        h2("10. Belanja harian ikut kategori (3 bulan)")
        val kr = reps.takeLast(3)
        val kats = LinkedHashMap<String, Double>()
        kr.forEach { x -> x.r.katHarian.forEach { (kk, v) -> kats[kk] = (kats[kk] ?: 0.0) + v } }
        val kRows = kats.keys.sortedWith { a, b -> java.lang.Double.compare(kats.getValue(b), kats.getValue(a)) }.map { kk ->
            listOf(PG.katLabel(kk)) + kr.map { x -> M(x.r.katHarian[kk] ?: 0.0) }
        }
        L.add(if (kRows.isNotEmpty()) mdJadual(listOf("Kategori") + kr.map { x -> fmtMonth(ym(x.per.start)) + (if (x.kini) " (setakat " + fmtShort(today) + ")" else "") }, kRows, "lrrr")
            else "Tiada belanja harian dalam 3 bulan ini.")

        h2("11. Semakan data")
        val semak = ArrayList<String>()
        semak.add("- Semakan bank terakhir: " + (if (bs != null) fmtDate(bs.check.tarikh) + (if (Math.abs(bs.beza) < 0.005) ", sama dengan app." else ", beza " + M(bs.beza) + " (bank tolak app).") +
            (if (PG.hariAntara(bs.check.tarikh, today) > 14) " Sudah " + PG.hariAntara(bs.check.tarikh, today) + " hari tak disemak." else "") else "belum pernah dibuat."))
        val t90 = state.transactions.filter { it.tarikh >= d90 && it.tarikh <= today }
        val tk = t90.filter { PG.bolehKategori(it) && !PG.katValid(it.kategori) }
        semak.add("- Belanja tanpa kategori (90 hari): " + tk.size + " transaksi, " + M(tk.sumOf { it.jumlah }) + ".")
        val dup = ArrayList<String>()
        val seen = HashMap<String, Tx>()
        t90.filter { it.jenis == "keluar" || it.jenis == "kad" }.sortedWith { a, b -> a.tarikh.compareTo(b.tarikh) }.forEach { t ->
            val key = t.jenis + "|" + PG.normNama(t.perkara) + "|" + jsNum(round2(t.jumlah))
            val prev = seen[key]
            if (prev != null && PG.hariAntara(prev.tarikh, t.tarikh) <= 1) dup.add(fmtDate(t.tarikh) + " · " + mdSel(t.perkara.ifEmpty { "(tiada nama)" }) + " · " + M(t.jumlah))
            seen[key] = t
        }
        semak.add("- Kemungkinan transaksi berganda (nama & jumlah sama dalam 1 hari): " + (if (dup.isNotEmpty()) dup.take(10).joinToString("; ") + (if (dup.size > 10) " (+" + (dup.size - 10) + " lagi)" else "") else "tiada."))
        var kosong = 0
        val lepasC = PG.shiftCycle(kini, -1, sd)
        (lepasC.days + kini.days).forEach { dt -> if (dt < today && !state.ot.containsKey(dt)) kosong++ }
        semak.add("- Log OT: " + kosong + " hari belum diisi dalam kitaran " + fmtShort(lepasC.start) + " – " + fmtShort(kini.end) + " (sehingga semalam). Hari kosong dianggap tiada OT.")
        val neg = state.pockets.filter { (bal[it.id] ?: 0.0) < -0.004 }
        if (neg.isNotEmpty()) semak.add("- Poket negatif: " + neg.joinToString("; ") { it.nama + " " + M(bal[it.id]) } + ".")
        val tun = t90.filter { it.jenis == "tunai-kad" }
        if (tun.isNotEmpty()) semak.add("- Tunai dari kad (90 hari): " + tun.size + " kali, " + M(tun.sumOf { it.jumlah }) + ", fee " + M(tun.sumOf { it.fee ?: 0.0 }) + ".")
        L.add(semak.joinToString("\n"))

        if (opts.transaksi) {
            h2("12. Transaksi 90 hari (terbaru dahulu)")
            val list = t90.sortedWith { a, b -> val c = b.tarikh.compareTo(a.tarikh); if (c != 0) c else b.dibuat.compareTo(a.dibuat) }
            val lim = 500
            val rows13 = list.take(lim).map { t ->
                val jn = PG.JENIS.find { it.id == t.jenis }
                val bt = ArrayList<String>()
                if (t.jenis == "pindah") bt.add("ke " + pn(t.ke))
                if (t.jenis == "kad" || t.jenis == "tunai-kad") {
                    val kd = state.debts.find { it.id == t.kadId }
                    bt.add((if (t.jenis == "kad") "guna " else "dari ") + (kd?.nama ?: "kad"))
                    if (t.jenis == "tunai-kad" && (t.fee ?: 0.0) > 0) bt.add("fee " + M(t.fee))
                }
                if (t.komitmenId.isNotEmpty()) { val kc = state.commitments.find { it.id == t.komitmenId }; bt.add("komitmen" + (if (kc != null) ": " + kc.nama else "")) }
                if (t.hutangId.isNotEmpty()) { val hd = state.debts.find { it.id == t.hutangId }; bt.add("bayar hutang" + (if (hd != null) ": " + hd.nama else "")) }
                if (PG.bolehKategori(t)) bt.add(PG.katLabel(PG.kategoriOf(t)))
                listOf(fmtDate(t.tarikh), jn?.label ?: t.jenis, t.perkara, M(t.jumlah), pn(t.poket), bt.joinToString(" · "))
            }
            L.add(if (rows13.isNotEmpty()) mdJadual(listOf("Tarikh", "Jenis", "Perkara", "Jumlah", "Poket", "Butiran"), rows13, "lllrll") else "Tiada transaksi dalam 90 hari.")
            if (list.size > lim) { L.add(""); L.add("(" + (list.size - lim) + " transaksi lebih lama tidak dimasukkan.)") }
        }
        L.add(""); L.add("---"); L.add("Tamat fail CFO PoketGaji.")
        return L.joinToString("\n") + "\n"
    }
}
