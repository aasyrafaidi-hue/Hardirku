package com.asyraf.hadirku.ai

import com.asyraf.hadirku.data.Repo
import com.asyraf.hadirku.net.Api
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.PgState
import com.asyraf.hadirku.pg.Tx
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.SocketTimeoutException
import java.util.Locale

class AiError(msg: String) : Exception(msg)

private fun jarr(vararg s: String): JSONArray = JSONArray().also { a -> s.forEach { a.put(it) } }

/** Bulan ini: bilangan panggilan, token dan anggaran kos (USD). */
data class AiUsage(val n: Int = 0, val usd: Double = 0.0, val inTok: Long = 0, val outTok: Long = 0)

/** Hasil satu panggilan alat: input alat (jawapan berstruktur) dan anggaran kos. */
class AiToolResult(val data: JSONObject, val usd: Double)

/**
 * Pembantu AI (Claude) dengan kunci API pengguna sendiri. Kunci & tetapan disimpan dalam
 * telefon sahaja (bukan dalam data / fail salinan). Port daripada PoketGaji v0.9.3.
 */
object Ai {
    /** Bahasa untuk teks yang dipapar kepada pengguna (ringkasan resit, nota). */
    private fun bahasaJawapan(): String = if (com.asyraf.hadirku.pg.PG.en) "in British English" else "dalam Bahasa Melayu"

    const val MODEL_LALAI = "claude-haiku-5-5"
    const val TEMPAT = "Tetapan → Pembantu AI"
    private val HARGA = mapOf(MODEL_LALAI to doubleArrayOf(0.10, 0.50)) // USD sejuta token: input, output

    fun key(): String = Repo.getStr("ai.key").trim()
    fun model(): String = Repo.getStr("ai.model").trim().ifEmpty { MODEL_LALAI }
    fun ready(): Boolean = key().isNotEmpty()
    fun autoKat(): Boolean = Repo.getBool("ai.autoKat", true)
    fun setAutoKat(v: Boolean) = Repo.putBool("ai.autoKat", v)
    fun setKey(k: String) = Repo.putStr("ai.key", k.trim())
    fun setModel(m: String) = Repo.putStr("ai.model", m.trim().ifEmpty { MODEL_LALAI })
    fun deleteKey() = Repo.remove("ai.key")
    fun mask(k: String): String = "••••" + (if (k.length > 10) k.takeLast(4) else "")

    fun usageMonth(today: String): AiUsage {
        val g = runCatching { JSONObject(Repo.getStr("ai.guna", "{}")) }.getOrNull() ?: JSONObject()
        val m = g.optJSONObject(PG.ym(today)) ?: return AiUsage()
        return AiUsage(m.optInt("n"), m.optDouble("usd", 0.0), m.optLong("inTok"), m.optLong("outTok"))
    }

    private fun noteUsage(u: JSONObject?, today: String): Double {
        val g = runCatching { JSONObject(Repo.getStr("ai.guna", "{}")) }.getOrNull() ?: JSONObject()
        val ym = PG.ym(today)
        val m = g.optJSONObject(ym) ?: JSONObject().put("n", 0).put("usd", 0.0).put("inTok", 0).put("outTok", 0)
        val pr = HARGA[model()]
        val i = u?.optLong("input_tokens") ?: 0L
        val o = u?.optLong("output_tokens") ?: 0L
        val usd = if (pr != null) (i * pr[0] + o * pr[1]) / 1e6 else 0.0
        m.put("n", m.optInt("n") + 1)
        m.put("inTok", m.optLong("inTok") + i)
        m.put("outTok", m.optLong("outTok") + o)
        m.put("usd", Math.round((m.optDouble("usd", 0.0) + usd) * 1e6) / 1e6)
        g.put(ym, m)
        Repo.putStr("ai.guna", g.toString())
        return usd
    }

    private fun errMsg(status: Int, j: JSONObject?): String {
        val err = j?.optJSONObject("error")
        val m = err?.optString("message", "") ?: ""
        val code = err?.optJSONObject("details")?.optString("error_code", "") ?: ""
        if (Regex("credit balance", RegexOption.IGNORE_CASE).containsMatchIn(m)) return "Baki kredit akaun Anthropic tidak cukup. Tambah kredit di platform.claude.com → Billing."
        if (code == "enforced_spend_limit_reached" || Regex("reached your (specified )?(workspace )?API usage limits", RegexOption.IGNORE_CASE).containsMatchIn(m))
            return "Had belanja bulanan akaun Anthropic sudah dicapai. Naikkan had di platform.claude.com → Billing, atau tunggu bulan depan."
        if (status == 401) return "Kunci API tidak sah. Semak semula di $TEMPAT."
        if (status == 403) return "Kunci ini tiada kebenaran untuk model ${model()}."
        if (status == 404) return "Model \"${model()}\" tidak dijumpai. Semak nama model di Tetapan."
        if (status == 413) return "Fail terlalu besar. Cuba gambar yang lebih kecil."
        if (status == 400 && Regex("pdf|document", RegexOption.IGNORE_CASE).containsMatchIn(m)) return "PDF ini tak dapat dibaca (mungkin berkata laluan atau rosak). Ambil tangkapan skrin dan imbas gambar itu."
        if (status == 429) return "Terlalu banyak permintaan. Tunggu sebentar dan cuba lagi."
        if (status == 529 || status == 503 || status == 500) return "Pelayan AI sibuk. Cuba lagi sebentar."
        return "Ralat AI ($status)" + (if (m.isNotEmpty()) ": $m" else "") + "."
    }

    suspend fun call(body: JSONObject, timeoutMs: Int = 60_000): JSONObject = withContext(Dispatchers.IO) {
        if (!ready()) throw AiError("Belum ada kunci API. Tetapkan di $TEMPAT.")
        val res = try {
            Api.anthropicRaw(key(), body.toString(), timeoutMs)
        } catch (e: SocketTimeoutException) {
            throw AiError("AI ambil masa terlalu lama. Cuba lagi.")
        } catch (e: IOException) {
            throw AiError("Tak dapat sambung ke AI. Semak internet dan cuba lagi.")
        }
        val j = runCatching { JSONObject(res.body) }.getOrNull()
        if (res.code !in 200..299) throw AiError(errMsg(res.code, j))
        j ?: JSONObject()
    }

    /** Panggil AI dengan satu alat wajib (jawapan sentiasa berstruktur). */
    suspend fun tool(body: JSONObject, nama: String, today: String, timeoutMs: Int = 60_000): AiToolResult {
        body.put("tool_choice", JSONObject().put("type", "tool").put("name", nama))
        val j = call(body, timeoutMs)
        val usd = noteUsage(j.optJSONObject("usage"), today)
        val content = j.optJSONArray("content") ?: JSONArray()
        for (i in 0 until content.length()) {
            val c = content.optJSONObject(i) ?: continue
            if (c.optString("type") == "tool_use" && c.optString("name") == nama) {
                val inp = c.optJSONObject("input")
                if (inp != null) return AiToolResult(inp, usd)
            }
        }
        throw AiError("AI tak pulangkan jawapan yang lengkap. Cuba lagi.")
    }

    suspend fun test(today: String) {
        val body = JSONObject().put("model", model()).put("max_tokens", 5)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", "Balas: OK")))
        call(body, 30_000)
        noteUsage(null, today)
    }

    /** Jawapan teks biasa (jurulatih disiplin). */
    suspend fun text(system: String, prompt: String, today: String, maxTokens: Int = 900): String {
        val body = JSONObject().put("model", model()).put("max_tokens", maxTokens).put("system", system)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
        val j = call(body, 60_000)
        noteUsage(j.optJSONObject("usage"), today)
        val content = j.optJSONArray("content") ?: JSONArray()
        val sb = StringBuilder()
        for (i in 0 until content.length()) {
            val c = content.optJSONObject(i) ?: continue
            if (c.optString("type") == "text") { if (sb.isNotEmpty()) sb.append('\n'); sb.append(c.optString("text")) }
        }
        val t = sb.toString().trim()
        if (t.isEmpty()) throw AiError("Jawapan kosong.")
        return t
    }

    // ---------------- kategori ----------------

    private fun katIds(): JSONArray = JSONArray().also { a -> PG.KATEGORI.forEach { a.put(it.id) } }
    fun katSenarai(): String = PG.KATEGORI.joinToString("\n") { "- " + it.id + ": " + it.label + " (" + it.ai + ")" }

    // ---------------- imbas resit ----------------

    class KedaiPoket(val poket: String, val nama: String, val tarikh: String)

    /** Sejarah pengguna: kedai → poket terakhir dipilih (untuk cadangan & belajar). */
    fun kedaiPoket(s: PgState): Map<String, KedaiPoket> {
        val m = HashMap<String, KedaiPoket>()
        s.transactions.filter { (it.jenis == "keluar" || it.jenis == "kad") && it.perkara.isNotEmpty() && it.komitmenId.isEmpty() && it.hutangId.isEmpty() }
            .sortedWith { a, b -> val c = a.tarikh.compareTo(b.tarikh); if (c != 0) c else a.dibuat.compareTo(b.dibuat) }
            .forEach { t -> val k = PG.normNama(t.perkara); if (k.length >= 3) m[k] = KedaiPoket(t.poket, t.perkara, t.tarikh) }
        return m
    }

    private fun resitTool(pockets: List<String>): JSONObject {
        val props = JSONObject()
            .put("boleh_baca", JSONObject().put("type", "boolean").put("description", "false jika bukan resit / bil atau terlalu kabur untuk dibaca"))
            .put("kedai", JSONObject().put("type", "string").put("description", "Nama kedai ringkas seperti orang sebut, tanpa SDN BHD / nombor pendaftaran / alamat"))
            .put("tarikh", JSONObject().put("type", "string").put("description", "Tarikh resit YYYY-MM-DD, kosong jika tiada"))
            .put("jumlah", JSONObject().put("type", "number").put("description", "Jumlah akhir dibayar dalam RM (selepas diskaun, cukai dan rounding)"))
            .put("cara_bayar", JSONObject().put("type", "string").put("enum", jarr("tunai", "kad_kredit", "kad_debit", "ewallet", "lain", "tak_pasti")))
            .put("ringkasan", JSONObject().put("type", "string").put("description", "Apa yang dibeli, pendek, " + bahasaJawapan()))
            .put("poket", JSONObject().put("type", "string").put("enum", jarr(*pockets.toTypedArray())).put("description", "Poket pengguna yang paling sesuai untuk belanja ini"))
            .put("kategori", JSONObject().put("type", "string").put("enum", katIds()).put("description", "Kategori belanja (lihat senarai dalam arahan)"))
            .put("item", JSONObject().put("type", "array").put("description", "Item utama dengan harga (maksimum 15)").put("items",
                JSONObject().put("type", "object").put("properties", JSONObject()
                    .put("nama", JSONObject().put("type", "string")).put("jumlah", JSONObject().put("type", "number")))
                    .put("required", jarr("nama", "jumlah"))))
            .put("keyakinan", JSONObject().put("type", "string").put("enum", jarr("tinggi", "sederhana", "rendah")))
            .put("nota", JSONObject().put("type", "string").put("description", "Masalah bacaan atau perkara yang pengguna perlu semak, " + bahasaJawapan()))
        return JSONObject().put("name", "rekod_resit").put("description", "Rekod maklumat daripada satu resit, bil atau bukti bayaran.")
            .put("input_schema", JSONObject().put("type", "object").put("properties", props)
                .put("required", jarr("boleh_baca", "kedai", "jumlah", "poket", "kategori", "keyakinan")))
    }

    private fun resitPrompt(s: PgState, pockets: List<String>, pdf: Boolean, today: String): String {
        val hints = kedaiPoket(s).values.sortedByDescending { it.tarikh }.take(20).map { "\"" + it.nama + "\" → " + PG.pocketName(s, it.poket) }
        return "Ini " + (if (pdf) "fail PDF" else "gambar") + " resit, bil atau bukti bayaran dari Malaysia untuk app kewangan peribadi. Baca dan panggil alat rekod_resit sekali.\n" +
            "Peraturan:\n" +
            "- jumlah: amaun AKHIR yang dibayar dalam RM, selepas diskaun, SST/cukai dan pelarasan bundar (rounding). Utamakan JUMLAH BESAR / GRAND TOTAL / NET TOTAL / TOTAL / AMOUNT DUE. Jangan guna TUNAI/CASH (duit diserah), BAKI/CHANGE (duit baki), SUBTOTAL atau jumlah kuantiti.\n" +
            "- tarikh: YYYY-MM-DD. Resit Malaysia biasanya hari/bulan/tahun. Hari ini $today. Kosongkan jika tiada.\n" +
            "- kedai: nama ringkas, contoh \"Petronas Lunas\", \"Mydin Kulim\", \"99 Speedmart\".\n" +
            "- ringkasan: apa yang dibeli, contoh \"RON95 30.25L\", \"Barang dapur, 12 item\", \"Makan tengah hari\".\n" +
            "- poket: pilih satu daripada senarai poket: " + pockets.joinToString(", ") + "." + (if (hints.isNotEmpty()) " Sejarah pilihan pengguna: " + hints.joinToString("; ") + "." else "") + "\n" +
            "- kategori: pilih yang paling sesuai dengan apa yang dibeli:\n" + katSenarai() + "\n" +
            "- cara_bayar: ikut resit. Pilih tak_pasti jika hanya tertulis VISA/MASTERCARD tanpa jelas kredit atau debit.\n" +
            "- item: item utama dengan harga (maksimum 15); kosongkan jika resit tak tunjuk item.\n" +
            "- boleh_baca false jika bukan resit atau terlalu kabur; terangkan dalam nota. keyakinan rendah jika jumlah atau tarikh kabur."
    }

    /** [block] = blok "image" atau "document" Anthropic (base64). */
    suspend fun readReceipt(s: PgState, block: JSONObject, pdf: Boolean, today: String): AiToolResult {
        var pockets = s.pockets.filter { it.id != PG.BELUM_AGIH }.map { it.nama }
        if (pockets.isEmpty()) pockets = s.pockets.map { it.nama }
        val body = JSONObject().put("model", model()).put("max_tokens", 1200)
            .put("tools", JSONArray().put(resitTool(pockets)))
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content",
                JSONArray().put(block).put(JSONObject().put("type", "text").put("text", resitPrompt(s, pockets, pdf, today))))))
        return tool(body, "rekod_resit", today, 60_000)
    }

    // ---------------- kategori automatik ----------------

    class KatGroup(val txs: MutableList<Tx>, val perkara: String, val poket: String, val catatan: String, var jumlah: Double, val komitmen: Boolean, val kad: Boolean)

    private fun katGroups(txs: List<Tx>): List<KatGroup> {
        val map = LinkedHashMap<String, KatGroup>()
        txs.forEach { t ->
            val nm = PG.normNama(t.perkara)
            val key = if (nm.length >= 2) nm else "|" + t.poket + "|" + PG.normNama(t.catatan)
            val g = map.getOrPut(key) { KatGroup(ArrayList(), t.perkara, t.poket, t.catatan, 0.0, t.komitmenId.isNotEmpty(), t.jenis == "kad") }
            g.txs.add(t); g.jumlah += t.jumlah
        }
        return map.values.toList()
    }

    private fun katTool(): JSONObject = JSONObject().put("name", "kategori_belanja").put("description", "Beri satu kategori untuk setiap belanja dalam senarai.")
        .put("input_schema", JSONObject().put("type", "object").put("properties", JSONObject().put("hasil", JSONObject().put("type", "array").put("items",
            JSONObject().put("type", "object").put("properties", JSONObject()
                .put("i", JSONObject().put("type", "integer").put("description", "Nombor belanja dalam senarai"))
                .put("k", JSONObject().put("type", "string").put("enum", katIds())))
                .put("required", jarr("i", "k"))))).put("required", jarr("hasil")))

    private fun katPrompt(s: PgState, groups: List<KatGroup>): String =
        "Kategorikan setiap belanja pengguna app kewangan peribadi di Malaysia. Panggil alat kategori_belanja sekali, dengan jawapan untuk SEMUA nombor dalam senarai.\n" +
            "Kategori:\n" + katSenarai() + "\n" +
            "Guna nama belanja dahulu; poket dan catatan hanya petunjuk. Jika tak pasti, pilih lain.\nSenarai:\n" +
            groups.mapIndexed { i, g ->
                val n = g.txs.size
                (i + 1).toString() + ". \"" + g.perkara.ifEmpty { "(tiada nama)" }.take(60) + "\" · poket " + PG.pocketName(s, g.poket) + " · " +
                    (if (n > 1) "$n kali, purata " else "") + "RM" + String.format(Locale.US, "%.2f", g.jumlah / n) +
                    (if (g.catatan.isNotEmpty()) " · catatan: " + g.catatan.take(60) else "") + (if (g.komitmen) " · bayaran komitmen bulanan" else "") + (if (g.kad) " · guna kad kredit" else "")
            }.joinToString("\n")

    class KatHasil(val sejarah: Int, val ai: Int, val usd: Double, val gagal: String, val kat: Map<String, String>)

    /**
     * Kategori untuk transaksi tanpa kategori: 1) ikut rekod lepas nama sama (percuma) 2) AI, 60 nama setiap panggilan.
     * Pulang peta id transaksi → kategori; pemanggil yang simpan.
     */
    suspend fun kategorikan(s: PgState, list: List<Tx>, today: String, onProg: (Int, Int) -> Unit = { _, _ -> }): KatHasil {
        val hist = PG.kategoriSejarah(s)
        val out = LinkedHashMap<String, String>()
        var sej = 0
        var ai = 0
        var usd = 0.0
        var gagal = ""
        val rest = ArrayList<Tx>()
        list.forEach { t ->
            if (!PG.bolehKategori(t) || PG.katValid(t.kategori)) return@forEach
            val k = hist[PG.normNama(t.perkara)]
            if (k != null) { out[t.id] = k; sej++ } else rest.add(t)
        }
        if (rest.isEmpty() || !ready()) return KatHasil(sej, 0, 0.0, "", out)
        val groups = katGroups(rest)
        val sz = 60
        var s0 = 0
        while (s0 < groups.size) {
            val chunk = groups.subList(s0, minOf(groups.size, s0 + sz))
            onProg(s0 / sz + 1, (groups.size + sz - 1) / sz)
            try {
                val body = JSONObject().put("model", model()).put("max_tokens", 300 + chunk.size * 24)
                    .put("tools", JSONArray().put(katTool()))
                    .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", katPrompt(s, chunk))))
                val r = tool(body, "kategori_belanja", today, 90_000)
                usd += r.usd
                val arr = r.data.optJSONArray("hasil") ?: JSONArray()
                for (i in 0 until arr.length()) {
                    val h = arr.optJSONObject(i) ?: continue
                    val g = chunk.getOrNull(Math.round(h.optDouble("i", 0.0)).toInt() - 1) ?: continue
                    val k = h.optString("k")
                    if (!PG.katValid(k)) continue
                    g.txs.forEach { t -> if (!out.containsKey(t.id)) { out[t.id] = k; ai++ } }
                }
            } catch (e: Exception) {
                gagal = e.message ?: "Ralat AI."
                break
            }
            s0 += sz
        }
        return KatHasil(sej, ai, usd, gagal, out)
    }
}
