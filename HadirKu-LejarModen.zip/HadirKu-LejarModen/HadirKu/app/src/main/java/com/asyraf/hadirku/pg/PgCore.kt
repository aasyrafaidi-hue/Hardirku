package com.asyraf.hadirku.pg

import java.time.LocalDate
import java.util.Locale
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/* ---------- jenis hasil kiraan ---------- */

data class Ymd(val y: Int, val m: Int, val d: Int)
data class Flow(val inn: String?, val out: String?)
data class Period(val start: String, val endExcl: String, val end: String, val key: String)
data class OtCycle(val y: Int, val m: Int, val start: String, val end: String, val days: List<String>, val bayarYm: String)
data class OtH(val h15: Double, val h20: Double, val h30: Double, val recorded: Boolean)
data class OtVal(val nilai: Double, val jam: Double, val h15: Double, val h20: Double, val h30: Double, val recorded: Boolean)
data class OtRow(val tarikh: String, val entry: OtEntry?, val h15: Double, val h20: Double, val h30: Double, val recorded: Boolean, val nilai: Double)
data class OtSum(
    val rows: List<OtRow>, val hari: Int, val jam: Double, val h15: Double, val h20: Double, val h30: Double,
    val kiraHad: Double, val had: Double, val bakiHad: Double, val hrp: Double, val nilai: Double, val asas: Double,
    val kasar: Double, val potongan: Double, val bersih: Double, val advance: Double, val gaji30: Double,
)
data class Settle(val txId: String, val jumlah: Double, val tarikh: String, val auto: Boolean)
data class Settlements(val byTx: Map<String, Double>, val byCycle: Map<String, Settle>)
data class OtAuto(val cycle: OtCycle, val nilai: Double, val gaji: Boolean, val sudah: Settle?, val auto: Double)
data class OtPart(val cycle: OtCycle, val nilai: Double, val dibayar: Settle? = null)
data class OtOutstanding(val kini: OtPart, val lepas: OtPart, val jumlah: Double)
data class KadLog(
    val id: String, val txId: String?, val tarikh: String, val jenis: String, val jumlah: Double,
    val debtId: String, val nama: String, val catatan: String, val dibuat: Long,
)
data class CommitStat(
    val c: Commitment, val dibayar: Double, val baki: Double, val status: String, val manualTanda: Boolean, val periodKey: String,
) {
    val id get() = c.id
    val nama get() = c.nama
    val jumlah get() = c.jumlah
    val kitaran get() = c.kitaran
    val poket get() = c.poket
}
data class CommitSummary(val jumlah: Double, val dibayar: Double, val baki: Double, val belum: Int)
data class BankStat(val check: BankCheck, val tracker: Double, val beza: Double)

class EppInfo(
    val tempoh: Int, val pokok: Double, val ans: Double, val last: Double, val jumlahBayar: Double, val faedah: Double,
    val dates: List<String>, val dibil: Int, val baki: Double, val tamat: String, val seterusnya: String?, val aktif: Boolean,
    /** pecahan pokok setiap ansuran (kaedah rata: pokok ÷ tempoh; ansuran akhir laras sen) */
    val pokokAns: Double = 0.0, val pokokLast: Double = 0.0,
    /** baki belum dibil dipecah: pokok + faedah (pokokBaki + faedahBaki = baki) */
    val pokokBaki: Double = 0.0, val faedahBaki: Double = 0.0,
    /** pokok bagi setiap ansuran (kaedah "baki"/"tetap"); kosong = kaedah rata (guna pokokAns/pokokLast) */
    val pokokList: List<Double> = emptyList(),
    val kaedah: String = "rata",
    /** false = pecahan pokok/faedah tidak diketahui (kaedah "tetap"): baki pokok dipapar "Tidak diketahui" */
    val pokokTahu: Boolean = true,
    /** kadar nominal setahun (%) bagi baki berkurang — anggaran daripada penyata, belum disahkan bank */
    val kadarNominal: Double? = null,
    /** perbandingan setiap semakan penyata dengan kiraan app */
    val banding: List<SemakBanding> = emptyList(),
) {
    fun amountAt(k: Int): Double = if (k == tempoh - 1) last else ans
    fun pokokAt(k: Int): Double =
        if (pokokList.isNotEmpty()) max(0.0, min(amountAt(k), pokokList.getOrElse(k) { 0.0 }))
        else max(0.0, min(amountAt(k), if (k == tempoh - 1) pokokLast else pokokAns))
    fun faedahAt(k: Int): Double = PG.round2(max(0.0, amountAt(k) - pokokAt(k)))
    /** faedah yang terkandung dalam setiap ansuran biasa (rata) / ansuran seterusnya (baki) */
    val faedahAns: Double get() = PG.round2(max(0.0, ans - pokokAns))
    /** baki tempoh (ansuran belum dibil) */
    val bakiBulan: Int get() = max(0, tempoh - dibil)
    /** ansuran ke- yang terakhir dibil (1-based); 0 = belum ada */
    val keSekarang: Int get() = min(dibil, tempoh)
    /** kadar efektif setahun (EAR, %) bagi baki berkurang */
    val kadarEfektif: Double? get() = kadarNominal?.let { (Math.pow(1 + it / 1200.0, 12.0) - 1) * 100 }
    /** kadar rata setara setahun (%) = jumlah faedah ÷ pokok ÷ tahun */
    val kadarRataSetara: Double get() = if (pokok > 0.004 && tempoh > 0) PG.round2(faedah) * 1200 / (pokok * tempoh) else 0.0
}

/** Pecahan satu ansuran: ikut penyata bank vs kiraan app. */
data class SemakBanding(val ke: Int, val pokokBank: Double, val faedahBank: Double, val pokokApp: Double, val faedahApp: Double) {
    val beza: Double get() = PG.round2(Math.abs(faedahBank - faedahApp))
}

/** Butiran bayaran minimum: jumlah, asas peratus, dan apa yang menentukannya. */
data class MinDetail(
    val jumlah: Double,
    /** asas yang didarab peratus minimum (pokok penuh bagi "jumlah", baki biasa bagi "biasa") */
    val asas: Double,
    /** "peratus" | "lantai" | "ansuran" | "baki" | "tiada" | "penyata" (nilai RM ikut penyata) */
    val sebab: String,
    /** ansuran EPP yang dimasukkan penuh (cara "biasa") */
    val ansuran: Double = 0.0,
    val peratus: Double = 5.0,
    val lantai: Double = 50.0,
    /** "jumlah" | "biasa" | "tetap" | "penyata" */
    val cara: String = "jumlah",
)

data class DebtEv(
    val id: String, val tarikh: String, val dibuat: Long, val jenis: String, val jumlah: Double, val catatan: String,
    val log: Boolean = false, val tx: Boolean = false, val eppId: String? = null, var baki: Double = 0.0,
)

data class DebtStat(
    val d: Debt, val baki: Double, val eppBaki: Double, val eppDue: Double, val eppAktif: Int, val jumlah: Double,
    val dibayar: Double, val sasaran: Double, val sasaranAsal: Double, val belanjaKad: Double, val tunaiKad: Double,
    val tambahan: Double, val min: Double, val status: String, val pelanBaki: Double, val tambahanBaki: Double,
    val bakiBayar: Double, val periodKey: String, val guna: Double?,
    /** pokok EPP belum dibil & faedah EPP belum dibil (eppPokok + eppFaedah = eppBaki) */
    val eppPokok: Double = 0.0, val eppFaedah: Double = 0.0,
    val minInfo: MinDetail? = null,
    /** tempoh bayaran yang dikira: bulan kalendar, atau kitaran penyata bank (kad dengan tarikh penyata) */
    val perMula: String = "", val perAkhir: String = "",
    /** true = kad ikut kitaran penyata bank ([perMula] = tarikh penyata) */
    val kitaranBank: Boolean = false,
    /** tarikh akhir bayar bagi penyata semasa (kad dengan tarikh akhir bayar sahaja) */
    val tarikhAkhir: String? = null,
) {
    /** minimum yang belum dibayar dalam tempoh ini */
    val minTinggal: Double get() = PG.round2(kotlin.math.max(0.0, min - dibayar))
    /** hutang pokok = baki kad + pokok EPP belum dibil (tanpa faedah EPP akan datang) */
    val pokok: Double get() = PG.round2(baki + eppPokok)
    val id get() = d.id
    val nama get() = d.nama
    val jenis get() = d.jenis
    val poket get() = d.poket
    val kadar get() = d.kadar
}
data class DebtSummary(val baki: Double, val epp: Double, val sasaran: Double, val dibayar: Double, val belum: Int, val aktif: Int)
data class PayOpt(val id: String, val jumlah: Double)
data class CardPay(
    val id: String, val nama: String, val poket: String, val baki: Double, val eppBaki: Double, val dibayar: Double,
    val sasaran: Double, val asal: Double, val belanja: Double, val tunai: Double, val rancangan: Double,
    val pelan: Double, val syor: Double, val min: Double, val cukup: Boolean, val opts: List<PayOpt>, val lalai: String, val lalaiJumlah: Double,
)
data class SimItem(val d: Debt, val b: Double, val sched: List<Double>, val pokokSched: List<Double> = emptyList())
data class Urutan(val id: String, val nama: String, val bulan: Int?, val faedah: Double)
data class SimResult(val bulan: Int, val faedah: Double, val bayar: Double, val siri: List<Double>, val never: Boolean, val urutan: List<Urutan>)
data class DebtPlan(
    val kosong: Boolean, val cukup: Boolean = false, val minimum: Double = 0.0, val budget: Double = 0.0, val strategi: String = "avalanche",
    val bulan: Int = 0, val faedah: Double = 0.0, val siri: List<Double> = emptyList(), val urutan: List<Urutan> = emptyList(),
    val never: Boolean = false, val asas: SimResult? = null, val jimatFaedah: Double? = null, val jimatBulan: Int? = null,
)
data class Belum(var n: Int = 0, var jumlah: Double = 0.0)
data class OtKitaranInfo(val start: String, val end: String, val hari: Int, val bayarYm: String)
data class OtKitaranBulan(val cycle: OtCycle, val nilai: Double, val hari: Int, val jam: Double)

class PeriodReport(val start: String, val end: String) {
    var masuk = 0.0; var keluar = 0.0; var hutang = 0.0; var komitmen = 0.0; var kad = 0.0; var bil = 0
    val poket = LinkedHashMap<String, Double>(); val poketTunai = LinkedHashMap<String, Double>(); val poketHarian = LinkedHashMap<String, Double>()
    var top: List<Tx> = emptyList(); var topL: List<Tx> = emptyList()
    var otBayar = 0.0; var bayarKad = 0.0; var bayarPinjaman = 0.0; var kadLog = 0.0; var otEarned = 0.0; var otHarian = 0.0
    var otKitaran: OtKitaranInfo? = null
    val katHarian = LinkedHashMap<String, Double>(); val katTunai = LinkedHashMap<String, Double>()
    val belumHarian = Belum(); val belumTunai = Belum()
    var tunaiKad = 0.0; var feeTunai = 0.0
    var bersih = 0.0; var harianTunai = 0.0; var harian = 0.0; var pendGaji = 0.0; var pend = 0.0; var belanja = 0.0; var lebihan = 0.0
}
data class TrendRow(
    val start: String, val end: String, val masuk: Double, val keluar: Double, val bersih: Double, val hutang: Double,
    val pend: Double, val belanja: Double, val lebihan: Double,
)
data class OtTrendRow(val start: String, val end: String, val bayarYm: String, val nilai: Double, val jam: Double, val kiraHad: Double, val hari: Int)

class DayRow(val tarikh: String) {
    var masuk = 0.0; var keluar = 0.0; var harian = 0.0; var tetap = 0.0; var kad = 0.0; var ubah = 0.0; var n = 0
    var otBayar = 0.0; var bayarKad = 0.0; var kadLog = 0.0; var tunai = 0.0
    var bersih = 0.0; var ot = 0.0; var otJam = 0.0; var otAda = false; var bakiOt = 0.0
    var pend = 0.0; var belanja = 0.0; var bersihL = 0.0; var baki = 0.0; var ada = false
}
class DailySummary(
    val awal: Double, val days: List<DayRow>, val masuk: Double, val keluar: Double, val akhir: Double, val ot: Double,
    val harian: Double, val tetap: Double, val bakiOt: Double, val pend: Double, val belanja: Double, val bersihL: Double,
    val otBayar: Double, val bayarKad: Double,
)

/** Port kiraan PoketGaji (core.js v0.9.3) ke Kotlin. Nama fungsi dikekalkan supaya mudah dibandingkan. */
object PG {
    const val BELUM_AGIH = "belum-agih"
    private const val EPS = 2.220446049250313E-16

    val JENIS = listOf(
        Label("keluar", "Keluar"), Label("masuk", "Masuk"), Label("pindah", "Pindah"),
        Label("pelarasan+", "Pelarasan (+)"), Label("pelarasan-", "Pelarasan (−)"), Label("baki-awal", "Baki Awal"),
        Label("kad", "Guna kad kredit"), Label("tunai-kad", "Tunai dari kad"),
    )
    val JENIS_HARI = listOf(
        Label("biasa", "Hari Biasa", "Biasa"), Label("off", "Off Day", "Off"), Label("rest", "Rest Day", "Rest"),
        Label("umum", "Cuti Umum", "Umum"), Label("tidak", "Tidak Bekerja", "Cuti"),
    )
    val JENIS_HUTANG = listOf(
        Label("kad", "Kad kredit"), Label("pinjaman", "Pinjaman"), Label("bnpl", "Beli dulu bayar kemudian"), Label("lain", "Lain-lain"),
    )
    val KATEGORI = listOf(
        Label("makan", "Makan & minum", ai = "kedai makan, restoran, mamak, gerai, minuman, kopi, makanan segera, makanan dihantar"),
        Label("dapur", "Barang dapur", ai = "pasar raya, kedai runcit, pasar, ikan, ayam, sayur, beras, barang basah dan kering untuk masak di rumah"),
        Label("rumah", "Rumah", ai = "sewa atau ansuran rumah, perabot, peralatan dan barang rumah, pembaikan, barang cucian"),
        Label("bil", "Bil & utiliti", ai = "elektrik (TNB), air, internet, pelan telefon, Astro, takaful atau insurans bulanan"),
        Label("minyak", "Minyak & tol", ai = "petrol, diesel, tol, parking, e-hailing, tambang bas atau kereta api"),
        Label("kenderaan", "Kenderaan", ai = "servis, alat ganti, tayar, cukai jalan, insurans kenderaan, ansuran motor atau kereta"),
        Label("kesihatan", "Kesihatan", ai = "klinik, hospital, ubat, farmasi, gigi, cermin mata"),
        Label("keluarga", "Keluarga & anak", ai = "keperluan anak, sekolah, yuran, susu, lampin, duit untuk ibu bapa atau keluarga"),
        Label("diri", "Pakaian & diri", ai = "pakaian, kasut, gunting rambut, barang peribadi, kosmetik"),
        Label("hiburan", "Hiburan & cuti", ai = "wayang, permainan, langganan streaming, hobi, percutian, hotel"),
        Label("sedekah", "Sedekah & hadiah", ai = "sedekah, derma, zakat, hadiah, kenduri, sumbangan"),
        Label("lain", "Lain-lain", ai = "tidak sesuai dengan mana-mana kategori lain"),
    )
    private val KAT_LBL: Map<String, String> = LinkedHashMap<String, String>().apply {
        put("hutang", "Bayar hutang & kad"); put("belum", "Tiada kategori")
        KATEGORI.forEach { put(it.id, it.label) }
    }
    /** Bahasa paparan: true = English (UK). Ditetapkan oleh i18n/Bahasa. Hanya nama hari & bulan bergantung pada ini. */
    @Volatile var en: Boolean = false
    private val HARI_MS = listOf("Ahd", "Isn", "Sel", "Rab", "Kha", "Jum", "Sab")
    private val HARI_EN = listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
    private val HARI_PENUH_MS = listOf("Ahad", "Isnin", "Selasa", "Rabu", "Khamis", "Jumaat", "Sabtu")
    private val HARI_PENUH_EN = listOf("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")
    private val BULAN_MS = listOf("Jan", "Feb", "Mac", "Apr", "Mei", "Jun", "Jul", "Ogo", "Sep", "Okt", "Nov", "Dis")
    private val BULAN_EN = listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
    private val BULAN_PENUH_MS = listOf("Januari", "Februari", "Mac", "April", "Mei", "Jun", "Julai", "Ogos", "September", "Oktober", "November", "Disember")
    private val BULAN_PENUH_EN = listOf("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December")
    val HARI: List<String> get() = if (en) HARI_EN else HARI_MS
    val HARI_PENUH: List<String> get() = if (en) HARI_PENUH_EN else HARI_PENUH_MS
    val BULAN: List<String> get() = if (en) BULAN_EN else BULAN_MS
    val BULAN_PENUH: List<String> get() = if (en) BULAN_PENUH_EN else BULAN_PENUH_MS

    /* ---------- nombor gaya JavaScript ---------- */
    fun jsRound(x: Double): Double = floor(x + 0.5)
    /**
     * Bundar ke sen, separuh sen naik (cara bank). Nombor perpuluhan dalam Double tidak tepat: 1476.815 disimpan sebagai
     * 1476.81499999…, jadi Math.round biasa memberi 1476.81. Toleransi relatif 1e-12 (jauh lebih besar daripada ralat Double,
     * jauh lebih kecil daripada 1 sen) memulihkan kes separuh sen ini; nilai lain tidak berubah.
     */
    fun round2(x: Double): Double { val y = (x + EPS) * 100; return jsRound(y + abs(y) * 1e-12) / 100 }
    /** String(x) dalam JavaScript (83 → "83", 1.5 → "1.5"). */
    fun jsNum(x: Double): String {
        if (x.isNaN()) return "NaN"
        if (x == floor(x) && abs(x) < 1e15) return x.toLong().toString()
        return x.toString()
    }
    fun toFixed(x: Double, n: Int): String = String.format(Locale.US, "%.${n}f", x)
    fun num(x: Double?): Double = if (x == null || x.isNaN()) 0.0 else x

    /* ---------- tarikh (YYYY-MM-DD) ---------- */
    fun pad(n: Int): String = if (n in 0..9) "0$n" else n.toString()
    fun iso(y: Int, m: Int, d: Int): String {
        val dt = LocalDate.of(y, 1, 1).plusMonths((m - 1).toLong()).plusDays((d - 1).toLong())
        return dt.year.toString() + "-" + pad(dt.monthValue) + "-" + pad(dt.dayOfMonth)
    }
    fun parse(s: String): Ymd {
        val p = s.split("-")
        return Ymd(p[0].toInt(), p[1].toInt(), p[2].toInt())
    }
    fun addDays(s: String, n: Int): String { val p = parse(s); return iso(p.y, p.m, p.d + n) }
    fun addMonths(s: String, n: Int): String { val p = parse(s); return iso(p.y, p.m + n, p.d) }
    fun todayISO(now: LocalDate = LocalDate.now()): String = iso(now.year, now.monthValue, now.dayOfMonth)
    fun ym(s: String): String = s.substring(0, 7)
    fun weekday(s: String): Int { val p = parse(s); return LocalDate.of(p.y, p.m, p.d).dayOfWeek.value % 7 }
    fun fmtDate(s: String): String { val p = parse(s); return pad(p.d) + "/" + pad(p.m) + "/" + p.y }
    fun fmtShort(s: String): String { val p = parse(s); return "${p.d} ${BULAN[p.m - 1]}" }
    fun fmtMonth(ymStr: String): String { val p = ymStr.split("-").map { it.toInt() }; return BULAN_PENUH[p[1] - 1] + " " + p[0] }
    fun shiftYm(ymStr: String, n: Int): String = ym(addMonths("$ymStr-01", n))
    private fun lastDayOfMonth(y: Int, m: Int): Int = LocalDate.of(y, 1, 1).plusMonths((m - 1).toLong()).lengthOfMonth()

    /* ---------- wang ---------- */
    fun money(x: Double?, plus: Boolean = false): String {
        val v = round2(num(x))
        val s = String.format(Locale.US, "%,.2f", abs(v))
        val sign = if (v < 0) "−" else if (plus && v > 0) "+" else ""
        return sign + "RM" + s
    }

    private val rnd = java.util.Random()
    fun uid(prefix: String = "x"): String {
        val a = java.lang.Long.toString(System.currentTimeMillis(), 36)
        val sb = StringBuilder()
        repeat(5) { sb.append(Character.forDigit(rnd.nextInt(36), 36)) }
        return prefix + a + sb
    }

    /* ---------- aliran duit ---------- */
    private fun nz(s: String): String? = s.ifEmpty { null }
    fun flows(t: Tx): Flow = when (t.jenis) {
        "masuk", "baki-awal", "pelarasan+" -> Flow(nz(t.poket), null)
        "keluar", "pelarasan-" -> Flow(null, nz(t.poket))
        "pindah" -> Flow(nz(t.ke), nz(t.poket))
        "kad" -> if (t.ke.isNotEmpty() && t.ke != t.poket) Flow(t.ke, nz(t.poket)) else Flow(null, null)
        "tunai-kad" -> Flow(nz(t.poket), null)
        else -> Flow(null, null)
    }
    fun signed(t: Tx): Double { val f = flows(t); return (if (f.inn != null) t.jumlah else 0.0) - (if (f.out != null) t.jumlah else 0.0) }
    fun dompetSet(s: PgState): Set<String> = s.pockets.filter { it.dompet }.map { it.id }.toSet()
    fun tunaiSet(s: PgState): Set<String> = s.pockets.filter { it.tunai }.map { it.id }.toSet()
    /** "bank" / "tunai" / "ewallet" — di mana duit poket ini sebenarnya disimpan */
    fun simpanDi(p: Pocket): String = if (p.tunai) "tunai" else if (p.dompet) "ewallet" else "bank"
    fun signedBank(t: Tx, dom: Set<String>): Double {
        val f = flows(t)
        return (if (f.inn != null && f.inn !in dom) t.jumlah else 0.0) - (if (f.out != null && f.out !in dom) t.jumlah else 0.0)
    }

    /* ---------- kategori ---------- */
    /** Jumlah nafkah dalam bulan [ym]: masuk (app isteri, "Nafkah dari …") atau keluar (app suami, "Nafkah …"). */
    fun nafkahBulan(s: PgState, ym: String, masuk: Boolean): Double = round2(s.transactions.filter { t ->
        t.tarikh.startsWith(ym) && t.jenis == (if (masuk) "masuk" else "keluar") && !t.pulangan && t.perkara.trim().lowercase().startsWith("nafkah")
    }.sumOf { it.jumlah })

    fun katValid(id: String?): Boolean = id != null && KATEGORI.any { it.id == id }
    fun katLabel(id: String?): String = KAT_LBL[id] ?: KAT_LBL.getValue("belum")
    fun bolehKategori(t: Tx?): Boolean =
        t != null && (t.jenis == "keluar" || t.jenis == "kad") && !(t.jenis == "keluar" && t.hutangId.isNotEmpty())
    /** Duit masuk yang memulangkan belanja satu kategori (bukan pendapatan). */
    fun isPulangan(t: Tx?): Boolean = t != null && t.jenis == "masuk" && t.pulangan && katValid(t.kategori)
    fun kategoriOf(t: Tx?): String {
        if (t == null || (t.jenis != "keluar" && t.jenis != "kad")) return ""
        if (t.jenis == "keluar" && t.hutangId.isNotEmpty()) return "hutang"
        return if (katValid(t.kategori)) t.kategori!! else "belum"
    }
    private val RE_M = Regex("\\(m\\)")
    private val RE_CO = Regex("\\b(sdn|bhd|berhad|enterprise|ent|trading|plt)\\b")
    private val RE_NON = Regex("[^a-z0-9]+")
    fun normNama(s: String?): String =
        (s ?: "").lowercase(Locale.ROOT).replace(RE_M, " ").replace(RE_CO, " ").replace(RE_NON, "")
    private val byTarikhDibuat = Comparator<Tx> { a, b ->
        val c = a.tarikh.compareTo(b.tarikh)
        if (c != 0) c else a.dibuat.compareTo(b.dibuat)
    }
    fun kategoriSejarah(s: PgState): Map<String, String> {
        val m = HashMap<String, String>()
        val list = s.transactions.filter { bolehKategori(it) && katValid(it.kategori) && it.perkara.isNotEmpty() }.sortedWith(byTarikhDibuat)
        for (auto in listOf(true, false)) {
            list.forEach { t -> if (t.katAuto == auto) { val k = normNama(t.perkara); if (k.length >= 3) m[k] = t.kategori!! } }
        }
        return m
    }

    fun validateTx(tx: Tx, pocketIds: List<String>, dompetIds: List<String>? = null): List<String> {
        val e = ArrayList<String>()
        if (!Regex("^\\d{4}-\\d{2}-\\d{2}$").matches(tx.tarikh)) e.add("Pilih tarikh.")
        if (JENIS.none { it.id == tx.jenis }) e.add("Pilih jenis transaksi.")
        if (!(tx.jumlah.isFinite() && tx.jumlah > 0)) e.add("Masukkan jumlah lebih daripada RM0.")
        if (tx.poket.isEmpty() || tx.poket !in pocketIds) e.add("Pilih poket.")
        if (tx.jenis == "pindah") {
            if (tx.ke.isEmpty() || tx.ke !in pocketIds) e.add("Pilih poket tujuan.")
            else if (tx.ke == tx.poket) e.add("Poket tujuan mesti berbeza.")
        }
        if (tx.jenis == "kad") {
            if (tx.kadId.isEmpty()) e.add("Pilih kad kredit.")
            if (tx.ke.isNotEmpty() && tx.ke !in pocketIds) e.add("Poket bayaran kad tidak wujud.")
            if (tx.komitmenId.isNotEmpty() || tx.hutangId.isNotEmpty()) e.add("Belanja guna kad tak boleh dikaitkan dengan komitmen atau bayaran hutang.")
            if (dompetIds != null && (tx.poket in dompetIds || (tx.ke.isNotEmpty() && tx.ke in dompetIds))) e.add("Belanja guna kad tak boleh guna poket e-wallet atau tunai. Pilih poket bank.")
        }
        if (tx.jenis == "tunai-kad") {
            if (tx.kadId.isEmpty()) e.add("Pilih kad kredit.")
            if (tx.komitmenId.isNotEmpty() || tx.hutangId.isNotEmpty()) e.add("Tunai dari kad tak boleh dikaitkan dengan komitmen atau bayaran hutang.")
            val fee = tx.fee
            if (fee == null || !fee.isFinite() || fee < 0) e.add("Fee mesti nombor 0 atau lebih.")
            else if (fee > tx.jumlah) e.add("Fee tak boleh lebih daripada jumlah dikeluarkan.")
        } else if (tx.fee != null) e.add("Fee hanya untuk Tunai dari kad.")
        if (tx.komitmenId.isNotEmpty() && tx.jenis != "keluar") e.add("Bayar komitmen hanya untuk jenis Keluar.")
        if (tx.hutangId.isNotEmpty() && tx.jenis != "keluar") e.add("Bayar hutang hanya untuk jenis Keluar.")
        if (tx.hutangId.isNotEmpty() && tx.komitmenId.isNotEmpty()) e.add("Pilih sama ada komitmen atau hutang, bukan kedua-duanya.")
        val ob = tx.otBayar
        if (ob != null) {
            if (tx.jenis != "masuk") e.add("Bahagian OT hanya untuk jenis Masuk.")
            else if (!(ob.isFinite() && ob >= 0)) e.add("Bahagian OT mesti nombor 0 atau lebih.")
            else if (ob > tx.jumlah + 0.004) e.add("Bahagian OT tak boleh lebih daripada jumlah duit masuk.")
        }
        val kat = tx.kategori
        if (tx.pulangan) {
            if (tx.jenis != "masuk") e.add("Duit dipulangkan hanya untuk jenis Masuk.")
            else if (!katValid(kat)) e.add("Pilih kategori belanja yang dipulangkan.")
            if (tx.otBayar != null) e.add("Duit dipulangkan tidak boleh ada bahagian OT.")
        } else if (!kat.isNullOrEmpty()) {
            if (!katValid(kat)) e.add("Kategori tidak sah.")
            else if (!bolehKategori(tx)) e.add("Kategori hanya untuk belanja (Keluar atau Guna kad), bukan bayar hutang.")
        }
        return e
    }

    fun balances(s: PgState): Map<String, Double> {
        val b = LinkedHashMap<String, Double>()
        s.pockets.forEach { b[it.id] = 0.0 }
        s.transactions.forEach { t ->
            val f = flows(t)
            if (f.inn != null && b.containsKey(f.inn)) b[f.inn] = round2(b.getValue(f.inn) + t.jumlah)
            if (f.out != null && b.containsKey(f.out)) b[f.out] = round2(b.getValue(f.out) - t.jumlah)
        }
        return b
    }
    fun total(s: PgState, upto: String? = null): Double {
        val dom = dompetSet(s)
        var sum = 0.0
        s.transactions.forEach { t -> if (upto == null || t.tarikh <= upto) sum += signedBank(t, dom) }
        return round2(sum)
    }
    fun totalDompet(s: PgState, upto: String? = null): Double {
        val dom = dompetSet(s)
        var b = 0.0
        s.transactions.forEach { t ->
            if (upto != null && t.tarikh > upto) return@forEach
            val f = flows(t)
            if (f.inn != null && f.inn in dom) b += t.jumlah
            if (f.out != null && f.out in dom) b -= t.jumlah
        }
        return round2(b)
    }
    private fun totalSet(s: PgState, ids: Set<String>, upto: String?): Double {
        var b = 0.0
        s.transactions.forEach { t ->
            if (upto != null && t.tarikh > upto) return@forEach
            val f = flows(t)
            if (f.inn != null && f.inn in ids) b += t.jumlah
            if (f.out != null && f.out in ids) b -= t.jumlah
        }
        return round2(b)
    }
    /** Duit tunai fizikal (semua poket tunai). */
    fun totalTunai(s: PgState, upto: String? = null): Double = totalSet(s, tunaiSet(s), upto)
    /** E-wallet sahaja (poket luar bank yang bukan tunai). */
    fun totalEwallet(s: PgState, upto: String? = null): Double = totalSet(s, dompetSet(s) - tunaiSet(s), upto)

    const val TUNAI_ID = "p-tunai"
    private val RE_TUNAI = Regex("(tunai|cash|dompet|duit\\s*(poket|kocek))", RegexOption.IGNORE_CASE)
    private val RE_EWALLET = Regex("(tng|touch|grab|boost|shopee|bigpay|setel|e-?wallet|mae)", RegexOption.IGNORE_CASE)

    /**
     * Pastikan ada satu dompet tunai. Kalau dah ada poket e-wallet yang namanya macam tunai
     * (contoh "Tunai", "Cash"), poket itu ditanda tunai; kalau tiada, poket "Dompet Tunai" ditambah selepas Belum Agih.
     */
    fun withTunai(s: PgState): PgState {
        if (s.pockets.any { it.tunai }) return s
        val cand = s.pockets.find { it.dompet && it.id != BELUM_AGIH && RE_TUNAI.containsMatchIn(it.nama) && !RE_EWALLET.containsMatchIn(it.nama) }
        if (cand != null) return s.copy(pockets = s.pockets.map { if (it.id == cand.id) it.copy(tunai = true) else it })
        val id = if (s.pockets.any { it.id == TUNAI_ID }) uid("p-") else TUNAI_ID
        val nama = if (s.pockets.any { it.nama.equals("Dompet Tunai", ignoreCase = true) }) "Duit Tunai" else "Dompet Tunai"
        val list = s.pockets.toMutableList()
        val i = list.indexOfFirst { it.id == BELUM_AGIH }
        list.add(if (i >= 0) i + 1 else 0, Pocket(id, nama, 0.0, dompet = true, tunai = true))
        return s.copy(pockets = list)
    }

    /** Susun semula poket: Belum Agih kekal paling atas, poket lain ikut senarai id yang diberi. */
    fun movePocket(s: PgState, id: String, dir: Int): PgState {
        val belum = s.pockets.filter { it.id == BELUM_AGIH }
        val rest = s.pockets.filter { it.id != BELUM_AGIH }.toMutableList()
        val i = rest.indexOfFirst { it.id == id }
        val j = i + dir
        if (i < 0 || j < 0 || j >= rest.size) return s
        val tmp = rest[i]; rest[i] = rest[j]; rest[j] = tmp
        return s.copy(pockets = belum + rest)
    }

    fun pocketUsage(s: PgState, id: String): Boolean =
        s.transactions.any { it.poket == id || it.ke == id } || s.commitments.any { it.poket == id } || s.debts.any { it.poket == id }

    /* ---------- semakan bank ---------- */
    fun bankStatus(s: PgState): BankStat? {
        if (s.bankChecks.isEmpty()) return null
        val last = s.bankChecks.sortedWith { a, b -> val c = a.tarikh.compareTo(b.tarikh); if (c != 0) c else a.dibuat.compareTo(b.dibuat) }.last()
        val tracker = total(s, last.tarikh)
        return BankStat(last, tracker, round2(last.baki - tracker))
    }

    /* ---------- komitmen ---------- */
    fun finMonthStart(dIso: String, startDay: Int): String {
        val p = parse(dIso)
        return if (p.d >= startDay) iso(p.y, p.m, startDay) else iso(p.y, p.m - 1, startDay)
    }
    fun commitmentPeriod(today: String, startDay: Int): Period {
        val s = finMonthStart(today, startDay)
        val next = addMonths(s, 1)
        return Period(s, next, addDays(next, -1), s)
    }
    /** Tempoh komitmen yang mengandungi [date] (ikut hari mula komitmen dalam tetapan). */
    fun commitmentPeriodOf(s: PgState, date: String): Period = commitmentPeriod(date, s.settings.komitmenMulaHari.takeIf { it > 0 } ?: 1)

    /**
     * Tarikh rujukan paparan komitmen: hari ini, KECUALI bila semua komitmen tempoh ini sudah dibayar penuh —
     * paparan terus beralih ke tempoh seterusnya (hari pertamanya) supaya ringkasan menunjuk unjuran bulan depan.
     */
    fun commitmentViewDate(s: PgState, today: String): String {
        if (s.commitments.isEmpty()) return today
        val list = commitmentStatus(s, today)
        return if (list.all { it.status == "sudah" }) commitmentPeriodOf(s, today).endExcl else today
    }

    /** true = paparan komitmen sudah beralih ke tempoh seterusnya (semua tempoh semasa selesai). */
    fun commitmentDiAlih(s: PgState, today: String): Boolean = commitmentViewDate(s, today) != today

    fun commitmentStatus(s: PgState, today: String): List<CommitStat> {
        val per = commitmentPeriodOf(s, today)
        val prevStart = addMonths(per.start, -1)
        val prevKey = commitmentPeriodOf(s, prevStart).key
        return s.commitments.map { c ->
            var paid = 0.0
            var paidPrev = 0.0
            s.transactions.forEach { t ->
                if (t.komitmenId == c.id && t.jenis == "keluar") {
                    if (t.tarikh >= per.start && t.tarikh < per.endExcl) paid += t.jumlah
                    else if (t.tarikh >= prevStart && t.tarikh < per.start) paidPrev += t.jumlah
                }
            }
            // bayaran lebih tempoh lepas (cth bayar bil Dis awal pada 28 Nov selepas Nov selesai) dibawa ke tempoh ini
            val bayarPrev = if (c.manual[prevKey] == true) max(c.jumlah, paidPrev) else paidPrev
            val bawa = max(0.0, bayarPrev - c.jumlah)
            val manual = c.manual[per.key] == true
            var dibayar = (if (manual) max(c.jumlah, paid) else paid) + bawa
            dibayar = round2(dibayar)
            val baki = round2(max(0.0, c.jumlah - dibayar))
            val status = if (dibayar >= c.jumlah - 0.004) "sudah" else if (dibayar > 0) "separuh" else "belum"
            CommitStat(c, dibayar, baki, status, manual, per.key)
        }
    }
    /** Tarikh jatuh tempo komitmen dalam bulan tarikh [ref] (hari 29–31 → hari akhir bulan pendek). null = tiada tempo. */
    fun tempoDate(c: Commitment, ref: String): String? {
        if (c.tempo !in 1..31) return null
        val p = parse(ref)
        return iso(p.y, p.m, min(c.tempo, lastDay(p.y, p.m)))
    }
    fun commitmentSummary(list: List<CommitStat>): CommitSummary {
        var j = 0.0; var d = 0.0; var b = 0.0; var belum = 0
        list.forEach { c -> j += c.jumlah; d += min(c.dibayar, c.jumlah); b += c.baki; if (c.status != "sudah") belum++ }
        return CommitSummary(round2(j), round2(d), round2(b), belum)
    }
    fun targetsFromCommitments(s: PgState, today: String?): Map<String, Double> {
        val t = LinkedHashMap<String, Double>()
        s.commitments.forEach { c -> if (c.poket.isNotEmpty()) t[c.poket] = round2((t[c.poket] ?: 0.0) + c.jumlah) }
        if (today != null && s.debts.isNotEmpty()) {
            debtStatus(s, today).forEach { d -> if (d.poket.isNotEmpty() && d.sasaran > 0) t[d.poket] = round2((t[d.poket] ?: 0.0) + d.sasaran) }
        }
        return t
    }

    /* ---------- OT ---------- */
    fun cycleStartFor(today: String, startDay: Int): Pair<Int, Int> {
        val p = parse(today)
        if (p.d >= startDay) return p.y to p.m
        return if (p.m == 1) (p.y - 1) to 12 else p.y to (p.m - 1)
    }
    fun otCycle(y: Int, m: Int, startDay: Int): OtCycle {
        val start = iso(y, m, startDay)
        val end = addDays(iso(y, m + 1, startDay), -1)
        val days = ArrayList<String>()
        var s = start
        while (s <= end) { days.add(s); s = addDays(s, 1) }
        val pay = parse(iso(y, m + 1, 1))
        return OtCycle(y, m, start, end, days, pay.y.toString() + "-" + pad(pay.m))
    }
    fun otCycleOf(date: String, startDay: Int): OtCycle { val c = cycleStartFor(date, startDay); return otCycle(c.first, c.second, startDay) }
    fun shiftCycle(c: OtCycle, n: Int, startDay: Int): OtCycle { val p = parse(iso(c.y, c.m + n, 1)); return otCycle(p.y, p.m, startDay) }
    fun hrp(g: Gaji): Double = (g.basic + g.night + g.transport) / 26 / 8
    fun otHours(e: OtEntry?, jamNormal: Double): OtH {
        val jam = e?.jam
        if (e == null || jam == null || !jam.isFinite()) return OtH(0.0, 0.0, 0.0, false)
        var h15 = 0.0; var h20 = 0.0; var h30 = 0.0
        when (e.jenis) {
            "biasa" -> h15 = max(0.0, jam - jamNormal)
            "off" -> h15 = jam
            "rest", "umum" -> { h20 = min(jam, jamNormal); h30 = max(0.0, jam - jamNormal) }
        }
        return OtH(h15, h20, h30, true)
    }
    fun otValue(s: PgState, date: String): OtVal {
        val e = s.ot[date]
        val g = s.settings.gaji
        val h = otHours(e, g.jamNormal)
        return OtVal(round2((h.h15 * 1.5 + h.h20 * 2 + h.h30 * 3) * hrp(g)), h.h15 + h.h20 + h.h30, h.h15, h.h20, h.h30, h.recorded)
    }
    fun otSummary(s: PgState, c: OtCycle): OtSum {
        val g = s.settings.gaji
        val rate = hrp(g)
        var h15 = 0.0; var h20 = 0.0; var h30 = 0.0; var hari = 0; var jam = 0.0
        val rows = c.days.map { dt ->
            val e = s.ot[dt]
            val h = otHours(e, g.jamNormal)
            if (h.recorded) { hari++; jam += e!!.jam!! }
            h15 += h.h15; h20 += h.h20; h30 += h.h30
            OtRow(dt, e, h.h15, h.h20, h.h30, h.recorded, (h.h15 * 1.5 + h.h20 * 2 + h.h30 * 3) * rate)
        }
        val nilai = (h15 * 1.5 + h20 * 2 + h30 * 3) * rate
        val asas = g.basic + g.night + g.transport
        val kasar = asas + nilai
        val bersih = kasar - g.potongan
        return OtSum(
            rows, hari, jam, h15, h20, h30, h15 + h30, g.hadOT, g.hadOT - (h15 + h30), rate, round2(nilai), round2(asas),
            round2(kasar), round2(g.potongan), round2(bersih), round2(g.advance), round2(bersih - g.advance),
        )
    }

    private val RE_GAJI = Regex("gaji|salary|payroll|upah", RegexOption.IGNORE_CASE)
    private val RE_ADV = Regex("advance|pendahuluan|\\badv\\b", RegexOption.IGNORE_CASE)
    fun isGajiTx(t: Tx?): Boolean = t != null && t.jenis == "masuk" && RE_GAJI.containsMatchIn(t.perkara) && !RE_ADV.containsMatchIn(t.perkara)
    private fun hasOtBayar(t: Tx): Boolean = t.otBayar != null && t.otBayar.isFinite()
    fun prevCycleOf(date: String, sd: Int): OtCycle {
        val c = otCycleOf(date, sd)
        return if (c.end == date) c else shiftCycle(c, -1, sd)
    }
    fun otSettlements(s: PgState): Settlements {
        val sd = s.settings.otMulaHari.takeIf { it > 0 } ?: 22
        val byTx = LinkedHashMap<String, Double>()
        val byCycle = LinkedHashMap<String, Settle>()
        val cache = HashMap<String, Double>()
        s.transactions.filter { it.jenis == "masuk" && (hasOtBayar(it) || isGajiTx(it)) }.sortedWith(byTarikhDibuat).forEach { t ->
            val pc = prevCycleOf(t.tarikh, sd)
            val key = pc.start
            var amt: Double
            if (hasOtBayar(t)) amt = max(0.0, min(t.jumlah, t.otBayar!!))
            else {
                if (byCycle.containsKey(key)) return@forEach
                val nilai = cache.getOrPut(key) { otSummary(s, pc).nilai }
                amt = min(t.jumlah, nilai)
            }
            amt = round2(amt)
            if (amt > 0) {
                byTx[t.id] = amt
                if (!byCycle.containsKey(key)) byCycle[key] = Settle(t.id, amt, t.tarikh, !hasOtBayar(t))
            }
        }
        return Settlements(byTx, byCycle)
    }
    fun otAutoFor(s: PgState, tx: Tx?): OtAuto? {
        if (tx == null || tx.jenis != "masuk" || tx.tarikh.isEmpty()) return null
        val sd = s.settings.otMulaHari.takeIf { it > 0 } ?: 22
        val pc = prevCycleOf(tx.tarikh, sd)
        val nilai = otSummary(s, pc).nilai
        val lain = otSettlements(s.copy(transactions = s.transactions.filter { it.id != tx.id })).byCycle[pc.start]
        val gaji = isGajiTx(tx)
        val jumlah = tx.jumlah
        val auto = if (gaji && lain == null) round2(if (jumlah.isFinite() && jumlah > 0) min(jumlah, nilai) else nilai) else 0.0
        return OtAuto(pc, nilai, gaji, lain, auto)
    }
    fun otOutstanding(s: PgState, today: String): OtOutstanding {
        val sd = s.settings.otMulaHari.takeIf { it > 0 } ?: 22
        val kini = otCycleOf(today, sd)
        val lepas = shiftCycle(kini, -1, sd)
        var nKini = 0.0
        kini.days.forEach { d -> if (d <= today) nKini += otValue(s, d).nilai }
        val sett = otSettlements(s).byCycle[lepas.start]
        val nLepas = otSummary(s, lepas).nilai
        val belum = if (sett != null) 0.0 else nLepas
        return OtOutstanding(OtPart(kini, round2(nKini)), OtPart(lepas, nLepas, sett), round2(nKini + belum))
    }
    fun kadLogs(s: PgState, start: String, endExcl: String): List<KadLog> {
        val out = ArrayList<KadLog>()
        s.debts.forEach { d ->
            if (d.jenis != "kad") return@forEach
            d.log.forEach { l ->
                if ((l.jenis == "faedah" || l.jenis == "caj") && l.tarikh >= start && l.tarikh < endExcl && l.jumlah > 0)
                    out.add(KadLog(l.id, null, l.tarikh, l.jenis, round2(l.jumlah), d.id, d.nama, l.catatan, l.dibuat))
            }
        }
        val nama = HashMap<String, String>()
        s.debts.forEach { if (it.jenis == "kad") nama[it.id] = it.nama }
        s.transactions.forEach { t ->
            val fee = t.fee ?: 0.0
            if (t.jenis == "tunai-kad" && nama.containsKey(t.kadId) && fee > 0 && t.tarikh >= start && t.tarikh < endExcl)
                out.add(KadLog(t.id + ":fee", t.id, t.tarikh, "fee", round2(fee), t.kadId, nama.getValue(t.kadId), t.perkara, t.dibuat))
        }
        return out
    }
    fun kadDebtIds(s: PgState): Set<String> = s.debts.filter { it.jenis == "kad" }.map { it.id }.toSet()

    /* ---------- hutang ---------- */
    private val LOG_RANK = mapOf("epp" to -1, "penyata" to 0, "caj" to 1, "beli" to 1, "tunai" to 1, "faedah" to 1, "bayar" to 2)
    fun addMonthsClamp(s: String, n: Int): String {
        val p = parse(s)
        val target = LocalDate.of(p.y, 1, 1).plusMonths((p.m - 1 + n).toLong())
        val last = target.lengthOfMonth()
        return iso(p.y, p.m + n, min(p.d, last))
    }
    /**
     * Kadar bulanan baki berkurang daripada SATU penyata: faedah ansuran ke-k = r × baki sebelum ansuran itu, dan
     * baki itu = nilai kini (n − k + 1) ansuran ⇒ A × (1 − (1+r)^−(n−k+1)) = faedah. null jika tidak boleh dikira.
     */
    fun eppKadarDariPenyata(ans: Double, tempoh: Int, ke: Int, faedah: Double): Double? {
        if (!(ans > 0) || !(faedah > 0) || faedah >= ans || ke !in 1..tempoh) return null
        val m = tempoh - ke + 1
        val r = Math.pow(1 - faedah / ans, -1.0 / m) - 1
        return if (r.isFinite() && r > 0 && r < 0.05) r else null
    }

    /**
     * Jadual pokok setiap ansuran (baki berkurang) berpaut pada penyata [sauh]: ansuran ke-k ikut penyata tepat,
     * ansuran sebelumnya diundur daripada baki tersirat, ansuran selepasnya faedah = bundar(baki × r).
     * Ansuran kekal [ans] setiap bulan (termasuk akhir); baki sen pembundaran masuk faedah ansuran akhir.
     */
    fun eppJadualBaki(ans: Double, tempoh: Int, sauh: EppSemak): Pair<Double, List<Double>>? {
        val k = sauh.ke
        val r = eppKadarDariPenyata(ans, tempoh, k, sauh.faedah) ?: return null
        val p = DoubleArray(tempoh)
        val sebelum = round2(sauh.faedah / r)
        var b = sebelum
        for (j in k - 1 downTo 1) {
            val prev = round2((b + ans) / (1 + r))
            p[j - 1] = round2(max(0.0, min(ans, prev - b)))
            b = prev
        }
        p[k - 1] = round2(max(0.0, ans - sauh.faedah))
        var bal = round2(max(0.0, sebelum - p[k - 1]))
        for (j in k + 1..tempoh) {
            val pp = if (j == tempoh) min(bal, ans) else round2(min(bal, max(0.0, ans - round2(bal * r))))
            p[j - 1] = round2(pp)
            bal = round2(max(0.0, bal - pp))
        }
        return r to p.toList()
    }

    /** Semak pelan sebelum disimpan. [ke] = "ansuran ke berapa pada penyata" yang diisi pengguna. "" = sah. */
    fun eppValidate(e: Epp, ke: Int? = null): String {
        if (e.nama.isEmpty()) return "Masukkan nama pelan."
        if (e.tempoh !in 1..120) return "Tempoh mesti antara 1 dan 120 bulan."
        if (ke != null && ke !in 1..e.tempoh) return "Ansuran ke- mesti antara 1 dan " + e.tempoh + "."
        if (e.mula.isEmpty()) return "Pilih tarikh penyata."
        if (e.kaedah == "rata") return when {
            !(e.pokok > 0) -> "Masukkan jumlah pokok lebih daripada RM0."
            e.faedahJumlah != null && !(e.faedahJumlah >= 0) -> "Masukkan jumlah faedah, RM0 atau lebih."
            e.faedahJumlah != null && !(e.kadar <= 50) -> "Jumlah faedah terlalu besar berbanding pokok dan tempoh (lebih 50% setahun). Semak semula."
            !(e.kadar >= 0 && e.kadar <= 50) -> "Kadar faedah mesti antara 0 dan 50."
            !(e.ansuran >= 0) -> "Ansuran mesti 0 atau lebih."
            else -> ""
        }
        if (!(e.ansuran > 0)) return "Masukkan ansuran sebulan lebih daripada RM0."
        if (e.kaedah == "baki") {
            val k = e.semak.maxByOrNull { it.ke } ?: return "Masukkan pokok dan faedah/AMF ikut penyata."
            if (k.ke !in 1..e.tempoh) return "Ansuran ke- mesti antara 1 dan " + e.tempoh + "."
            if (!(k.faedah > 0) || k.faedah >= e.ansuran) return "Faedah/AMF mesti lebih daripada RM0 dan kurang daripada ansuran."
            if (Math.abs(k.pokok + k.faedah - e.ansuran) > 0.011) return "Pokok + faedah mesti sama dengan ansuran (" + money(e.ansuran) + ")."
            if (eppKadarDariPenyata(e.ansuran, e.tempoh, k.ke, k.faedah) == null) return "Angka penyata tidak munasabah. Semak semula."
        }
        return ""
    }

    /** Isi medan simpanan untuk pembaca lama: baki → pokok tersirat & kadar rata setara; tetap → pokok = ansuran × tempoh. */
    fun eppSediaSimpan(e: Epp, asOf: String): Epp = when (e.kaedah) {
        "baki" -> { val i = eppInfo(e, asOf); e.copy(pokok = i.pokok, kadar = round2(i.kadarRataSetara), kadarNominal = i.kadarNominal?.let { Math.round(it * 1000) / 1000.0 }, faedahJumlah = null) }
        "tetap" -> e.copy(pokok = round2(e.ansuran * e.tempoh), kadar = 0.0, kadarNominal = null, faedahJumlah = null, semak = emptyList())
        else -> e.copy(kadarNominal = null, semak = emptyList())
    }

    /** Tarikh bil ansuran pertama daripada "ansuran ke-[ke] dibil pada [tarikh]" (untuk masuk pelan separuh jalan). */
    fun eppMulaDariKe(tarikh: String, ke: Int): String = addMonthsClamp(tarikh, -(max(1, ke) - 1))

    /** Kaedah "baki" & "tetap": ansuran tetap setiap bulan; pecahan daripada penyata (baki) atau tidak diketahui (tetap). */
    private fun eppInfoAnsuran(plan: Epp, asOf: String): EppInfo {
        val tempoh = max(1, plan.tempoh)
        val ans = round2(if (plan.ansuran > 0) plan.ansuran else plan.pokok / tempoh)
        val dates = (0 until tempoh).map { addMonthsClamp(plan.mula, it) }
        val dibil = dates.count { it <= asOf }
        val jumlahBayar = round2(ans * tempoh)
        val baki = round2(ans * (tempoh - min(dibil, tempoh)))
        val sauh = if (plan.kaedah == "baki") plan.semak.filter { it.ke in 1..tempoh }.maxByOrNull { it.ke } else null
        val jd = sauh?.let { eppJadualBaki(ans, tempoh, it) }
        if (jd == null) {
            // pecahan tidak diketahui: setiap ansuran dikira pokok penuh, tiada faedah dilapor (bukan diteka)
            return EppInfo(tempoh, jumlahBayar, ans, ans, jumlahBayar, 0.0, dates, dibil, baki, dates[tempoh - 1], dates.getOrNull(dibil), dibil < tempoh,
                ans, ans, baki, 0.0, List(tempoh) { ans }, plan.kaedah, pokokTahu = false)
        }
        val (r, pl) = jd
        val pokok = round2(pl.sum())
        val pokokBaki = round2(pl.drop(min(dibil, tempoh)).sum())
        val banding = plan.semak.filter { it.ke in 1..tempoh }.sortedBy { it.ke }
            .map { SemakBanding(it.ke, it.pokok, it.faedah, pl[it.ke - 1], round2(ans - pl[it.ke - 1])) }
        return EppInfo(tempoh, pokok, ans, ans, jumlahBayar, round2(jumlahBayar - pokok), dates, dibil, baki, dates[tempoh - 1], dates.getOrNull(dibil), dibil < tempoh,
            pl.getOrElse(dibil) { pl.last() }, pl.last(), pokokBaki, round2(max(0.0, baki - pokokBaki)), pl, "baki", true, r * 1200, banding)
    }

    fun eppInfo(plan: Epp, asOf: String): EppInfo {
        if (plan.kaedah == "baki" || plan.kaedah == "tetap") return eppInfoAnsuran(plan, asOf)
        val tempoh = max(1, jsRound(plan.tempoh.toDouble().takeIf { it != 0.0 } ?: 1.0).toInt())
        val pokok = round2(plan.pokok)
        val kadar = plan.kadar
        val fj = plan.faedahJumlah?.takeIf { it.isFinite() }
        var jumlahBayar = if (fj != null) round2(pokok + max(0.0, fj)) else round2(pokok + pokok * kadar / 100 * tempoh / 12)
        var ans = round2(jumlahBayar / tempoh)
        if (plan.ansuran > 0) { ans = round2(plan.ansuran); jumlahBayar = round2(ans * tempoh) }
        val last = round2(jumlahBayar - ans * (tempoh - 1))
        val dates = (0 until tempoh).map { addMonthsClamp(plan.mula, it) }
        val dibil = dates.count { it <= asOf }
        val dibilJumlah = if (dibil >= tempoh) jumlahBayar else round2(ans * dibil)
        val baki = round2(jumlahBayar - dibilJumlah)
        // pecahan pokok/faedah kaedah rata (flat): setiap ansuran bawa pokok ÷ tempoh, selebihnya faedah
        val pp = round2(pokok / tempoh)
        val ppLast = round2(pokok - pp * (tempoh - 1))
        val pokokDibil = if (dibil >= tempoh) pokok else round2(pp * dibil)
        val pokokBaki = round2(max(0.0, min(baki, pokok - pokokDibil)))
        return EppInfo(tempoh, pokok, ans, last, jumlahBayar, round2(jumlahBayar - pokok), dates, dibil, baki,
            dates[tempoh - 1], dates.getOrNull(dibil), dibil < tempoh, pp, ppLast, pokokBaki, round2(max(0.0, baki - pokokBaki)))
    }
    fun eppDueIn(d: Debt, per: Period): Double {
        var due = 0.0
        d.epp.forEach { p ->
            val e = eppInfo(p, per.end)
            e.dates.forEachIndexed { k, dt -> if (dt >= per.start && dt < per.endExcl) due += e.amountAt(k) }
        }
        return round2(due)
    }
    fun eppUnbilled(d: Debt, asOf: String): Double = round2(d.epp.sumOf { eppInfo(it, asOf).baki })
    /** pokok EPP belum dibil (tanpa faedah) */
    fun eppUnbilledPokok(d: Debt, asOf: String): Double = round2(d.epp.sumOf { eppInfo(it, asOf).pokokBaki })

    fun debtEvents(s: PgState, d: Debt, upto: String?, today: String?): List<DebtEv> {
        val cut = upto ?: today ?: todayISO()
        var ev = ArrayList<DebtEv>()
        d.log.forEach { l -> ev.add(DebtEv(l.id, l.tarikh, l.dibuat, l.jenis, l.jumlah, l.catatan, log = true)) }
        s.transactions.forEach { t ->
            if (t.hutangId == d.id && t.jenis == "keluar") ev.add(DebtEv(t.id, t.tarikh, t.dibuat, "bayar", t.jumlah, t.perkara, tx = true))
            if (t.kadId == d.id && t.jenis == "kad") ev.add(DebtEv(t.id, t.tarikh, t.dibuat, "beli", t.jumlah, t.perkara, tx = true))
            if (t.kadId == d.id && t.jenis == "tunai-kad") {
                val fe = t.fee ?: 0.0
                ev.add(DebtEv(t.id, t.tarikh, t.dibuat, "tunai", round2(t.jumlah + fe), t.perkara + (if (fe > 0) " (termasuk fee " + money(fe) + ")" else ""), tx = true))
            }
        }
        d.epp.forEach { p ->
            val e = eppInfo(p, cut)
            for (k in 0 until e.dibil) ev.add(DebtEv(p.id + "-" + k, e.dates[k], 0, "epp", e.amountAt(k), p.nama.ifEmpty { "EPP" } + " (" + (k + 1) + "/" + e.tempoh + ")", eppId = p.id))
        }
        if (upto != null) ev = ArrayList(ev.filter { it.tarikh <= upto })
        val sorted = ev.sortedWith { a, b ->
            if (a.tarikh != b.tarikh) a.tarikh.compareTo(b.tarikh)
            else if (a.dibuat != b.dibuat) a.dibuat.compareTo(b.dibuat)
            else (LOG_RANK[a.jenis] ?: 0).compareTo(LOG_RANK[b.jenis] ?: 0)
        }
        var bal = 0.0
        sorted.forEach { e ->
            when (e.jenis) {
                "penyata" -> bal = e.jumlah
                "bayar" -> bal -= e.jumlah
                else -> bal += e.jumlah
            }
            e.baki = round2(bal)
        }
        return sorted
    }
    fun debtBalance(s: PgState, d: Debt, upto: String?, today: String?): Double {
        val ev = debtEvents(s, d, upto, today)
        return if (ev.isNotEmpty()) ev.last().baki else 0.0
    }
    /**
     * Bayaran minimum.
     *  Kad, cara "jumlah" (lalai): p% × (baki kad + pokok EPP belum dibil), sekurang-kurangnya lantai (RM50)
     *    dan ansuran EPP bulan ini, tidak melebihi baki kad. Faedah EPP akan datang TIDAK dikira.
     *  Kad, cara "biasa": ansuran EPP bulan ini penuh + p% baki selebihnya (lantai RM50) — cara asal PoketGaji.
     *  Kad, nilai RM ikut penyata ([tepat] & minRm diisi): minimum = minRm tepat, tidak melebihi baki.
     *  Lain-lain: ansuran tetap.
     */
    fun debtMinDetail(d: Debt, bal: Double, eppDue: Double, eppPokok: Double = 0.0, tepat: Boolean = false): MinDetail {
        if (!(bal > 0.004)) return MinDetail(0.0, 0.0, "tiada", cara = d.minAsas)
        // SPayLater: tiada bayaran minimum — bil mesti dibayar penuh (simulasi: baki dilangsaikan setiap bulan)
        if (isSpl(d)) return MinDetail(round2(bal), bal, "bil", num(eppDue), 0.0, 0.0, "bil")
        if (d.jenis == "kad" && tepat && d.minRm != null) {
            val m = round2(min(bal, max(0.0, d.minRm)))
            return MinDetail(m, bal, if (m >= bal - 0.004) "baki" else "penyata", num(eppDue), d.minPeratus, d.minLantai ?: 50.0, "penyata")
        }
        if (d.jenis == "kad") {
            var p = d.minPeratus
            if (!(p > 0)) p = 5.0
            var floorV = d.minLantai ?: 50.0
            if (!(floorV >= 0)) floorV = 50.0
            val due = min(bal, num(eppDue))
            if (d.minAsas != "biasa") {
                val asas = round2(bal + max(0.0, num(eppPokok)))
                val byPct = round2(asas * p / 100)
                var m = byPct; var sebab = "peratus"
                if (floorV > m + 0.004) { m = floorV; sebab = "lantai" }
                if (due > m + 0.004) { m = due; sebab = "ansuran" }
                if (m >= bal - 0.004) { m = bal; sebab = "baki" }
                return MinDetail(round2(m), asas, sebab, due, p, floorV, "jumlah")
            }
            val rest = round2(bal - due)
            var sebab = "peratus"
            val minRev = if (rest > 0.004) {
                val byPct = rest * p / 100
                if (floorV > byPct) sebab = "lantai"
                if (min(rest, max(floorV, byPct)) >= rest - 0.004) sebab = "baki"
                min(rest, max(floorV, byPct))
            } else { sebab = if (due > 0.004) "ansuran" else "baki"; 0.0 }
            return MinDetail(round2(due + minRev), rest, sebab, due, p, floorV, "biasa")
        }
        val m = round2(min(bal, d.ansuran))
        return MinDetail(m, bal, if (m >= bal - 0.004) "baki" else "ansuran", cara = "tetap")
    }
    fun debtMin(d: Debt, bal: Double, eppDue: Double, eppPokok: Double = 0.0, tepat: Boolean = false): Double = debtMinDetail(d, bal, eppDue, eppPokok, tepat).jumlah
    fun debtTarget(d: Debt, bal: Double, eppDue: Double, eppPokok: Double = 0.0, tepat: Boolean = false): Double {
        if (!(bal > 0.004)) return 0.0
        return round2(min(bal, max(d.rancangan, debtMin(d, bal, eppDue, eppPokok, tepat))))
    }
    /** Minimum RM ikut penyata dipakai tepat dalam tempoh bayaran yang mengandungi tarikh ia diisi. */
    /* ---------- kitaran penyata kad kredit (ikut bank) ---------- */
    /** Tarikh hari [hari] dalam bulan (y, m); bulan boleh lebih/kurang (dinormalkan), hari 29–31 → hari akhir bulan pendek. */
    private fun tarikhHari(y: Int, m: Int, hari: Int): String {
        val b = LocalDate.of(y, 1, 1).plusMonths((m - 1).toLong())
        return iso(b.year, b.monthValue, min(hari, b.lengthOfMonth()))
    }
    /** Kitaran penyata yang mengandungi [today]: dari tarikh penyata (termasuk) hingga sehari sebelum penyata berikutnya. key = tarikh penyata. */
    fun kitaranPenyata(today: String, penyataHari: Int): Period {
        val p = parse(today)
        var start = tarikhHari(p.y, p.m, penyataHari)
        if (today < start) start = tarikhHari(p.y, p.m - 1, penyataHari)
        val sp = parse(start)
        val next = tarikhHari(sp.y, sp.m + 1, penyataHari)
        return Period(start, next, addDays(next, -1), start)
    }
    /** Tarikh akhir bayar bagi penyata bertarikh [penyata]: hari [bayarHari] yang pertama selepas tarikh penyata. */
    fun tarikhAkhirBayar(penyata: String, bayarHari: Int): String? {
        if (bayarHari !in 1..31) return null
        val p = parse(penyata)
        val c = tarikhHari(p.y, p.m, bayarHari)
        return if (c > penyata) c else tarikhHari(p.y, p.m + 1, bayarHari)
    }
    fun ikutKitaranBank(d: Debt): Boolean = d.jenis == "kad" && d.penyataHari in 1..31
    /** Tempoh bayaran hutang: kad dengan tarikh penyata → kitaran penyata bank; lain-lain → bulan (sama macam komitmen). */
    fun debtPeriod(s: PgState, d: Debt, today: String): Period =
        if (ikutKitaranBank(d)) kitaranPenyata(today, d.penyataHari) else commitmentPeriod(today, s.settings.komitmenMulaHari.takeIf { it > 0 } ?: 1)

    fun minIkutPenyata(d: Debt, per: Period): Boolean =
        d.jenis == "kad" && d.minRm != null && d.minTarikh.isNotEmpty() && d.minTarikh >= per.start && d.minTarikh < per.endExcl
    /** Faedah sebulan (RM) → kadar setahun (%) atas baki. */
    fun kadarDariRm(faedahSebulan: Double, baki: Double): Double = if (baki > 0.004) faedahSebulan * 1200 / baki else 0.0
    /** Kadar setahun (%) → anggaran faedah sebulan (RM) atas baki. */
    fun rmDariKadar(kadar: Double, baki: Double): Double = round2(max(0.0, baki) * kadar / 1200)
    /**
     * Minimum (RM) ikut penyata → peratus minimum, supaya bulan lain & simulasi boleh dianggar.
     *  cara "jumlah": minRm ÷ (baki + pokok EPP belum dibil); cara "biasa": (minRm − ansuran EPP) ÷ (baki − ansuran EPP).
     */
    fun minPeratusDariRm(minRm: Double, baki: Double, eppPokok: Double = 0.0, eppDue: Double = 0.0, cara: String = "jumlah"): Double {
        val p = if (cara == "biasa") {
            val rest = baki - max(0.0, eppDue)
            if (rest > 0.004) (minRm - max(0.0, eppDue)) * 100 / rest else 0.0
        } else {
            val asas = baki + max(0.0, eppPokok)
            if (asas > 0.004) minRm * 100 / asas else 0.0
        }
        return if (p.isFinite()) max(0.01, min(100.0, p)) else 5.0
    }
    /** Jumlah faedah EPP (RM) → kadar rata setahun (%). */
    fun eppKadarDariRm(faedah: Double, pokok: Double, tempoh: Int): Double = if (pokok > 0.004 && tempoh > 0) faedah * 1200 / (pokok * tempoh) else 0.0
    /* ---------- SPayLater ---------- */
    const val SPL = "spaylater"
    fun isSpl(d: Debt?): Boolean = d != null && d.jenis == "kad" && d.penyedia == SPL
    /** Kitaran bil SPayLater Malaysia (ditetapkan Shopee masa aktif): tarikh bil → tarikh akhir bayar. */
    val SPL_KITARAN = listOf(1 to 10, 11 to 20, 21 to 1, 25 to 5)
    /** Kadar keuntungan rata SPayLater (% sebulan atas harga asal) bagi ansuran 3–48 bulan. 1 bulan = 0%. */
    const val SPL_KADAR_BULAN = 1.5
    /** Caj lewat SPayLater: RM10, atau pokok bil jika kurang daripada RM10 (dikenakan sekali bagi tunggakan berturut-turut). */
    fun splCajLewat(pokokBil: Double): Double = round2(min(10.0, max(0.0, pokokBil)))
    /** Tarikh bil yang memasukkan belian bertarikh [tarikh]: tarikh bil pertama selepas kitaran tarikh itu. */
    fun splTarikhBil(d: Debt, tarikh: String): String = kitaranPenyata(tarikh, d.penyataHari.takeIf { it in 1..31 } ?: 1).endExcl
    /** Pelan ansuran SPayLater (rata): kadar [kadarBulan]% sebulan atas [harga] selama [tempoh] bulan. */
    data class SplPelan(val caj: Double, val jumlah: Double, val ansuran: Double, val akhir: Double, val epr: Double)
    fun splPelan(harga: Double, tempoh: Int, kadarBulan: Double): SplPelan {
        val n = max(1, tempoh)
        val e = eppInfo(Epp(id = "x", pokok = harga, tempoh = n, kadar = kadarBulan * 12, mula = "2000-01-01"), "1999-12-31")
        return SplPelan(e.faedah, e.jumlahBayar, e.ans, e.last, splEpr(kadarBulan, n))
    }
    /** Kadar keuntungan efektif setahun (EPR, %): kadar bulanan sebenar atas baki berkurang × 12. */
    fun splEpr(kadarBulan: Double, tempoh: Int): Double {
        if (!(kadarBulan > 0) || tempoh < 2) return 0.0
        val ans = (1 + kadarBulan / 100 * tempoh) / tempoh
        var lo = 0.0; var hi = 1.0
        repeat(200) {
            val r = (lo + hi) / 2
            val pv = ans * (1 - Math.pow(1 + r, -tempoh.toDouble())) / r
            if (pv > 1) lo = r else hi = r
        }
        return round2((lo + hi) / 2 * 1200)
    }
    /** Ringkasan bil SPayLater kitaran semasa (untuk paparan). */
    data class SplInfo(
        val tarikhBil: String, val tarikhAkhir: String?, val bil: Double, val dibayar: Double, val tinggal: Double,
        /** lepas tarikh akhir & bil belum dibayar penuh */
        val lewat: Boolean, val cajLewat: Double, val cajDicatat: Boolean,
        /** belanja kitaran ini (masuk bil seterusnya) + ansuran bil seterusnya */
        val belanjaKini: Double, val tarikhBilSeterusnya: String, val bilSeterusnya: Double,
        val had: Double, val digunakan: Double, val bakiHad: Double?,
    )
    fun splInfo(s: PgState, d: Debt, today: String): SplInfo? {
        if (!isSpl(d)) return null
        val st = debtStatus(s, today).find { it.id == d.id } ?: return null
        val per = debtPeriod(s, d, today)
        val tinggal = round2(max(0.0, st.sasaran - st.dibayar))
        val lewat = st.tarikhAkhir != null && today > st.tarikhAkhir && tinggal > 0.004
        val cajDicatat = d.log.any { it.jenis == "caj" && it.tarikh >= per.start && it.tarikh < per.endExcl }
        val perNext = Period(per.endExcl, addMonthsClamp(per.endExcl, 1), addDays(addMonthsClamp(per.endExcl, 1), -1), per.endExcl)
        val bilNext = round2(max(0.0, st.baki - tinggal) + eppDueIn(d, perNext))
        val guna = round2(max(0.0, st.jumlah))
        return SplInfo(per.start, st.tarikhAkhir, st.sasaran, st.dibayar, tinggal, lewat, splCajLewat(tinggal), cajDicatat,
            st.belanjaKad, per.endExcl, bilNext, d.hadKredit, guna, if (d.hadKredit > 0.004) round2(d.hadKredit - guna) else null)
    }
    /**
     * Status SPayLater bagi kitaran bil yang mengandungi [today]:
     * bil = baki sehari sebelum tarikh bil + ansuran yang dibil pada kitaran ini + caj yang dicatat dalam kitaran ini.
     * Belanja dalam kitaran ini masuk bil seterusnya (tidak menambah apa yang perlu dibayar sekarang).
     */
    private fun splStat(s: PgState, d: Debt, today: String): DebtStat {
        val per = debtPeriod(s, d, today)
        val baki = debtBalance(s, d, null, today)
        val sebelum = debtBalance(s, d, addDays(per.start, -1), today)
        var caj = 0.0
        d.log.forEach { l -> if ((l.jenis == "caj" || l.jenis == "faedah") && l.tarikh >= per.start && l.tarikh < per.endExcl) caj += l.jumlah }
        val eppDue = eppDueIn(d, per)
        val bil = round2(max(0.0, sebelum + eppDue + caj))
        var paid = 0.0
        var belanja = 0.0
        s.transactions.forEach { t ->
            if (t.tarikh < per.start || t.tarikh >= per.endExcl) return@forEach
            if (t.hutangId == d.id && t.jenis == "keluar") paid += t.jumlah
            if (t.kadId == d.id && t.jenis == "kad") belanja += t.jumlah
        }
        d.log.forEach { l -> if (l.jenis == "beli" && l.tarikh >= per.start && l.tarikh < per.endExcl) belanja += l.jumlah }
        paid = round2(paid); belanja = round2(belanja)
        val eppBaki = eppUnbilled(d, today)
        val eppPokok = eppUnbilledPokok(d, today)
        val jumlah = round2(baki + eppPokok)
        val status = when {
            baki <= 0.004 && eppBaki <= 0.004 -> "langsai"
            bil <= 0.004 || paid >= bil - 0.004 -> "sudah"
            paid > 0.004 -> "separuh"
            else -> "belum"
        }
        val tinggal = round2(max(0.0, bil - paid))
        val bank = ikutKitaranBank(d)
        return DebtStat(d, baki, eppBaki, eppDue, d.epp.count { eppInfo(it, today).aktif }, jumlah, paid, bil, bil, belanja, 0.0, 0.0, bil, status,
            tinggal, 0.0, tinggal, per.key, if (d.hadKredit > 0) max(0.0, jumlah) / d.hadKredit else null,
            eppPokok, round2(max(0.0, eppBaki - eppPokok)), MinDetail(bil, bil, if (bil > 0.004) "bil" else "tiada", eppDue, 0.0, 0.0, "bil"),
            per.start, per.end, bank, if (bank) tarikhAkhirBayar(per.start, d.bayarHari) else null)
    }
    fun debtStatus(s: PgState, today: String): List<DebtStat> {
        return s.debts.map { d ->
            if (isSpl(d)) return@map splStat(s, d, today)
            val per = debtPeriod(s, d, today)
            val bank = ikutKitaranBank(d)
            val baki = debtBalance(s, d, null, today)
            var paid = 0.0
            s.transactions.forEach { t -> if (t.hutangId == d.id && t.jenis == "keluar" && t.tarikh >= per.start && t.tarikh < per.endExcl) paid += t.jumlah }
            paid = round2(paid)
            val eppDue = if (d.jenis == "kad") eppDueIn(d, per) else 0.0
            val eppBaki = if (d.jenis == "kad") eppUnbilled(d, today) else 0.0
            val eppPokok = if (d.jenis == "kad") eppUnbilledPokok(d, today) else 0.0
            val eppFaedah = round2(max(0.0, eppBaki - eppPokok))
            val asas = round2(max(0.0, baki) + paid)
            var belanjaKad = 0.0; var tunaiKad = 0.0
            if (d.jenis == "kad") s.transactions.forEach { t ->
                if (t.kadId != d.id || t.tarikh < per.start || t.tarikh >= per.endExcl) return@forEach
                if (t.jenis == "kad") belanjaKad += t.jumlah
                if (t.jenis == "tunai-kad") tunaiKad += t.jumlah + (t.fee ?: 0.0)
            }
            belanjaKad = round2(belanjaKad); tunaiKad = round2(tunaiKad)
            val tambahan = round2(belanjaKad + tunaiKad)
            val tepat = minIkutPenyata(d, per)
            val asal = debtTarget(d, asas, eppDue, eppPokok, tepat)
            val minInfo = debtMinDetail(d, asas, eppDue, eppPokok, tepat)
            val mn = minInfo.jumlah
            val sasaran = if (d.jenis == "kad") round2(min(asas, asal + tambahan)) else asal
            val pelanBaki = round2(max(0.0, asal - paid))
            val tambahanBaki = round2(max(0.0, sasaran - max(paid, asal)))
            // jumlah hutang = baki kad + POKOK EPP belum dibil. Faedah/AMF akan datang belum dikenakan, jadi bukan hutang
            // (baki ansuran berjadual kekal dalam eppBaki). Pelan tanpa pecahan diketahui → baki berjadual (konservatif).
            val jumlah = round2(baki + eppPokok)
            val status = when {
                baki <= 0.004 && eppBaki <= 0.004 -> "langsai"
                baki <= 0.004 || paid >= sasaran - 0.004 -> "sudah"
                paid > 0 && paid >= asal - 0.004 -> "pelan"
                paid > 0 && paid >= mn - 0.004 -> "min"
                else -> if (paid > 0) "separuh" else "belum"
            }
            val had = d.hadKredit
            val eppAktif = d.epp.count { eppInfo(it, today).aktif }
            DebtStat(d, baki, eppBaki, eppDue, eppAktif, jumlah, paid, sasaran, asal, belanjaKad, tunaiKad, tambahan, mn, status,
                pelanBaki, tambahanBaki, round2(max(0.0, sasaran - paid)), per.key, if (d.jenis == "kad" && had > 0) max(0.0, jumlah) / had else null,
                eppPokok, eppFaedah, minInfo, per.start, per.end, bank, if (bank) tarikhAkhirBayar(per.start, d.bayarHari) else null)
        }
    }
    fun debtSummary(list: List<DebtStat>): DebtSummary {
        var baki = 0.0; var epp = 0.0; var sasaran = 0.0; var dibayar = 0.0; var belum = 0; var aktif = 0
        list.forEach { d ->
            if (d.jumlah > 0.004) { baki += max(0.0, d.baki) + d.eppPokok; aktif++ }
            epp += d.eppBaki
            sasaran += d.sasaran
            dibayar += min(d.dibayar, if (d.sasaran != 0.0) d.sasaran else d.dibayar)
            if (d.status in setOf("belum", "separuh", "min", "pelan")) belum++
        }
        return DebtSummary(round2(baki), round2(epp), round2(sasaran), round2(dibayar), belum, aktif)
    }
    fun cardPayOptions(s: PgState, debtId: String, today: String): CardPay? {
        val st = debtStatus(s, today).find { it.id == debtId } ?: return null
        val baki = round2(max(0.0, st.baki))
        val paid = st.dibayar
        val pelan = round2(min(baki, max(0.0, st.sasaranAsal - paid)))
        val syor = round2(min(baki, max(0.0, st.sasaran - paid)))
        val mn = round2(min(baki, max(0.0, st.min - paid)))
        val opts = ArrayList<PayOpt>()
        var lalai = ""
        if (baki > 0.004) {
            opts.add(PayOpt("penuh", baki))
            if (syor > pelan + 0.004 && syor < baki - 0.004) opts.add(PayOpt("syor", syor))
            if (pelan > 0.004 && pelan < baki - 0.004) opts.add(PayOpt("pelan", pelan))
            if (mn > 0.004 && mn < baki - 0.004 && mn < pelan - 0.004) opts.add(PayOpt("min", mn))
            val cand = if (pelan > 0.004) pelan else syor
            if (cand > 0.004) lalai = if (cand >= baki - 0.004) "penuh" else (if (pelan > 0.004) "pelan" else "syor")
        }
        val pilih = opts.find { it.id == lalai }
        return CardPay(st.id, st.nama, st.poket, baki, st.eppBaki, paid, st.sasaran, st.sasaranAsal, st.belanjaKad, st.tunaiKad,
            st.d.rancangan, pelan, syor, mn, baki > 0.004 && syor <= 0.004, opts, lalai, pilih?.jumlah ?: 0.0)
    }

    private class SimD(val id: String, val nama: String, val d: Debt, var b: Double, val r: Double, val sched: List<Double>, var rem: Double,
                       val pokokSched: List<Double> = emptyList(), var remPokok: Double = 0.0) {
        var lunas: Int? = null
        var faedah = 0.0
        var due = 0.0
    }
    private fun sgn(x: Double): Int = if (x > 0) 1 else if (x < 0) -1 else 0
    fun simulateDebts(items: List<SimItem>, budget: Double?, strategy: String, maxN: Int = 600): SimResult {
        val ds = items.map { x -> SimD(x.d.id, x.d.nama, x.d, round2(x.b), x.d.kadar / 1200, x.sched, round2(x.sched.sum()), x.pokokSched, round2(x.pokokSched.sum())) }
        var n = 0; var faedah = 0.0; var bayar = 0.0; var stuck = 0
        fun open(x: SimD) = x.b > 0.004 || x.rem > 0.004
        fun sum() = round2(ds.sumOf { max(0.0, it.b) + it.rem })
        val siri = arrayListOf(sum())
        while (ds.any { open(it) } && n < maxN) {
            n++
            val before = sum()
            ds.forEach { x ->
                if (x.b > 0.004) { val i = round2(x.b * x.r); x.b = round2(x.b + i); x.faedah += i; faedah += i }
                x.due = round2(x.sched.getOrNull(n - 1) ?: 0.0)
                if (x.due > 0) { x.b = round2(x.b + x.due); x.rem = round2(max(0.0, x.rem - x.due)) }
                val pk = x.pokokSched.getOrNull(n - 1) ?: 0.0
                if (pk > 0) x.remPokok = round2(max(0.0, x.remPokok - pk))
            }
            var left = budget ?: 0.0
            ds.forEach { x ->
                if (x.b > 0.004) { val m = min(x.b, debtMin(x.d, x.b, x.due, x.remPokok)); x.b = round2(x.b - m); left -= m; bayar += m }
            }
            if (budget != null) {
                left = round2(max(0.0, left))
                val order = ds.filter { it.b > 0.004 }.sortedWith { a, b ->
                    if (strategy == "snowball") {
                        val c = sgn((a.b + a.rem) - (b.b + b.rem)); if (c != 0) c else sgn(b.r - a.r)
                    } else {
                        val c = sgn(b.r - a.r); if (c != 0) c else sgn(a.b - b.b)
                    }
                }
                var k = 0
                while (k < order.size && left > 0.004) {
                    val p = min(order[k].b, left)
                    order[k].b = round2(order[k].b - p); left = round2(left - p); bayar += p
                    k++
                }
            }
            ds.forEach { x -> if (x.lunas == null && !open(x)) x.lunas = n }
            val after = sum()
            siri.add(after)
            stuck = if (after >= before - 0.004) stuck + 1 else 0
            if (stuck >= 6) break
        }
        val never = ds.any { open(it) }
        val urutan = ds.map { Urutan(it.id, it.nama, it.lunas, round2(it.faedah)) }
            .sortedWith { a, b -> sgn((a.bulan?.toDouble() ?: 1e9) - (b.bulan?.toDouble() ?: 1e9)) }
        return SimResult(n, round2(faedah), round2(bayar), siri, never, urutan)
    }
    fun eppSchedule(d: Debt, today: String): List<Double> {
        val sched = ArrayList<Double>()
        (if (d.jenis == "kad") d.epp else emptyList()).forEach { p ->
            val e = eppInfo(p, today)
            var i = 0
            for (k in e.dibil until e.tempoh) {
                while (sched.size <= i) sched.add(0.0)
                sched[i] = round2(sched[i] + e.amountAt(k))
                i++
            }
        }
        return sched
    }
    /** pecahan pokok bagi setiap ansuran EPP akan datang, ikut bulan (selari dengan eppSchedule) */
    fun eppPokokSchedule(d: Debt, today: String): List<Double> {
        val sched = ArrayList<Double>()
        (if (d.jenis == "kad") d.epp else emptyList()).forEach { p ->
            val e = eppInfo(p, today)
            var i = 0
            for (k in e.dibil until e.tempoh) {
                while (sched.size <= i) sched.add(0.0)
                sched[i] = round2(sched[i] + e.pokokAt(k))
                i++
            }
        }
        return sched
    }
    fun debtPlan(s: PgState, budget0: Double, strategy: String, today: String = todayISO()): DebtPlan {
        val items = s.debts.map { d -> SimItem(d, max(0.0, debtBalance(s, d, null, today)), eppSchedule(d, today), eppPokokSchedule(d, today)) }
            .filter { x -> x.b > 0.004 || x.sched.any { it > 0 } }
        if (items.isEmpty()) return DebtPlan(kosong = true)
        val mins = round2(items.sumOf { x ->
            val due = x.sched.getOrNull(0) ?: 0.0
            val pokokLepas = round2(max(0.0, x.pokokSched.sum() - (x.pokokSched.getOrNull(0) ?: 0.0)))
            debtMin(x.d, x.b + due, due, pokokLepas)
        })
        val asas = simulateDebts(items, null, strategy)
        val budget = num(budget0)
        if (budget + 0.004 < mins) return DebtPlan(kosong = false, cukup = false, minimum = mins, asas = asas)
        val plan = simulateDebts(items, budget, strategy)
        return DebtPlan(
            kosong = false, cukup = true, minimum = mins, budget = round2(budget), strategi = if (strategy == "snowball") "snowball" else "avalanche",
            bulan = plan.bulan, faedah = plan.faedah, siri = plan.siri, urutan = plan.urutan, never = plan.never, asas = asas,
            jimatFaedah = if (asas.never) null else round2(asas.faedah - plan.faedah), jimatBulan = if (asas.never) null else asas.bulan - plan.bulan,
        )
    }

    /* ---------- laporan ---------- */
    fun finPeriod(dIso: String, startDay: Int): Period = commitmentPeriod(dIso, startDay)
    fun shiftPeriod(per: Period, n: Int, startDay: Int): Period = commitmentPeriod(addMonths(per.start, n), startDay)
    fun otKitaranBulan(s: PgState, ymStr: String): OtKitaranBulan {
        val sd = s.settings.otMulaHari.takeIf { it > 0 } ?: 22
        val q = parse(addMonths("$ymStr-01", -1))
        val c = otCycle(q.y, q.m, sd)
        val sm = otSummary(s, c)
        return OtKitaranBulan(c, round2(sm.nilai), sm.hari, round2(sm.h15 + sm.h20 + sm.h30))
    }
    private fun addTo(map: MutableMap<String, Double>, k: String, v: Double) { map[k] = round2((map[k] ?: 0.0) + v) }
    fun periodReport(s: PgState, per: Period): PeriodReport {
        val r = PeriodReport(per.start, per.end)
        val top = ArrayList<Tx>()
        fun katAdd(map: MutableMap<String, Double>, belum: Belum, t: Tx) {
            val k = kategoriOf(t)
            addTo(map, k, t.jumlah)
            if (k == "belum") { belum.n++; belum.jumlah = round2(belum.jumlah + t.jumlah) }
        }
        val sett = otSettlements(s).byTx
        val kadIds = kadDebtIds(s)
        s.transactions.forEach { t ->
            if (t.tarikh < per.start || t.tarikh >= per.endExcl) return@forEach
            if (isPulangan(t)) {
                // duit dipulangkan: kurangkan belanja harian kategori itu (bukan pendapatan)
                val k = t.kategori!!
                r.keluar -= t.jumlah
                addTo(r.poket, t.poket, -t.jumlah); addTo(r.poketTunai, t.poket, -t.jumlah); addTo(r.poketHarian, t.poket, -t.jumlah)
                addTo(r.katTunai, k, -t.jumlah); addTo(r.katHarian, k, -t.jumlah)
                return@forEach
            }
            if (t.jenis == "masuk") { r.masuk += t.jumlah; sett[t.id]?.let { r.otBayar += it } }
            if (t.jenis == "keluar" && t.hutangId.isNotEmpty()) { if (t.hutangId in kadIds) r.bayarKad += t.jumlah else r.bayarPinjaman += t.jumlah }
            if (t.jenis == "keluar") {
                r.keluar += t.jumlah; r.bil++
                addTo(r.poket, t.poket, t.jumlah)
                addTo(r.poketTunai, t.poket, t.jumlah)
                katAdd(r.katTunai, r.belumTunai, t)
                if (t.komitmenId.isEmpty() && t.hutangId.isEmpty()) { addTo(r.poketHarian, t.poket, t.jumlah); katAdd(r.katHarian, r.belumHarian, t) }
                if (t.hutangId.isNotEmpty()) r.hutang += t.jumlah
                if (t.komitmenId.isNotEmpty()) r.komitmen += t.jumlah
                top.add(t)
            }
            if (t.jenis == "tunai-kad") { r.tunaiKad += t.jumlah; r.feeTunai += t.fee ?: 0.0 }
            if (t.jenis == "kad") {
                r.kad += t.jumlah; r.bil++
                addTo(r.poket, t.poket, t.jumlah)
                addTo(r.poketHarian, t.poket, t.jumlah)
                katAdd(r.katHarian, r.belumHarian, t)
                top.add(t)
            }
        }
        // pulangan boleh menjadikan entri poket/kategori sifar atau negatif — buang supaya carta tidak pelik
        for (m in listOf(r.poket, r.poketTunai, r.poketHarian, r.katTunai, r.katHarian)) m.entries.removeAll { it.value < 0.005 }
        r.masuk = round2(r.masuk); r.keluar = round2(r.keluar); r.hutang = round2(r.hutang); r.komitmen = round2(r.komitmen); r.kad = round2(r.kad)
        r.bersih = round2(r.masuk - r.keluar)
        r.harianTunai = round2(r.keluar - r.hutang - r.komitmen)
        r.harian = round2(r.harianTunai + r.kad)
        val sortedTop = top.sortedWith { a, b ->
            val c = sgn(b.jumlah - a.jumlah); if (c != 0) c else b.tarikh.compareTo(a.tarikh)
        }
        r.topL = sortedTop.filter { !(it.jenis == "keluar" && it.hutangId.isNotEmpty() && it.hutangId in kadIds) }.take(5)
        r.top = sortedTop.take(5)
        kadLogs(s, per.start, per.endExcl).forEach { r.kadLog += it.jumlah }
        var d = per.start
        while (d < per.endExcl) { if (s.ot.containsKey(d)) r.otHarian += otValue(s, d).nilai; d = addDays(d, 1) }
        val okb = otKitaranBulan(s, ym(per.start))
        r.otEarned = okb.nilai
        r.otKitaran = OtKitaranInfo(okb.cycle.start, okb.cycle.end, okb.hari, okb.cycle.bayarYm)
        r.otBayar = round2(r.otBayar); r.bayarKad = round2(r.bayarKad); r.bayarPinjaman = round2(r.bayarPinjaman); r.kadLog = round2(r.kadLog)
        r.otEarned = round2(r.otEarned); r.otHarian = round2(r.otHarian)
        r.tunaiKad = round2(r.tunaiKad); r.feeTunai = round2(r.feeTunai)
        r.pendGaji = round2(r.masuk - r.otBayar)
        r.pend = round2(r.pendGaji + r.otEarned)
        r.belanja = round2(r.harian + r.komitmen + r.bayarPinjaman + r.kadLog)
        r.lebihan = round2(r.pend - r.belanja)
        return r
    }
    fun trendPeriods(s: PgState, per: Period, n: Int, startDay: Int): List<TrendRow> {
        val out = ArrayList<TrendRow>()
        for (i in n - 1 downTo 0) {
            val p = shiftPeriod(per, -i, startDay)
            val r = periodReport(s, p)
            out.add(TrendRow(p.start, p.end, r.masuk, r.keluar, r.bersih, r.hutang, r.pend, r.belanja, r.lebihan))
        }
        while (out.size > 1 && out[0].masuk == 0.0 && out[0].keluar == 0.0) out.removeAt(0)
        return out
    }
    fun otTrend(s: PgState, c: OtCycle, n: Int, startDay: Int): List<OtTrendRow> {
        val out = ArrayList<OtTrendRow>()
        for (i in n - 1 downTo 0) {
            val cc = shiftCycle(c, -i, startDay)
            val sm = otSummary(s, cc)
            out.add(OtTrendRow(cc.start, cc.end, cc.bayarYm, sm.nilai, round2(sm.h15 + sm.h20 + sm.h30), sm.kiraHad, sm.hari))
        }
        while (out.size > 1 && out[0].hari == 0) out.removeAt(0)
        return out
    }

    /* ---------- kalendar harian ---------- */
    fun dailySummary(s: PgState, ymStr: String, pocketId: String?): DailySummary {
        val start = "$ymStr-01"
        val p = parse(start)
        val endExcl = iso(p.y, p.m + 1, 1)
        val days = ArrayList<DayRow>()
        val idx = HashMap<String, Int>()
        var d = start
        while (d < endExcl) { idx[d] = days.size; days.add(DayRow(d)); d = addDays(d, 1) }
        val dom = dompetSet(s)
        var awal = 0.0; var sebelum = 0
        val pk = pocketId?.ifEmpty { null }
        val sett = if (pk != null) emptyMap() else otSettlements(s).byTx
        val kadIds = kadDebtIds(s)
        if (pk == null) kadLogs(s, start, endExcl).forEach { l -> days[idx.getValue(l.tarikh)].kadLog += l.jumlah }
        s.transactions.forEach { t ->
            val f = flows(t)
            val delta: Double
            if (pk != null) {
                if (f.inn != pk && f.out != pk) return@forEach
                delta = (if (f.inn == pk) t.jumlah else 0.0) - (if (f.out == pk) t.jumlah else 0.0)
            } else delta = signedBank(t, dom)
            if (t.tarikh < start) { awal += delta; sebelum++; return@forEach }
            val i = idx[t.tarikh] ?: return@forEach
            val x = days[i]
            x.n++; x.ubah += delta
            if (pk != null) { if (delta > 0) x.masuk += delta else x.keluar -= delta }
            else {
                if (isPulangan(t)) { x.keluar -= t.jumlah; x.harian -= t.jumlah }
                else if (t.jenis == "masuk") { x.masuk += t.jumlah; sett[t.id]?.let { x.otBayar += it } }
                if (t.jenis == "keluar") {
                    x.keluar += t.jumlah
                    if (t.komitmenId.isNotEmpty() || t.hutangId.isNotEmpty()) x.tetap += t.jumlah else x.harian += t.jumlah
                    if (t.hutangId.isNotEmpty() && t.hutangId in kadIds) x.bayarKad += t.jumlah
                }
                if (t.jenis == "kad") { x.harian += t.jumlah; x.kad += t.jumlah }
                if (t.jenis == "tunai-kad") x.tunai += t.jumlah
            }
        }
        var bal = round2(awal)
        var seen = sebelum
        days.forEach { x ->
            x.masuk = round2(x.masuk); x.keluar = round2(x.keluar); x.ubah = round2(x.ubah)
            x.harian = round2(x.harian); x.tetap = round2(x.tetap); x.kad = round2(x.kad); x.tunai = round2(x.tunai)
            x.bersih = round2(x.masuk - x.keluar)
            val ov = if (pk != null) OtVal(0.0, 0.0, 0.0, 0.0, 0.0, false) else otValue(s, x.tarikh)
            x.ot = ov.nilai; x.otJam = ov.jam; x.otAda = ov.recorded
            x.bakiOt = round2(x.ot - x.harian)
            x.otBayar = round2(x.otBayar); x.bayarKad = round2(x.bayarKad); x.kadLog = round2(x.kadLog)
            x.pend = round2(x.masuk - x.otBayar + x.ot)
            x.belanja = round2(x.keluar - x.bayarKad + x.kad + x.kadLog)
            x.bersihL = round2(x.pend - x.belanja)
            bal = round2(bal + x.ubah); x.baki = bal
            seen += x.n; x.ada = seen > 0
        }
        var tm = 0.0; var tk = 0.0; var tot = 0.0; var th = 0.0; var tt = 0.0; var tp = 0.0; var tb = 0.0; var tob = 0.0; var tbk = 0.0
        days.forEach { x -> tm += x.masuk; tk += x.keluar; tot += x.ot; th += x.harian; tt += x.tetap; tp += x.pend; tb += x.belanja; tob += x.otBayar; tbk += x.bayarKad }
        return DailySummary(round2(awal), days, round2(tm), round2(tk), bal, round2(tot), round2(th), round2(tt), round2(tot - th),
            round2(tp), round2(tb), round2(tp - tb), round2(tob), round2(tbk))
    }

    /* ---------- keadaan lalai ---------- */
    fun defaultState(): PgState = PgState(
        version = 2, contoh = false,
        settings = PgSettings(Gaji(2500.0, 0.0, 0.0, 9.0, 104.0, 0.0, 0.0), 1, 22, 0.0, "avalanche", true),
        pockets = listOf(
            Pocket(BELUM_AGIH, "Belum Agih", 0.0, tetap = true),
            Pocket("p-komitmen", "Komitmen & Bil"), Pocket("p-dapur", "Dapur"), Pocket("p-minyak", "Minyak & Tol"),
            Pocket("p-kecemasan", "Dana Kecemasan"), Pocket("p-bebas", "Belanja Bebas"),
        ),
    )

    /* ---------- pembantu ---------- */
    fun hariAntara(a: String, b: String): Int {
        val pa = parse(a); val pb = parse(b)
        return (LocalDate.of(pb.y, pb.m, pb.d).toEpochDay() - LocalDate.of(pa.y, pa.m, pa.d).toEpochDay()).toInt()
    }
    fun pocketName(s: PgState, id: String): String = s.pockets.find { it.id == id }?.nama ?: "(poket dipadam)"
    fun cariPoket(s: PgState, re: Regex): String =
        s.pockets.find { it.id != BELUM_AGIH && !it.dompet && re.containsMatchIn(it.nama) }?.id ?: ""
    fun lastDay(y: Int, m: Int): Int = lastDayOfMonth(y, m)
}
