package com.asyraf.hadirku.ui;

/**
 * Enjin gerakan gaya iPhone (ditulis dalam Java, dipanggil dari Kotlin / Jetpack Compose).
 *
 *  - bezier()      : lengkung cubic-bezier sama seperti UIKit / CSS
 *  - iosEase()     : lengkung lalai animasi iOS (lembut masuk & keluar)
 *  - iosOut()      : ease-out kuat untuk benda yang muncul
 *  - easeOutBack() : ease-out dengan sedikit lajak (bounce kecil di hujung)
 *  - bounceOut()   : lantunan seperti bola jatuh (untuk pie)
 *  - stagger()     : kemajuan bergilir untuk item ke-i (cth potongan pie satu-satu)
 *  - rubberBand()  : rintangan "getah" bila skrol melebihi hujung (macam iOS)
 *  - friction      : geseran fling iOS (lebih lama meluncur daripada Android)
 */
public final class Gerak {
    private Gerak() {}

    /** Geseran fling: kurang daripada 1 = meluncur lebih jauh dan licin (iOS ≈ 0.998 / ms). */
    public static final float FRICTION = 0.55f;

    /** Pemalar getah iOS (UIScrollView guna 0.55). */
    public static final float RUBBER = 0.55f;

    // ------------------------------------------------------------------ bezier

    /** Cubic-bezier (x1, y1, x2, y2) pada masa t (0..1). */
    public static float bezier(float x1, float y1, float x2, float y2, float t) {
        if (t <= 0f) return 0f;
        if (t >= 1f) return 1f;
        // cari u supaya X(u) = t : Newton-Raphson dulu, kemudian bahagi dua jika perlu
        float u = t;
        for (int i = 0; i < 8; i++) {
            float x = bx(u, x1, x2) - t;
            if (Math.abs(x) < 1e-5f) return by(u, y1, y2);
            float d = dbx(u, x1, x2);
            if (Math.abs(d) < 1e-6f) break;
            u -= x / d;
        }
        float lo = 0f, hi = 1f;
        u = t;
        for (int i = 0; i < 40; i++) {
            float x = bx(u, x1, x2);
            if (Math.abs(x - t) < 1e-5f) break;
            if (x < t) lo = u; else hi = u;
            u = (lo + hi) * 0.5f;
        }
        return by(u, y1, y2);
    }

    private static float bx(float u, float x1, float x2) {
        float m = 1f - u;
        return 3f * m * m * u * x1 + 3f * m * u * u * x2 + u * u * u;
    }

    private static float dbx(float u, float x1, float x2) {
        float m = 1f - u;
        return 3f * m * m * x1 + 6f * m * u * (x2 - x1) + 3f * u * u * (1f - x2);
    }

    private static float by(float u, float y1, float y2) {
        float m = 1f - u;
        return 3f * m * m * u * y1 + 3f * m * u * u * y2 + u * u * u;
    }

    // ------------------------------------------------------------------ lengkung siap

    /** Lengkung lalai UIKit. */
    public static float iosEase(float t) { return bezier(0.25f, 0.1f, 0.25f, 1f, t); }

    /** Ease-out kuat (cth helaian naik, kad muncul). */
    public static float iosOut(float t) { return bezier(0.17f, 0.84f, 0.44f, 1f, t); }

    /** Ease-out dengan lajak kecil di hujung. */
    public static float easeOutBack(float t) {
        t = clamp01(t);
        final float c1 = 1.55f, c3 = c1 + 1f;
        float x = t - 1f;
        return 1f + c3 * x * x * x + c1 * x * x;
    }

    /** Lantunan bola (3 lantunan kecil). */
    public static float bounceOut(float t) {
        t = clamp01(t);
        final float n1 = 7.5625f, d1 = 2.75f;
        if (t < 1f / d1) return n1 * t * t;
        if (t < 2f / d1) { t -= 1.5f / d1; return n1 * t * t + 0.75f; }
        if (t < 2.5f / d1) { t -= 2.25f / d1; return n1 * t * t + 0.9375f; }
        t -= 2.625f / d1;
        return n1 * t * t + 0.984375f;
    }

    /** Kemajuan setempat item ke-i daripada n; span = bahagian masa yang setiap item ambil. */
    public static float stagger(float t, int i, int n, float span) {
        if (n <= 1) return clamp01(t);
        span = Math.max(0.05f, Math.min(1f, span));
        float start = (1f - span) * i / (float) (n - 1);
        return clamp01((t - start) / span);
    }

    // ------------------------------------------------------------------ skrol

    /** Getah iOS: makin jauh ditarik, makin berat. offset & dimension dalam piksel. */
    public static float rubberBand(float offset, float dimension) {
        float d = Math.max(1f, dimension);
        float a = Math.abs(offset);
        float r = (1f - 1f / (a * RUBBER / d + 1f)) * d;
        return offset < 0f ? -r : r;
    }

    /** Hadkan halaju lantunan di hujung senarai supaya tak terlalu kuat. */
    public static float edgeVelocity(float v) {
        float max = 7000f;
        float s = v * 0.6f;
        return Math.max(-max, Math.min(max, s));
    }

    public static float clamp01(float v) { return v < 0f ? 0f : (v > 1f ? 1f : v); }

    public static float lerp(float a, float b, float t) { return a + (b - a) * t; }
}
