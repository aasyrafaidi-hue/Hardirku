package com.asyraf.hadirku.engine.core

import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId

/** Local timezone of the app's users. Due dates are local dates; creation times are UTC instants. */
val APP_ZONE: ZoneId = ZoneId.of("Asia/Kuala_Lumpur")

/** Injectable clock so every engine output is reproducible in tests. */
interface EngineClock {
    fun now(): Instant
    fun zone(): ZoneId = APP_ZONE
    // atZone().toLocalDate() (API 26) — LocalDate.ofInstant is Java 9 / Android API 34 only.
    fun today(): LocalDate = now().atZone(zone()).toLocalDate()
}

object SystemEngineClock : EngineClock {
    override fun now(): Instant = Instant.now()
}

class FixedClock(private val instant: Instant, private val z: ZoneId = APP_ZONE) : EngineClock {
    override fun now(): Instant = instant
    override fun zone(): ZoneId = z

    companion object {
        /** Clock fixed at 09:00 local time on [date]. */
        fun at(date: LocalDate, zone: ZoneId = APP_ZONE): FixedClock =
            FixedClock(date.atTime(9, 0).atZone(zone).toInstant(), zone)
    }
}

/**
 * What a "day 29–31" schedule does in a shorter month. Explicit policy — never implicit.
 * CLAMP_TO_MONTH_END is what the existing app already does for commitment `tempo`.
 */
enum class DueDayPolicy { CLAMP_TO_MONTH_END, ROLL_TO_NEXT_MONTH }

object Dates {
    /** Due date for [dayOfMonth] (1..31) in [ym] under [policy]. */
    fun dueDate(ym: YearMonth, dayOfMonth: Int, policy: DueDayPolicy = DueDayPolicy.CLAMP_TO_MONTH_END): LocalDate {
        require(dayOfMonth in 1..31) { "dayOfMonth must be 1..31" }
        val last = ym.lengthOfMonth()
        return if (dayOfMonth <= last) ym.atDay(dayOfMonth)
        else when (policy) {
            DueDayPolicy.CLAMP_TO_MONTH_END -> ym.atEndOfMonth()
            DueDayPolicy.ROLL_TO_NEXT_MONTH -> ym.plusMonths(1).atDay(1)
        }
    }

    /** Add months to [d] keeping the day, clamped to the target month length (31 Jan + 1 → 28/29 Feb). */
    fun addMonthsClamped(d: LocalDate, months: Long): LocalDate = d.plusMonths(months)

    fun parseIsoOrNull(s: String?): LocalDate? = try {
        if (s.isNullOrBlank()) null else LocalDate.parse(s.trim())
    } catch (_: Exception) { null }

    /** Inclusive day count from a to b (a ≤ b → ≥ 1). */
    fun daysInclusive(a: LocalDate, b: LocalDate): Long = java.time.temporal.ChronoUnit.DAYS.between(a, b) + 1

    fun daysBetween(a: LocalDate, b: LocalDate): Long = java.time.temporal.ChronoUnit.DAYS.between(a, b)
}

/** Half-open date range [start, endExclusive). */
data class DateRange(val start: LocalDate, val endExclusive: LocalDate) {
    init { require(!endExclusive.isBefore(start)) { "range end before start" } }
    operator fun contains(d: LocalDate): Boolean = !d.isBefore(start) && d.isBefore(endExclusive)
    val lastDay: LocalDate get() = endExclusive.minusDays(1)
    val days: Long get() = Dates.daysBetween(start, endExclusive)

    companion object {
        fun month(ym: YearMonth) = DateRange(ym.atDay(1), ym.plusMonths(1).atDay(1))
        fun inclusive(a: LocalDate, b: LocalDate) = DateRange(a, b.plusDays(1))
    }
}
