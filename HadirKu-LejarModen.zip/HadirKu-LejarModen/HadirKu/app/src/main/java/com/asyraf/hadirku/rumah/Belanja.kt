package com.asyraf.hadirku.rumah

import com.asyraf.hadirku.kongsi.SejarahBeli
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.PgState
import com.asyraf.hadirku.pg.Pocket
import com.asyraf.hadirku.pg.Tx
import kotlin.math.max

/** Kiraan rumah tangga: boleh belanja hari ni, amaran poket, ringkasan mingguan, bil & beli semula. */
object Belanja {
    private val RE_HARIAN = Regex("dapur|minyak|petrol|anak|keperluan|beli|shopping|harian|bebas|makan", RegexOption.IGNORE_CASE)
    private val RE_BUKAN = Regex("bil|simpan|kecemasan|komitmen|tabung", RegexOption.IGNORE_CASE)

    /** Poket belanja harian lalai: ikut nama (Dapur, Minyak, Anak, Beli-belah), tanpa Bil & Simpanan. */
    fun lalaiPoket(s: PgState): Set<String> = s.pockets.filter {
        it.id != PG.BELUM_AGIH && RE_HARIAN.containsMatchIn(it.nama) && !RE_BUKAN.containsMatchIn(it.nama)
    }.map { it.id }.toSet()

    /** Poket yang dikira: pilihan pengguna (jika ada & masih wujud), atau lalai. */
    fun poketHarian(s: PgState, pilihan: Set<String>?): List<Pocket> {
        val ids = pilihan?.filter { id -> s.pockets.any { it.id == id } }?.toSet()?.takeIf { it.isNotEmpty() } ?: lalaiPoket(s)
        return s.pockets.filter { it.id in ids }
    }

    /** Belanja dari poket (Keluar + Guna kad) antara dua tarikh, termasuk kedua-duanya. */
    fun belanjaPoket(s: PgState, id: String, dari: String, hingga: String): Double = PG.round2(
        s.transactions.filter { it.poket == id && it.tarikh >= dari && it.tarikh <= hingga && (it.jenis == "keluar" || it.jenis == "kad") }.sumOf { it.jumlah },
    )

    // ---------------- boleh belanja hari ni ----------------

    class Harian(val boleh: Double, val baki: Double, val hariTinggal: Int, val poket: List<Pocket>, val belanjaHariIni: Double, val sehari: Double)

    /**
     * Baki poket belanja (sebelum belanja hari ini) dibahagi hari yang tinggal termasuk hari ini,
     * kemudian ditolak belanja hari ini. Negatif = dah lebih untuk hari ini.
     */
    fun harian(s: PgState, today: String, pilihan: Set<String>?): Harian {
        val pk = poketHarian(s, pilihan)
        val b = PG.balances(s)
        val p = PG.parse(today)
        val tinggal = PG.lastDay(p.y, p.m) - p.d + 1
        val baki = PG.round2(pk.sumOf { max(0.0, b[it.id] ?: 0.0) })
        val hariIni = PG.round2(pk.sumOf { belanjaPoket(s, it.id, today, today) })
        val sehari = (baki + hariIni) / tinggal
        return Harian(PG.round2(sehari - hariIni), baki, tinggal, pk, hariIni, PG.round2(sehari))
    }

    // ---------------- amaran poket ----------------

    class Amaran(val pocket: Pocket, val tahap: Int, val guna: Double, val belanja: Double, val baki: Double, val hariTinggal: Int) {
        val sehari: Double get() = if (hariTinggal > 0) PG.round2(max(0.0, baki) / hariTinggal) else 0.0
        /** Ayat mesra, bukan marah-marah. */
        fun teks(): String = when (tahap) {
            100 -> "Poket ${pocket.nama} dah habis untuk bulan ni. Tak apa — kalau perlu, pindah sikit dari Belum Agih atau poket lain."
            80 -> "Poket ${pocket.nama} tinggal ${PG.money(baki)} dan bulan masih ada $hariTinggal hari. Perlahan sikit ya, lebih kurang ${PG.money(sehari)} sehari cukup sampai hujung bulan."
            else -> "Poket ${pocket.nama} dah guna separuh (${PG.money(belanja)}). Baki ${PG.money(baki)} untuk $hariTinggal hari — lebih kurang ${PG.money(sehari)} sehari."
        }
        fun tajuk(): String = when (tahap) { 100 -> "${pocket.nama} dah habis"; 80 -> "${pocket.nama} hampir habis"; else -> "${pocket.nama} dah separuh" }
    }

    /**
     * Poket belanja yang habis lebih cepat daripada bulan berjalan
     * (cth 80% dah guna tapi baru hari ke-10). Tahap 50 / 80 / 100.
     */
    fun amaran(s: PgState, today: String, pilihan: Set<String>?): List<Amaran> {
        val per = PG.finPeriod(today, 1)
        val p = PG.parse(today)
        val akhir = PG.lastDay(p.y, p.m)
        val masa = p.d.toDouble() / akhir
        val tinggal = akhir - p.d + 1
        val b = PG.balances(s)
        return poketHarian(s, pilihan).mapNotNull { pk ->
            val bel = belanjaPoket(s, pk.id, per.start, today)
            val baki = b[pk.id] ?: 0.0
            val jum = bel + max(0.0, baki)
            if (bel <= 0.004 || jum <= 0.004) return@mapNotNull null
            val guna = bel / jum
            val tahap = when { baki <= 0.004 -> 100; guna >= 0.8 -> 80; guna >= 0.5 -> 50; else -> 0 }
            if (tahap == 0 || (tahap < 100 && guna - masa < 0.25) || (tahap == 100 && p.d == akhir)) null
            else Amaran(pk, tahap, guna, PG.round2(bel), PG.round2(baki), tinggal)
        }
    }

    // ---------------- ringkasan mingguan ----------------

    class Minggu(val mula: String, val akhir: String, val belanja: Double, val lepas: Double, val poket: List<Pair<String, Double>>, val kat: Pair<String, Double>?, val bil: Int) {
        val beza: Double get() = PG.round2(belanja - lepas)
        fun label(): String = PG.fmtShort(mula) + " – " + PG.fmtShort(akhir)
    }

    /** Ahad (akhir minggu Isnin–Ahad) bagi minggu yang mengandungi tarikh ini. */
    fun ahadMinggu(d: String): String = PG.addDays(d, (7 - PG.weekday(d)) % 7)

    private fun isBelanja(s: PgState, t: Tx): Boolean {
        if (t.jenis == "kad") return true
        if (t.jenis != "keluar") return false
        // bayar kad kredit = pindah ke kad, belanja sudah dikira semasa guna kad
        return !(t.hutangId.isNotEmpty() && s.debts.any { it.id == t.hutangId && it.jenis == "kad" })
    }

    private fun jumlahMinggu(s: PgState, mula: String, akhir: String): List<Tx> = s.transactions.filter { it.tarikh >= mula && it.tarikh <= akhir && isBelanja(s, it) }

    fun minggu(s: PgState, akhir: String): Minggu {
        val mula = PG.addDays(akhir, -6)
        val ini = jumlahMinggu(s, mula, akhir)
        val lepas = jumlahMinggu(s, PG.addDays(mula, -7), PG.addDays(akhir, -7))
        val byP = LinkedHashMap<String, Double>()
        ini.forEach { byP[it.poket] = (byP[it.poket] ?: 0.0) + it.jumlah }
        val byK = LinkedHashMap<String, Double>()
        ini.filter { PG.bolehKategori(it) }.forEach { val k = PG.kategoriOf(it); if (k != "belum") byK[k] = (byK[k] ?: 0.0) + it.jumlah }
        val top = byP.entries.sortedByDescending { it.value }.map { PG.pocketName(s, it.key) to PG.round2(it.value) }
        val k = byK.entries.maxByOrNull { it.value }?.let { PG.katLabel(it.key) to PG.round2(it.value) }
        return Minggu(mula, akhir, PG.round2(ini.sumOf { it.jumlah }), PG.round2(lepas.sumOf { it.jumlah }), top, k, ini.size)
    }

    /** Teks pendek untuk notifikasi / WhatsApp. */
    fun teksMinggu(m: Minggu, nama: String? = null): String {
        val sb = StringBuilder()
        sb.append("Ringkasan belanja ").append(m.label()).append(if (nama != null) " ($nama)" else "").append("\n")
        if (m.bil == 0) { sb.append("Tiada belanja direkod minggu ni."); return sb.toString() }
        sb.append("• Belanja minggu ni ").append(PG.money(m.belanja)).append(" (").append(m.bil).append(" transaksi)\n")
        m.poket.firstOrNull()?.let { sb.append("• Paling banyak: ").append(it.first).append(" ").append(PG.money(it.second)).append("\n") }
        m.kat?.let { sb.append("• Kategori utama: ").append(it.first).append(" ").append(PG.money(it.second)).append("\n") }
        when {
            m.lepas <= 0.004 -> sb.append("• Tiada belanja direkod minggu lepas untuk dibanding")
            m.beza < -0.004 -> sb.append("• Jimat ").append(PG.money(-m.beza)).append(" berbanding minggu lepas 👏")
            m.beza > 0.004 -> sb.append("• Lebih ").append(PG.money(m.beza)).append(" berbanding minggu lepas")
            else -> sb.append("• Sama dengan minggu lepas")
        }
        return sb.toString()
    }

    /** Satu ayat untuk notifikasi Ahad malam. */
    fun ayatMinggu(m: Minggu): String {
        if (m.bil == 0) return "Tiada belanja direkod minggu ni. Jangan lupa rekod belanja ya."
        val top = m.poket.firstOrNull()?.first?.lowercase()
        val banding = when {
            m.lepas <= 0.004 -> ""
            m.beza < -0.004 -> ", jimat " + PG.money(-m.beza) + " berbanding minggu lepas"
            m.beza > 0.004 -> ", lebih " + PG.money(m.beza) + " berbanding minggu lepas"
            else -> ", sama macam minggu lepas"
        }
        return "Minggu ni belanja " + PG.money(m.belanja) + (if (top != null) ", $top paling banyak" else "") + banding + "."
    }

    // ---------------- beli semula ----------------

    class Cadangan(val nama: String, val selang: Int, val terakhir: String, val jangka: String)

    /** Barang yang biasa dibeli setiap ~N hari dan hampir sampai masa (dalam 2 hari), tapi belum ada dalam senarai. */
    fun cadangan(sej: List<SejarahBeli>, adaDalamSenarai: Set<String>, today: String, kunci: (String) -> String): List<Cadangan> = sej.mapNotNull { h ->
        val t = h.tarikh.distinct().sorted()
        if (t.size < 2 || kunci(h.nama) in adaDalamSenarai) return@mapNotNull null
        val gaps = t.zipWithNext { a, b -> PG.hariAntara(a, b) }.filter { it > 0 }
        if (gaps.isEmpty()) return@mapNotNull null
        val selang = Math.round(gaps.average()).toInt().coerceAtLeast(2)
        val jangka = PG.addDays(t.last(), selang)
        if (PG.hariAntara(today, jangka) <= 2) Cadangan(h.nama, selang, t.last(), jangka) else null
    }.sortedBy { it.jangka }
}
