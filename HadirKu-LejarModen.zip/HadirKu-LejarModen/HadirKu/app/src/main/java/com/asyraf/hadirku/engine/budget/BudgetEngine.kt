package com.asyraf.hadirku.engine.budget

import com.asyraf.hadirku.engine.core.DateRange
import com.asyraf.hadirku.engine.core.Money
import com.asyraf.hadirku.engine.ledger.LedgerBook
import com.asyraf.hadirku.engine.ledger.LedgerReports
import java.math.BigDecimal
import java.time.YearMonth

/* =====================================================================
 * Engine 10 — Budget Optimisation
 * Category budgets per month, planned vs actual (refunds netted, reversals removed), configurable
 * carry-over, and SUGGESTIONS only — budgets are never rewritten by the engine.
 * ===================================================================== */

enum class CarryOver { NONE, UNDERSPEND_ONLY, BOTH }

data class Budget(
    val id: String,
    val category: String,
    val amount: Money,
    val startMonth: YearMonth,
    val carryOver: CarryOver = CarryOver.NONE,
    /** essential spending (groceries, bills, health…) — suggestions never cut it below its trailing average */
    val essential: Boolean = false,
)

data class BudgetLine(
    val budget: Budget, val month: YearMonth, val carryIn: Money, val planned: Money,
    val actual: Money, val remaining: Money, val over: Money, val usedBp: Int,
)

enum class SuggestionKind { RAISE, LOWER, KEEP, NEW_BUDGET }

data class BudgetSuggestion(
    val kind: SuggestionKind, val category: String, val current: Money?, val suggested: Money,
    val trailingAverage: Money, val trendBp: Int, val protectedEssential: Boolean, val basis: List<String>,
    /** bilangan bulan penuh yang benar-benar ada rekod dan dipakai untuk purata (≤ lookback) */
    val months: Int = 3,
)

object BudgetEngine {
    /** Categories treated as essential by default (existing app category ids). */
    val DEFAULT_ESSENTIALS = setOf("dapur", "bil", "rumah", "kesihatan", "minyak", "keluarga")

    fun actual(book: LedgerBook, category: String, month: YearMonth): Money =
        LedgerReports.expenseByCategory(book, DateRange.month(month))[category] ?: Money.ZERO

    /** Budget line for [month] with carry-over computed sequentially from the budget's start month. */
    fun line(book: LedgerBook, b: Budget, month: YearMonth): BudgetLine {
        var carry = Money.ZERO
        var m = b.startMonth
        while (m.isBefore(month)) {
            val planned = b.amount + carry
            val left = planned - actual(book, b.category, m)
            carry = when (b.carryOver) {
                CarryOver.NONE -> Money.ZERO
                CarryOver.UNDERSPEND_ONLY -> left.coerceAtLeast(Money.ZERO)
                CarryOver.BOTH -> left
            }
            m = m.plusMonths(1)
        }
        val planned = b.amount + carry
        val act = actual(book, b.category, month)
        val rem = planned - act
        val bp = if (!planned.isPositive) (if (act.isPositive) 99999 else 0) else ((act.sen * 10000) / planned.sen).toInt()
        return BudgetLine(b, month, carry, planned, act, rem.coerceAtLeast(Money.ZERO), (-rem).coerceAtLeast(Money.ZERO), bp)
    }

    fun lines(book: LedgerBook, budgets: List<Budget>, month: YearMonth): List<BudgetLine> =
        budgets.filter { !it.startMonth.isAfter(month) }.map { line(book, it, month) }

    /**
     * Suggestions from the trailing [lookback] complete months before [month]. Returns proposals only.
     * Only months the user was actually recording are used ("data matang"): a month counts when recording
     * started on or before day [GRACE_DAY] of it. Empty months before the first record are NOT averaged in as
     * RM0 (that would understate spending and suggest budgets that are too low).
     * Rules: suggested = average over the counted months rounded up to RM10; essentials are never suggested below
     * their average; a RAISE is proposed when the budget was exceeded in most counted months; a LOWER only when all
     * [lookback] months have data and spending stayed under 70% of the budget in every one; categories with spending
     * but no budget get NEW_BUDGET. No counted month → no suggestions.
     */
    fun suggestions(book: LedgerBook, budgets: List<Budget>, month: YearMonth, lookback: Int = 3, essentials: Set<String> = DEFAULT_ESSENTIALS): List<BudgetSuggestion> {
        val mula = LedgerReports.activityStart(book) ?: return emptyList()
        val months = (1..lookback).map { month.minusMonths(it.toLong()) }.filter { !mula.isAfter(it.atDay(GRACE_DAY)) }
        val n = months.size
        if (n == 0) return emptyList()
        val perMonth = months.map { m -> LedgerReports.expenseByCategory(book, DateRange.month(m)) }
        val cats = (perMonth.flatMap { it.keys }.filterNotNull() + budgets.map { it.category }).toSortedSet()
        val out = ArrayList<BudgetSuggestion>()
        for (c in cats) {
            val series = perMonth.map { it[c] ?: Money.ZERO }               // newest first
            val avg = Money.sum(series).div(n.toLong())
            val newest = series.first(); val oldest = series.last()
            val trend = if (n > 1 && oldest.isPositive) (((newest.sen - oldest.sen) * 10000) / oldest.sen).toInt() else 0
            val rounded = roundUpTo(avg, Money.parse("10.00"))
            val ess = c in essentials
            val b = budgets.find { it.category == c }
            if (b == null) {
                if (avg.isPositive) out += BudgetSuggestion(SuggestionKind.NEW_BUDGET, c, null, rounded, avg, trend, ess, listOf("avg_${n}m"), n)
                continue
            }
            val overMonths = series.count { it > b.amount }
            val lowMonths = series.count { it <= b.amount.times(BigDecimal("0.70")) }
            val (kind, sug) = when {
                overMonths * 2 > n -> SuggestionKind.RAISE to rounded.max(b.amount)
                n == lookback && lowMonths == n && !ess -> SuggestionKind.LOWER to rounded.max(Money.parse("10.00")).min(b.amount)
                else -> SuggestionKind.KEEP to b.amount
            }
            val protectedSug = if (ess) sug.max(avg) else sug
            out += BudgetSuggestion(kind, c, b.amount, protectedSug, avg, trend, ess,
                listOf("avg_${n}m", "over_months=$overMonths", "low_months=$lowMonths"), n)
        }
        return out
    }

    /** Bulan dikira "ada rekod" jika pengguna mula merekod pada atau sebelum hari ini dalam bulan itu. */
    const val GRACE_DAY = 5

    private fun roundUpTo(x: Money, step: Money): Money {
        if (!x.isPositive) return Money.ZERO
        val n = (x.sen + step.sen - 1) / step.sen
        return Money(n * step.sen)
    }
}
