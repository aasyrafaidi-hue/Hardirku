package com.asyraf.hadirku.engine.receipt

import com.asyraf.hadirku.engine.core.MiniJson
import com.asyraf.hadirku.engine.core.Money
import com.asyraf.hadirku.engine.core.list
import java.math.BigDecimal
import java.time.LocalDate
import java.time.LocalTime

/* =====================================================================
 * Engine 1 — Receipt Intelligence: versioned strict JSON contract (schema v1)
 *
 * Every field is an object { "value": …, "confidence": "high|medium|low", "source": "printed|handwritten|inferred" }
 * or null / absent. Missing or unreadable data stays NULL — the parser never invents values and never
 * converts a wrong type silently (it records a warning instead).
 *
 * {
 *   "schema_version": 1,
 *   "merchant": F<string>, "date": F<"YYYY-MM-DD">, "time": F<"HH:mm">, "currency": F<"MYR">,
 *   "items": [ { "name": F<string>, "quantity": F<number>, "unit_price": F<number>, "line_total": F<number> } ],
 *   "subtotal": F<number>, "service_charge": F<number>, "tax": F<number>,
 *   "discount": F<number ≥ 0, amount taken off>, "rounding": F<number, signed>, "total": F<number>,
 *   "payment_method": F<"cash|credit_card|debit_card|ewallet|other">, "receipt_id": F<string>
 * }
 * ===================================================================== */

const val RECEIPT_SCHEMA_VERSION = 1

enum class FieldConfidence { HIGH, MEDIUM, LOW }
enum class FieldSource { PRINTED, HANDWRITTEN, INFERRED }

data class Field<T>(val value: T?, val confidence: FieldConfidence? = null, val source: FieldSource? = null) {
    val present: Boolean get() = value != null
    val uncertain: Boolean get() = value == null || confidence == FieldConfidence.LOW || source == FieldSource.INFERRED
    companion object { fun <T> empty(): Field<T> = Field(null) }
}

data class ReceiptItem(
    val name: Field<String>, val quantity: Field<BigDecimal>, val unitPrice: Field<Money>, val lineTotal: Field<Money>,
)

data class ReceiptData(
    val schemaVersion: Int = RECEIPT_SCHEMA_VERSION,
    val merchant: Field<String> = Field.empty(),
    val date: Field<LocalDate> = Field.empty(),
    val time: Field<LocalTime> = Field.empty(),
    val currency: Field<String> = Field.empty(),
    val items: List<ReceiptItem> = emptyList(),
    val subtotal: Field<Money> = Field.empty(),
    val serviceCharge: Field<Money> = Field.empty(),
    val tax: Field<Money> = Field.empty(),
    val discount: Field<Money> = Field.empty(),
    val rounding: Field<Money> = Field.empty(),
    val total: Field<Money> = Field.empty(),
    val paymentMethod: Field<String> = Field.empty(),
    val receiptId: Field<String> = Field.empty(),
    /** which provider produced it ("legacy-device", "backend-claude", "backend-openai", "manual") */
    val provider: String = "",
)

sealed class ReceiptParse {
    data class Ok(val data: ReceiptData, val warnings: List<String>) : ReceiptParse()
    data class Invalid(val errors: List<String>) : ReceiptParse()
}

object ReceiptJson {
    private val PAYMENT = setOf("cash", "credit_card", "debit_card", "ewallet", "other")

    fun parse(text: String, provider: String = ""): ReceiptParse {
        val root = try { MiniJson.parseObject(text) } catch (e: Exception) { return ReceiptParse.Invalid(listOf("not_json")) }
        val ver = (root["schema_version"] as? BigDecimal)?.toInt()
        if (ver != RECEIPT_SCHEMA_VERSION) return ReceiptParse.Invalid(listOf("schema_version:" + (ver ?: "missing")))
        val w = ArrayList<String>()
        fun meta(o: Map<String, Any?>?, path: String): Pair<FieldConfidence?, FieldSource?> {
            if (o == null) return null to null
            val c = (o["confidence"] as? String)?.let { s -> FieldConfidence.entries.find { it.name.equals(s, true) } ?: run { w += "$path.confidence"; null } }
            val src = (o["source"] as? String)?.let { s -> FieldSource.entries.find { it.name.equals(s, true) } ?: run { w += "$path.source"; null } }
            return c to src
        }
        fun field(o: Map<String, Any?>, k: String, path: String = k): Map<String, Any?>? {
            val f = o[k] ?: return null
            @Suppress("UNCHECKED_CAST")
            return (f as? Map<String, Any?>) ?: run { w += "$path:not_object"; null }
        }
        fun str(o: Map<String, Any?>, k: String, path: String = k): Field<String> {
            val f = field(o, k, path) ?: return Field.empty()
            val v = f["value"]; val (c, s) = meta(f, path)
            return when (v) { null -> Field(null, c, s); is String -> Field(v.trim().ifEmpty { null }, c, s); else -> { w += "$path:type"; Field(null, c, s) } }
        }
        fun money(o: Map<String, Any?>, k: String, path: String = k): Field<Money> {
            val f = field(o, k, path) ?: return Field.empty()
            val v = f["value"]; val (c, s) = meta(f, path)
            return when (v) { null -> Field(null, c, s); is BigDecimal -> Field(Money.of(v), c, s); else -> { w += "$path:type"; Field(null, c, s) } }
        }
        fun dec(o: Map<String, Any?>, k: String, path: String): Field<BigDecimal> {
            val f = field(o, k, path) ?: return Field.empty()
            val v = f["value"]; val (c, s) = meta(f, path)
            return when (v) { null -> Field(null, c, s); is BigDecimal -> Field(v, c, s); else -> { w += "$path:type"; Field(null, c, s) } }
        }
        val dateS = str(root, "date")
        val date = dateS.value?.let { runCatching { LocalDate.parse(it) }.getOrNull() ?: run { w += "date:format"; null } }
        val timeS = str(root, "time")
        val time = timeS.value?.let { runCatching { LocalTime.parse(it) }.getOrNull() ?: run { w += "time:format"; null } }
        val pay = str(root, "payment_method").let { f -> if (f.value != null && f.value !in PAYMENT) { w += "payment_method:enum"; f.copy(value = null) } else f }
        val items = (root.list("items") ?: emptyList()).mapIndexedNotNull { i, x ->
            @Suppress("UNCHECKED_CAST")
            val o = x as? Map<String, Any?> ?: run { w += "items[$i]:not_object"; return@mapIndexedNotNull null }
            ReceiptItem(str(o, "name", "items[$i].name"), dec(o, "quantity", "items[$i].quantity"), money(o, "unit_price", "items[$i].unit_price"), money(o, "line_total", "items[$i].line_total"))
        }
        val discount = money(root, "discount").let { f -> if (f.value?.isNegative == true) { w += "discount:negative"; f.copy(value = f.value.abs()) } else f }
        return ReceiptParse.Ok(
            ReceiptData(
                RECEIPT_SCHEMA_VERSION, str(root, "merchant"), Field(date, dateS.confidence, dateS.source), Field(time, timeS.confidence, timeS.source),
                str(root, "currency"), items, money(root, "subtotal"), money(root, "service_charge"), money(root, "tax"),
                discount, money(root, "rounding"), money(root, "total"), pay, str(root, "receipt_id"), provider,
            ), w,
        )
    }

    /** Map the EXISTING app's receipt tool output (`rekod_resit`, Ai.readReceipt) into schema v1 without inventing fields. */
    fun fromLegacy(json: String): ReceiptParse {
        val o = try { MiniJson.parseObject(json) } catch (e: Exception) { return ReceiptParse.Invalid(listOf("not_json")) }
        if (o["boleh_baca"] == false) return ReceiptParse.Ok(ReceiptData(provider = "legacy-device"), listOf("unreadable"))
        val conf = when (o["keyakinan"]) { "tinggi" -> FieldConfidence.HIGH; "sederhana" -> FieldConfidence.MEDIUM; "rendah" -> FieldConfidence.LOW; else -> null }
        val date = (o["tarikh"] as? String)?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
        val total = (o["jumlah"] as? BigDecimal)?.let { Money.of(it) }
        val pay = when (o["cara_bayar"]) { "tunai" -> "cash"; "kad_kredit" -> "credit_card"; "kad_debit" -> "debit_card"; "ewallet" -> "ewallet"; "lain" -> "other"; else -> null }
        val items = (o.list("item") ?: emptyList()).mapNotNull { x ->
            @Suppress("UNCHECKED_CAST") val m = x as? Map<String, Any?> ?: return@mapNotNull null
            ReceiptItem(Field((m["nama"] as? String)?.trim()?.ifEmpty { null }, conf), Field.empty(), Field.empty(), Field((m["jumlah"] as? BigDecimal)?.let { Money.of(it) }, conf))
        }
        return ReceiptParse.Ok(ReceiptData(
            merchant = Field((o["kedai"] as? String)?.trim()?.ifEmpty { null }, conf), date = Field(date, conf), currency = Field(null),
            items = items, total = Field(total, conf), paymentMethod = Field(pay, conf), provider = "legacy-device",
        ), emptyList())
    }

    fun toJson(d: ReceiptData): String {
        fun <T> f(x: Field<T>, conv: (T) -> Any?): Any? = if (x.value == null && x.confidence == null) null else linkedMapOf(
            "value" to x.value?.let(conv), "confidence" to x.confidence?.name?.lowercase(), "source" to x.source?.name?.lowercase())
        val m: (Money) -> Any = { it.toDecimal() }
        return MiniJson.write(linkedMapOf(
            "schema_version" to d.schemaVersion, "merchant" to f(d.merchant) { it }, "date" to f(d.date) { it.toString() },
            "time" to f(d.time) { it.toString() }, "currency" to f(d.currency) { it },
            "items" to d.items.map { linkedMapOf("name" to f(it.name) { v -> v }, "quantity" to f(it.quantity) { v -> v }, "unit_price" to f(it.unitPrice, m), "line_total" to f(it.lineTotal, m)) },
            "subtotal" to f(d.subtotal, m), "service_charge" to f(d.serviceCharge, m), "tax" to f(d.tax, m), "discount" to f(d.discount, m),
            "rounding" to f(d.rounding, m), "total" to f(d.total, m), "payment_method" to f(d.paymentMethod) { it }, "receipt_id" to f(d.receiptId) { it },
        ))
    }
}
