package com.asyraf.hadirku.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.asyraf.hadirku.MainViewModel
import com.asyraf.hadirku.Sheet
import com.asyraf.hadirku.pg.OtRow
import com.asyraf.hadirku.pg.PG

/**
 * Tab OT (id dalaman kekal "kerja").
 * Susunan ringkas: kitaran ‹ › → nilai OT + had → kad Hari ini → peringatan hari belum diisi → log (terkini di atas).
 * Key in guna helaian papan nombor (OtSheet.kt): tekan kad Hari ini, mana-mana baris log, atau butang "Key in OT".
 */
@Composable
fun KerjaScreen(vm: MainViewModel) {
    val pal = LocalPal.current
    val pg by vm.pg.collectAsState()
    val today = vm.today()
    val c = vm.cyc
    val sd = vm.otSd()
    val sum = remember(pg, c) { PG.otSummary(pg, c) }
    val otJam = sum.h15 + sum.h20 + sum.h30

    NavRow(PG.fmtShort(c.start) + " – " + PG.fmtShort(c.end), "Dibayar dalam gaji " + PG.fmtMonth(c.bayarYm),
        { vm.cyc = PG.shiftCycle(c, -1, sd) }, { vm.cyc = PG.shiftCycle(c, 1, sd) })

    Hero("Nilai OT kitaran ini", sum.nilai) {
        Txt(rich("**" + fmtH(otJam) + " jam OT** · " + sum.hari + " hari direkod · " + M(sum.hrp) + " sejam"), size = 13f, color = pal.muted)
        if (sum.had > 0) {
            val f = sum.kiraHad / sum.had
            Spacer(Modifier.height(10.dp))
            Bar(f, over = f > 1.0, warn = f >= 0.85)
            Spacer(Modifier.height(5.dp))
            Txt(
                "Had OT " + fmtH(sum.kiraHad) + " / " + PG.jsNum(sum.had) + " jam" +
                    if (sum.bakiHad >= 0) " · baki " + fmtH(sum.bakiHad) + " jam" else " · melebihi had",
                size = 12f, color = if (f > 1.0) pal.bad else pal.muted,
            )
        }
    }
    Stats(listOf(fmtH(sum.h15) to "Jam 1.5x", fmtH(sum.h20) to "Jam 2.0x", fmtH(sum.h30) to "Jam 3.0x"))

    // kad hari ini (hanya bila hari ini dalam kitaran yang dipapar)
    if (today >= c.start && today <= c.end) HariIniCard(vm, today, sum.rows.find { it.tarikh == today })

    // hari lepas yang belum diisi → satu peringatan, bukan senarai panjang
    val kosong = sum.rows.filter { it.tarikh < today && it.entry == null }
    if (kosong.isNotEmpty()) {
        Notice(
            rich("**" + kosong.size + " hari** belum diisi dalam kitaran ini" + (if (kosong.size == 1) " (" + PG.fmtShort(kosong[0].tarikh) + ")." else ".")),
            Tone.INFO, "Isi",
        ) { vm.open(Sheet.OtDay(kosong.first().tarikh)) }
    }

    val rows = sum.rows.filter { it.tarikh <= today }.reversed()
    SecHead("Log harian", right = if (rows.isNotEmpty()) "Terkini di atas" else null)
    if (rows.isEmpty()) {
        Empty(rich("Kitaran ini belum bermula. Tekan **Key in OT** kalau nak isi awal."))
    } else {
        ListBlock { rows.forEach { r -> OtLogRow(vm, r, today) } }
    }
    Note("Tekan mana-mana hari untuk isi atau ubah jam.")
}

@Composable
private fun HariIniCard(vm: MainViewModel, today: String, row: OtRow?) {
    val pal = LocalPal.current
    val e = row?.entry
    val nilai = row?.nilai ?: 0.0
    val p = PG.parse(today)
    Block(Modifier.pressable({ vm.open(Sheet.OtDay(today)) }, scaleTo = 0.98f, haptic = true), bg = if (e == null) pal.accentSoft else null) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Txt("Hari ini · " + PG.HARI_PENUH[PG.weekday(today)] + " " + p.d + " " + PG.BULAN[p.m - 1], size = 12.5f,
                    color = if (e == null) pal.accentStrong else pal.muted)
                Spacer(Modifier.height(3.dp))
                if (e == null) {
                    Txt("Belum key in OT", size = 17f, weight = FontWeight.SemiBold, color = pal.accentStrong)
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        HariChip(e.jenis)
                        Spacer(Modifier.width(8.dp))
                        Txt(if (e.jenis == "tidak") "Tidak bekerja" else fmtH(e.jam ?: 0.0) + " jam", size = 17f, weight = FontWeight.SemiBold, num = true)
                    }
                }
            }
            if (e == null) {
                Box(Modifier.background(pal.accent, RoundedCornerShape(20.dp)).padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Txt("Key in", size = 14f, weight = FontWeight.Bold, color = pal.accentInk)
                }
            } else {
                Column(horizontalAlignment = Alignment.End) {
                    Txt(if (nilai > 0) "+" + M(nilai) else "Tiada OT", size = 17f, weight = FontWeight.SemiBold, num = true,
                        color = if (nilai > 0) pal.inn else pal.muted)
                    Txt("Tekan untuk ubah", size = 11.5f, color = pal.muted)
                }
            }
        }
    }
}

@Composable
private fun OtLogRow(vm: MainViewModel, r: OtRow, today: String) {
    val pal = LocalPal.current
    val e = r.entry
    val p = PG.parse(r.tarikh)
    val ot = r.h15 + r.h20 + r.h30
    Row(
        Modifier.fillMaxWidth().hairlines(pal.line).pressable({ vm.open(Sheet.OtDay(r.tarikh)) }, scaleTo = 0.985f)
            .heightIn(min = 52.dp).padding(horizontal = GL, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.width(52.dp)) {
            Txt(PG.pad(p.d) + "/" + PG.pad(p.m), size = 15f, weight = FontWeight.SemiBold, num = true)
            Txt(if (r.tarikh == today) "Hari ini" else PG.HARI[PG.weekday(r.tarikh)], size = 11.5f, color = pal.muted)
        }
        Spacer(Modifier.width(10.dp))
        if (e == null) {
            Txt("Belum diisi", Modifier.weight(1f), size = 14f, color = pal.muted)
            Txt("+ Isi", size = 13.5f, weight = FontWeight.SemiBold, color = pal.accent)
        } else {
            HariChip(e.jenis)
            Txt(
                if (e.jenis == "tidak") "Tidak bekerja"
                else fmtH(e.jam ?: 0.0) + " jam" + if (ot > 0) " · OT " + fmtH(ot) + "j" else "",
                Modifier.weight(1f).padding(start = 10.dp), size = 14f, color = pal.muted, num = true, maxLines = 1,
            )
            Txt(if (r.nilai > 0) M(r.nilai) else "–", size = 14.5f, weight = FontWeight.SemiBold, num = true,
                color = if (r.nilai > 0) pal.ink else pal.muted)
        }
    }
}

@Composable
fun HariChip(jenis: String?) {
    val pal = LocalPal.current
    val shape = RoundedCornerShape(7.dp)
    val (bg, fg, bd) = when (jenis) {
        null -> Triple(pal.surface2, pal.muted, pal.line)
        "biasa" -> Triple(pal.surface2, pal.ink, pal.line)
        "off" -> Triple(pal.goodSoft, pal.good, Color.Transparent)
        "rest", "umum" -> Triple(pal.accentSoft, pal.accentStrong, Color.Transparent)
        else -> Triple(pal.surface2, pal.muted, pal.line)
    }
    Box(Modifier.background(bg, shape).border(1.dp, bd, shape).padding(horizontal = 7.dp, vertical = 3.dp)) {
        Txt(if (jenis == null) "–" else hariLabel(jenis).short, size = 11.5f, weight = FontWeight.SemiBold, color = fg)
    }
}
