package com.asyraf.hadirku.pg

import kotlin.math.max
import kotlin.math.min

/**
 * Ramalan baki bank sampai gaji seterusnya.
 *
 * Andaian (semua boleh dilihat dalam skrin Ramalan):
 *  - Hari gaji: 15hb (advance, kalau ada nilai advance dalam Tetapan) dan 30hb / hari akhir bulan pendek.
 *  - Komitmen ikut tarikh jatuh tempo (kalau ada); tanpa tempo → hari gaji kitarannya (15hb / 30hb).
 *    Hutang ikut kitaran. Yang tarikhnya sudah lepas tapi belum dibayar → dikira perlu dibayar sekarang.
 *    Yang jatuh tempo selepas gaji tapi dibayar guna gaji itu (kitaran sama) → "dibayar guna gaji ini".
 *  - Belanja harian = purata duit keluar dari bank (belanja + ambil ATM / top up e-wallet) dalam 60 hari lepas,
 *    TIDAK termasuk komitmen, bayaran hutang dan belanja guna kad kredit (sudah dikira berasingan).
 *  - Poket simpanan (nama ada simpan / tabung / kecemasan / ASB / haji) tidak dikira duit boleh belanja.
 */
object Ramalan {

    class Item(val nama: String, val jumlah: Double, val tarikh: String, val jenis: String)
    class GajiJangka(val tarikh: String, val jumlah: Double, val label: String, val otSetakat: Boolean)

    class Hasil(
        val today: String,
        val bank: Double,
        val simpanan: Double,
        val payday: String,
        val hari: Int,
        val kadar: Double,
        val kadarHari: Int,
        val sebelum: List<Item>,
        val padaGaji: List<Item>,
        val gaji: GajiJangka,
        /** baki bank dijangka sehari sebelum gaji (termasuk simpanan) */
        val terendah: Double,
        /** baki selepas gaji masuk & komitmen kitaran itu dibayar */
        val selepas: Double,
        /** duit boleh belanja sehari sampai gaji (tanpa simpanan) */
        val bolehSehari: Double,
        val siri: List<Double>,
        val siriTarikh: List<String>,
        val otSehari: Double,
    ) {
        val sebelumJumlah get() = PG.round2(sebelum.sumOf { it.jumlah })
        val padaGajiJumlah get() = PG.round2(padaGaji.sumOf { it.jumlah })
        /** baki dijangka tanpa sentuh simpanan */
        val terendahBebas get() = PG.round2(terendah - simpanan)
    }

    private val RE_SIMPAN = Regex("simpan|tabung|kecemasan|emergency|saving|\\basb\\b|haji|pelaburan|invest", RegexOption.IGNORE_CASE)
    private val RE_GAJI_ADV = Regex("gaji|salary|payroll|upah|advance|pendahuluan", RegexOption.IGNORE_CASE)

    fun poketSimpanan(s: PgState): List<Pocket> = s.pockets.filter { !it.dompet && it.id != PG.BELUM_AGIH && RE_SIMPAN.containsMatchIn(it.nama) }

    private fun hariGaji(ym: String, adaAdvance: Boolean): List<String> {
        val p = PG.parse("$ym-01")
        val last = PG.lastDay(p.y, p.m)
        return (if (adaAdvance) listOf(PG.iso(p.y, p.m, 15)) else emptyList()) + PG.iso(p.y, p.m, min(30, last))
    }

    /** Tarikh bayar bagi kitaran "15" / "30" dalam bulan tarikh [d]. */
    private fun tarikhKitaran(d: String, kitaran: String?): String {
        val p = PG.parse(d)
        return if (kitaran == "15") PG.iso(p.y, p.m, 15) else PG.iso(p.y, p.m, min(30, PG.lastDay(p.y, p.m)))
    }

    /** Gaji dijangka pada hari gaji [d]. */
    fun gajiPada(s: PgState, d: String, today: String): GajiJangka {
        val g = s.settings.gaji
        val p = PG.parse(d)
        if (p.d == 15 && g.advance > 0.004) return GajiJangka(d, PG.round2(g.advance), "Advance 15hb", false)
        val sd = s.settings.otMulaHari.takeIf { it in 1..28 } ?: 22
        val q = PG.parse(PG.addMonths(PG.ym(d) + "-01", -1))
        val c = PG.otCycle(q.y, q.m, sd)
        val sm = PG.otSummary(s, c)
        return GajiJangka(d, PG.round2(max(0.0, sm.gaji30)), "Gaji hujung bulan", today <= c.end)
    }

    /** Gaji untuk hari [d] sudah masuk? (ada duit masuk gaji/advance ≥ separuh jangkaan, dari 4 hari sebelum). */
    private fun dahMasuk(s: PgState, d: String, today: String, jangka: Double): Boolean {
        val dari = PG.addDays(d, -4)
        val had = if (jangka > 0) jangka * 0.5 else 100.0
        return s.transactions.any { t ->
            t.jenis == "masuk" && !t.pulangan && t.tarikh >= dari && t.tarikh <= maxOf(today, d) && t.jumlah >= had &&
                (t.poket == PG.BELUM_AGIH || RE_GAJI_ADV.containsMatchIn(t.perkara))
        }
    }

    fun hariGajiSeterusnya(s: PgState, today: String): String {
        val adv = s.settings.gaji.advance > 0.004
        for (k in 0..2) {
            for (d in hariGaji(PG.shiftYm(PG.ym(today), k), adv)) {
                if (d < today) continue
                // gaji yang dekat (≤ 4 hari lagi) dan sudah masuk awal → langkau
                if (PG.hariAntara(today, d) <= 4 && dahMasuk(s, d, today, gajiPada(s, d, today).jumlah)) continue
                return d
            }
        }
        return PG.addDays(today, 15)
    }

    /** Purata belanja harian dari bank (60 hari lepas, tidak termasuk hari ini). Pulang (kadar, bilangan hari). */
    fun kadarBelanja(s: PgState, today: String, abaiNama: Set<String>): Pair<Double, Int> {
        val pertama = s.transactions.minOfOrNull { it.tarikh } ?: return 0.0 to 0
        val mula = maxOf(pertama, PG.addDays(today, -60))
        val hari = PG.hariAntara(mula, today)
        if (hari < 1) return 0.0 to 0
        val dom = PG.dompetSet(s)
        var jumlah = 0.0
        s.transactions.forEach { t ->
            if (t.tarikh < mula || t.tarikh >= today) return@forEach
            if (t.jenis != "keluar" && t.jenis != "pindah") return@forEach
            if (t.komitmenId.isNotEmpty() || t.hutangId.isNotEmpty()) return@forEach
            if (t.jenis == "keluar" && PG.normNama(t.perkara).let { it.length >= 3 && it in abaiNama }) return@forEach
            val b = PG.signedBank(t, dom)
            if (b < 0) jumlah += -b
        }
        return PG.round2(jumlah / hari) to hari
    }

    fun kira(s: PgState, today: String): Hasil {
        val bal = PG.balances(s)
        val bank = PG.total(s)
        val simpanan = PG.round2(poketSimpanan(s).sumOf { max(0.0, bal[it.id] ?: 0.0) })
        val payday = hariGajiSeterusnya(s, today)
        val hari = max(0, PG.hariAntara(today, payday))
        val gaji = gajiPada(s, payday, today)

        val sebelum = ArrayList<Item>()
        val pada = ArrayList<Item>()
        fun letak(nama: String, jumlah: Double, kitaran: String?, jenis: String, tempo: String? = null) {
            if (jumlah <= 0.004) return
            val gajiKitaran = tarikhKitaran(today, kitaran)
            val due = tempo ?: gajiKitaran
            when {
                due <= today -> sebelum.add(Item(nama, jumlah, today, jenis))
                due < payday -> sebelum.add(Item(nama, jumlah, due, jenis))
                gajiKitaran == payday -> pada.add(Item(nama, jumlah, due, jenis))
                else -> {}
            }
        }
        PG.commitmentStatus(s, today).forEach { c -> if (c.status != "sudah") letak(c.nama, c.baki, c.kitaran, "komitmen", PG.tempoDate(c.c, today)) }
        PG.debtStatus(s, today).forEach { d -> if (d.baki > 0.004) letak(d.d.nama, d.bakiBayar, d.d.kitaran, "hutang") }
        sebelum.sortBy { it.tarikh }
        pada.sortBy { it.tarikh }

        val namaKomit = s.commitments.map { PG.normNama(it.nama) }.toSet()
        val (kadar, kadarHari) = kadarBelanja(s, today, namaKomit)

        // siri baki hujung hari: hari ini (sekarang) → setiap hari sebelum gaji → selepas gaji
        val siri = ArrayList<Double>()
        val siriT = ArrayList<String>()
        siri.add(bank); siriT.add(today)
        var b = bank
        for (k in 0 until hari) {
            val d = PG.addDays(today, k)
            b -= kadar
            sebelum.forEach { if (it.tarikh == d) b -= it.jumlah }
            siri.add(PG.round2(b)); siriT.add(d)
        }
        if (hari == 0) sebelum.forEach { b -= it.jumlah }
        val terendah = PG.round2(b)
        val selepas = PG.round2(terendah + gaji.jumlah - pada.sumOf { it.jumlah })
        siri.add(selepas); siriT.add(payday)

        val boleh = if (hari > 0) PG.round2(max(0.0, bank - simpanan - sebelum.sumOf { it.jumlah }) / hari) else 0.0

        // OT purata sehari dalam kitaran semasa (prinsip: belanja harian ≤ OT hari itu)
        val sd = s.settings.otMulaHari.takeIf { it in 1..28 } ?: 22
        val cy = PG.otCycleOf(today, sd)
        val lalu = max(1, PG.hariAntara(cy.start, today) + 1)
        val otSehari = PG.round2(PG.otSummary(s, cy).nilai / lalu)

        return Hasil(today, bank, simpanan, payday, hari, kadar, kadarHari, sebelum, pada, gaji, terendah, selepas, boleh, siri, siriT, otSehari)
    }
}
