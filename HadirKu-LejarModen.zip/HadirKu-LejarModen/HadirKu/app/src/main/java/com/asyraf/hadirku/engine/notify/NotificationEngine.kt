package com.asyraf.hadirku.engine.notify

import com.asyraf.hadirku.engine.bills.BillReminder
import com.asyraf.hadirku.engine.budget.BudgetLine
import com.asyraf.hadirku.engine.core.EngineClock
import com.asyraf.hadirku.engine.risk.RiskAlert
import com.asyraf.hadirku.engine.savings.GoalProgress
import java.time.LocalDate
import java.time.LocalTime

/* =====================================================================
 * Engine 12 — Financial Notifications
 * Central trigger model with de-duplication (stable keys persisted by the caller), permission check,
 * preferences and quiet hours in the app timezone. The engine produces EVENTS (codes + params);
 * turning them into visible notification text is left to the existing notification code or to a
 * future, owner-approved UI. Existing commitment reminders (rumah/Peringatan.kt) are NOT changed.
 * ===================================================================== */

enum class NotifKind { BILL_DUE, BUDGET_EXCEEDED, ANOMALY, GOAL_MILESTONE, RISK }

data class NotifEvent(
    val kind: NotifKind,
    val subjectId: String,
    /** what makes this occurrence unique (due date + offset, budget month, milestone…) */
    val occurrence: String,
    val date: LocalDate,
    val params: Map<String, String> = emptyMap(),
    val priority: Int = 0,
) {
    val key: String get() = "${kind.name}:$subjectId:$occurrence"
}

data class NotifPrefs(
    val enabled: Set<NotifKind> = NotifKind.entries.toSet(),
    val quietStart: LocalTime? = null,
    val quietEnd: LocalTime? = null,
    val maxPerRun: Int = 5,
)

/** Platform side. The engine never posts by itself. */
interface NotificationSink {
    fun canPost(): Boolean
    fun post(event: NotifEvent): Boolean
}

data class NotifPlan(
    val send: List<NotifEvent>,
    val deferredQuietHours: List<NotifEvent>,
    val duplicates: List<NotifEvent>,
    val disabled: List<NotifEvent>,
    val blockedNoPermission: List<NotifEvent>,
    val overLimit: List<NotifEvent>,
)

data class DispatchResult(val plan: NotifPlan, val posted: List<NotifEvent>, val sent: Map<String, String>)

class NotificationEngine(private val prefs: NotifPrefs, private val clock: EngineClock) {

    fun inQuietHours(t: LocalTime = clock.now().atZone(clock.zone()).toLocalTime()): Boolean {
        val a = prefs.quietStart ?: return false
        val b = prefs.quietEnd ?: return false
        return if (a <= b) t >= a && t < b else t >= a || t < b // overnight window, e.g. 22:00–07:00
    }

    /** Decide what may be sent now. [sent] = keys already delivered (persisted). */
    fun plan(events: List<NotifEvent>, sent: Set<String>, canPost: Boolean): NotifPlan {
        val disabled = events.filter { it.kind !in prefs.enabled }
        val seen = HashSet(sent)
        val dup = ArrayList<NotifEvent>(); val fresh = ArrayList<NotifEvent>()
        events.filter { it.kind in prefs.enabled }.forEach { if (seen.add(it.key)) fresh += it else dup += it }
        if (!canPost) return NotifPlan(emptyList(), emptyList(), dup, disabled, fresh, emptyList())
        if (inQuietHours()) return NotifPlan(emptyList(), fresh, dup, disabled, emptyList(), emptyList())
        val ordered = fresh.sortedWith(compareByDescending<NotifEvent> { it.priority }.thenBy { it.date }.thenBy { it.key })
        return NotifPlan(ordered.take(prefs.maxPerRun), emptyList(), dup, disabled, emptyList(), ordered.drop(prefs.maxPerRun))
    }

    /**
     * Idempotent dispatch: repeated runs with the same events post nothing new. Only successfully posted
     * events are recorded in the returned [DispatchResult.sent] map (key → ISO date), which the caller persists.
     */
    fun dispatch(events: List<NotifEvent>, sent: Map<String, String>, sink: NotificationSink): DispatchResult {
        val p = plan(events, sent.keys, sink.canPost())
        val posted = p.send.filter { runCatching { sink.post(it) }.getOrDefault(false) }
        val today = clock.today().toString()
        return DispatchResult(p, posted, sent + posted.associate { it.key to today })
    }

    /** Forget delivery records older than [keepDays] so the store does not grow forever. */
    fun prune(sent: Map<String, String>, keepDays: Long = 400): Map<String, String> {
        val limit = clock.today().minusDays(keepDays).toString()
        return sent.filterValues { it >= limit }
    }

    companion object {
        fun fromBillReminders(r: List<BillReminder>): List<NotifEvent> = r.map {
            NotifEvent(NotifKind.BILL_DUE, it.billId, "${it.dueDate}:${it.daysBefore}", it.fireDate,
                mapOf("due_date" to it.dueDate.toString(), "days_before" to it.daysBefore.toString(), "remaining" to it.remaining.toDecimal().toPlainString()),
                priority = if (it.daysBefore <= 1) 2 else 1)
        }

        fun fromBudgetLines(lines: List<BudgetLine>, today: LocalDate): List<NotifEvent> = lines.filter { it.over.isPositive }.map {
            NotifEvent(NotifKind.BUDGET_EXCEEDED, it.budget.id, it.month.toString(), today,
                mapOf("category" to it.budget.category, "over" to it.over.toDecimal().toPlainString()), priority = 1)
        }

        fun fromRisk(alerts: List<RiskAlert>, today: LocalDate): List<NotifEvent> = alerts.map {
            // one notification per code + subject per calendar month
            NotifEvent(NotifKind.RISK, it.code.name + ":" + (it.subjectId ?: "-"), today.toString().substring(0, 7), today,
                it.params + ("severity" to it.severity.name), priority = it.severity.ordinal)
        }

        fun fromGoals(progress: List<GoalProgress>, today: LocalDate, milestonesBp: List<Int> = listOf(5000, 10000)): List<NotifEvent> =
            progress.flatMap { p -> milestonesBp.filter { p.progressBp >= it }.map { m ->
                NotifEvent(NotifKind.GOAL_MILESTONE, p.goal.id, "bp$m", today, mapOf("milestone_bp" to m.toString()))
            } }
    }
}
