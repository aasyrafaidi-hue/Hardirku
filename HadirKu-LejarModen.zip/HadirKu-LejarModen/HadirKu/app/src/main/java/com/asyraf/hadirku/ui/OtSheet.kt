package com.asyraf.hadirku.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.asyraf.hadirku.MainViewModel
import com.asyraf.hadirku.pg.OtEntry
import com.asyraf.hadirku.pg.PG

/**
 * Helaian key in OT gaya papan nombor Transaksi.
 * Atas: tarikh (‹ ›, tekan = pilih tarikh) dan jenis hari. Tengah: jam besar + kiraan OT terus.
 * Bawah: jam cepat, papan nombor sendiri (tiada papan kekunci telefon) dan Simpan.
 * "Simpan & hari seterusnya" simpan tanpa tutup, terus ke tarikh esoknya — laju untuk isi beberapa hari.
 */
@Composable
fun OtDaySheet(vm: MainViewModel, d0: String) {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    val s by vm.pg.collectAsState()
    val today = vm.today()
    var d by remember { mutableStateOf(d0) }
    val cur = s.ot[d]
    var jenis by remember(d, cur) { mutableStateOf(cur?.jenis ?: vm.defaultHari(d)) }
    var jam by remember(d, cur) { mutableStateOf(cur?.jam?.let { PG.jsNum(it) } ?: "") }
    // nilai sedia ada: tekan nombor pertama = ganti terus (tak perlu padam dulu)
    var fresh by remember(d, cur) { mutableStateOf(true) }
    var err by remember(d) { mutableStateOf("") }
    val g = s.settings.gaji
    val kerja = jenis != "tidak"

    // nombor "pop" sikit setiap kali berubah
    val pop = remember { Animatable(1f) }
    LaunchedEffect(jam, jenis) {
        pop.snapTo(1.07f)
        pop.animateTo(1f, spring(dampingRatio = 0.45f, stiffness = 700f))
    }

    fun step(dx: Double) {
        val v = vm.parseAmt(jam)
        jam = PG.jsNum(Math.max(0.0, Math.min(24.0, (if (v.isFinite()) v else 0.0) + dx)))
        fresh = false
    }

    fun tekan(k: String) {
        if (!kerja) return
        err = ""
        when (k) {
            "C" -> { jam = ""; fresh = false }
            "⌫" -> { jam = jam.dropLast(1); fresh = false }
            "−½" -> step(-0.5)
            "+½" -> step(0.5)
            "." -> {
                val b = if (fresh) "" else jam
                fresh = false
                if (!b.contains('.')) jam = (if (b.isEmpty()) "0" else b) + "."
            }
            else -> {
                val b = if (fresh) "" else jam
                val cand = if (b == "0") k else b + k
                val dot = cand.indexOf('.')
                if (dot >= 0 && cand.length - dot - 1 > 2) return
                val v = cand.toDoubleOrNull() ?: return
                if (v > 24.0) { err = "Maksimum 24 jam sehari."; return }
                jam = cand
                fresh = false
            }
        }
    }

    fun simpan(lanjut: Boolean) {
        val e = vm.saveOtDay(d, jenis, jam, tutup = !lanjut)
        err = e
        if (e.isEmpty()) {
            if (d < vm.cyc.start || d > vm.cyc.end) vm.cyc = PG.otCycleOf(d, vm.otSd())
            if (lanjut) d = PG.addDays(d, 1)
        }
    }

    SheetBody(actions = {
        Column {
            Row(Modifier.fillMaxWidth().padding(horizontal = GL), verticalAlignment = Alignment.CenterVertically) {
                if (cur != null) LinkDanger("Kosongkan") { vm.clearOtDay(d) }
                Spacer(Modifier.weight(1f))
                Txt(
                    "Simpan & hari seterusnya ›",
                    Modifier.clickable { simpan(true) }.padding(vertical = 10.dp, horizontal = 2.dp),
                    size = 14f, weight = FontWeight.SemiBold, color = pal.accentStrong,
                )
            }
            OtKeypad(kerja, { k -> tekan(k) }) { simpan(false) }
        }
    }) {
        // ---------- tarikh ----------
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).pressable({ d = PG.addDays(d, -1) }, scaleTo = 0.85f, haptic = true), contentAlignment = Alignment.Center) {
                Txt("‹", size = 28f, color = pal.muted)
            }
            Column(
                Modifier.weight(1f).clickable {
                    val p = PG.parse(d)
                    android.app.DatePickerDialog(ctx, { _, y, m, dd -> d = PG.iso(y, m + 1, dd) }, p.y, p.m - 1, p.d).show()
                }.padding(vertical = 2.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Txt(longDate(d), size = 17f, weight = FontWeight.SemiBold, align = TextAlign.Center, maxLines = 1)
                Txt(
                    (if (d == today) "Hari ini" else if (d == PG.addDays(today, -1)) "Semalam" else "Tekan untuk tukar tarikh") +
                        (if (cur != null) " · sudah direkod" else ""),
                    size = 12.5f, color = if (cur != null) pal.accentStrong else pal.muted,
                )
            }
            Box(Modifier.size(44.dp).pressable({ d = PG.addDays(d, 1) }, scaleTo = 0.85f, haptic = true), contentAlignment = Alignment.Center) {
                Txt("›", size = 28f, color = pal.muted)
            }
        }
        Spacer(Modifier.height(10.dp))

        // ---------- jenis hari ----------
        Row(Modifier.fillMaxWidth().padding(horizontal = GL), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            PG.JENIS_HARI.forEach { j ->
                OtTile(j.short, jenis == j.id, Modifier.weight(1f)) { jenis = j.id; err = "" }
            }
        }

        // ---------- paparan jam ----------
        val v = vm.parseAmt(jam)
        val h = PG.otHours(OtEntry(jenis, if (v.isFinite()) v else 0.0), g.jamNormal)
        val nilai = (h.h15 * 1.5 + h.h20 * 2 + h.h30 * 3) * PG.hrp(g)
        Column(
            Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(Modifier.graphicsLayer { scaleX = pop.value; scaleY = pop.value }) {
                if (kerja) Row(verticalAlignment = Alignment.Bottom) {
                    Txt(jam.ifEmpty { "0" }, size = 50f, weight = FontWeight.SemiBold, num = true, maxLines = 1,
                        color = if (jam.isEmpty()) pal.muted else pal.ink)
                    Txt(" jam", Modifier.padding(bottom = 10.dp), size = 18f, color = pal.muted)
                } else {
                    Txt("Tidak bekerja", Modifier.padding(vertical = 14.dp), size = 26f, weight = FontWeight.SemiBold, color = pal.muted)
                }
            }
            Box(Modifier.padding(top = 2.dp).width(140.dp).height(2.dp).background(if (kerja) pal.accent else pal.line, RoundedCornerShape(1.dp)))
            Spacer(Modifier.height(8.dp))
            val parts = ArrayList<String>()
            if (h.h15 > 0) parts.add(fmtH(h.h15) + "j × 1.5"); if (h.h20 > 0) parts.add(fmtH(h.h20) + "j × 2.0"); if (h.h30 > 0) parts.add(fmtH(h.h30) + "j × 3.0")
            Txt(
                if (!kerja) rich("Tiada OT untuk hari cuti / MC.")
                else if (parts.isNotEmpty()) rich("OT " + parts.joinToString(" + ") + " = **" + M(nilai) + "**", pal.inn)
                else if (jam.isEmpty()) rich("Masuk sampai balik, termasuk rehat")
                else rich("Tiada OT (jam normal " + PG.jsNum(g.jamNormal) + " jam)"),
                size = 14f, color = pal.muted, align = TextAlign.Center,
            )
        }

        // ---------- jam cepat ----------
        if (kerja) {
            Row(Modifier.fillMaxWidth().padding(horizontal = GL, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(8, 9, 10, 11, 12).forEach { n ->
                    OtTile(n.toString() + " jam", jam == n.toString(), Modifier.weight(1f)) { jam = n.toString(); fresh = true; err = "" }
                }
            }
        }
        Box(Modifier.padding(horizontal = GL)) { FormError(err) }
        Spacer(Modifier.height(6.dp))
    }
}

/** Jubin pilihan kecil (jenis hari, jam cepat). */
@Composable
private fun OtTile(label: String, on: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val pal = LocalPal.current
    val shape = RoundedCornerShape(8.dp)
    val bg by animateColorAsState(if (on) pal.accentSoft else pal.surface2, label = "otTile")
    val bd by animateColorAsState(if (on) pal.accent else pal.line, label = "otTileBd")
    Box(
        modifier.height(42.dp).background(bg, shape).border(if (on) 1.5.dp else 1.dp, bd, shape)
            .pressable(onClick, scaleTo = 0.92f, haptic = true),
        contentAlignment = Alignment.Center,
    ) {
        Txt(label, size = 13.5f, weight = if (on) FontWeight.SemiBold else FontWeight.Medium, color = if (on) pal.accentStrong else pal.muted, maxLines = 1)
    }
}

/**
 * Papan nombor OT (gaya sama dengan papan nombor Transaksi):
 * 1–9, 0, titik, padam, C (kosong), −½ / +½ jam dan Simpan.
 * Hari "Cuti" (tidak bekerja): nombor dimalapkan, Simpan masih boleh.
 */
@Composable
private fun OtKeypad(enabled: Boolean, onKey: (String) -> Unit, onSave: () -> Unit) {
    val pal = LocalPal.current
    val rows = listOf(
        listOf("1", "2", "3", "⌫"),
        listOf("4", "5", "6", "−½"),
        listOf("7", "8", "9", "+½"),
        listOf("C", "0", ".", "Simpan"),
    )
    Column(Modifier.fillMaxWidth().background(pal.line).padding(top = 1.dp), verticalArrangement = Arrangement.spacedBy(1.dp)) {
        rows.forEach { r ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(1.dp)) {
                r.forEach { k ->
                    val save = k == "Simpan"
                    val side = k == "⌫" || k == "−½" || k == "+½" || k == "C"
                    val on = save || enabled
                    Box(
                        Modifier.weight(1f).height(60.dp)
                            .graphicsLayer { alpha = if (on) 1f else 0.4f }
                            .background(if (save) pal.accent else if (side) pal.surface2 else pal.surface)
                            .pressable({ if (save) onSave() else onKey(k) }, enabled = on, scaleTo = 0.86f, haptic = true),
                        contentAlignment = Alignment.Center,
                    ) {
                        Txt(
                            k,
                            size = if (save) 17f else if (k.length > 1) 19f else 24f,
                            weight = if (save) FontWeight.SemiBold else FontWeight.Normal,
                            color = if (save) pal.accentInk else if (k == "C") pal.bad else if (side) pal.muted else pal.ink,
                        )
                    }
                }
            }
        }
    }
}
