package com.asyraf.hadirku.engine.forecast

import com.asyraf.hadirku.engine.bills.BillEngine
import com.asyraf.hadirku.engine.cashflow.CashFlowEngine
import com.asyraf.hadirku.engine.core.DateRange
import com.asyraf.hadirku.engine.core.Dates
import com.asyraf.hadirku.engine.core.DueDayPolicy
import com.asyraf.hadirku.engine.core.Money
import com.asyraf.hadirku.engine.ledger.AccountKind
import com.asyraf.hadirku.engine.ledger.EntryType
import com.asyraf.hadirku.engine.ledger.LedgerBook
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.PgState
import java.math.BigDecimal
import java.time.LocalDate
import java.time.YearMonth

/* =====================================================================
 * Engine 6 — Financial Forecast
 * Projects the liquid balance day by day. Guaranteed salary (basic + allowances − deductions,
 * advance on the 15th) is separated from overtime, which is irregular and depends on the scenario:
 *   CONSERVATIVE: only OT already recorded for a running cycle; no OT for future cycles; spending +10%
 *   BASE:         recorded OT + average daily OT (last 3 complete cycles) for the rest of the cycle; spending ×1
 *   OPTIMISTIC:   recorded OT + best daily OT of the last 3 cycles; spending −10%
 * Every point is labelled ACTUAL or FORECAST and every assumption is returned with the result.
 * Forecasts are estimates, never certainties.
 * ===================================================================== */

enum class Scenario { CONSERVATIVE, BASE, OPTIMISTIC }
enum class PointKind { ACTUAL, FORECAST }
enum class Certainty { RECORDED, GUARANTEED, ESTIMATE }
enum class EventKind { RECORDED, ADVANCE, SALARY, OVERTIME, BILL, DEBT }

data class ForecastPoint(val date: LocalDate, val balance: Money, val kind: PointKind)
data class ForecastEvent(val date: LocalDate, val kind: EventKind, val amount: Money /* signed */, val certainty: Certainty, val refId: String)
data class MonthSummary(val month: YearMonth, val inflow: Money, val outflow: Money, val endBalance: Money)
data class Assumption(val code: String, val value: String)

data class ForecastResult(
    val scenario: Scenario,
    val asOf: LocalDate,
    val startBalance: Money,
    val points: List<ForecastPoint>,
    val events: List<ForecastEvent>,
    val months: List<MonthSummary>,
    val lowest: ForecastPoint,
    val guaranteedIncome: Money,
    val overtimeIncome: Money,
    val dailyDiscretionary: Money,
    val assumptions: List<Assumption>,
)

object ForecastEngine {

    /** Average discretionary spending per day from liquid accounts (bills and debt payments excluded). */
    fun dailyDiscretionary(book: LedgerBook, asOf: LocalDate, days: Long = 60): Pair<Money, Long> {
        val first = book.entries.minOfOrNull { it.date } ?: return Money.ZERO to 0
        val start = maxOf(first, asOf.minusDays(days))
        val n = Dates.daysBetween(start, asOf)
        if (n < 1) return Money.ZERO to 0
        val liquid = book.accounts.values.filter { it.kind == AccountKind.ASSET }.map { it.id }.toSet()
        var sum = Money.ZERO
        for (e in book.effective()) {
            if (e.date.isBefore(start) || !e.date.isBefore(asOf)) continue
            if (e.type == EntryType.EXPENSE && e.from in liquid && e.commitmentId == null) sum += e.amount
            if (e.type == EntryType.REFUND && e.to in liquid) sum -= e.amount
        }
        return sum.coerceAtLeast(Money.ZERO).div(n) to n
    }

    private fun payDates(ym: YearMonth, advance: Boolean): List<LocalDate> =
        (if (advance) listOf(ym.atDay(15)) else emptyList()) + ym.atDay(minOf(30, ym.lengthOfMonth()))

    /** OT value per calendar day of the last [n] complete cycles before the cycle containing [asOf]. */
    private fun otDailyRates(s: PgState, asOf: LocalDate, n: Int = 3): List<BigDecimal> {
        val sd = s.settings.otMulaHari.takeIf { it in 1..28 } ?: 22
        val cur = PG.otCycleOf(asOf.toString(), sd)
        val out = ArrayList<BigDecimal>()
        var c = cur
        repeat(n) {
            c = PG.shiftCycle(c, -1, sd)
            val sum = PG.otSummary(s, c)
            if (sum.hari > 0) out += BigDecimal.valueOf(sum.nilai).divide(BigDecimal(c.days.size), 6, java.math.RoundingMode.HALF_UP)
        }
        return out
    }

    fun project(
        s: PgState, book: LedgerBook, asOf: LocalDate, horizonDays: Int = 90, scenario: Scenario = Scenario.BASE,
        historyDays: Int = 30, policy: DueDayPolicy = DueDayPolicy.CLAMP_TO_MONTH_END,
    ): ForecastResult {
        val g = s.settings.gaji
        val sd = s.settings.otMulaHari.takeIf { it in 1..28 } ?: 22
        val end = asOf.plusDays(horizonDays.toLong())
        val liquid = book.accounts.values.filter { it.kind == AccountKind.ASSET }.map { it.id }
        val start = Money.sum(liquid.map { book.balance(it, asOf) })
        val events = ArrayList<ForecastEvent>()

        // 1) entries already recorded with a future date
        val future = CashFlowEngine.flows(book, DateRange(asOf.plusDays(1), end.plusDays(1)))
        book.effective().filter { it.date.isAfter(asOf) && !it.date.isAfter(end) }.forEach { e ->
            val net = Money.sum(liquid.map { e.effectOn(it) })
            if (!net.isZero) events += ForecastEvent(e.date, EventKind.RECORDED, net, Certainty.RECORDED, e.id)
        }
        check(future.netLiquid == Money.sum(events.map { it.amount })) { "recorded future flows mismatch" }

        // 2) income: guaranteed salary vs overtime
        val adv = Money.fromDouble(maxOf(0.0, g.advance))
        val basePay = Money.fromDouble(maxOf(0.0, g.basic + g.night + g.transport - g.potongan - g.advance))
        val rates = otDailyRates(s, asOf)
        val avgRate = if (rates.isEmpty()) BigDecimal.ZERO else rates.fold(BigDecimal.ZERO) { a, b -> a + b }.divide(BigDecimal(rates.size), 6, java.math.RoundingMode.HALF_UP)
        val bestRate = rates.maxOrNull() ?: BigDecimal.ZERO
        val rate = when (scenario) { Scenario.CONSERVATIVE -> BigDecimal.ZERO; Scenario.BASE -> avgRate; Scenario.OPTIMISTIC -> bestRate }
        var ym = YearMonth.from(asOf)
        while (!ym.atDay(1).isAfter(end)) {
            for (pd in payDates(ym, adv.isPositive)) {
                if (!pd.isAfter(asOf) || pd.isAfter(end)) continue
                if (alreadyPaid(book, pd, asOf)) continue
                if (pd.dayOfMonth == 15 && adv.isPositive) { events += ForecastEvent(pd, EventKind.ADVANCE, adv, Certainty.GUARANTEED, "pay:$pd"); continue }
                if (basePay.isPositive) events += ForecastEvent(pd, EventKind.SALARY, basePay, Certainty.GUARANTEED, "pay:$pd")
                // OT paid at month-end of M is for the cycle that started in M−1
                val prev = ym.minusMonths(1)
                val c = PG.otCycle(prev.year, prev.monthValue, sd)
                val cStart = LocalDate.parse(c.start); val cEnd = LocalDate.parse(c.end)
                val earned = if (cStart.isAfter(asOf)) BigDecimal.ZERO else BigDecimal.valueOf(PG.otSummary(s, c).nilai)
                val restDays = when {
                    asOf.isBefore(cStart) -> c.days.size.toLong()
                    asOf.isBefore(cEnd) -> Dates.daysBetween(asOf, cEnd)
                    else -> 0L
                }
                val ot = Money.of(earned + rate.multiply(BigDecimal(restDays)))
                if (ot.isPositive) events += ForecastEvent(pd, EventKind.OVERTIME, ot,
                    if (restDays == 0L) Certainty.GUARANTEED else Certainty.ESTIMATE, "ot:${c.start}")
            }
            ym = ym.plusMonths(1)
        }

        // 3) bills: current period remainder, then full amounts for later periods
        var ref = asOf
        while (!ref.isAfter(end)) {
            val occ = BillEngine.occurrences(s, book, ref, policy)
            occ.filter { it.remaining.isPositive }.forEach { o ->
                val due = o.dueDate ?: payDayFor(o.bill.payCycle, YearMonth.from(o.period.start))
                val d = if (due.isAfter(asOf)) due else asOf.plusDays(1)
                if (!d.isAfter(end)) events += ForecastEvent(d, EventKind.BILL, -o.remaining, Certainty.GUARANTEED, "bill:${o.bill.id}:${o.periodKey}")
            }
            ref = BillEngine.periodFor(s, ref).first.endExclusive
        }

        // 4) debt payments: this period's unpaid target, then the plan/minimum each later period until cleared
        val status = PG.debtStatus(s, asOf.toString())
        status.forEach { d ->
            var owed = Money.fromDouble(maxOf(0.0, d.jumlah))
            val now = Money.fromDouble(d.bakiBayar)
            val cycle = d.d.kitaran ?: "30"
            if (now.isPositive) {
                val day = payDayFor(cycle, YearMonth.from(asOf)).let { if (it.isAfter(asOf)) it else asOf.plusDays(1) }
                events += ForecastEvent(day, EventKind.DEBT, -now, Certainty.GUARANTEED, "debt:${d.id}:now"); owed -= now
            }
            val monthly = Money.fromDouble(maxOf(d.sasaranAsal, d.min))
            var m = YearMonth.from(BillEngine.periodFor(s, asOf).first.endExclusive)
            while (owed.isPositive && monthly.isPositive) {
                val day = payDayFor(cycle, m)
                if (day.isAfter(end)) break
                val pay = monthly.min(owed)
                events += ForecastEvent(day, EventKind.DEBT, -pay, Certainty.ESTIMATE, "debt:${d.id}:$m"); owed -= pay
                m = m.plusMonths(1)
            }
        }

        // 5) daily walk
        val (daily0, histDays) = dailyDiscretionary(book, asOf)
        val factor = when (scenario) { Scenario.CONSERVATIVE -> BigDecimal("1.10"); Scenario.BASE -> BigDecimal.ONE; Scenario.OPTIMISTIC -> BigDecimal("0.90") }
        val daily = daily0.times(factor)
        val byDate = events.groupBy { it.date }
        val points = ArrayList<ForecastPoint>()
        // recent actual history (labelled ACTUAL)
        for (k in historyDays downTo 1) {
            val d = asOf.minusDays(k.toLong())
            points += ForecastPoint(d, Money.sum(liquid.map { book.balance(it, d) }), PointKind.ACTUAL)
        }
        points += ForecastPoint(asOf, start, PointKind.ACTUAL)
        var bal = start
        val months = LinkedHashMap<YearMonth, Pair<Money, Money>>()
        var d = asOf.plusDays(1)
        while (!d.isAfter(end)) {
            var inn = Money.ZERO; var out = daily
            byDate[d].orEmpty().forEach { e -> if (e.amount.isPositive) inn += e.amount else out -= e.amount }
            bal = bal + inn - out
            val ymd = YearMonth.from(d)
            val (mi, mo) = months[ymd] ?: (Money.ZERO to Money.ZERO)
            months[ymd] = (mi + inn) to (mo + out)
            points += ForecastPoint(d, bal, PointKind.FORECAST)
            d = d.plusDays(1)
        }
        val monthSummaries = months.map { (m, io) ->
            MonthSummary(m, io.first, io.second, points.last { YearMonth.from(it.date) == m }.balance)
        }
        val fc = points.filter { it.kind == PointKind.FORECAST }
        val lowest = (fc.ifEmpty { listOf(points.last()) }).minWith(compareBy<ForecastPoint>({ it.balance }, { it.date }))
        val guaranteed = Money.sum(events.filter { it.kind == EventKind.SALARY || it.kind == EventKind.ADVANCE }.map { it.amount })
        val ot = Money.sum(events.filter { it.kind == EventKind.OVERTIME }.map { it.amount })
        return ForecastResult(
            scenario, asOf, start, points, events.sortedWith(compareBy({ it.date }, { it.kind })), monthSummaries, lowest, guaranteed, ot, daily,
            listOf(
                Assumption("scenario", scenario.name),
                Assumption("discretionary_daily", daily.toDecimal().toPlainString()),
                Assumption("discretionary_history_days", histDays.toString()),
                Assumption("discretionary_factor", factor.toPlainString()),
                Assumption("salary_guaranteed_per_month", basePay.toDecimal().toPlainString()),
                Assumption("advance_on_15th", adv.toDecimal().toPlainString()),
                Assumption("ot_daily_rate", rate.setScale(2, java.math.RoundingMode.HALF_UP).toPlainString()),
                Assumption("ot_rate_basis", if (scenario == Scenario.CONSERVATIVE) "recorded_only" else "last_${rates.size}_cycles"),
                Assumption("bills_due_day_policy", policy.name),
                Assumption("debt_future_payment", "max(plan, current_minimum)_until_cleared"),
                Assumption("income_not_guaranteed", "overtime_and_estimates_may_differ"),
            ),
        )
    }

    private fun payDayFor(cycle: String, ym: YearMonth): LocalDate =
        if (cycle == "15") ym.atDay(15) else ym.atDay(minOf(30, ym.lengthOfMonth()))

    /** Salary already credited for payday [pd]: any income in [pd−4, asOf] (same rule as the existing forecast). */
    private fun alreadyPaid(book: LedgerBook, pd: LocalDate, asOf: LocalDate): Boolean =
        book.effective().any { it.type == EntryType.INCOME && !it.date.isBefore(pd.minusDays(4)) && !it.date.isAfter(asOf) && it.amount >= Money.parse("100.00") }
}
