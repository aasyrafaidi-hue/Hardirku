package com.asyraf.hadirku.pg

/* Model data PoketGaji (sama dengan format salinan JSON v2 PoketGaji PWA). */

data class Pocket(
    val id: String,
    val nama: String,
    val sasaran: Double = 0.0,
    val tetap: Boolean = false,
    /** duit poket ini di luar bank (e-wallet ATAU tunai) — tidak dikira dalam baki bank */
    val dompet: Boolean = false,
    /** tambahan HadirKu: duit tunai fizikal dalam dompet (sentiasa dompet = true juga) */
    val tunai: Boolean = false,
)

data class Tx(
    val id: String = "",
    val tarikh: String = "",
    val jenis: String = "keluar",
    val poket: String = "",
    val ke: String = "",
    val jumlah: Double = 0.0,
    val perkara: String = "",
    val komitmenId: String = "",
    val hutangId: String = "",
    val kadId: String = "",
    val catatan: String = "",
    val dibuat: Long = 0,
    val otBayar: Double? = null,
    val fee: Double? = null,
    val feePct: Double? = null,
    val kategori: String? = null,
    val katAuto: Boolean = false,
    /**
     * Duit masuk yang memulangkan belanja (cth: isteri pulangkan baki duit dapur, refund kedai, kawan bayar balik).
     * Hanya untuk jenis "masuk" dan mesti ada [kategori]: baki poket bertambah seperti biasa, tetapi BUKAN pendapatan —
     * ia mengurangkan belanja kategori itu dalam laporan, bajet, ramalan dan amaran.
     */
    val pulangan: Boolean = false,
)

data class Commitment(
    val id: String,
    val nama: String,
    val jumlah: Double,
    val kitaran: String = "30",
    val poket: String = "",
    val manual: Map<String, Boolean> = emptyMap(),
    /** hari jatuh tempo dalam bulan (1–31; 29–31 jadi hari akhir bulan pendek). 0 = tiada tarikh tetap */
    val tempo: Int = 0,
)

data class DebtLog(
    val id: String,
    val tarikh: String,
    val jenis: String,
    val jumlah: Double,
    val catatan: String = "",
    val dibuat: Long = 0,
)

data class Epp(
    val id: String,
    val nama: String = "EPP",
    val pokok: Double = 0.0,
    val tempoh: Int = 1,
    val kadar: Double = 0.0,
    val ansuran: Double = 0.0,
    val mula: String = "",
    val catatan: String = "",
    /** Jumlah faedah keseluruhan (RM) kalau diisi sebagai nilai, bukan peratus. null = guna [kadar]. [kadar] tetap disimpan (dikira). */
    val faedahJumlah: Double? = null,
    /**
     * Kaedah kiraan ansuran:
     *  "rata"  = kadar rata / flat (lalai; termasuk 0%) — formula asal, rekod lama tidak berubah
     *  "baki"  = baki berkurang (reducing balance / annuity): pecahan dikira daripada [semak] penyata terkini
     *  "tetap" = ansuran tetap sahaja: pecahan pokok/faedah tidak diketahui ([pokok] disimpan = ansuran × tempoh)
     * Untuk "baki", [pokok] disimpan = pokok asal tersirat dan [kadar] = kadar rata setara (supaya pembaca lama dapat
     * anggaran terbaik); kadar nominal dalam [kadarNominal].
     */
    val kaedah: String = "rata",
    /** kadar nominal setahun (%) — anggaran daripada penyata, belum disahkan bank */
    val kadarNominal: Double? = null,
    /** pecahan pokok + faedah ikut penyata bank (ansuran ke-[EppSemak.ke]); yang terkini menjadi sauh kiraan */
    val semak: List<EppSemak> = emptyList(),
)

/** Pecahan satu ansuran seperti dalam penyata bank. */
data class EppSemak(val ke: Int, val pokok: Double, val faedah: Double, val tarikh: String = "")

data class Debt(
    val id: String,
    val nama: String,
    val jenis: String = "kad",
    val kadar: Double = 0.0,
    val minPeratus: Double = 5.0,
    /** null = kosong ('' dalam JS) → lantai lalai RM50 */
    val minLantai: Double? = 50.0,
    val ansuran: Double = 0.0,
    val rancangan: Double = 0.0,
    val hadKredit: Double = 0.0,
    val poket: String = "",
    val log: List<DebtLog> = emptyList(),
    val epp: List<Epp> = emptyList(),
    val kitaran: String? = null,
    /**
     * Asas bayaran minimum kad kredit (tambahan HadirKu, tiada dalam PoketGaji JS):
     *  "jumlah" = minPeratus% × (baki kad + pokok EPP belum dibil), sekurang-kurangnya lantai & ansuran EPP bulan ini (lalai)
     *  "biasa"  = ansuran EPP bulan ini penuh + minPeratus% × baki selebihnya (cara asal PoketGaji)
     */
    val minAsas: String = "jumlah",
    /**
     * Faedah sebulan (RM) ikut penyata, kalau diisi sebagai nilai. null = pengguna isi peratus terus.
     * Bila diisi, [kadar] = faedahRm × 1200 ÷ [faedahBaki] (dikira & disimpan), jadi kiraan lain kekal guna [kadar].
     */
    val faedahRm: Double? = null,
    /** baki penyata yang dipakai untuk tukar [faedahRm] ke peratus */
    val faedahBaki: Double = 0.0,
    /**
     * Bayaran minimum (RM) ikut penyata (kad kredit), kalau diisi sebagai nilai. null = guna [minPeratus].
     * Dalam tempoh bayaran yang mengandungi [minTarikh], minimum = nilai ini tepat (tak lebih daripada baki).
     * Bulan lain & simulasi guna [minPeratus] = minRm ÷ (minBaki + pokok EPP masa itu) × 100 (dikira & disimpan).
     */
    val minRm: Double? = null,
    val minBaki: Double = 0.0,
    val minTarikh: String = "",
)

data class BankCheck(
    val id: String,
    val tarikh: String,
    val baki: Double,
    val catatan: String = "",
    val dibuat: Long = 0,
)

data class OtEntry(val jenis: String, val jam: Double? = null)

data class Gaji(
    val basic: Double = 2500.0,
    val night: Double = 0.0,
    val transport: Double = 0.0,
    val jamNormal: Double = 9.0,
    val hadOT: Double = 104.0,
    val potongan: Double = 0.0,
    val advance: Double = 0.0,
)

data class TunaiFee(val mode: String = "pct", val nilai: Double? = null)

data class PgSettings(
    val gaji: Gaji = Gaji(),
    val komitmenMulaHari: Int = 1,
    val otMulaHari: Int = 22,
    val hutangBajet: Double = 0.0,
    val hutangStrategi: String = "avalanche",
    val otPendapatan: Boolean = true,
    val tunaiFee: TunaiFee? = null,
    val cfoMatlamat: String? = null,
    /** Kunci tetapan lain yang tidak dikenali (contoh 'agihan' lama), disimpan semula seperti asal. */
    val extraJson: String? = null,
)

data class PgState(
    val version: Int = 2,
    val contoh: Boolean = false,
    val settings: PgSettings = PgSettings(),
    val pockets: List<Pocket> = emptyList(),
    val transactions: List<Tx> = emptyList(),
    val commitments: List<Commitment> = emptyList(),
    val debts: List<Debt> = emptyList(),
    val bankChecks: List<BankCheck> = emptyList(),
    val ot: Map<String, OtEntry> = emptyMap(),
)

data class Label(val id: String, val label: String, val short: String = label, val ai: String = "")
