package com.asyraf.hadirku.engine.cashflow

import com.asyraf.hadirku.engine.bills.BillEngine
import com.asyraf.hadirku.engine.core.DateRange
import com.asyraf.hadirku.engine.core.DueDayPolicy
import com.asyraf.hadirku.engine.core.Money
import com.asyraf.hadirku.engine.ledger.AccountKind
import com.asyraf.hadirku.engine.ledger.EntryType
import com.asyraf.hadirku.engine.ledger.LedgerBook
import com.asyraf.hadirku.engine.ledger.Storage
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.PgState
import com.asyraf.hadirku.pg.Ramalan
import java.time.LocalDate

/* =====================================================================
 * Engine 2 — Cash Flow
 *  actual    = posted entries dated ≤ asOf inside the window
 *  pending   = entries already in the book but dated after asOf (future-dated)
 *  scheduled = obligations not yet in the book: unpaid bill remainders and unpaid debt targets of the
 *              current period, plus expected salary. Linked payments already reduce the remainders,
 *              so a pending payment is never counted twice.
 * Transfers between owned accounts never count as inflow/outflow. Debt repayments are reported apart
 * from spending.
 * ===================================================================== */

data class Flows(
    val income: Money = Money.ZERO,
    val spending: Money = Money.ZERO,
    val debtRepayment: Money = Money.ZERO,
    val charges: Money = Money.ZERO,
    val disbursement: Money = Money.ZERO,
    val adjustmentNet: Money = Money.ZERO,
) {
    /** Net change of liquid (owned asset) accounts. Charges sit on liabilities, so they are excluded. */
    val netLiquid: Money get() = income + disbursement + adjustmentNet - spending - debtRepayment
}

enum class ScheduledKind { BILL, DEBT, SALARY, ADVANCE }
enum class Confidence { CERTAIN, ESTIMATE }

data class ScheduledItem(
    val kind: ScheduledKind, val refId: String, val date: LocalDate?, val amount: Money,
    val inflow: Boolean, val confidence: Confidence,
)

data class AccountBalance(val accountId: String, val name: String, val storage: Storage, val posted: Money, val withPending: Money)

data class CashFlowReport(
    val asOf: LocalDate,
    val window: DateRange,
    val accounts: List<AccountBalance>,
    /** owned asset balances posted up to asOf (bank + e-wallet + cash) */
    val liquid: Money,
    val liquidByStorage: Map<Storage, Money>,
    val actual: Flows,
    val pending: Flows,
    val scheduled: List<ScheduledItem>,
    val earmarked: Money,
    /**
     * liquid + net pending − scheduled outflows due in the window − earmarked funds.
     * Expected income is deliberately NOT added (conservative; it is listed in [scheduled]).
     */
    val availableToSpend: Money,
    val assumptions: List<String>,
)

object CashFlowEngine {

    fun flows(book: LedgerBook, range: DateRange, onlyAfter: LocalDate? = null, onlyUpTo: LocalDate? = null): Flows {
        var f = Flows()
        val liquid = book.accounts.values.filter { it.kind == AccountKind.ASSET }.map { it.id }.toSet()
        for (e in book.effective()) {
            if (e.date !in range) continue
            if (onlyAfter != null && !e.date.isAfter(onlyAfter)) continue
            if (onlyUpTo != null && e.date.isAfter(onlyUpTo)) continue
            f = when (e.type) {
                EntryType.INCOME -> f.copy(income = f.income + e.amount)
                EntryType.EXPENSE -> if (e.from in liquid) f.copy(spending = f.spending + e.amount) else f // card purchase: no cash left yet
                EntryType.REFUND -> if (e.to in liquid) f.copy(spending = f.spending - e.amount) else f
                EntryType.DEBT_REPAYMENT -> if (e.from in liquid) f.copy(debtRepayment = f.debtRepayment + e.amount) else f
                EntryType.DEBT_DISBURSEMENT -> if (e.to in liquid) f.copy(disbursement = f.disbursement + e.amount) else f
                EntryType.CHARGE -> f.copy(charges = f.charges + e.amount)
                EntryType.ADJUSTMENT, EntryType.OPENING_BALANCE -> {
                    val inn = e.to in liquid; val out = e.from in liquid
                    if (e.type == EntryType.OPENING_BALANCE) f
                    else if (inn && !out) f.copy(adjustmentNet = f.adjustmentNet + e.amount)
                    else if (out && !inn) f.copy(adjustmentNet = f.adjustmentNet - e.amount) else f
                }
                EntryType.TRANSFER, EntryType.REVERSAL -> f
            }
        }
        return f
    }

    fun report(
        s: PgState, book: LedgerBook, asOf: LocalDate,
        windowEnd: LocalDate? = null, earmarked: Money = Money.ZERO,
        policy: DueDayPolicy = DueDayPolicy.CLAMP_TO_MONTH_END,
    ): CashFlowReport {
        val end = windowEnd ?: LocalDate.parse(Ramalan.hariGajiSeterusnya(s, asOf.toString()))
        val period = BillEngine.periodFor(s, asOf).first
        val window = DateRange(minOf(period.start, asOf), maxOf(end, asOf).plusDays(1))
        val posted = book.balances(asOf)
        val all = book.balances()
        val assets = book.accounts.values.filter { it.kind == AccountKind.ASSET }
        val accounts = assets.map { AccountBalance(it.id, it.name, it.storage, posted[it.id] ?: Money.ZERO, all[it.id] ?: Money.ZERO) }
        val liquid = Money.sum(accounts.map { it.posted })
        val byStorage = accounts.groupBy { it.storage }.mapValues { (_, v) -> Money.sum(v.map { it.posted }) }

        val actual = flows(book, window, onlyUpTo = asOf)
        val pending = flows(book, window, onlyAfter = asOf)

        val scheduled = ArrayList<ScheduledItem>()
        // bills of the current period not yet paid (due date may be null → paid by pay cycle)
        BillEngine.occurrences(s, book, asOf, policy).filter { it.remaining.isPositive }.forEach { o ->
            scheduled += ScheduledItem(ScheduledKind.BILL, o.bill.id, o.dueDate, o.remaining, inflow = false, confidence = Confidence.CERTAIN)
        }
        // debt targets of the current period not yet paid (cards: plan or minimum + card spending)
        PG.debtStatus(s, asOf.toString()).forEach { d ->
            val left = Money.fromDouble(d.bakiBayar)
            if (left.isPositive) scheduled += ScheduledItem(ScheduledKind.DEBT, d.id, null, left, inflow = false, confidence = Confidence.CERTAIN)
        }
        // expected pay on the next payday (estimate: depends on recorded OT)
        val pay = Ramalan.gajiPada(s, end.toString(), asOf.toString())
        Money.fromDoubleOrNull(pay.jumlah)?.takeIf { it.isPositive }?.let {
            scheduled += ScheduledItem(if (end.dayOfMonth == 15) ScheduledKind.ADVANCE else ScheduledKind.SALARY, "pay:$end", end, it, inflow = true, confidence = Confidence.ESTIMATE)
        }

        val outDue = Money.sum(scheduled.filter { !it.inflow && (it.date == null || !it.date.isAfter(end)) }.map { it.amount })
        val available = liquid + pending.netLiquid - outDue - earmarked
        return CashFlowReport(
            asOf, window, accounts, liquid, byStorage, actual, pending, scheduled, earmarked, available,
            assumptions = listOf(
                "window_end=$end",
                "expected_income_excluded_from_available",
                "bills_without_due_date_counted_in_window",
                "debt_targets_from_existing_plan_or_minimum",
            ),
        )
    }
}
