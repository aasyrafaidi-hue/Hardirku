package com.asyraf.hadirku.engine.receipt

import com.asyraf.hadirku.engine.core.MiniJson
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.util.Base64

/* =====================================================================
 * Engine 1 — Receipt Intelligence: providers
 *
 * Providers talk to a SECURE BACKEND owned by the app owner, never to OpenAI/Anthropic directly with
 * a key inside the APK. The backend holds the provider keys, authenticates the device, rate-limits,
 * minimises data and returns schema-v1 JSON. With no backend configured every provider reports
 * Unavailable and the existing manual entry / existing receipt scan keep working unchanged.
 *
 * Backend contract (v1):
 *   POST {baseUrl}/v1/receipts/extract
 *   Authorization: Bearer <device token issued by the backend — NOT a provider API key>
 *   Content-Type: application/json
 *   { "vendor": "claude"|"openai", "schema_version": 1, "mime": "image/jpeg", "locale": "ms-MY",
 *     "request_id": "<uuid>", "image_base64": "<…>" }
 *   200 → schema-v1 receipt JSON (see ReceiptModel.kt) · 401/403 auth · 413 too large · 429 rate limited · 5xx
 * ===================================================================== */

data class ReceiptRequest(val bytes: ByteArray, val mime: String, val requestId: String, val locale: String = "ms-MY")

sealed class ProviderResult {
    data class Success(val json: String, val provider: String) : ProviderResult()
    data class Unavailable(val reason: String) : ProviderResult()
    data class Failed(val code: String, val retryable: Boolean) : ProviderResult()
}

interface ReceiptExtractionProvider {
    val id: String
    fun isAvailable(): Boolean
    /** Blocking call — run it off the main thread. Never throws. */
    fun extract(req: ReceiptRequest): ProviderResult
}

data class BackendConfig(val baseUrl: String, val deviceToken: String, val timeoutMs: Int = 45_000, val maxRetries: Int = 2) {
    /** Only HTTPS endpoints are accepted (no silent clear-text transmission of financial data). */
    val valid: Boolean get() = baseUrl.startsWith("https://") && deviceToken.isNotBlank()
}

data class HttpResponse(val code: Int, val body: String)

fun interface HttpTransport {
    @Throws(IOException::class)
    fun post(url: String, headers: Map<String, String>, body: String, timeoutMs: Int): HttpResponse
}

/** java.net based transport (works on Android and on the JVM). Bodies are never logged. */
object JdkHttpTransport : HttpTransport {
    override fun post(url: String, headers: Map<String, String>, body: String, timeoutMs: Int): HttpResponse {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15_000; c.readTimeout = timeoutMs
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.use { String(it.readBytes(), Charsets.UTF_8) }.orEmpty()
            return HttpResponse(code, text)
        } finally { c.disconnect() }
    }
}

open class BackendReceiptProvider(
    private val vendor: String,
    private val config: BackendConfig?,
    private val transport: HttpTransport = JdkHttpTransport,
    private val sleeper: (Long) -> Unit = { Thread.sleep(it) },
    private val policy: ImagePolicy = ImagePolicy(),
) : ReceiptExtractionProvider {
    override val id: String = "backend-$vendor"

    override fun isAvailable(): Boolean = config?.valid == true

    override fun extract(req: ReceiptRequest): ProviderResult {
        val cfg = config
        if (cfg == null || !cfg.valid) return ProviderResult.Unavailable("no_backend_configured")
        val issues = ReceiptEngine.validateUpload(req.mime, req.bytes.size, policy)
        if (issues.isNotEmpty()) return ProviderResult.Failed("upload:" + issues.joinToString(",") { it.name.lowercase() }, retryable = false)
        val body = MiniJson.write(linkedMapOf(
            "vendor" to vendor, "schema_version" to RECEIPT_SCHEMA_VERSION, "mime" to req.mime, "locale" to req.locale,
            "request_id" to req.requestId, "image_base64" to Base64.getEncoder().encodeToString(req.bytes),
        ))
        val headers = mapOf("Authorization" to "Bearer " + cfg.deviceToken, "Content-Type" to "application/json", "X-Request-Id" to req.requestId)
        var attempt = 0
        while (true) {
            val r = try { transport.post(cfg.baseUrl.trimEnd('/') + "/v1/receipts/extract", headers, body, cfg.timeoutMs) }
            catch (e: SocketTimeoutException) { null } catch (e: IOException) { null }
            val retryable = r == null || r.code == 429 || r.code >= 500
            if (r != null && r.code in 200..299) return ProviderResult.Success(r.body, id)
            if (!retryable || attempt >= cfg.maxRetries) {
                return ProviderResult.Failed(when { r == null -> "network"; r.code == 401 || r.code == 403 -> "auth"; r.code == 413 -> "too_large"; r.code == 429 -> "rate_limited"; else -> "http_${r.code}" }, retryable)
            }
            sleeper(1000L shl attempt) // 1s, 2s … exponential back-off
            attempt++
        }
    }
}

class ClaudeBackendProvider(config: BackendConfig?, transport: HttpTransport = JdkHttpTransport) : BackendReceiptProvider("claude", config, transport)
class OpenAiBackendProvider(config: BackendConfig?, transport: HttpTransport = JdkHttpTransport) : BackendReceiptProvider("openai", config, transport)

/** Tries providers in order; the first available one is used. AI failure never throws. */
class ReceiptExtractor(private val providers: List<ReceiptExtractionProvider>) {
    fun isAvailable(): Boolean = providers.any { it.isAvailable() }

    fun extract(req: ReceiptRequest): Pair<ProviderResult, ReceiptParse?> {
        val p = providers.firstOrNull { it.isAvailable() } ?: return ProviderResult.Unavailable("no_provider") to null
        val r = runCatching { p.extract(req) }.getOrElse { ProviderResult.Failed("exception", retryable = true) }
        return r to (r as? ProviderResult.Success)?.let { ReceiptJson.parse(it.json, it.provider) }
    }
}
