package com.asyraf.hadirku.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Ikon garis halus ala PoketGaji (dilukis dalam grid 24 unit). */
enum class Ic {
    POKET, TRANSAKSI, BAYARAN, KERJA, LAPORAN, GEAR, PLUS, CAMERA, FINGER, LOGOUT, CHECK, PIN, CLOUD, FIRE, SUN, MOON, DOWNLOAD, UP, DOWN, WALLET, SENARAI, CALC,
    // ---- Lejar Moden ----
    HOME, CARD, BELL, MENU, BACK, CHEVRON, SEARCH, EYE, EYE_OFF, ARROW_DOWN, ARROW_UP, CALENDAR, LAYERS, MONEYBAG, BRIEFCASE,
    FORK, CAR, COINS, BOLT, DROP, WIFI, PHONE, SHIELD, CART, CLOSE, BOOK, SWAP, TAG, CLIPBOARD, HEART, DOTS, RECEIPT, TREND, GEM, LIST,
}

@Composable
fun Ico(ic: Ic, color: Color, size: Dp = 22.dp, stroke: Float = 1.8f, modifier: Modifier = Modifier, desc: String? = null) {
    Canvas(modifier.size(size).then(if (desc != null) Modifier.semantics { contentDescription = com.asyraf.hadirku.i18n.tr(desc) } else Modifier)) {
        val u = this.size.width / 24f
        val st = Stroke(width = stroke * u, cap = StrokeCap.Round, join = StrokeJoin.Round)
        fun p(vararg pts: Float, close: Boolean = false): Path {
            val path = Path()
            var i = 0
            while (i < pts.size - 1) {
                if (i == 0) path.moveTo(pts[0] * u, pts[1] * u) else path.lineTo(pts[i] * u, pts[i + 1] * u)
                i += 2
            }
            if (close) path.close()
            return path
        }
        fun line(vararg pts: Float) = drawPath(p(*pts), color, style = st)
        fun rrect(x: Float, y: Float, w: Float, h: Float, r: Float) {
            val path = Path().apply { addRoundRect(RoundRect(x * u, y * u, (x + w) * u, (y + h) * u, CornerRadius(r * u, r * u))) }
            drawPath(path, color, style = st)
        }
        fun circle(cx: Float, cy: Float, r: Float, fill: Boolean = false) {
            if (fill) drawCircle(color, radius = r * u, center = Offset(cx * u, cy * u))
            else drawCircle(color, radius = r * u, center = Offset(cx * u, cy * u), style = st)
        }
        draw(ic, ::line, ::rrect, ::circle, u, color, st)
    }
}

private fun DrawScope.draw(
    ic: Ic,
    line: (FloatArray) -> Unit,
    rrect: (Float, Float, Float, Float, Float) -> Unit,
    circle: (Float, Float, Float, Boolean) -> Unit,
    u: Float,
    color: Color,
    st: Stroke,
) {
    fun l(vararg f: Float) = line(f)
    when (ic) {
        Ic.POKET -> { rrect(4f, 7f, 16f, 13f, 1.2f); l(4f, 7f, 6f, 4f, 18f, 4f, 20f, 7f); l(15f, 13.5f, 17f, 13.5f) }
        Ic.TRANSAKSI -> { l(8f, 6f, 20f, 6f); l(8f, 12f, 20f, 12f); l(8f, 18f, 20f, 18f); circle(4f, 6f, 0.9f, true); circle(4f, 12f, 0.9f, true); circle(4f, 18f, 0.9f, true) }
        Ic.BAYARAN -> { rrect(4f, 5f, 16f, 15f, 2f); l(8f, 3f, 8f, 7f); l(16f, 3f, 16f, 7f); l(4f, 10f, 20f, 10f); l(9f, 15f, 11f, 17f, 15f, 13f) }
        Ic.KERJA -> { circle(12f, 13f, 8f, false); l(12f, 9f, 12f, 13f, 15f, 15f); l(9f, 2f, 15f, 2f) }
        Ic.LAPORAN -> { l(4f, 20f, 20f, 20f); l(7f, 16f, 7f, 11f); l(12f, 16f, 12f, 7f); l(17f, 16f, 17f, 8f) }
        Ic.GEAR -> {
            circle(12f, 12f, 3f, false)
            for (k in 0 until 8) {
                val a = Math.toRadians(k * 45.0)
                val x1 = 12f + 6.2f * Math.cos(a).toFloat(); val y1 = 12f + 6.2f * Math.sin(a).toFloat()
                val x2 = 12f + 8.6f * Math.cos(a).toFloat(); val y2 = 12f + 8.6f * Math.sin(a).toFloat()
                l(x1, y1, x2, y2)
            }
            circle(12f, 12f, 6.2f, false)
        }
        Ic.PLUS -> { l(12f, 5f, 12f, 19f); l(5f, 12f, 19f, 12f) }
        Ic.CAMERA -> { l(4f, 8f, 7f, 8f, 9f, 5f, 15f, 5f, 17f, 8f, 20f, 8f, 20f, 19f, 4f, 19f, 4f, 8f); circle(12f, 13f, 3.5f, false) }
        Ic.FINGER -> {
            l(8f, 20f, 8f, 13f); l(12f, 21f, 12f, 12f); l(16f, 19f, 16f, 13f)
            drawArc(color, 180f, 180f, false, Offset(8f * u, 9f * u), Size(8f * u, 8f * u), style = st)
            drawArc(color, 180f, 180f, false, Offset(5f * u, 5f * u), Size(14f * u, 14f * u), style = st)
            l(5f, 12f, 5f, 16f); l(19f, 12f, 19f, 15f)
        }
        Ic.LOGOUT -> { l(10f, 4f, 5f, 4f, 5f, 20f, 10f, 20f); l(10f, 12f, 20f, 12f); l(16f, 8f, 20f, 12f, 16f, 16f) }
        Ic.CHECK -> { circle(12f, 12f, 9f, false); l(8f, 12.5f, 11f, 15.5f, 16.5f, 9.5f) }
        Ic.PIN -> { circle(12f, 10f, 2.6f, false); l(12f, 21f, 6.5f, 13.5f); l(12f, 21f, 17.5f, 13.5f); drawArc(color, 150f, 240f, false, Offset(5.5f * u, 3.5f * u), Size(13f * u, 13f * u), style = st) }
        Ic.CLOUD -> { l(7f, 18f, 17f, 18f); drawArc(color, 90f, 180f, false, Offset(3f * u, 10f * u), Size(8f * u, 8f * u), style = st); drawArc(color, 180f, 180f, false, Offset(7f * u, 6f * u), Size(10f * u, 10f * u), style = st); drawArc(color, 270f, 180f, false, Offset(13f * u, 10f * u), Size(8f * u, 8f * u), style = st) }
        Ic.FIRE -> { l(12f, 3f, 16f, 9f, 17f, 14f, 15f, 19f, 12f, 21f, 9f, 19f, 7f, 14f, 9f, 10f, 11f, 12f, 12f, 3f) }
        Ic.SUN -> { circle(12f, 12f, 4f, false); for (k in 0 until 8) { val a = Math.toRadians(k * 45.0); l(12f + 6.5f * Math.cos(a).toFloat(), 12f + 6.5f * Math.sin(a).toFloat(), 12f + 8.8f * Math.cos(a).toFloat(), 12f + 8.8f * Math.sin(a).toFloat()) } }
        Ic.MOON -> { drawArc(color, 60f, 250f, false, Offset(4f * u, 4f * u), Size(16f * u, 16f * u), style = st); drawArc(color, 120f, 120f, false, Offset(9f * u, 2f * u), Size(12f * u, 12f * u), style = st) }
        Ic.DOWNLOAD -> { l(12f, 3f, 12f, 15f); l(7f, 10f, 12f, 15f, 17f, 10f); l(5f, 21f, 19f, 21f) }
        Ic.UP -> { l(6f, 15f, 12f, 9f, 18f, 15f) }
        Ic.DOWN -> { l(6f, 9f, 12f, 15f, 18f, 9f) }
        // bakul belanja
        Ic.SENARAI -> { l(3f, 9f, 21f, 9f); l(5f, 9f, 6.5f, 19f, 17.5f, 19f, 19f, 9f); l(8f, 9f, 11f, 4f); l(16f, 9f, 13f, 4f); l(10f, 12.5f, 10f, 15.5f); l(14f, 12.5f, 14f, 15.5f) }
        // kalkulator: badan, skrin, 3×3 butang
        Ic.CALC -> {
            rrect(5f, 2.5f, 14f, 19f, 2f)
            rrect(7.5f, 5f, 9f, 4f, 0.8f)
            for (r in 0 until 3) for (c in 0 until 3) circle(9f + c * 3f, 12.5f + r * 3f, 0.95f, true)
        }
        Ic.WALLET -> { rrect(3f, 6f, 18f, 14f, 2.2f); l(5f, 6f, 15f, 3.5f, 17f, 6f); rrect(14f, 10.5f, 7f, 5f, 1.5f); circle(16.8f, 13f, 0.9f, true) }
        // ================= Lejar Moden =================
        Ic.HOME -> { l(3f, 11f, 12f, 3.8f, 21f, 11f); l(5.5f, 9.3f, 5.5f, 20f, 18.5f, 20f, 18.5f, 9.3f); l(10f, 20f, 10f, 14.5f, 14f, 14.5f, 14f, 20f) }
        Ic.CARD -> { rrect(3f, 5.5f, 18f, 13f, 2.2f); l(3f, 10f, 21f, 10f); l(6.5f, 15f, 10.5f, 15f) }
        Ic.BELL -> {
            l(6f, 11f, 6f, 16.5f); l(18f, 11f, 18f, 16.5f)
            drawArc(color, 180f, 180f, false, Offset(6f * u, 5f * u), Size(12f * u, 12f * u), style = st)
            l(4.5f, 16.5f, 19.5f, 16.5f); l(12f, 3f, 12f, 5f)
            drawArc(color, 0f, 180f, false, Offset(10f * u, 17.5f * u), Size(4f * u, 3f * u), style = st)
        }
        Ic.MENU -> { l(4f, 7f, 20f, 7f); l(4f, 12f, 20f, 12f); l(4f, 17f, 20f, 17f) }
        Ic.BACK -> { l(19f, 12f, 5f, 12f); l(11f, 6f, 5f, 12f, 11f, 18f) }
        Ic.CHEVRON -> { l(9f, 5f, 16f, 12f, 9f, 19f) }
        Ic.SEARCH -> { circle(10.5f, 10.5f, 6.5f, false); l(15.5f, 15.5f, 20.5f, 20.5f) }
        Ic.EYE, Ic.EYE_OFF -> {
            val e = Path().apply { moveTo(2f * u, 12f * u); quadraticBezierTo(12f * u, 2.5f * u, 22f * u, 12f * u); quadraticBezierTo(12f * u, 21.5f * u, 2f * u, 12f * u); close() }
            drawPath(e, color, style = st)
            circle(12f, 12f, 3f, false)
            if (ic == Ic.EYE_OFF) l(4f, 4f, 20f, 20f)
        }
        Ic.ARROW_DOWN -> { l(12f, 4f, 12f, 19f); l(6f, 13f, 12f, 19f, 18f, 13f) }
        Ic.ARROW_UP -> { l(12f, 20f, 12f, 5f); l(6f, 11f, 12f, 5f, 18f, 11f) }
        Ic.CALENDAR -> {
            rrect(3.5f, 5f, 17f, 15.5f, 2.2f); l(3.5f, 10f, 20.5f, 10f); l(8f, 3f, 8f, 7f); l(16f, 3f, 16f, 7f)
            circle(8f, 14.5f, 0.9f, true); circle(12f, 14.5f, 0.9f, true); circle(16f, 14.5f, 0.9f, true)
        }
        Ic.LAYERS -> { l(12f, 3f, 21f, 8f, 12f, 13f, 3f, 8f, 12f, 3f); l(3f, 12f, 12f, 17f, 21f, 12f); l(3f, 16f, 12f, 21f, 21f, 16f) }
        Ic.MONEYBAG -> {
            l(9.5f, 8f, 8f, 3.8f, 16f, 3.8f, 14.5f, 8f)
            drawOval(color, Offset(4.5f * u, 8f * u), Size(15f * u, 13f * u), style = st)
            l(12f, 11.5f, 12f, 18f); l(14.2f, 12.8f, 10.8f, 12.8f, 10.8f, 14.6f, 13.2f, 14.6f, 13.2f, 16.6f, 9.8f, 16.6f)
        }
        Ic.BRIEFCASE -> { rrect(3f, 7.5f, 18f, 12.5f, 2f); l(9f, 7.5f, 9f, 5f, 15f, 5f, 15f, 7.5f); l(3f, 12.5f, 21f, 12.5f); l(12f, 11.5f, 12f, 13.5f) }
        Ic.FORK -> { l(5f, 3f, 5f, 8.5f, 9f, 8.5f, 9f, 3f); l(7f, 3f, 7f, 21f); l(16.5f, 21f, 16.5f, 3f, 19.5f, 6.5f, 19.5f, 12.5f, 16.5f, 12.5f) }
        Ic.CAR -> {
            rrect(3f, 10.5f, 18f, 6.5f, 2f); l(5.5f, 10.5f, 7.5f, 6f, 16.5f, 6f, 18.5f, 10.5f)
            circle(7.5f, 17.5f, 1.8f, false); circle(16.5f, 17.5f, 1.8f, false)
        }
        Ic.COINS -> {
            for (k in 0 until 3) {
                val y = 4f + k * 5f
                drawOval(color, Offset(5f * u, y * u), Size(14f * u, 4.5f * u), style = st)
            }
            l(5f, 6.25f, 5f, 16.25f); l(19f, 6.25f, 19f, 16.25f)
        }
        Ic.BOLT -> { l(13f, 2.5f, 5f, 13.5f, 11.5f, 13.5f, 10.5f, 21.5f, 19f, 10f, 12.5f, 10f, 13f, 2.5f) }
        Ic.DROP -> { l(7.24f, 11.75f, 12f, 3f, 16.76f, 11.75f); drawArc(color, -30f, 240f, false, Offset(6.5f * u, 9f * u), Size(11f * u, 11f * u), style = st) }
        Ic.WIFI -> {
            listOf(3.2f, 6.6f, 10f).forEach { r -> drawArc(color, -135f, 90f, false, Offset((12f - r) * u, (19f - r) * u), Size(2 * r * u, 2 * r * u), style = st) }
            circle(12f, 19f, 1.1f, true)
        }
        Ic.PHONE -> { rrect(7f, 2.5f, 10f, 19f, 2.2f); l(10.5f, 18.5f, 13.5f, 18.5f) }
        Ic.SHIELD -> {
            val sh = Path().apply {
                moveTo(12f * u, 3f * u); lineTo(19.5f * u, 6f * u); lineTo(19.5f * u, 11.5f * u)
                quadraticBezierTo(19f * u, 18f * u, 12f * u, 21f * u); quadraticBezierTo(5f * u, 18f * u, 4.5f * u, 11.5f * u); lineTo(4.5f * u, 6f * u); close()
            }
            drawPath(sh, color, style = st); l(8.5f, 12f, 11f, 14.5f, 15.5f, 9.5f)
        }
        Ic.CART -> { l(2.5f, 4f, 5f, 4f, 7.5f, 15f, 18f, 15f, 20.5f, 7.5f, 6f, 7.5f); circle(9f, 19f, 1.4f, false); circle(17f, 19f, 1.4f, false) }
        Ic.CLOSE -> { l(6f, 6f, 18f, 18f); l(18f, 6f, 6f, 18f) }
        Ic.BOOK -> {
            val lp = Path().apply { moveTo(12f * u, 6.5f * u); quadraticBezierTo(8f * u, 4.2f * u, 3f * u, 5.2f * u); lineTo(3f * u, 18f * u); quadraticBezierTo(8f * u, 17f * u, 12f * u, 19.5f * u) }
            val rp = Path().apply { moveTo(12f * u, 6.5f * u); quadraticBezierTo(16f * u, 4.2f * u, 21f * u, 5.2f * u); lineTo(21f * u, 18f * u); quadraticBezierTo(16f * u, 17f * u, 12f * u, 19.5f * u) }
            drawPath(lp, color, style = st); drawPath(rp, color, style = st); l(12f, 6.5f, 12f, 19.5f)
        }
        Ic.SWAP -> { l(4f, 8f, 18f, 8f); l(14f, 4f, 18f, 8f, 14f, 12f); l(20f, 16f, 6f, 16f); l(10f, 12f, 6f, 16f, 10f, 20f) }
        Ic.TAG -> { l(3f, 12f, 11f, 4f, 20f, 4f, 20f, 13f, 12f, 21f, 3f, 12f); circle(15.5f, 8.5f, 1.3f, false) }
        Ic.CLIPBOARD -> { rrect(5f, 4.5f, 14f, 16.5f, 2f); rrect(9f, 2.5f, 6f, 4f, 1f); l(8.5f, 11f, 15.5f, 11f); l(8.5f, 15f, 13f, 15f) }
        Ic.HEART -> {
            val h = Path().apply {
                moveTo(12f * u, 20f * u)
                cubicTo(3f * u, 14f * u, 2.5f * u, 7f * u, 7.5f * u, 5.5f * u)
                cubicTo(10f * u, 4.8f * u, 11.5f * u, 6.5f * u, 12f * u, 8f * u)
                cubicTo(12.5f * u, 6.5f * u, 14f * u, 4.8f * u, 16.5f * u, 5.5f * u)
                cubicTo(21.5f * u, 7f * u, 21f * u, 14f * u, 12f * u, 20f * u)
                close()
            }
            drawPath(h, color, style = st)
        }
        Ic.DOTS -> { circle(12f, 5.5f, 1.5f, true); circle(12f, 12f, 1.5f, true); circle(12f, 18.5f, 1.5f, true) }
        Ic.RECEIPT -> { l(6f, 3f, 18f, 3f, 18f, 21f, 15f, 19f, 12f, 21f, 9f, 19f, 6f, 21f, 6f, 3f); l(9f, 8f, 15f, 8f); l(9f, 12f, 15f, 12f) }
        Ic.TREND -> { l(3f, 17f, 9f, 11f, 13f, 15f, 21f, 7f); l(15f, 7f, 21f, 7f, 21f, 13f) }
        Ic.GEM -> { l(6f, 4f, 18f, 4f, 21f, 9f, 12f, 20f, 3f, 9f, 6f, 4f); l(3f, 9f, 21f, 9f); l(9.5f, 4f, 8f, 9f, 12f, 20f, 16f, 9f, 14.5f, 4f) }
        Ic.LIST -> { l(9f, 6.5f, 20f, 6.5f); l(9f, 12f, 20f, 12f); l(9f, 17.5f, 20f, 17.5f); circle(5f, 6.5f, 1f, true); circle(5f, 12f, 1f, true); circle(5f, 17.5f, 1f, true) }
    }
}
