package com.asyraf.hadirku.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Ikon garis halus (grid 24 unit): pek ikon DuitkuIsteri + beberapa ikon lukisan tangan dalam gaya sama. */
enum class Ic {
    POKET, TRANSAKSI, BAYARAN, KERJA, LAPORAN, GEAR, PLUS, CAMERA, FINGER, LOGOUT, CHECK, PIN, CLOUD, FIRE, SUN, MOON, DOWNLOAD, UP, DOWN, WALLET, SENARAI, CALC,
    // ---- Lejar Moden ----
    HOME, CARD, BELL, MENU, BACK, CHEVRON, SEARCH, EYE, EYE_OFF, ARROW_DOWN, ARROW_UP, CALENDAR, LAYERS, MONEYBAG, BRIEFCASE,
    FORK, CAR, COINS, BOLT, DROP, WIFI, PHONE, SHIELD, CART, CLOSE, BOOK, SWAP, TAG, CLIPBOARD, HEART, DOTS, RECEIPT, TREND, GEM, LIST,
    // ---- pek ikon DuitkuIsteri (Soft Violet) ----
    P_INCOME, P_EXPENSE, P_SAVINGS, P_BUDGET, P_CASH, P_BANK, P_GOAL, P_FOOD, P_GROCERY, P_PETROL, P_SHOPPING, P_UTILITIES, P_HOUSE, P_TRANSPORT, P_HEALTH, P_EDUCATION, P_ENTERTAINMENT, P_SUBSCRIPTION, P_TRAVEL, P_GIFT, P_OTHER, P_INSTALLMENT, P_INTEREST, P_PAYMENT, P_STATEMENT, P_PROFILE, P_SYNC, P_CATEGORIES, P_EDIT, P_DELETE, P_FILTER, P_SCAN, P_NOTE, P_ATTACHMENT, P_REPORT, P_TRANSFER, P_BACKUP, P_ANALYTICS, P_LEDGER,
}

/**
 * Glyph pek ikon DuitkuIsteri (grid 24 unit, garis 1.8, hujung bulat). Ikon dalam peta ini dilukis daripada path SVG pek;
 * ikon lain (cth KERJA, CALC, FINGER) kekal dilukis tangan dalam gaya garis yang sama.
 */
private val PEK: Map<Ic, String> = mapOf(
    Ic.POKET to "M4 6h15v14H4z M4 6l12-3v3 M15 11h6v5h-6z",
    Ic.TRANSAKSI to "M6 3h12v18H6z M9 7h6 M9 11h6 M9 15h4",
    Ic.BAYARAN to "M3 5h18v14H3z M3 9h18 M8 14l3 3 5-5",
    Ic.LAPORAN to "M4 20h16 M6 16v-5 M12 16V5 M18 16V8",
    Ic.GEAR to "M12 3v3 M12 18v3 M3 12h3 M18 12h3 M6 6l2 2 M16 16l2 2 M6 18l2-2 M16 8l2-2 M12 7a5 5 0 1 0 0 10 5 5 0 0 0 0-10z",
    Ic.PLUS to "M12 5v14 M5 12h14",
    Ic.CAMERA to "M3 7h5l2-3h4l2 3h5v13H3z M12 10a4 4 0 1 0 0 8 4 4 0 0 0 0-8z",
    Ic.CHECK to "M4 12l5 5L20 6",
    Ic.CLOUD to "M6 18a5 5 0 0 1-1-10 7 7 0 0 1 13-1 5 5 0 0 1 0 11 M12 20V10 M8 14l4-4 4 4",
    Ic.SUN to "M12 2v3 M12 19v3 M2 12h3 M19 12h3 M5 5l2 2 M17 17l2 2 M5 19l2-2 M17 7l2-2 M12 7a5 5 0 1 0 0 10 5 5 0 0 0 0-10z",
    Ic.MOON to "M19 15A8 8 0 0 1 9 5a8 8 0 1 0 10 10z",
    Ic.SENARAI to "M3 9h18l-2 11H5z M7 9l3-6 M17 9l-3-6 M9 13v3 M15 13v3",
    Ic.WALLET to "M4 6h15v14H4z M4 6l12-3v3 M15 11h6v5h-6z",
    Ic.HOME to "M4 11 12 4l8 7v9h-6v-6h-4v6H4Z",
    Ic.CARD to "M3 5h18v14H3z M3 9h18 M6 15h4",
    Ic.BELL to "M5 17h14l-2-4V9a5 5 0 0 0-10 0v4z M10 20h4",
    Ic.MENU to "M5 6h14 M5 12h14 M5 18h14",
    Ic.BACK to "M15 5l-7 7 7 7",
    Ic.CHEVRON to "M9 5l7 7-7 7",
    Ic.SEARCH to "M10 3a7 7 0 1 0 0 14 7 7 0 0 0 0-14z M15 15l6 6",
    Ic.EYE to "M2 12q10-14 20 0-10 14-20 0z M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6z",
    Ic.ARROW_DOWN to "M12 4v15 M6 13l6 6 6-6 M4 21h16",
    Ic.ARROW_UP to "M12 20V5 M6 11l6-6 6 6 M4 3h16",
    Ic.CALENDAR to "M3 5h18v16H3z M7 3v4 M17 3v4 M3 10h18 M8 14h2 M14 14h2",
    Ic.MONEYBAG to "M3 6h18v12H3z M8 12h.1 M16 12h.1 M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6z",
    Ic.COINS to "M3 9 12 3l9 6z M5 11v7 M10 11v7 M14 11v7 M19 11v7 M3 21h18",
    Ic.FORK to "M5 3v7q3 3 6 0V3 M8 3v18 M18 3q-4 4-4 9h4v9",
    Ic.CAR to "M4 10l2-5h12l2 5v8H4z M4 10h16 M7 14h.1 M17 14h.1 M6 18v3 M18 18v3",
    Ic.BOLT to "M13 2 5 14h6l-1 8 9-12h-7z",
    Ic.SHIELD to "M12 3 4 6v6q0 6 8 9 8-3 8-9V6z M8 12l3 3 5-5",
    Ic.CART to "M4 8h16l1 13H3z M8 9V6a4 4 0 0 1 8 0v3",
    Ic.CLOSE to "M6 6l12 12 M18 6 6 18",
    Ic.BOOK to "M2 9 12 4l10 5-10 5z M6 11v6q6 5 12 0v-6 M22 9v8",
    Ic.SWAP to "M4 8h16l-4-4 M20 16H4l4 4",
    Ic.DOTS to "M5 12h.1 M12 12h.1 M19 12h.1",
    Ic.RECEIPT to "M6 3h12v18l-3-2-3 2-3-2-3 2z M9 7h6 M9 11h6 M9 15h4",
    Ic.LIST to "M6 3h12v18H6z M9 7h6 M9 11h6 M9 15h4",
    Ic.LAYERS to "M4 5h16v15H4z M4 9h16 M8 3v4 M16 3v4 M8 13h2 M14 13h2 M8 17h2",
    Ic.EYE_OFF to "M2 12q10-14 20 0-10 14-20 0z M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6z M3 3l18 18",
    Ic.P_INCOME to "M12 4v15 M6 13l6 6 6-6 M4 21h16",
    Ic.P_EXPENSE to "M12 20V5 M6 11l6-6 6 6 M4 3h16",
    Ic.P_SAVINGS to "M5 10c0-4 4-6 8-5l4-2v5l3 2v5l-3 2v3h-3v-2H9v2H6v-4l-3-3v-3z M15 10h.1",
    Ic.P_BUDGET to "M5 4h14v16H5z M8 8h8 M8 12h3 M14 12h2 M8 16h3 M14 16h2",
    Ic.P_CASH to "M3 6h18v12H3z M8 12h.1 M16 12h.1 M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6z",
    Ic.P_BANK to "M3 9 12 3l9 6z M5 11v7 M10 11v7 M14 11v7 M19 11v7 M3 21h18",
    Ic.P_GOAL to "M12 3a9 9 0 1 0 9 9 M12 7a5 5 0 1 0 5 5 M12 12l8-8 M16 4h4v4",
    Ic.P_FOOD to "M5 3v7q3 3 6 0V3 M8 3v18 M18 3q-4 4-4 9h4v9",
    Ic.P_GROCERY to "M3 9h18l-2 11H5z M7 9l3-6 M17 9l-3-6 M9 13v3 M15 13v3",
    Ic.P_PETROL to "M4 21V4h10v17 M4 12h10 M14 14h2v4q4 3 4-1V9l-3-3 M6 7h6 M2 21h14",
    Ic.P_SHOPPING to "M4 8h16l1 13H3z M8 9V6a4 4 0 0 1 8 0v3",
    Ic.P_UTILITIES to "M13 2 5 14h6l-1 8 9-12h-7z",
    Ic.P_HOUSE to "M3 11 12 3l9 8 M5 10v11h14V10 M10 21v-7h4v7",
    Ic.P_TRANSPORT to "M4 10l2-5h12l2 5v8H4z M4 10h16 M7 14h.1 M17 14h.1 M6 18v3 M18 18v3",
    Ic.P_HEALTH to "M8 4h8v5h5v6h-5v5H8v-5H3V9h5z",
    Ic.P_EDUCATION to "M2 9 12 4l10 5-10 5z M6 11v6q6 5 12 0v-6 M22 9v8",
    Ic.P_ENTERTAINMENT to "M4 5h16v14H4z M10 9l5 3-5 3z",
    Ic.P_SUBSCRIPTION to "M5 8a8 8 0 0 1 14-1l2 3 M21 4v6h-6 M19 16a8 8 0 0 1-14 1l-2-3 M3 20v-6h6",
    Ic.P_TRAVEL to "M3 11l18-7-7 17-3-7z M11 14l10-10",
    Ic.P_GIFT to "M3 9h18v4H3z M5 13v8h14v-8 M12 9v12 M12 9C3 9 6 1 10 5l2 4 M12 9c9 0 6-8 2-4z",
    Ic.P_OTHER to "M5 12h.1 M12 12h.1 M19 12h.1",
    Ic.P_INSTALLMENT to "M4 5h16v15H4z M4 9h16 M8 3v4 M16 3v4 M8 13h2 M14 13h2 M8 17h2",
    Ic.P_INTEREST to "M6 18 18 6 M7 5a2 2 0 1 0 0 4 2 2 0 0 0 0-4z M17 15a2 2 0 1 0 0 4 2 2 0 0 0 0-4z",
    Ic.P_PAYMENT to "M3 5h18v14H3z M3 9h18 M8 14l3 3 5-5",
    Ic.P_STATEMENT to "M6 3h12v18l-3-2-3 2-3-2-3 2z M9 7h6 M9 11h6 M9 15h4",
    Ic.P_PROFILE to "M12 4a4 4 0 1 0 0 8 4 4 0 0 0 0-8z M4 21v-2a8 8 0 0 1 16 0v2",
    Ic.P_SYNC to "M4 10a8 8 0 0 1 14-4l3 3 M21 3v6h-6 M20 14a8 8 0 0 1-14 4l-3-3 M3 21v-6h6",
    Ic.P_CATEGORIES to "M4 4h6v6H4z M14 4h6v6h-6z M4 14h6v6H4z M14 14h6v6h-6z",
    Ic.P_EDIT to "M4 16 16 4l4 4L8 20H4z M13 7l4 4",
    Ic.P_DELETE to "M4 6h16 M9 6V3h6v3 M6 6l1 15h10l1-15 M10 10v7 M14 10v7",
    Ic.P_FILTER to "M3 5h18l-7 8v6l-4 2v-8z",
    Ic.P_SCAN to "M3 8V3h5 M16 3h5v5 M21 16v5h-5 M8 21H3v-5 M5 12h14",
    Ic.P_NOTE to "M5 3h14v18H5z M8 7h8 M8 11h8 M8 15h5",
    Ic.P_ATTACHMENT to "M8 13l7-7a3 3 0 0 1 4 4L9 20a5 5 0 0 1-7-7L13 2 M7 15l8-8",
    Ic.P_REPORT to "M5 3h10l4 4v14H5z M14 3v5h5 M8 17v-4 M12 17v-7 M16 17v-3",
    Ic.P_TRANSFER to "M4 8h16l-4-4 M20 16H4l4 4",
    Ic.P_BACKUP to "M6 18a5 5 0 0 1-1-10 7 7 0 0 1 13-1 5 5 0 0 1 0 11 M12 20V10 M8 14l4-4 4 4",
    Ic.P_ANALYTICS to "M4 20h16 M6 16v-5 M12 16V5 M18 16V8",
    Ic.P_LEDGER to "M6 3h12v18H6z M9 7h6 M9 11h6 M9 15h4",
)

/** Path pek yang sudah dihurai (sekali sahaja bagi setiap ikon). */
private val PEK_PATH = HashMap<Ic, Path>()
private fun pekPath(ic: Ic): Path? {
    PEK_PATH[ic]?.let { return it }
    val d = PEK[ic] ?: return null
    val path = PathParser().parsePathString(d).toPath()
    PEK_PATH[ic] = path
    return path
}

/** Warna jubin ikon kategori ikut pek (latar, garis) — cerah; gelap guna versi lembut. */
fun pekTint(ic: Ic, pal: Pal): Pair<Color, Color>? = when (ic) {
    Ic.P_INCOME, Ic.P_HEALTH, Ic.ARROW_DOWN -> if (pal.dark) Pair(Color(0xFF1E3B33), Color(0xFF6FD3A8)) else Pair(Color(0xFFDDF6EC), Color(0xFF087D59))
    Ic.P_EXPENSE, Ic.P_PETROL, Ic.ARROW_UP -> if (pal.dark) Pair(Color(0xFF46252F), Color(0xFFF4909F)) else Pair(Color(0xFFFFE5E9), Color(0xFFB83B55))
    Ic.P_FOOD, Ic.P_UTILITIES, Ic.FORK, Ic.BOLT -> if (pal.dark) Pair(Color(0xFF3F2F24), Color(0xFFF0B27A)) else Pair(Color(0xFFFFF0DE), Color(0xFFB85B16))
    Ic.P_GROCERY, Ic.P_TRAVEL, Ic.SENARAI, Ic.DROP -> if (pal.dark) Pair(Color(0xFF22324A), Color(0xFF8FBEF2)) else Pair(Color(0xFFE4F1FF), Color(0xFF2866A5))
    else -> null
}

@Composable
fun Ico(ic: Ic, color: Color, size: Dp = 22.dp, stroke: Float = 1.8f, modifier: Modifier = Modifier, desc: String? = null) {
    Canvas(modifier.size(size).then(if (desc != null) Modifier.semantics { contentDescription = com.asyraf.hadirku.i18n.tr(desc) } else Modifier)) {
        val u = this.size.width / 24f
        val st = Stroke(width = stroke * u, cap = StrokeCap.Round, join = StrokeJoin.Round)
        fun p(vararg pts: Float, close: Boolean = false): Path {
            val path = Path()
            var i = 0
            while (i < pts.size - 1) {
                if (i == 0) path.moveTo(pts[0] * u, pts[1] * u) else path.lineTo(pts[i] * u, pts[i + 1] * u)
                i += 2
            }
            if (close) path.close()
            return path
        }
        fun line(vararg pts: Float) = drawPath(p(*pts), color, style = st)
        fun rrect(x: Float, y: Float, w: Float, h: Float, r: Float) {
            val path = Path().apply { addRoundRect(RoundRect(x * u, y * u, (x + w) * u, (y + h) * u, CornerRadius(r * u, r * u))) }
            drawPath(path, color, style = st)
        }
        fun circle(cx: Float, cy: Float, r: Float, fill: Boolean = false) {
            if (fill) drawCircle(color, radius = r * u, center = Offset(cx * u, cy * u))
            else drawCircle(color, radius = r * u, center = Offset(cx * u, cy * u), style = st)
        }
        val pk = pekPath(ic)
        if (pk != null) {
            // path pek dalam unit 24 → skala ke saiz ikon; tebal garis dalam unit yang sama
            scale(u, u, pivot = Offset.Zero) { drawPath(pk, color, style = Stroke(width = stroke, cap = StrokeCap.Round, join = StrokeJoin.Round)) }
        } else draw(ic, ::line, ::rrect, ::circle, u, color, st)
    }
}

private fun DrawScope.draw(
    ic: Ic,
    line: (FloatArray) -> Unit,
    rrect: (Float, Float, Float, Float, Float) -> Unit,
    circle: (Float, Float, Float, Boolean) -> Unit,
    u: Float,
    color: Color,
    st: Stroke,
) {
    fun l(vararg f: Float) = line(f)
    when (ic) {
        Ic.POKET -> { rrect(4f, 7f, 16f, 13f, 1.2f); l(4f, 7f, 6f, 4f, 18f, 4f, 20f, 7f); l(15f, 13.5f, 17f, 13.5f) }
        Ic.TRANSAKSI -> { l(8f, 6f, 20f, 6f); l(8f, 12f, 20f, 12f); l(8f, 18f, 20f, 18f); circle(4f, 6f, 0.9f, true); circle(4f, 12f, 0.9f, true); circle(4f, 18f, 0.9f, true) }
        Ic.BAYARAN -> { rrect(4f, 5f, 16f, 15f, 2f); l(8f, 3f, 8f, 7f); l(16f, 3f, 16f, 7f); l(4f, 10f, 20f, 10f); l(9f, 15f, 11f, 17f, 15f, 13f) }
        Ic.KERJA -> { circle(12f, 13f, 8f, false); l(12f, 9f, 12f, 13f, 15f, 15f); l(9f, 2f, 15f, 2f) }
        Ic.LAPORAN -> { l(4f, 20f, 20f, 20f); l(7f, 16f, 7f, 11f); l(12f, 16f, 12f, 7f); l(17f, 16f, 17f, 8f) }
        Ic.GEAR -> {
            circle(12f, 12f, 3f, false)
            for (k in 0 until 8) {
                val a = Math.toRadians(k * 45.0)
                val x1 = 12f + 6.2f * Math.cos(a).toFloat(); val y1 = 12f + 6.2f * Math.sin(a).toFloat()
                val x2 = 12f + 8.6f * Math.cos(a).toFloat(); val y2 = 12f + 8.6f * Math.sin(a).toFloat()
                l(x1, y1, x2, y2)
            }
            circle(12f, 12f, 6.2f, false)
        }
        Ic.PLUS -> { l(12f, 5f, 12f, 19f); l(5f, 12f, 19f, 12f) }
        Ic.CAMERA -> { l(4f, 8f, 7f, 8f, 9f, 5f, 15f, 5f, 17f, 8f, 20f, 8f, 20f, 19f, 4f, 19f, 4f, 8f); circle(12f, 13f, 3.5f, false) }
        Ic.FINGER -> {
            l(8f, 20f, 8f, 13f); l(12f, 21f, 12f, 12f); l(16f, 19f, 16f, 13f)
            drawArc(color, 180f, 180f, false, Offset(8f * u, 9f * u), Size(8f * u, 8f * u), style = st)
            drawArc(color, 180f, 180f, false, Offset(5f * u, 5f * u), Size(14f * u, 14f * u), style = st)
            l(5f, 12f, 5f, 16f); l(19f, 12f, 19f, 15f)
        }
        Ic.LOGOUT -> { l(10f, 4f, 5f, 4f, 5f, 20f, 10f, 20f); l(10f, 12f, 20f, 12f); l(16f, 8f, 20f, 12f, 16f, 16f) }
        Ic.CHECK -> { circle(12f, 12f, 9f, false); l(8f, 12.5f, 11f, 15.5f, 16.5f, 9.5f) }
        Ic.PIN -> { circle(12f, 10f, 2.6f, false); l(12f, 21f, 6.5f, 13.5f); l(12f, 21f, 17.5f, 13.5f); drawArc(color, 150f, 240f, false, Offset(5.5f * u, 3.5f * u), Size(13f * u, 13f * u), style = st) }
        Ic.CLOUD -> { l(7f, 18f, 17f, 18f); drawArc(color, 90f, 180f, false, Offset(3f * u, 10f * u), Size(8f * u, 8f * u), style = st); drawArc(color, 180f, 180f, false, Offset(7f * u, 6f * u), Size(10f * u, 10f * u), style = st); drawArc(color, 270f, 180f, false, Offset(13f * u, 10f * u), Size(8f * u, 8f * u), style = st) }
        Ic.FIRE -> { l(12f, 3f, 16f, 9f, 17f, 14f, 15f, 19f, 12f, 21f, 9f, 19f, 7f, 14f, 9f, 10f, 11f, 12f, 12f, 3f) }
        Ic.SUN -> { circle(12f, 12f, 4f, false); for (k in 0 until 8) { val a = Math.toRadians(k * 45.0); l(12f + 6.5f * Math.cos(a).toFloat(), 12f + 6.5f * Math.sin(a).toFloat(), 12f + 8.8f * Math.cos(a).toFloat(), 12f + 8.8f * Math.sin(a).toFloat()) } }
        Ic.MOON -> { drawArc(color, 60f, 250f, false, Offset(4f * u, 4f * u), Size(16f * u, 16f * u), style = st); drawArc(color, 120f, 120f, false, Offset(9f * u, 2f * u), Size(12f * u, 12f * u), style = st) }
        Ic.DOWNLOAD -> { l(12f, 3f, 12f, 15f); l(7f, 10f, 12f, 15f, 17f, 10f); l(5f, 21f, 19f, 21f) }
        Ic.UP -> { l(6f, 15f, 12f, 9f, 18f, 15f) }
        Ic.DOWN -> { l(6f, 9f, 12f, 15f, 18f, 9f) }
        // bakul belanja
        Ic.SENARAI -> { l(3f, 9f, 21f, 9f); l(5f, 9f, 6.5f, 19f, 17.5f, 19f, 19f, 9f); l(8f, 9f, 11f, 4f); l(16f, 9f, 13f, 4f); l(10f, 12.5f, 10f, 15.5f); l(14f, 12.5f, 14f, 15.5f) }
        // kalkulator: badan, skrin, 3×3 butang
        Ic.CALC -> {
            rrect(5f, 2.5f, 14f, 19f, 2f)
            rrect(7.5f, 5f, 9f, 4f, 0.8f)
            for (r in 0 until 3) for (c in 0 until 3) circle(9f + c * 3f, 12.5f + r * 3f, 0.95f, true)
        }
        Ic.WALLET -> { rrect(3f, 6f, 18f, 14f, 2.2f); l(5f, 6f, 15f, 3.5f, 17f, 6f); rrect(14f, 10.5f, 7f, 5f, 1.5f); circle(16.8f, 13f, 0.9f, true) }
        // ================= Lejar Moden =================
        Ic.HOME -> { l(3f, 11f, 12f, 3.8f, 21f, 11f); l(5.5f, 9.3f, 5.5f, 20f, 18.5f, 20f, 18.5f, 9.3f); l(10f, 20f, 10f, 14.5f, 14f, 14.5f, 14f, 20f) }
        Ic.CARD -> { rrect(3f, 5.5f, 18f, 13f, 2.2f); l(3f, 10f, 21f, 10f); l(6.5f, 15f, 10.5f, 15f) }
        Ic.BELL -> {
            l(6f, 11f, 6f, 16.5f); l(18f, 11f, 18f, 16.5f)
            drawArc(color, 180f, 180f, false, Offset(6f * u, 5f * u), Size(12f * u, 12f * u), style = st)
            l(4.5f, 16.5f, 19.5f, 16.5f); l(12f, 3f, 12f, 5f)
            drawArc(color, 0f, 180f, false, Offset(10f * u, 17.5f * u), Size(4f * u, 3f * u), style = st)
        }
        Ic.MENU -> { l(4f, 7f, 20f, 7f); l(4f, 12f, 20f, 12f); l(4f, 17f, 20f, 17f) }
        Ic.BACK -> { l(19f, 12f, 5f, 12f); l(11f, 6f, 5f, 12f, 11f, 18f) }
        Ic.CHEVRON -> { l(9f, 5f, 16f, 12f, 9f, 19f) }
        Ic.SEARCH -> { circle(10.5f, 10.5f, 6.5f, false); l(15.5f, 15.5f, 20.5f, 20.5f) }
        Ic.EYE, Ic.EYE_OFF -> {
            val e = Path().apply { moveTo(2f * u, 12f * u); quadraticBezierTo(12f * u, 2.5f * u, 22f * u, 12f * u); quadraticBezierTo(12f * u, 21.5f * u, 2f * u, 12f * u); close() }
            drawPath(e, color, style = st)
            circle(12f, 12f, 3f, false)
            if (ic == Ic.EYE_OFF) l(4f, 4f, 20f, 20f)
        }
        Ic.ARROW_DOWN -> { l(12f, 4f, 12f, 19f); l(6f, 13f, 12f, 19f, 18f, 13f) }
        Ic.ARROW_UP -> { l(12f, 20f, 12f, 5f); l(6f, 11f, 12f, 5f, 18f, 11f) }
        Ic.CALENDAR -> {
            rrect(3.5f, 5f, 17f, 15.5f, 2.2f); l(3.5f, 10f, 20.5f, 10f); l(8f, 3f, 8f, 7f); l(16f, 3f, 16f, 7f)
            circle(8f, 14.5f, 0.9f, true); circle(12f, 14.5f, 0.9f, true); circle(16f, 14.5f, 0.9f, true)
        }
        Ic.LAYERS -> { l(12f, 3f, 21f, 8f, 12f, 13f, 3f, 8f, 12f, 3f); l(3f, 12f, 12f, 17f, 21f, 12f); l(3f, 16f, 12f, 21f, 21f, 16f) }
        Ic.MONEYBAG -> {
            l(9.5f, 8f, 8f, 3.8f, 16f, 3.8f, 14.5f, 8f)
            drawOval(color, Offset(4.5f * u, 8f * u), Size(15f * u, 13f * u), style = st)
            l(12f, 11.5f, 12f, 18f); l(14.2f, 12.8f, 10.8f, 12.8f, 10.8f, 14.6f, 13.2f, 14.6f, 13.2f, 16.6f, 9.8f, 16.6f)
        }
        Ic.BRIEFCASE -> { rrect(3f, 7.5f, 18f, 12.5f, 2f); l(9f, 7.5f, 9f, 5f, 15f, 5f, 15f, 7.5f); l(3f, 12.5f, 21f, 12.5f); l(12f, 11.5f, 12f, 13.5f) }
        Ic.FORK -> { l(5f, 3f, 5f, 8.5f, 9f, 8.5f, 9f, 3f); l(7f, 3f, 7f, 21f); l(16.5f, 21f, 16.5f, 3f, 19.5f, 6.5f, 19.5f, 12.5f, 16.5f, 12.5f) }
        Ic.CAR -> {
            rrect(3f, 10.5f, 18f, 6.5f, 2f); l(5.5f, 10.5f, 7.5f, 6f, 16.5f, 6f, 18.5f, 10.5f)
            circle(7.5f, 17.5f, 1.8f, false); circle(16.5f, 17.5f, 1.8f, false)
        }
        Ic.COINS -> {
            for (k in 0 until 3) {
                val y = 4f + k * 5f
                drawOval(color, Offset(5f * u, y * u), Size(14f * u, 4.5f * u), style = st)
            }
            l(5f, 6.25f, 5f, 16.25f); l(19f, 6.25f, 19f, 16.25f)
        }
        Ic.BOLT -> { l(13f, 2.5f, 5f, 13.5f, 11.5f, 13.5f, 10.5f, 21.5f, 19f, 10f, 12.5f, 10f, 13f, 2.5f) }
        Ic.DROP -> { l(7.24f, 11.75f, 12f, 3f, 16.76f, 11.75f); drawArc(color, -30f, 240f, false, Offset(6.5f * u, 9f * u), Size(11f * u, 11f * u), style = st) }
        Ic.WIFI -> {
            listOf(3.2f, 6.6f, 10f).forEach { r -> drawArc(color, -135f, 90f, false, Offset((12f - r) * u, (19f - r) * u), Size(2 * r * u, 2 * r * u), style = st) }
            circle(12f, 19f, 1.1f, true)
        }
        Ic.PHONE -> { rrect(7f, 2.5f, 10f, 19f, 2.2f); l(10.5f, 18.5f, 13.5f, 18.5f) }
        Ic.SHIELD -> {
            val sh = Path().apply {
                moveTo(12f * u, 3f * u); lineTo(19.5f * u, 6f * u); lineTo(19.5f * u, 11.5f * u)
                quadraticBezierTo(19f * u, 18f * u, 12f * u, 21f * u); quadraticBezierTo(5f * u, 18f * u, 4.5f * u, 11.5f * u); lineTo(4.5f * u, 6f * u); close()
            }
            drawPath(sh, color, style = st); l(8.5f, 12f, 11f, 14.5f, 15.5f, 9.5f)
        }
        Ic.CART -> { l(2.5f, 4f, 5f, 4f, 7.5f, 15f, 18f, 15f, 20.5f, 7.5f, 6f, 7.5f); circle(9f, 19f, 1.4f, false); circle(17f, 19f, 1.4f, false) }
        Ic.CLOSE -> { l(6f, 6f, 18f, 18f); l(18f, 6f, 6f, 18f) }
        Ic.BOOK -> {
            val lp = Path().apply { moveTo(12f * u, 6.5f * u); quadraticBezierTo(8f * u, 4.2f * u, 3f * u, 5.2f * u); lineTo(3f * u, 18f * u); quadraticBezierTo(8f * u, 17f * u, 12f * u, 19.5f * u) }
            val rp = Path().apply { moveTo(12f * u, 6.5f * u); quadraticBezierTo(16f * u, 4.2f * u, 21f * u, 5.2f * u); lineTo(21f * u, 18f * u); quadraticBezierTo(16f * u, 17f * u, 12f * u, 19.5f * u) }
            drawPath(lp, color, style = st); drawPath(rp, color, style = st); l(12f, 6.5f, 12f, 19.5f)
        }
        Ic.SWAP -> { l(4f, 8f, 18f, 8f); l(14f, 4f, 18f, 8f, 14f, 12f); l(20f, 16f, 6f, 16f); l(10f, 12f, 6f, 16f, 10f, 20f) }
        Ic.TAG -> { l(3f, 12f, 11f, 4f, 20f, 4f, 20f, 13f, 12f, 21f, 3f, 12f); circle(15.5f, 8.5f, 1.3f, false) }
        Ic.CLIPBOARD -> { rrect(5f, 4.5f, 14f, 16.5f, 2f); rrect(9f, 2.5f, 6f, 4f, 1f); l(8.5f, 11f, 15.5f, 11f); l(8.5f, 15f, 13f, 15f) }
        Ic.HEART -> {
            val h = Path().apply {
                moveTo(12f * u, 20f * u)
                cubicTo(3f * u, 14f * u, 2.5f * u, 7f * u, 7.5f * u, 5.5f * u)
                cubicTo(10f * u, 4.8f * u, 11.5f * u, 6.5f * u, 12f * u, 8f * u)
                cubicTo(12.5f * u, 6.5f * u, 14f * u, 4.8f * u, 16.5f * u, 5.5f * u)
                cubicTo(21.5f * u, 7f * u, 21f * u, 14f * u, 12f * u, 20f * u)
                close()
            }
            drawPath(h, color, style = st)
        }
        Ic.DOTS -> { circle(12f, 5.5f, 1.5f, true); circle(12f, 12f, 1.5f, true); circle(12f, 18.5f, 1.5f, true) }
        Ic.RECEIPT -> { l(6f, 3f, 18f, 3f, 18f, 21f, 15f, 19f, 12f, 21f, 9f, 19f, 6f, 21f, 6f, 3f); l(9f, 8f, 15f, 8f); l(9f, 12f, 15f, 12f) }
        Ic.TREND -> { l(3f, 17f, 9f, 11f, 13f, 15f, 21f, 7f); l(15f, 7f, 21f, 7f, 21f, 13f) }
        Ic.GEM -> { l(6f, 4f, 18f, 4f, 21f, 9f, 12f, 20f, 3f, 9f, 6f, 4f); l(3f, 9f, 21f, 9f); l(9.5f, 4f, 8f, 9f, 12f, 20f, 16f, 9f, 14.5f, 4f) }
        Ic.LIST -> { l(9f, 6.5f, 20f, 6.5f); l(9f, 12f, 20f, 12f); l(9f, 17.5f, 20f, 17.5f); circle(5f, 6.5f, 1f, true); circle(5f, 12f, 1f, true); circle(5f, 17.5f, 1f, true) }
        else -> Unit // ikon pek dilukis daripada path SVG (PEK)
    }
}
