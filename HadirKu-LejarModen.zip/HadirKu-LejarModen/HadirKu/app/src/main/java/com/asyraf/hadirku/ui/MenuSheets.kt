package com.asyraf.hadirku.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.asyraf.hadirku.MainViewModel
import com.asyraf.hadirku.Sheet
import com.asyraf.hadirku.pg.PG

/* ================= Menu (ikon ☰ di Utama) ================= */

private class MenuItem(val ic: Ic, val label: String, val tint: (Pal) -> Color, val act: (MainViewModel) -> Unit)

private val MENU = listOf(
    MenuItem(Ic.HOME, "Utama & poket", { it.accent }) { it.close(); it.go("poket") },
    MenuItem(Ic.LIST, "Lejar harian", { it.accent }) { it.close(); it.go("transaksi") },
    MenuItem(Ic.KERJA, "Kerja lebih masa (OT)", { it.accent }) { it.close(); it.kerjaSeg = "ot"; it.go("kerja") },
    MenuItem(Ic.SENARAI, "Senarai barang", { it.amber }) { it.close(); it.go("senarai") },
    MenuItem(Ic.CALENDAR, "Komitmen & bil", { it.amber }) { it.close(); it.setBayarSeg("komitmen"); it.go("bayaran") },
    MenuItem(Ic.MONEYBAG, "Hutang & EPP", { it.amber }) { it.close(); it.setBayarSeg("hutang"); it.go("bayaran") },
    MenuItem(Ic.CLIPBOARD, "Projek", { it.p[1] }) { it.close(); it.setBayarSeg("projek"); it.go("bayaran") },
    MenuItem(Ic.LAPORAN, "Laporan bulanan", { it.accent }) { it.close(); it.setLapViewMode("ringkasan"); it.go("laporan") },
    MenuItem(Ic.TREND, "Ramalan gaji", { it.accent }) { it.close(); it.setLapViewMode("ramalan"); it.go("laporan") },
    MenuItem(Ic.GEM, "Kekayaan bersih", { it.p[3] }) { it.close(); it.setLapViewMode("kekayaan"); it.go("laporan") },
    MenuItem(Ic.WALLET, "Semak baki bank", { it.accent }) { it.open(Sheet.Bank) },
    MenuItem(Ic.DOWNLOAD, "Simpan salinan", { it.accent }) { it.open(Sheet.BackupMenu) },
    MenuItem(Ic.GEAR, "Tetapan & kongsi isteri", { it.muted }) { it.close(); it.go("tetapan") },
)

@Composable
fun MenuSheet(vm: MainViewModel) {
    val pal = LocalPal.current
    SheetBody(actions = { SheetActions("", {}, { vm.close() }, cancel = "Tutup") }) {
        Row(Modifier.padding(horizontal = GL).padding(bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Logo(40.dp)
            Spacer(Modifier.width(12.dp))
            Column {
                Txt("Duitku", size = 20f, weight = FontWeight.Bold, color = pal.accent)
                Txt("Lejar • Komitmen • Bayaran • Laporan", size = 12.5f, color = pal.muted)
            }
        }
        Column(Modifier.fillMaxWidth().padding(horizontal = GL), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            MENU.chunked(3).forEach { row ->
                Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { m ->
                        Column(
                            Modifier.weight(1f).fillMaxHeight().pressable({ m.act(vm) }, scaleTo = 0.96f).lejarCard(pal)
                                .heightIn(min = 92.dp).padding(horizontal = 8.dp, vertical = 12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            IconTile(m.ic, m.tint(pal), size = 42.dp)
                            Txt(m.label, size = 12.5f, weight = FontWeight.SemiBold, align = TextAlign.Center, maxLines = 2, lh = 16f)
                        }
                    }
                    repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

/* ================= Peringatan (ikon loceng di Utama) ================= */

@Composable
fun NotisSheet(vm: MainViewModel) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val today = vm.today()
    val list = remember(s, today) { PG.commitmentStatus(s, today) }
    // komitmen belum selesai yang ada tarikh tempo, paling hampir dulu
    val dekat = list.filter { it.status != "sudah" && PG.tempoDate(it.c, today) != null }
        .sortedBy { PG.tempoDate(it.c, today) }
    val tanpaTempo = list.count { it.status != "sudah" && PG.tempoDate(it.c, today) == null }
    val backup = vm.backupDue()
    SheetBody(actions = { SheetActions("Buka Bayaran", { vm.close(); vm.setBayarSeg("komitmen"); vm.go("bayaran") }, { vm.close() }, cancel = "Tutup") }) {
        SheetTitle("Peringatan", rich("Bil & komitmen belum dibayar bulan ini, paling hampir tempo di atas. Notifikasi dihantar **3 hari** dan **1 hari** sebelum tempo."))
        if (dekat.isEmpty() && backup == null) {
            Empty(rich(if (list.isEmpty()) "Belum ada komitmen. Tambah bil di **Bayaran → Komitmen** untuk dapat peringatan." else "✔ Tiada bil tertunggak buat masa ini."))
        }
        if (dekat.isNotEmpty()) ListBlock {
            dekat.forEach { c ->
                val (lbl, tone) = keadaanK(c, today)
                val due = PG.tempoDate(c.c, today)
                val ic = billIc(c.nama)
                Row(
                    Modifier.fillMaxWidth().hairlines(pal.line).pressable({ vm.open(Sheet.KMenu(c.id)) }, scaleTo = 0.985f)
                        .heightIn(min = 60.dp).padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconTile(ic, billTint(ic, pal), size = 38.dp, icon = 20.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Txt(c.nama, size = 15f, weight = FontWeight.SemiBold, maxLines = 1)
                        if (due != null) Txt("Tarikh akhir: " + PG.fmtShort(due) + " " + PG.parse(due).y, size = 12.5f, color = pal.muted, maxLines = 1)
                    }
                    Spacer(Modifier.width(8.dp))
                    Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Txt(M(c.baki), size = 14.5f, weight = FontWeight.SemiBold, num = true, maxLines = 1)
                        Pill(lbl, tone)
                    }
                }
            }
        }
        if (tanpaTempo > 0) Note(tanpaTempo.toString() + " komitmen belum dibayar tiada tarikh tempo, jadi tiada peringatan untuknya.", Modifier.padding(top = 8.dp))
        if (backup != null) {
            Spacer(Modifier.height(10.dp))
            Notice(
                rich(if (backup.second) "**Belum pernah simpan salinan.** Data hanya ada dalam telefon ini." else "Salinan terakhir **" + backup.first + " hari lalu**."),
                Tone.WARN, "Simpan",
            ) { vm.open(Sheet.BackupMenu) }
        }
        Spacer(Modifier.height(8.dp))
    }
}
