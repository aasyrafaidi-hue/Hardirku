package com.asyraf.hadirku.ui

import com.asyraf.hadirku.BuildConfig
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.asyraf.hadirku.MainViewModel
import com.asyraf.hadirku.Sheet
import com.asyraf.hadirku.pg.PG

/* ================= Menu (ikon ☰ di Utama) ================= */

/** [kerja] = ciri kerja/OT: tiada dalam app isteri. */
private class MenuItem(val ic: Ic, val label: String, val tint: (Pal) -> Color, val csv: Boolean = false, val kerja: Boolean = false, val act: (MainViewModel) -> Unit)

/** Menu dalam bentuk senarai berkumpulan — satu baris satu fungsi, mudah diimbas. */
private val MENU: List<Pair<String, List<MenuItem>>> = listOf(
    "Harian" to listOf(
        MenuItem(Ic.HOME, "Utama & poket", { it.accent }) { it.close(); it.go("poket") },
        MenuItem(Ic.P_LEDGER, "Lejar harian", { it.accent }) { it.close(); it.go("transaksi") },
        MenuItem(Ic.P_GROCERY, "Barang dapur", { it.accent }) { it.close(); it.go("senarai") },
        MenuItem(Ic.SEARCH, "Tanya Duitku", { it.accent }) { it.open(Sheet.Tanya) },
    ),
    "Kewangan" to listOf(
        MenuItem(Ic.SHIELD, "Pusat kewangan", { it.accent }) { it.close(); it.setKewSegMode("belanja"); it.go("kewangan") },
        MenuItem(Ic.P_BUDGET, "Bajet bulanan", { it.accent }) { it.close(); it.setKewSegMode("bajet"); it.go("kewangan") },
        MenuItem(Ic.P_GOAL, "Matlamat simpanan", { it.accent }) { it.close(); it.setKewSegMode("matlamat"); it.go("kewangan") },
        MenuItem(Ic.P_SAVINGS, "Kekayaan bersih", { it.accent }) { it.close(); it.setLapViewMode("kekayaan"); it.go("laporan") },
    ),
    "Bayaran & hutang" to listOf(
        MenuItem(Ic.CALENDAR, "Komitmen & bil", { it.accent }) { it.close(); it.setBayarSeg("komitmen"); it.go("bayaran") },
        MenuItem(Ic.CARD, "Hutang & EPP", { it.accent }) { it.close(); it.setBayarSeg("hutang"); it.go("bayaran") },
    ),
    "Kerja & laporan" to listOf(
        MenuItem(Ic.KERJA, "Kerja lebih masa (OT)", { it.accent }, kerja = true) { it.close(); it.kerjaSeg = "ot"; it.go("kerja") },
        MenuItem(Ic.LAPORAN, "Laporan bulanan", { it.accent }) { it.close(); it.setLapViewMode("ringkasan"); it.go("laporan") },
        MenuItem(Ic.TREND, "Ramalan gaji", { it.accent }, kerja = true) { it.close(); it.setLapViewMode("ramalan"); it.go("laporan") },
    ),
    "Semakan & tetapan" to listOf(
        MenuItem(Ic.P_STATEMENT, "Semak penyata bank", { it.accent }, csv = true) { },
        MenuItem(Ic.P_BANK, "Semak baki bank", { it.accent }) { it.open(Sheet.Bank) },
        MenuItem(Ic.CLOUD, "Simpan salinan", { it.accent }) { it.open(Sheet.BackupMenu) },
        MenuItem(Ic.GEAR, if (BuildConfig.ISTERI) "Tetapan & kongsi suami" else "Tetapan & kongsi isteri", { it.accent }) { it.close(); it.go("tetapan") },
    ),
)

@Composable
fun MenuSheet(vm: MainViewModel) {
    val pal = LocalPal.current
    val la = launch()
    SheetBody(actions = { SheetActions("", {}, { vm.close() }, cancel = "Tutup") }) {
        Row(Modifier.padding(horizontal = GL).padding(bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Logo(40.dp)
            Spacer(Modifier.width(12.dp))
            Column {
                Txt(if (BuildConfig.ISTERI) "Duitku Isteri" else "Duitku", size = 20f, weight = FontWeight.Bold, color = pal.accent)
                Txt("Urus Duit · Capai Impian", size = 12.5f, color = pal.muted)
            }
        }
        MENU.map { (k, l) -> k to l.filter { !(BuildConfig.ISTERI && it.kerja) } }.filter { it.second.isNotEmpty() }.forEach { (kumpulan0, items) ->
            val kumpulan = if (BuildConfig.ISTERI && kumpulan0 == "Kerja & laporan") "Laporan" else kumpulan0
            Txt(kumpulan, Modifier.padding(start = GL + 6.dp, top = 14.dp, bottom = 6.dp), size = 13f, weight = FontWeight.SemiBold, color = pal.muted)
            ListBlock {
                items.forEachIndexed { i, m ->
                    Row(
                        Modifier.fillMaxWidth().hairlines(pal.line, bottom = i < items.lastIndex)
                            .pressable({ if (m.csv) { vm.close(); la.pickText { u -> vm.csvPick(u) } } else m.act(vm) }, scaleTo = 0.985f)
                            .heightIn(min = 56.dp).padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        IconTile(m.ic, m.tint(pal), size = 38.dp, icon = 20.dp)
                        Spacer(Modifier.width(12.dp))
                        Txt(m.label, Modifier.weight(1f), size = 15.5f, weight = FontWeight.Medium, maxLines = 1)
                        Spacer(Modifier.width(8.dp))
                        Ico(Ic.CHEVRON, pal.muted, 16.dp, stroke = 2f)
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
    }
}

/* ================= Peringatan (ikon loceng di Utama) ================= */

@Composable
fun NotisSheet(vm: MainViewModel) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val today = vm.today()
    val list = remember(s, today) { PG.commitmentStatus(s, today) }
    // komitmen belum selesai yang ada tarikh tempo, paling hampir dulu
    val dekat = list.filter { it.status != "sudah" && PG.tempoDate(it.c, today) != null }
        .sortedBy { PG.tempoDate(it.c, today) }
    val tanpaTempo = list.count { it.status != "sudah" && PG.tempoDate(it.c, today) == null }
    val backup = vm.backupDue()
    SheetBody(actions = { SheetActions("Buka Bayaran", { vm.close(); vm.setBayarSeg("komitmen"); vm.go("bayaran") }, { vm.close() }, cancel = "Tutup") }) {
        SheetTitle("Peringatan", rich("Bil & komitmen belum dibayar bulan ini, paling hampir tempo di atas. Notifikasi dihantar **3 hari** dan **1 hari** sebelum tempo."))
        if (dekat.isEmpty() && backup == null) {
            Empty(rich(if (list.isEmpty()) "Belum ada komitmen. Tambah bil di **Bayaran → Komitmen** untuk dapat peringatan." else "✔ Tiada bil tertunggak buat masa ini."))
        }
        if (dekat.isNotEmpty()) ListBlock {
            dekat.forEach { c ->
                val (lbl, tone) = keadaanK(c, today)
                val due = PG.tempoDate(c.c, today)
                val ic = billIc(c.nama)
                Row(
                    Modifier.fillMaxWidth().hairlines(pal.line).pressable({ vm.open(Sheet.KMenu(c.id)) }, scaleTo = 0.985f)
                        .heightIn(min = 60.dp).padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconTile(ic, billTint(ic, pal), size = 38.dp, icon = 20.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Txt(c.nama, size = 15f, weight = FontWeight.SemiBold, maxLines = 1)
                        if (due != null) Txt("Tarikh akhir: " + PG.fmtShort(due) + " " + PG.parse(due).y, size = 12.5f, color = pal.muted, maxLines = 1)
                    }
                    Spacer(Modifier.width(8.dp))
                    Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Txt(M(c.baki), size = 14.5f, weight = FontWeight.SemiBold, num = true, maxLines = 1)
                        Pill(lbl, tone)
                    }
                }
            }
        }
        if (tanpaTempo > 0) Note(tanpaTempo.toString() + " komitmen belum dibayar tiada tarikh tempo, jadi tiada peringatan untuknya.", Modifier.padding(top = 8.dp))
        if (backup != null) {
            Spacer(Modifier.height(10.dp))
            Notice(
                rich(if (backup.second) "**Belum pernah simpan salinan.** Data hanya ada dalam telefon ini." else "Salinan terakhir **" + backup.first + " hari lalu**."),
                Tone.WARN, "Simpan",
            ) { vm.open(Sheet.BackupMenu) }
        }
        Spacer(Modifier.height(8.dp))
    }
}
