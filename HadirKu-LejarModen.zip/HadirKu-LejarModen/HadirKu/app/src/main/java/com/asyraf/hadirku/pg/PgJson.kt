package com.asyraf.hadirku.pg

import org.json.JSONArray
import org.json.JSONObject

/** Baca & tulis data PoketGaji dalam format JSON v2 yang sama dengan PoketGaji PWA (normalizeState). */
object PgJson {

    class BukanPoketGaji : Exception("Fail ini bukan data PoketGaji.")

    private fun raw(o: JSONObject, k: String): Any? = if (!o.has(k) || o.isNull(k)) null else o.opt(k)

    /** Number(x) dalam JS: '' → 0, teks bukan nombor → NaN, tiada → [def]. */
    private fun dbl(o: JSONObject, k: String, def: Double): Double = when (val v = raw(o, k)) {
        null -> def
        is Number -> v.toDouble()
        is Boolean -> if (v) 1.0 else 0.0
        is String -> if (v.isBlank()) 0.0 else v.trim().toDoubleOrNull() ?: Double.NaN
        else -> Double.NaN
    }
    private fun dblOrNull(o: JSONObject, k: String): Double? = when (val v = raw(o, k)) {
        null -> null
        is Number -> v.toDouble()
        is String -> if (v.isBlank()) null else v.trim().toDoubleOrNull()
        else -> null
    }
    private fun str(o: JSONObject, k: String, def: String = ""): String = when (val v = raw(o, k)) {
        null -> def
        is String -> v
        is Number -> {
            val d = v.toDouble()
            if (d == Math.floor(d) && Math.abs(d) < 1e15) d.toLong().toString() else d.toString()
        }
        else -> v.toString()
    }
    private fun lng(o: JSONObject, k: String): Long = when (val v = raw(o, k)) {
        is Number -> v.toLong()
        is String -> v.toLongOrNull() ?: 0L
        else -> 0L
    }
    private fun bool(o: JSONObject, k: String): Boolean = raw(o, k) == true
    private fun arr(o: JSONObject, k: String): JSONArray? = raw(o, k) as? JSONArray
    private fun obj(o: JSONObject, k: String): JSONObject? = raw(o, k) as? JSONObject
    private inline fun <T> JSONArray.mapObj(f: (JSONObject) -> T?): List<T> {
        val out = ArrayList<T>()
        for (i in 0 until length()) { val o = optJSONObject(i) ?: continue; f(o)?.let { out.add(it) } }
        return out
    }

    private val SETTINGS_KNOWN = setOf("gaji", "komitmenMulaHari", "otMulaHari", "hutangBajet", "hutangStrategi", "otPendapatan", "tunaiFee", "cfo")

    fun isPoketGaji(o: JSONObject): Boolean = arr(o, "pockets") != null && arr(o, "transactions") != null

    fun parseState(o: JSONObject): PgState {
        val pocketsA = arr(o, "pockets")
        val txA = arr(o, "transactions")
        if (pocketsA == null || txA == null) throw BukanPoketGaji()
        val base = PG.defaultState()
        val so = obj(o, "settings") ?: JSONObject()
        val go = obj(so, "gaji") ?: JSONObject()
        val bg = base.settings.gaji
        val gaji = Gaji(
            dbl(go, "basic", bg.basic), dbl(go, "night", bg.night), dbl(go, "transport", bg.transport),
            dbl(go, "jamNormal", bg.jamNormal), dbl(go, "hadOT", bg.hadOT), dbl(go, "potongan", bg.potongan), dbl(go, "advance", bg.advance),
        )
        val tf = obj(so, "tunaiFee")?.let { f -> TunaiFee(if (str(f, "mode") == "rm") "rm" else "pct", dblOrNull(f, "nilai")) }
        val extra = JSONObject()
        val keysIt = so.keys()
        while (keysIt.hasNext()) { val k = keysIt.next(); if (k !in SETTINGS_KNOWN) extra.put(k, so.opt(k)) }
        val settings = PgSettings(
            gaji = gaji,
            komitmenMulaHari = 1,
            otMulaHari = (dbl(so, "otMulaHari", 22.0).takeIf { v -> v.isFinite() && v >= 1 } ?: 22.0).toInt(),
            hutangBajet = dbl(so, "hutangBajet", 0.0),
            hutangStrategi = if (str(so, "hutangStrategi") == "snowball") "snowball" else "avalanche",
            otPendapatan = raw(so, "otPendapatan") != false,
            tunaiFee = tf,
            cfoMatlamat = obj(so, "cfo")?.let { c -> str(c, "matlamat").ifEmpty { null } },
            extraJson = if (extra.length() > 0) extra.toString() else null,
        )
        val pockets = ArrayList(pocketsA.mapObj { p ->
            val id = str(p, "id")
            val tunai = bool(p, "tunai") && id != PG.BELUM_AGIH
            Pocket(id, str(p, "nama"), dbl(p, "sasaran", 0.0), bool(p, "tetap"), (bool(p, "dompet") || tunai) && id != PG.BELUM_AGIH, tunai)
        })
        if (pockets.none { p -> p.id == PG.BELUM_AGIH }) pockets.add(0, base.pockets[0])

        val txs = txA.mapObj { t ->
            val jenis = str(t, "jenis")
            var otBayar: Double? = null
            if (jenis == "masuk") { val ob = dblOrNull(t, "otBayar"); if (ob != null && ob.isFinite() && ob >= 0) otBayar = ob }
            var fee: Double? = null
            var feePct: Double? = null
            if (jenis == "tunai-kad") {
                val fe = dbl(t, "fee", 0.0)
                fee = if (fe.isFinite() && fe >= 0) PG.round2(fe) else 0.0
                val fp = dblOrNull(t, "feePct")
                if (fp != null && fp.isFinite() && fp >= 0) feePct = fp
            }
            val base0 = Tx(
                id = str(t, "id"), tarikh = str(t, "tarikh"), jenis = jenis, poket = str(t, "poket"), ke = str(t, "ke"),
                jumlah = dbl(t, "jumlah", Double.NaN), perkara = str(t, "perkara"), komitmenId = str(t, "komitmenId"),
                hutangId = str(t, "hutangId"), kadId = str(t, "kadId"), catatan = str(t, "catatan"), dibuat = lng(t, "dibuat"),
                otBayar = otBayar, fee = fee, feePct = feePct,
            )
            val kat = raw(t, "kategori") as? String
            if (PG.katValid(kat) && PG.bolehKategori(base0)) base0.copy(kategori = kat, katAuto = raw(t, "katAuto") == true) else base0
        }
        val commitments = (arr(o, "commitments") ?: JSONArray()).mapObj { c ->
            val man = LinkedHashMap<String, Boolean>()
            obj(c, "manual")?.let { m -> val ks = m.keys(); while (ks.hasNext()) { val k = ks.next(); man[k] = m.opt(k) == true } }
            val tempo = dbl(c, "tempo", 0.0).let { if (it.isFinite()) it.toInt() else 0 }.takeIf { it in 1..31 } ?: 0
            Commitment(str(c, "id"), str(c, "nama"), dbl(c, "jumlah", 0.0), str(c, "kitaran", "30"), str(c, "poket"), man, tempo)
        }
        val debts = (arr(o, "debts") ?: JSONArray()).mapObj { d ->
            val logs = (arr(d, "log") ?: JSONArray()).mapObj { l ->
                DebtLog(str(l, "id"), str(l, "tarikh"), str(l, "jenis"), dbl(l, "jumlah", Double.NaN), str(l, "catatan"), lng(l, "dibuat"))
            }
            val epps = (arr(d, "epp") ?: JSONArray()).mapObj { e ->
                if (str(e, "mula").isEmpty()) null else {
                    val tempoh = dbl(e, "tempoh", 1.0).let { v -> if (v.isFinite() && v != 0.0) Math.max(1, PG.jsRound(v).toInt()) else 1 }
                    Epp(str(e, "id"), str(e, "nama", "EPP").ifEmpty { "EPP" }, num0(dbl(e, "pokok", 0.0)), tempoh,
                        num0(dbl(e, "kadar", 0.0)), num0(dbl(e, "ansuran", 0.0)), str(e, "mula"), str(e, "catatan"),
                        faedahJumlah = dblOrNull(e, "faedahJumlah")?.takeIf { it.isFinite() && it >= 0 })
                }
            }
            val minL: Double? = when (val v = raw(d, "minLantai")) {
                null -> if (d.has("minLantai")) null else 50.0
                is String -> if (v.isBlank()) null else v.toDoubleOrNull()
                is Number -> v.toDouble()
                else -> null
            }
            Debt(
                id = str(d, "id"), nama = str(d, "nama"), jenis = str(d, "jenis", "kad").ifEmpty { "kad" },
                kadar = dbl(d, "kadar", 0.0), minPeratus = dbl(d, "minPeratus", 5.0), minLantai = minL,
                ansuran = dbl(d, "ansuran", 0.0), rancangan = dbl(d, "rancangan", 0.0), hadKredit = dbl(d, "hadKredit", 0.0),
                poket = str(d, "poket"), log = logs, epp = epps, kitaran = (raw(d, "kitaran"))?.toString(),
                minAsas = if (str(d, "minAsas") == "biasa") "biasa" else "jumlah",
                faedahRm = dblOrNull(d, "faedahRm")?.takeIf { it.isFinite() && it >= 0 }, faedahBaki = num0(dbl(d, "faedahBaki", 0.0)),
                minRm = dblOrNull(d, "minRm")?.takeIf { it.isFinite() && it >= 0 }, minBaki = num0(dbl(d, "minBaki", 0.0)), minTarikh = str(d, "minTarikh"),
            )
        }
        val checks = (arr(o, "bankChecks") ?: JSONArray()).mapObj { b ->
            BankCheck(str(b, "id"), str(b, "tarikh"), dbl(b, "baki", 0.0), str(b, "catatan"), lng(b, "dibuat"))
        }
        val ot = LinkedHashMap<String, OtEntry>()
        obj(o, "ot")?.let { m ->
            val ks = m.keys()
            while (ks.hasNext()) {
                val k = ks.next()
                val e = m.optJSONObject(k) ?: continue
                ot[k] = OtEntry(str(e, "jenis", "biasa"), dblOrNull(e, "jam"))
            }
        }
        return PgState(2, bool(o, "contoh"), settings, pockets, txs, commitments, debts, checks, ot)
    }
    private fun num0(x: Double): Double = if (x.isNaN()) 0.0 else x

    private fun putNum(o: JSONObject, k: String, v: Double) {
        if (v == Math.floor(v) && Math.abs(v) < 1e15) o.put(k, v.toLong()) else o.put(k, v)
    }

    fun txToJson(t: Tx): JSONObject = JSONObject().apply {
        put("id", t.id); put("tarikh", t.tarikh); put("jenis", t.jenis); put("poket", t.poket); put("ke", t.ke)
        putNum(this, "jumlah", t.jumlah)
        put("perkara", t.perkara); put("komitmenId", t.komitmenId); put("hutangId", t.hutangId); put("kadId", t.kadId)
        put("catatan", t.catatan); put("dibuat", t.dibuat)
        t.otBayar?.let { putNum(this, "otBayar", it) }
        t.fee?.let { putNum(this, "fee", it) }
        t.feePct?.let { putNum(this, "feePct", it) }
        if (t.kategori != null) { put("kategori", t.kategori); if (t.katAuto) put("katAuto", true) }
    }

    fun toJson(s: PgState): JSONObject {
        val o = JSONObject()
        o.put("version", 2)
        o.put("contoh", s.contoh)
        val st = if (s.settings.extraJson != null) JSONObject(s.settings.extraJson) else JSONObject()
        val g = s.settings.gaji
        st.put("gaji", JSONObject().also {
            putNum(it, "basic", g.basic); putNum(it, "night", g.night); putNum(it, "transport", g.transport)
            putNum(it, "jamNormal", g.jamNormal); putNum(it, "hadOT", g.hadOT); putNum(it, "potongan", g.potongan); putNum(it, "advance", g.advance)
        })
        st.put("komitmenMulaHari", s.settings.komitmenMulaHari)
        st.put("otMulaHari", s.settings.otMulaHari)
        putNum(st, "hutangBajet", s.settings.hutangBajet)
        st.put("hutangStrategi", s.settings.hutangStrategi)
        st.put("otPendapatan", s.settings.otPendapatan)
        s.settings.tunaiFee?.let { f ->
            st.put("tunaiFee", JSONObject().also { it.put("mode", f.mode); if (f.nilai != null) putNum(it, "nilai", f.nilai) else it.put("nilai", "") })
        }
        s.settings.cfoMatlamat?.let { m -> st.put("cfo", JSONObject().put("matlamat", m)) }
        o.put("settings", st)
        o.put("pockets", JSONArray().also { a ->
            s.pockets.forEach { p ->
                a.put(JSONObject().also {
                    it.put("id", p.id); it.put("nama", p.nama); putNum(it, "sasaran", p.sasaran)
                    if (p.tetap) it.put("tetap", true)
                    if (p.dompet) it.put("dompet", true)
                    if (p.tunai) it.put("tunai", true)
                })
            }
        })
        o.put("transactions", JSONArray().also { a -> s.transactions.forEach { a.put(txToJson(it)) } })
        o.put("commitments", JSONArray().also { a ->
            s.commitments.forEach { c ->
                a.put(JSONObject().also {
                    it.put("id", c.id); it.put("nama", c.nama); putNum(it, "jumlah", c.jumlah); it.put("kitaran", c.kitaran); it.put("poket", c.poket)
                    if (c.manual.isNotEmpty()) it.put("manual", JSONObject().also { m -> c.manual.forEach { (k, v) -> m.put(k, v) } })
                    if (c.tempo in 1..31) it.put("tempo", c.tempo)
                })
            }
        })
        o.put("debts", JSONArray().also { a ->
            s.debts.forEach { d ->
                a.put(JSONObject().also {
                    it.put("id", d.id); it.put("nama", d.nama); it.put("jenis", d.jenis)
                    putNum(it, "kadar", d.kadar); putNum(it, "minPeratus", d.minPeratus)
                    if (d.minLantai != null) putNum(it, "minLantai", d.minLantai) else it.put("minLantai", "")
                    putNum(it, "ansuran", d.ansuran); putNum(it, "rancangan", d.rancangan); putNum(it, "hadKredit", d.hadKredit)
                    it.put("poket", d.poket)
                    if (d.kitaran != null) it.put("kitaran", d.kitaran)
                    if (d.jenis == "kad") it.put("minAsas", d.minAsas)
                    if (d.faedahRm != null) { putNum(it, "faedahRm", d.faedahRm); putNum(it, "faedahBaki", d.faedahBaki) }
                    if (d.jenis == "kad" && d.minRm != null) { putNum(it, "minRm", d.minRm); putNum(it, "minBaki", d.minBaki); it.put("minTarikh", d.minTarikh) }
                    it.put("log", JSONArray().also { la ->
                        d.log.forEach { l ->
                            la.put(JSONObject().also { lo ->
                                lo.put("id", l.id); lo.put("tarikh", l.tarikh); lo.put("jenis", l.jenis); putNum(lo, "jumlah", l.jumlah)
                                lo.put("catatan", l.catatan); lo.put("dibuat", l.dibuat)
                            })
                        }
                    })
                    it.put("epp", JSONArray().also { ea ->
                        d.epp.forEach { e ->
                            ea.put(JSONObject().also { eo ->
                                eo.put("id", e.id); eo.put("nama", e.nama); putNum(eo, "pokok", e.pokok); eo.put("tempoh", e.tempoh)
                                putNum(eo, "kadar", e.kadar); putNum(eo, "ansuran", e.ansuran); eo.put("mula", e.mula); eo.put("catatan", e.catatan)
                                if (e.faedahJumlah != null) putNum(eo, "faedahJumlah", e.faedahJumlah)
                            })
                        }
                    })
                })
            }
        })
        o.put("bankChecks", JSONArray().also { a ->
            s.bankChecks.forEach { b ->
                a.put(JSONObject().also {
                    it.put("id", b.id); it.put("tarikh", b.tarikh); putNum(it, "baki", b.baki); it.put("catatan", b.catatan); it.put("dibuat", b.dibuat)
                })
            }
        })
        o.put("ot", JSONObject().also { m ->
            s.ot.forEach { (k, e) ->
                m.put(k, JSONObject().also { it.put("jenis", e.jenis); e.jam?.let { j -> putNum(it, "jam", j) } })
            }
        })
        return o
    }
}
