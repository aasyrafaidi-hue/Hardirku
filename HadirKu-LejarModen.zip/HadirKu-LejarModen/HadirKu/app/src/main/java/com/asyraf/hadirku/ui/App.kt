package com.asyraf.hadirku.ui

import androidx.compose.foundation.border
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsTopHeight
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.LocalOverscrollConfiguration
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.layout.layout
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.fragment.app.FragmentActivity
import com.asyraf.hadirku.MainViewModel
import com.asyraf.hadirku.Sheet
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.Tx
import com.asyraf.hadirku.system.Notif
import com.asyraf.hadirku.kongsi.Kongsi
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

/** Tindakan fail & sistem yang perlukan Activity (simpan, kongsi, salin, kamera). */
class Launch(
    val saveFile: (name: String, mime: String, text: String, ok: String, backup: Boolean) -> Unit,
    val share: (name: String, mime: String, text: String, title: String) -> Unit,
    val copy: (text: String, ok: String) -> Unit,
    val pickImport: () -> Unit,
    val pickScan: (onUri: (Uri) -> Unit) -> Unit,
    val takePhoto: (onUri: (Uri) -> Unit) -> Unit,
    /** Pilih fail teks (penyata bank CSV). */
    val pickText: (onUri: (Uri) -> Unit) -> Unit,
    val activity: FragmentActivity,
)

val LocalLaunch = staticCompositionLocalOf<Launch?> { null }

@Composable
fun launch(): Launch = LocalLaunch.current!!

private fun shareFile(ctx: Context, name: String, mime: String, text: String, title: String): Boolean = try {
    val dir = File(ctx.cacheDir, "kongsi").apply { mkdirs() }
    val f = File(dir, name)
    f.writeText(text, Charsets.UTF_8)
    val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
    val i = Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM, uri).putExtra(Intent.EXTRA_SUBJECT, title)
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    ctx.startActivity(Intent.createChooser(i, title).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    true
} catch (e: Exception) {
    false
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HadirApp(vm: MainViewModel, activity: FragmentActivity) {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    val pg by vm.pg.collectAsState()
    val now by vm.now.collectAsState()

    // ---------- fail ----------
    var pendingSave by remember { mutableStateOf<Triple<String, String, Boolean>?>(null) }
    val onSaved: (Uri?) -> Unit = { uri ->
        val p = pendingSave
        if (uri != null && p != null) vm.saveTextTo(uri, p.first, p.second, p.third)
        pendingSave = null
    }
    val saveJson = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json"), onSaved)
    val saveMd = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/markdown"), onSaved)
    val saveCsv = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv"), onSaved)
    val importL = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) vm.importPick(uri) }
    var scanCb by remember { mutableStateOf<((Uri) -> Unit)?>(null) }
    var camUri by remember { mutableStateOf<Uri?>(null) }
    val scanL = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) scanCb?.invoke(uri) }
    val camL = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok -> val u = camUri; if (ok && u != null) scanCb?.invoke(u) }
    var textCb by remember { mutableStateOf<((Uri) -> Unit)?>(null) }
    val textL = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) textCb?.invoke(uri) }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 && !Notif.canPost(activity)) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    val launch = remember {
        Launch(
            saveFile = { name, mime, text, ok, backup ->
                pendingSave = Triple(text, ok, backup)
                try {
                    when {
                        mime.contains("json") -> saveJson.launch(name)
                        mime.contains("csv") -> saveCsv.launch(name)
                        else -> saveMd.launch(name)
                    }
                } catch (e: Exception) { vm.toast("Tak dapat buka pemilih fail") }
            },
            share = { name, mime, text, title -> if (!shareFile(ctx, name, mime, text, title)) vm.toast("Tak dapat kongsi. Cuba simpan fail.") },
            copy = { text, ok ->
                try {
                    ctx.getSystemService(ClipboardManager::class.java)?.setPrimaryClip(ClipData.newPlainText("Duitku", text))
                    vm.toast(ok)
                } catch (e: Exception) { vm.toast("Tak dapat salin") }
            },
            pickImport = { try { importL.launch(arrayOf("application/json", "text/plain", "application/octet-stream", "*/*")) } catch (e: Exception) { vm.toast("Tak dapat buka pemilih fail") } },
            pickScan = { cb -> scanCb = cb; try { scanL.launch(arrayOf("image/*", "application/pdf")) } catch (e: Exception) { vm.toast("Tak dapat buka galeri") } },
            takePhoto = { cb ->
                scanCb = cb
                try {
                    val dir = File(ctx.cacheDir, "imbas").apply { mkdirs() }
                    val f = File(dir, "resit-" + System.currentTimeMillis() + ".jpg")
                    val u = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
                    camUri = u
                    camL.launch(u)
                } catch (e: Exception) { vm.toast("Kamera tak dapat dibuka") }
            },
            pickText = { cb ->
                textCb = cb
                try { textL.launch(arrayOf("text/csv", "text/comma-separated-values", "text/plain", "application/vnd.ms-excel", "*/*")) } catch (e: Exception) { vm.toast("Tak dapat buka pemilih fail") }
            },
            activity = activity,
        )
    }

    // tab bawah terakhir diingat → "kembali" dari OT / Senarai Barang pulang ke tab asal, bukan ke OT
    LaunchedEffect(vm.tab) { if (vm.tab in TAB_IDS) UiState.lastTab = vm.tab }
    val goBack: () -> Unit = {
        vm.close()
        if (vm.tab in TAB_IDS) vm.go("poket")
        else vm.go(UiState.lastTab.takeIf { it != vm.tab } ?: "poket")
    }
    BackHandler(enabled = vm.sheet == null && vm.tab != "poket") { goBack() }
    // carian lejar terbuka → kembali tutup carian dulu
    BackHandler(enabled = vm.sheet == null && vm.tab == "transaksi" && UiState.txCariBuka) { UiState.txCariBuka = false; UiState.txCari = "" }

    // kedudukan skrol diingat bagi setiap tab (balik ke tab = di tempat sama, macam iPhone)
    val scrolls = remember { HashMap<String, ScrollState>() }
    val scrollOf: (String) -> ScrollState = { t -> scrolls.getOrPut(t) { ScrollState(0) } }

    // ikon bar status: putih bila ilustrasi Utama kelihatan, gelap (mod cerah) di tempat lain
    val view = LocalView.current
    val heroPx = with(LocalDensity.current) { 170.dp.toPx() }
    LaunchedEffect(pal.dark) {
        val st = scrollOf("poket")
        snapshotFlow { vm.tab == "poket" && st.value < heroPx }.collect { atasHero ->
            try { WindowCompat.getInsetsController(activity.window, view).isAppearanceLightStatusBars = !(pal.dark || atasHero) } catch (e: Exception) { }
        }
    }
    val scope = rememberCoroutineScope()
    // tekan tab yang sedang dibuka sekali lagi → naik ke atas dengan licin
    val toTop: (String) -> Unit = { t -> scope.launch { scrollOf(t).animateScrollTo(0, tween(520, easing = IosOut)) } }

    // butang Transaksi mengecil jadi bulat bila skrol ke bawah, kembang semula bila skrol ke atas
    var fabOpen by remember { mutableStateOf(true) }
    LaunchedEffect(vm.tab) {
        fabOpen = true
        val st = scrollOf(vm.tab)
        var anchor = st.value
        snapshotFlow { st.value }.collect { v ->
            val d = v - anchor
            when {
                v <= 8 -> { fabOpen = true; anchor = v }
                d > 28 -> { fabOpen = false; anchor = v }
                d < -28 -> { fabOpen = true; anchor = v }
                (fabOpen && d < 0) || (!fabOpen && d > 0) -> anchor = v
            }
        }
    }

    // matikan "stretch" Android; lantunan iOS dibuat sendiri (iosScroll)
    CompositionLocalProvider(LocalLaunch provides launch, LocalSaiz provides vm.saiz, LocalOverscrollConfiguration provides null) {
        Box(Modifier.fillMaxSize().background(pageBrush(pal))) {
            Column(Modifier.fillMaxSize()) {
                TopBar(vm, goBack)
                // laporan app tergantung / tertutup (system/Jaga.kt)
                val lap = vm.laporanJaga
                AnimatedVisibility(visible = lap != null) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = GL, vertical = 4.dp).clip(RoundedCornerShape(14.dp)).background(pal.badSoft).padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Txt(rich("**Duitku tergantung / tertutup tadi.** Salin laporan dan hantar kepada Claude."), Modifier.weight(1f), size = 13f, color = pal.bad)
                        Spacer(Modifier.width(8.dp))
                        Column(horizontalAlignment = Alignment.End) {
                            LinkBtn("Salin laporan", { launch.copy(lap ?: "", "Laporan disalin") }, size = 13f)
                            LinkBtn("Tutup", { vm.buangLaporan() }, size = 13f)
                        }
                    }
                }
                AnimatedVisibility(visible = pg.contoh) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = GL, vertical = 4.dp).clip(RoundedCornerShape(14.dp)).background(pal.accentSoft).padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Txt(rich("Ini **data contoh** untuk tunjuk cara app berfungsi."), Modifier.weight(1f), size = 13.5f, color = pal.accentStrong)
                        Column(horizontalAlignment = Alignment.End) {
                            LinkBtn("Mula data sendiri", {
                                vm.open(Sheet.Confirm("Mula dengan data sendiri?", "Data contoh akan dibuang. Selepas ini masukkan baki bank anda sekarang sebagai titik mula. Rekod kehadiran kekal.", "Mula sekarang", "start-fresh"))
                            }, size = 13f)
                            LinkBtn("Pulihkan salinan", { launch.pickImport() }, size = 13f)
                        }
                    }
                }
                Box(Modifier.weight(1f).fillMaxWidth().imePadding()) {
                    // tukar tab: pudar + zum kecil dengan spring (gaya iOS)
                    AnimatedContent(
                        targetState = vm.tab,
                        // tukar tab: meluncur perlahan ikut arah tab (kanan → dari kanan, kiri → dari kiri)
                        transitionSpec = {
                            val dir = if (tabIndex(targetState) >= tabIndex(initialState)) 1 else -1
                            (slideInHorizontally(spring(dampingRatio = 0.9f, stiffness = 240f)) { w -> dir * w / 5 } +
                                fadeIn(tween(300, easing = IosEase)))
                                .togetherWith(
                                    slideOutHorizontally(tween(300, easing = IosEase)) { w -> -dir * w / 10 } +
                                        fadeOut(tween(180, easing = IosEase)),
                                )
                        },
                        label = "tab",
                    ) { tab ->
                        val sc = scrollOf(tab)
                        Column(
                            Modifier.fillMaxSize().iosScroll(sc).padding(top = if (tab == "poket") 0.dp else 4.dp, bottom = 34.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                            when (tab) {
                                "kerja" -> KerjaScreen(vm)
                                "poket" -> PoketScreen(vm)
                                "transaksi" -> TransaksiScreen(vm)
                                "senarai" -> SenaraiScreen(vm)
                                "bayaran" -> BayaranScreen(vm)
                                "laporan" -> LaporanScreen(vm)
                                "kewangan" -> KewanganScreen(vm)
                                else -> TetapanScreen(vm)
                            }
                        }
                    }
                }
                BottomTabs(vm, toTop)
            }
            // Utama: ilustrasi di bawah bar status; bila skrol, jalur bar status jadi lavender supaya teks tak bertindih
            if (vm.tab == "poket") {
                val st = scrollOf("poket")
                Box(
                    Modifier.fillMaxWidth().windowInsetsTopHeight(WindowInsets.statusBars)
                        .graphicsLayer { alpha = ((st.value - heroPx) / 120f).coerceIn(0f, 1f) }
                        .background(pal.bg),
                )
            }
            ToastHost(vm, Modifier.align(Alignment.BottomCenter))
            SheetHost(vm)
        }
    }
}

/* ================= logo ================= */

/** Logo Duitku: buku lejar terbuka putih di atas petak gradien ungu (Soft Violet). */
@Composable
fun Logo(size: Dp = 28.dp) {
    Canvas(Modifier.size(size)) {
        val k = this.size.width / 512f
        drawRoundRect(
            androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color(0xFFB77AF0), Color(0xFF5D2DB0))),
            cornerRadius = CornerRadius(116 * k, 116 * k),
        )
        val page = Color(0xFFFBF8FF)
        val left = Path().apply {
            moveTo(256 * k, 170 * k); quadraticBezierTo(190 * k, 128 * k, 108 * k, 140 * k)
            lineTo(108 * k, 370 * k); quadraticBezierTo(190 * k, 356 * k, 256 * k, 392 * k); close()
        }
        val right = Path().apply {
            moveTo(256 * k, 170 * k); quadraticBezierTo(322 * k, 128 * k, 404 * k, 140 * k)
            lineTo(404 * k, 370 * k); quadraticBezierTo(322 * k, 356 * k, 256 * k, 392 * k); close()
        }
        drawPath(left, page); drawPath(right, page)
        for (i in 0 until 4) {
            val y = (210 + i * 40) * k
            drawLine(Color(0x557840CE), Offset(140 * k, y), Offset(226 * k, y + 6 * k), strokeWidth = 10 * k, cap = StrokeCap.Round)
            drawLine(Color(0x557840CE), Offset(286 * k, y + 6 * k), Offset(372 * k, y), strokeWidth = 10 * k, cap = StrokeCap.Round)
        }
        drawLine(Color(0xFF5D2DB0), Offset(256 * k, 178 * k), Offset(256 * k, 386 * k), strokeWidth = 8 * k)
    }
}

/* ================= bar atas ================= */

private fun tajukTab(vm: MainViewModel): String = when (vm.tab) {
    "transaksi" -> "Lejar Harian"
    "bayaran" -> "Komitmen & Bayaran"
    "laporan" -> when (vm.lapView) { "ramalan" -> "Ramalan Gaji"; "kekayaan" -> "Kekayaan Bersih"; else -> "Laporan" }
    "kerja" -> "Kerja Lebih Masa"
    "senarai" -> "Barang Dapur"
    "kewangan" -> "Pusat Kewangan"
    "tetapan" -> "Tetapan"
    else -> "Duitku"
}

@Composable
private fun TopBar(vm: MainViewModel, onBack: () -> Unit) {
    val pal = LocalPal.current
    val pg by vm.pg.collectAsState()
    val today = vm.today()
    // Utama: tiada bar atas — ilustrasi hero (PoketScreen) memegang menu, nama app & loceng
    if (vm.tab == "poket") return
    Row(
        Modifier.fillMaxWidth().statusBarsPadding().heightIn(min = 60.dp).padding(start = 6.dp, end = 8.dp, top = 4.dp, bottom = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        run {
            IconBtn(Ic.BACK, "Kembali", onBack)
            Spacer(Modifier.width(4.dp))
            AnimatedContent(
                targetState = tajukTab(vm),
                transitionSpec = {
                    (fadeIn(tween(200, easing = IosEase)) + slideInVertically(tween(220, easing = IosOut)) { it / 3 })
                        .togetherWith(fadeOut(tween(120)) + slideOutVertically(tween(160, easing = IosEase)) { -it / 3 })
                },
                modifier = Modifier.weight(1f),
                label = "tajuk",
            ) { t -> Txt(t, size = 21f, weight = FontWeight.Bold, maxLines = 1, lh = 28f) }
            when (vm.tab) {
                "transaksi" -> {
                    IconBtn(if (UiState.txCariBuka) Ic.CLOSE else Ic.SEARCH, if (UiState.txCariBuka) "Tutup carian" else "Cari transaksi", {
                        if (UiState.txCariBuka) { UiState.txCariBuka = false; UiState.txCari = "" } else UiState.txCariBuka = true
                    })
                    Spacer(Modifier.width(4.dp))
                    IconBtn(Ic.PLUS, "Tambah transaksi", { vm.newTx(Tx(poket = vm.txPocket)) }, tint = pal.accentInk, bg = pal.accent)
                }
                // OT & Senarai Barang: tindakan utama pada butang terapung (FAB)
                else -> Unit
            }
        }
    }
}

/** Ada komitmen belum bayar yang lewat / jatuh tempo dalam 3 hari? (titik merah pada loceng) */
fun adaPeringatan(s: com.asyraf.hadirku.pg.PgState, today: String): Boolean =
    PG.commitmentStatus(s, today).any { c ->
        if (c.status == "sudah") return@any false
        val due = PG.tempoDate(c.c, today) ?: return@any false
        PG.hariAntara(today, due) <= 3
    }

/* ================= tab bawah ================= */

/** Tab bawah (templat Soft Violet): Utama · Lejar · [+] · Bayaran · Lain-lain. "lain" membuka menu semua bahagian. */
private val TABS = listOf(
    Triple("poket", "Utama", Ic.HOME),
    Triple("transaksi", "Lejar", Ic.P_LEDGER),
    Triple("bayaran", "Bayaran", Ic.CARD),
    Triple("lain", "Lain-lain", Ic.MENU),
)

/** Indeks untuk arah animasi: OT & Senarai Barang dianggap "lebih dalam" (masuk dari kanan). */
private fun tabIndex(id: String): Int = TABS.indexOfFirst { it.first == id }.let { if (it < 0) TABS.size else it }

/** FAB hanya di skrin yang ada tindakan utama (Lejar ada butang + di bar atas). */
private fun fabShown(tab: String): Boolean = tab in setOf("poket", "kerja", "senarai", "bayaran")

@Composable
private fun BottomTabs(vm: MainViewModel, onReselect: (String) -> Unit) {
    val pal = LocalPal.current
    val tick = rememberTick()
    val utama = setOf("poket", "transaksi", "bayaran")
    val shape = RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp)
    // label butang + tengah ikut skrin (tindakan sama seperti butang terapung lama)
    val tambah = when (vm.tab) { "kerja" -> "Key in OT"; "senarai" -> "Ambil barang"; "bayaran" -> "Bayar"; else -> "Tambah" }
    Box(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().padding(top = 18.dp)
                .shadow(14.dp, shape, ambientColor = pal.shadow, spotColor = pal.shadow)
                .background(pal.surface, shape)
                .navigationBarsPadding()
                .height(64.dp)
                .padding(horizontal = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TABS.forEachIndexed { i, (id, label, ic) ->
                if (i == 2) Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.BottomCenter) {
                    Txt(tambah, Modifier.padding(bottom = 9.dp), size = 11f, weight = FontWeight.SemiBold, color = pal.accent, maxLines = 1)
                }
                val on = if (id == "lain") vm.tab !in utama else vm.tab == id
                val col by animateColorAsState(if (on) pal.accent else pal.muted, label = "tabWarna")
                val pill by animateColorAsState(if (on) pal.accentSoft else Color.Transparent, label = "tabPil")
                val sc by animateFloatAsState(
                    targetValue = if (on) 1.05f else 1f,
                    animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
                    label = "tab",
                )
                Column(
                    Modifier.weight(1f).fillMaxHeight()
                        .semantics { role = Role.Tab; selected = on }
                        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                            tick()
                            when {
                                id == "lain" -> vm.open(Sheet.Menu)
                                on && vm.sheet == null -> onReselect(id)
                                else -> { vm.close(); vm.go(id) }
                            }
                        },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    Box(
                        Modifier.graphicsLayer { scaleX = sc; scaleY = sc }.background(pill, RoundedCornerShape(50)).padding(horizontal = 14.dp, vertical = 3.dp),
                        contentAlignment = Alignment.Center,
                    ) { Ico(ic, col, 22.dp, stroke = if (on) 2.1f else 1.8f) }
                    Spacer(Modifier.height(3.dp))
                    Txt(label, size = 11f, weight = if (on) FontWeight.Bold else FontWeight.Medium, color = col, maxLines = 1)
                }
            }
        }
        // butang + tengah: bulatan gradien ungu yang terapung separuh di atas bar
        Box(
            Modifier.align(Alignment.TopCenter)
                .size(58.dp)
                .shadow(10.dp, CircleShape, ambientColor = pal.accent, spotColor = pal.accent)
                .background(violetBrush(pal), CircleShape)
                .border(3.dp, pal.surface, CircleShape)
                .pressable({ tick(); fabAction(vm) }, scaleTo = 0.9f)
                .semantics { contentDescription = com.asyraf.hadirku.i18n.tr(tambah); role = Role.Button },
            contentAlignment = Alignment.Center,
        ) { Ico(Ic.PLUS, Color.White, 26.dp, stroke = 2.4f) }
    }
}

/* ================= butang terapung ================= */

@Composable
private fun Fab(vm: MainViewModel, expanded: Boolean, modifier: Modifier) {
    val pal = LocalPal.current
    val tick = rememberTick()
    val endPad by animateDpAsState(if (expanded) 20.dp else 16.dp, spring(dampingRatio = 0.8f, stiffness = 420f), label = "fabPad")
    val label = when {
        vm.tab == "kerja" -> "Key in OT"
        vm.tab == "senarai" -> "Ambil barang"
        vm.tab == "bayaran" -> "Bayar"
        else -> "Transaksi"
    }
    Box(modifier.navigationBarsPadding().padding(end = GL, bottom = 66.dp + 16.dp)) {
        Row(
            Modifier
                .pressable({ tick(); fabAction(vm) }, scaleTo = 0.94f)
                .shadow(8.dp, RoundedCornerShape(28.dp), ambientColor = pal.shadow, spotColor = pal.shadow)
                .height(56.dp)
                .background(androidx.compose.ui.graphics.Brush.linearGradient(listOf(pal.heroA, pal.heroB)), RoundedCornerShape(28.dp))
                .semantics { contentDescription = com.asyraf.hadirku.i18n.tr(label) }
                .padding(start = 18.dp, end = endPad),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Ico(Ic.PLUS, pal.heroInk, 22.dp, stroke = 2.4f)
            AnimatedVisibility(
                visible = expanded,
                enter = expandHorizontally(spring(dampingRatio = 0.82f, stiffness = 420f), expandFrom = Alignment.Start) + fadeIn(tween(200, delayMillis = 60)),
                exit = shrinkHorizontally(tween(220, easing = IosEase), shrinkTowards = Alignment.Start) + fadeOut(tween(120)),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Spacer(Modifier.width(8.dp))
                    AnimatedContent(
                        targetState = label,
                        transitionSpec = { (fadeIn(tween(180)) + scaleIn(initialScale = 0.8f)).togetherWith(fadeOut(tween(120)) + scaleOut(targetScale = 0.8f)) },
                        label = "fablabel",
                    ) { l -> Txt(l, size = 15f, weight = FontWeight.Bold, color = pal.heroInk, maxLines = 1) }
                }
            }
        }
    }
}

private fun fabAction(vm: MainViewModel) {
    val s = vm.pg.value
    val today = vm.today()
    when {
        vm.tab == "kerja" -> vm.open(Sheet.OtDay(today))
        vm.tab == "senarai" -> vm.open(Sheet.BarangForm())
        vm.tab == "bayaran" && vm.bayar == "hutang" -> {
            val nd = PG.debtStatus(s, today).find { it.baki > 0.004 && it.bakiBayar > 0.004 }
            when {
                nd != null && (nd.jenis == "kad" || PG.isSpl(nd.d)) -> vm.payDebt(nd.id)
                nd != null -> vm.newTx(Tx(jenis = "keluar", poket = nd.poket, jumlah = nd.bakiBayar, perkara = "Bayar " + nd.nama, hutangId = nd.id), "Bayar " + nd.nama)
                s.debts.isEmpty() -> vm.open(Sheet.HForm(null))
                else -> vm.toast("Semua bayaran hutang bulan ini sudah dibuat")
            }
        }
        vm.tab == "bayaran" -> {
            // komitmen belum bayar yang paling awal jatuh tempo (tanpa tempo → ikut hari gaji kitarannya)
            val next = PG.commitmentStatus(s, today).filter { it.status != "sudah" }
                .minByOrNull { c ->
                    val p = PG.parse(today)
                    PG.tempoDate(c.c, today) ?: PG.iso(p.y, p.m, if (c.kitaran == "15") 15 else minOf(30, PG.lastDay(p.y, p.m)))
                }
            when {
                next != null -> vm.newTx(Tx(jenis = "keluar", poket = next.poket, jumlah = next.baki, perkara = next.nama, komitmenId = next.id), "Bayar " + next.nama)
                s.commitments.isEmpty() -> vm.open(Sheet.KForm(null))
                else -> vm.toast("Semua komitmen bulan ini sudah dibayar")
            }
        }
        else -> vm.newTx(Tx(poket = vm.txPocket))
    }
}

/* ================= toast ================= */

@Composable
private fun ToastHost(vm: MainViewModel, modifier: Modifier) {
    val pal = LocalPal.current
    var shown by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(vm.toastId) {
        val m = vm.toastMsg
        if (m != null) {
            shown = m
            delay(2400)
            shown = null
        }
    }
    Box(modifier.navigationBarsPadding().padding(bottom = 66.dp + 84.dp, start = GL, end = GL)) {
        AnimatedVisibility(
            visible = shown != null,
            enter = fadeIn(tween(160)) + slideInVertically(tween(220)) { it / 2 },
            exit = fadeOut(tween(200)) + slideOutVertically(tween(200)) { it / 3 },
        ) {
            Box(
                Modifier.widthIn(max = 420.dp).shadow(6.dp, RoundedCornerShape(14.dp), ambientColor = pal.shadow, spotColor = pal.shadow).background(pal.ink, RoundedCornerShape(14.dp))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { shown = null }
                    .padding(horizontal = 16.dp, vertical = 10.dp),
            ) {
                Txt(shown ?: "", size = 14f, weight = FontWeight.SemiBold, color = pal.bg)
            }
        }
    }
}

/* ================= helaian bawah ================= */

@Composable
private fun SheetHost(vm: MainViewModel) {
    val pal = LocalPal.current
    var last by remember { mutableStateOf<Sheet?>(null) }
    val cur = vm.sheet
    if (cur != null) last = cur
    BackHandler(enabled = cur != null) { vm.close() }
    // tarik helaian ke bawah untuk tutup (gaya iPhone); latar gelap pudar ikut tarikan
    var drag by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(cur) { if (cur != null) drag = 0f }
    val dens = LocalDensity.current
    val closeAt = with(dens) { 120.dp.toPx() }
    val dragState = rememberDraggableState { d -> drag = (drag + d).coerceAtLeast(0f) }
    AnimatedVisibility(visible = cur != null, enter = fadeIn(tween(260, easing = IosEase)), exit = fadeOut(tween(200, easing = IosEase))) {
        Box(
            Modifier.fillMaxSize().graphicsLayer { alpha = 1f - (drag / (closeAt * 4f)).coerceIn(0f, 0.6f) }.background(pal.scrim)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { vm.close() },
        )
    }
    AnimatedVisibility(
        visible = cur != null,
        // helaian naik dari bawah dengan spring sedikit melantun, turun dengan lengkung iOS
        enter = slideInVertically(spring(dampingRatio = 0.82f, stiffness = 330f)) { it } + fadeIn(tween(160)),
        exit = slideOutVertically(tween(260, easing = IosEase)) { it } + fadeOut(tween(220, delayMillis = 60)),
    ) {
        // borang transaksi dibuka skrin penuh; helaian lain kekal sebagai helaian bawah
        val full = last is Sheet.TxForm
        Box(Modifier.fillMaxSize().imePadding(), contentAlignment = Alignment.BottomCenter) {
          // key(full): bila helaian bawah (cth menu poket) bertukar ke borang transaksi skrin penuh, bina susun atur BAHARU.
          // Dulu modifier statusBarsPadding() ditambah pada node yang sama dalam BoxWithConstraints → Compose
          // terperangkap mengira WindowInsets (ExcludeInsets.equals berulang) dan app beku ("not responding").
          key(full) {
            Column(
                (if (full) Modifier.fillMaxSize().background(pageBrush(pal)).statusBarsPadding()
                else Modifier.fillMaxWidth().widthIn(max = 560.dp).hadTinggi(0.92f)
                    .graphicsLayer { translationY = drag }
                    .shadow(12.dp, RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp), ambientColor = pal.shadow, spotColor = pal.shadow)
                    .background(pal.paper, RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp)))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
                    .navigationBarsPadding()
                    .then(if (full) Modifier else Modifier.padding(bottom = 10.dp)),
            ) {
                if (!full) Box(
                    Modifier.fillMaxWidth().height(26.dp).draggable(
                        state = dragState,
                        orientation = Orientation.Vertical,
                        onDragStopped = { v ->
                            if (drag > closeAt || v > 1400f) vm.close()
                            else animate(drag, 0f, v, spring(dampingRatio = 0.8f, stiffness = 520f)) { x, _ -> drag = x }
                        },
                    ),
                    contentAlignment = Alignment.Center,
                ) {
                    val gw by animateDpAsState(if (drag > 0f) 48.dp else 40.dp, label = "grab")
                    Box(Modifier.padding(top = 4.dp).width(gw).height(4.dp).background(pal.lineStrong, RoundedCornerShape(4.dp)))
                }
                val s = last
                if (s != null) key(s) { SheetContent(vm, s) }
            }
          }
        }
    }
}

/** Tinggi maksimum = [f] × ruang yang ada (ganti BoxWithConstraints, tanpa subcompose). */
private fun Modifier.hadTinggi(f: Float): Modifier = this.layout { m, c ->
    val mh = if (c.hasBoundedHeight) (c.maxHeight * f).toInt() else c.maxHeight
    val p = m.measure(c.copy(minHeight = minOf(c.minHeight, mh), maxHeight = mh))
    layout(p.width, p.height) { p.placeRelative(0, 0) }
}

/** Isi helaian yang boleh skrol, dengan butang tindakan melekat di bawah. */
@Composable
fun SheetBody(actions: (@Composable () -> Unit)? = null, content: @Composable () -> Unit) {
    Column {
        Column(Modifier.weight(1f, fill = false).iosScroll(rememberScrollState())) { content() }
        if (actions != null) actions()
    }
}

fun periodLabel(per: com.asyraf.hadirku.pg.Period): String =
    if (per.start.substring(8) == "01") PG.fmtMonth(PG.ym(per.start)) else PG.fmtShort(per.start) + " – " + PG.fmtShort(per.end)
