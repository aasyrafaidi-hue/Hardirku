package com.asyraf.hadirku

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Rect
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.asyraf.hadirku.ai.Ai
import com.asyraf.hadirku.data.AppSettings
import com.asyraf.hadirku.data.DayRecord
import com.asyraf.hadirku.data.PendingImport
import com.asyraf.hadirku.data.Repo
import com.asyraf.hadirku.logic.Cfg
import com.asyraf.hadirku.logic.Logic
import com.asyraf.hadirku.net.Api
import com.asyraf.hadirku.pg.BankCheck
import com.asyraf.hadirku.pg.Commitment
import com.asyraf.hadirku.pg.Debt
import com.asyraf.hadirku.pg.DebtLog
import com.asyraf.hadirku.pg.Epp
import com.asyraf.hadirku.pg.Gaji
import com.asyraf.hadirku.pg.OtCycle
import com.asyraf.hadirku.pg.OtEntry
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.PgCfo
import com.asyraf.hadirku.pg.PgSample
import com.asyraf.hadirku.pg.PgState
import com.asyraf.hadirku.pg.Period
import com.asyraf.hadirku.pg.Pocket
import com.asyraf.hadirku.pg.TunaiFee
import com.asyraf.hadirku.pg.Tx
import com.asyraf.hadirku.kongsi.Kongsi
import com.asyraf.hadirku.rumah.Dapur
import com.asyraf.hadirku.rumah.Peringatan
import com.asyraf.hadirku.ui.CsvLapor
import com.asyraf.hadirku.ui.muatEnjin
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.time.LocalDate


data class CoachState(
    val loading: Boolean = false,
    val text: String? = null,
    val error: String? = null,
    val label: String? = null,
)

/** Draf borang tunai dari kad (dikekalkan bila buat poket e-wallet baru). */
data class TunaiDraft(val kadId: String, val jumlah: String, val mode: String, val fee: String, val perkara: String, val tarikh: String, val catatan: String)

/** Helaian bawah (gaya PoketGaji). */
sealed interface Sheet {
    data class TxForm(val base: Tx, val title: String?, val editId: String?) : Sheet
    data class PocketMenu(val id: String) : Sheet
    data class PocketForm(val id: String?) : Sheet
    data object Bank : Sheet
    data class KMenu(val id: String) : Sheet
    data class KForm(val id: String?) : Sheet
    data class HMenu(val id: String) : Sheet
    data class HForm(val id: String?) : Sheet
    data class CardPay(val id: String) : Sheet
    data class EppList(val id: String) : Sheet
    data class EppForm(val debtId: String, val planId: String?) : Sheet
    data class HLog(val id: String, val jenis: String) : Sheet
    data class HHist(val id: String) : Sheet
    data object PlanForm : Sheet
    data class OtDay(val date: String) : Sheet
    data class Tunai(val tx: Tx?, val kadId: String?, val poket: String?, val draft: TunaiDraft?) : Sheet
    data class Day(val date: String) : Sheet
    data class KatList(val k: String) : Sheet
    data class PoketList(val id: String) : Sheet
    data object Cfo : Sheet
    data class TextOut(val title: String, val text: String) : Sheet
    data class Confirm(val title: String, val body: String, val label: String, val act: String) : Sheet
    data object BackupMenu : Sheet
    data class ImportAsk(val p: PendingImport) : Sheet
    data class KiraTunai(val id: String) : Sheet
    // ---- rumah (dikongsi dengan isteri) ----
    /** Ambil barang dapur (id null → terus masuk troli) atau ubah barang sedia ada. */
    data class BarangForm(val id: String? = null, val troli: Boolean? = null) : Sheet
    /** Had belanja dapur & baki MyKasih. */
    data object DapurHad : Sheet
    // ---- kekayaan bersih ----
    data class Aset(val id: String?) : Sheet
    // ---- navigasi Lejar Moden (paparan sahaja) ----
    data object Menu : Sheet
    data object Notis : Sheet
    // ---- enjin kewangan ----
    data class BajetForm(val id: String?, val kat: String? = null) : Sheet
    data class MatlamatForm(val id: String?) : Sheet
    data class MatlamatGerak(val id: String) : Sheet
    data object CsvSemak : Sheet
    data object Tanya : Sheet
}

/** Fail yang sudah disediakan untuk dihantar kepada AI. */
class Prepared(val block: JSONObject, val pdf: Boolean, val thumb: Bitmap?)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Application get() = getApplication()

    val settings: StateFlow<AppSettings> = Repo.settings
    val records: StateFlow<Map<LocalDate, DayRecord>> = Repo.records
    val pg: StateFlow<PgState> = Repo.pg

    private val _now = MutableStateFlow(System.currentTimeMillis())
    val now: StateFlow<Long> = _now.asStateFlow()



    // ---------------- keadaan paparan ----------------
    // Lejar Moden: app dibuka di Utama (dashboard). OT & Senarai Barang kekal boleh dicapai dari Utama / Menu.
    var tab by mutableStateOf("poket")
    var kerjaSeg by mutableStateOf("hadir")
    var bayar by mutableStateOf(Repo.getStr("ui.bayar", "ringkasan").let { if (it == "bil") "komitmen" else it })
    var txView by mutableStateOf(Repo.getStr("ui.txView", "kalendar"))
    var txYm by mutableStateOf(PG.ym(PG.todayISO()))
    var txPocket by mutableStateOf("")
    var cyc by mutableStateOf(PG.otCycleOf(PG.todayISO(), 22))
    var disCyc by mutableStateOf(PG.otCycleOf(PG.todayISO(), 22))
    var lap by mutableStateOf(PG.finPeriod(PG.todayISO(), 1))
    var lapView by mutableStateOf(Repo.getStr("ui.lapView", "ringkasan"))
    var pieBy by mutableStateOf(Repo.getStr("ui.pieBy", "poket"))
    var pieMode by mutableStateOf<String?>(null)
    var saiz by mutableIntStateOf(Repo.getInt("ui.saiz", 14))
    var sheet by mutableStateOf<Sheet?>(null)
    var toastMsg by mutableStateOf<String?>(null)
    var toastId by mutableLongStateOf(0L)
    var katBusy by mutableStateOf(false)
    var katProg by mutableStateOf("")
    var aiStatus by mutableStateOf("")
    var aiError by mutableStateOf("")
    var aiTesting by mutableStateOf(false)
    /** Dinaikkan setiap kali tetapan AI berubah supaya paparan dikira semula. */
    var aiTick by mutableIntStateOf(0)

    // ---------------- enjin kewangan (engine.json; pg.json kekal sumber utama) ----------------
    /** Bajet, matlamat, kunci import dsb. Dibaca semula selepas setiap perubahan (lihat EnjinVm.kt). */
    var engine by mutableStateOf(com.asyraf.hadirku.engine.store.EngineData())
    /** engine.json dari versi app lebih baru — paparan sahaja, tiada tulisan. */
    var engineReadOnly by mutableStateOf(false)
    var kewSeg by mutableStateOf(Repo.getStr("ui.kewSeg", "belanja"))
    fun setKewSegMode(v: String) { kewSeg = v; Repo.putStr("ui.kewSeg", v) }
    var csvLapor by mutableStateOf<CsvLapor?>(null)
    var tanyaLog by mutableStateOf<List<Pair<String, String>>>(emptyList())
    var tanyaBusy by mutableStateOf(false)
    /** Blok "enjin" daripada fail salinan yang sedang menunggu pengesahan pulih. */
    var pendingEnjin: String? = null
    /** Dijalankan selepas transaksi baru disimpan (tanda bil dibayar, hantar nafkah, barang dibeli…). */
    private var afterTx: ((Tx) -> Unit)? = null
    private var lastToday = PG.todayISO()

    fun today(): String = Logic.iso(Logic.today(_now.value))
    fun cfg(): Cfg = Cfg(settings.value, pg.value.settings)
    fun otSd(): Int = pg.value.settings.otMulaHari.takeIf { it in 1..28 } ?: 22

    init {
        resetPeriods()
        viewModelScope.launch {
            while (isActive) {
                tick()
                delay(30_000L)
            }
        }
        Kongsi.mula()
        Peringatan.semakKomitmen(ctx, today())
        muatEnjin()
    }

    fun tick() {
        _now.value = System.currentTimeMillis()
        val t = today()
        if (t != lastToday) { lastToday = t; resetPeriods() }
    }

    fun resetCycle() { cyc = PG.otCycleOf(today(), otSd()) }
    fun resetPeriods() {
        val t = today()
        cyc = PG.otCycleOf(t, otSd())
        disCyc = PG.otCycleOf(t, otSd())
        lap = PG.finPeriod(t, 1)
    }

    // ---------------- umum ----------------

    fun toast(msg: String) { toastMsg = msg; toastId = toastId + 1 }

    /** Bahasa paparan: "ms" (Bahasa Melayu) atau "en" (English UK). */
    var bahasa by mutableStateOf(com.asyraf.hadirku.i18n.Bahasa.kod())
        private set
    fun tukarBahasa(kod: String) {
        if (kod == bahasa) return
        com.asyraf.hadirku.i18n.Bahasa.pilih(kod)
        bahasa = kod
        Peringatan.saluran(ctx)
        toast("Bahasa ditukar")
    }

    /** Laporan app tergantung / tertutup (system/Jaga.kt), untuk disalin kepada Claude. */
    var laporanJaga by mutableStateOf<String?>(null)
        private set
    fun semakJaga() { laporanJaga = com.asyraf.hadirku.system.Jaga.baca(ctx) }
    fun buangLaporan() { com.asyraf.hadirku.system.Jaga.buang(ctx); laporanJaga = null }
    fun open(s: Sheet) { sheet = s }
    fun close() { sheet = null; afterTx = null }

    fun go(t: String) {
        if (t != "transaksi") txPocket = ""
        tab = t
    }
    fun setBayarSeg(v: String) { bayar = v; Repo.putStr("ui.bayar", v) }
    fun setTxViewMode(v: String) { txView = v; Repo.putStr("ui.txView", v) }
    fun setLapViewMode(v: String) { lapView = v; Repo.putStr("ui.lapView", v) }
    fun setPieByMode(v: String) { pieBy = v; Repo.putStr("ui.pieBy", v) }
    fun changeSaiz(v: Int) { saiz = v.coerceIn(10, 20); Repo.putInt("ui.saiz", saiz) }

    private fun commit(f: (PgState) -> PgState) = Repo.updatePg(f)
    private fun pocketIds(s: PgState) = s.pockets.map { it.id }
    fun dompetIds(s: PgState = pg.value) = s.pockets.filter { it.dompet }.map { it.id }
    fun isDompet(id: String, s: PgState = pg.value) = s.pockets.any { it.id == id && it.dompet }
    fun isTunai(id: String, s: PgState = pg.value) = s.pockets.any { it.id == id && it.tunai }
    /** Dompet tunai utama (yang pertama). */
    fun tunaiMain(s: PgState = pg.value): Pocket? = s.pockets.firstOrNull { it.tunai }

    fun parseAmt(v: String): Double {
        val c = v.replace(Regex("[^0-9.,]"), "").replaceFirst(',', '.')
        val n = c.toDoubleOrNull() ?: return Double.NaN
        return if (n.isFinite()) PG.round2(n) else Double.NaN
    }

    // ---------------- transaksi ----------------

    fun newTx(base: Tx = Tx(), title: String? = null, after: ((Tx) -> Unit)? = null) {
        val t = base.copy(tarikh = base.tarikh.ifEmpty { today() }, jumlah = if (base.jumlah == 0.0 && base.id.isEmpty()) Double.NaN else base.jumlah)
        open(Sheet.TxForm(t, title, null))
        afterTx = after
    }

    fun editTx(id: String) {
        val t = pg.value.transactions.find { it.id == id } ?: return
        if (t.jenis == "tunai-kad") open(Sheet.Tunai(t, null, null, null)) else open(Sheet.TxForm(t, null, t.id))
    }

    class TxInput(
        val jenis: String, val tarikh: String, val poket: String, val ke: String, val kadId: String, val jumlah: String,
        val perkara: String, val untuk: String, val catatan: String, val otShown: Boolean, val otRaw: String,
        val katShown: Boolean, val kat: String, val katSrc: String,
        /** Masuk sahaja: duit dipulangkan (bukan pendapatan), kategori wajib. */
        val pulangan: Boolean = false,
    )

    /** Simpan transaksi. Pulang ralat (kosong = berjaya). */
    fun saveTx(editId: String?, f: TxInput): String {
        val s = pg.value
        val kd = if (f.jenis == "kad" && f.kadId.isNotEmpty()) s.debts.find { it.id == f.kadId } else null
        var tx = Tx(
            tarikh = f.tarikh, jenis = f.jenis, poket = f.poket,
            ke = if (f.jenis == "pindah") f.ke else (kd?.poket ?: ""), kadId = if (f.jenis == "kad") f.kadId else "",
            jumlah = parseAmt(f.jumlah), perkara = f.perkara.trim(),
            komitmenId = if (f.jenis == "keluar" && f.untuk.startsWith("k:")) f.untuk.substring(2) else "",
            hutangId = if (f.jenis == "keluar" && f.untuk.startsWith("h:")) f.untuk.substring(2) else "",
            catatan = f.catatan.trim(),
        )
        val pulang = f.jenis == "masuk" && f.pulangan
        val otSet = f.jenis == "masuk" && !pulang && f.otShown && f.otRaw.trim().isNotEmpty()
        if (otSet) tx = tx.copy(otBayar = parseAmt(f.otRaw))
        val kat = if (f.katShown) f.kat else ""
        if (pulang) tx = tx.copy(pulangan = true, kategori = kat.ifEmpty { null }, katAuto = false)
        else if (kat.isNotEmpty()) tx = tx.copy(kategori = kat, katAuto = f.katSrc == "ai" || f.katSrc == "sejarah")
        val errs = PG.validateTx(tx, pocketIds(s), dompetIds(s))
        if (errs.isNotEmpty()) return errs.joinToString(" ")
        val old = if (editId != null) s.transactions.find { it.id == editId } else null
        val saved: Tx = if (old != null) {
            tx.copy(
                id = old.id, dibuat = old.dibuat,
                otBayar = if (f.jenis != "masuk" || pulang || (f.otShown && f.otRaw.trim().isEmpty())) null else (tx.otBayar ?: old.otBayar),
                fee = if (f.jenis == "tunai-kad") old.fee else null,
                feePct = if (f.jenis == "tunai-kad") old.feePct else null,
            )
        } else {
            tx.copy(id = PG.uid("t-"), dibuat = System.currentTimeMillis())
        }
        var list = if (old != null) s.transactions.map { if (it.id == saved.id) saved else it } else s.transactions + saved
        var nSama = 0
        val key = PG.normNama(saved.perkara)
        if (!pulang && kat.isNotEmpty() && f.katSrc == "user" && key.length >= 3) {
            list = list.map { o ->
                if (o.id != saved.id && PG.bolehKategori(o) && o.kategori != kat && (!PG.katValid(o.kategori) || o.katAuto) && PG.normNama(o.perkara) == key) {
                    nSama++; o.copy(kategori = kat, katAuto = true)
                } else o
            }
        }
        var perluAi = false
        if (kat.isEmpty() && PG.bolehKategori(saved)) {
            val hk = PG.kategoriSejarah(s.copy(transactions = list))[key]
                // sejarah dulu, kemudian kamus pedagang Malaysia (enjin kategori), AI paling akhir
                ?: com.asyraf.hadirku.engine.category.BuiltinMerchants.match(saved.perkara.lowercase())?.takeIf { PG.katValid(it) }
            if (hk != null) list = list.map { if (it.id == saved.id) it.copy(kategori = hk, katAuto = true) else it } else perluAi = true
        }
        commit { it.copy(transactions = list) }
        if (old == null) txYm = PG.ym(saved.tarikh)
        val cb = if (old == null) afterTx else null
        close()
        toast(if (pulang) "Disimpan · belanja " + PG.katLabel(kat) + " dikurangkan" else "Transaksi disimpan" + if (nSama > 0) " · kategori sama untuk $nSama lagi" else "")
        if (perluAi) katAiLatar(saved.id)
        try { cb?.invoke(saved) } catch (e: Exception) { toast("Transaksi disimpan, tapi langkah susulan gagal: " + (e.message ?: "ralat").take(60)) }
        return ""
    }

    // ---------------- rumah (dikongsi dengan isteri) ----------------

    /** Tambah / edit barang dapur. Pulang ralat (kosong = berjaya). */
    fun simpanBarang(id: String?, nama0: String, nota: String, unitRaw: String, hargaRaw: String, mykasih: Boolean, troli: Boolean = false): String {
        val nama = nama0.trim()
        if (nama.isEmpty()) return "Masukkan jenis barang."
        val u = Dapur.bacaUnit(unitRaw) ?: return "Unit mesti nombor lebih daripada 0."
        val h = Dapur.bacaHarga(hargaRaw) ?: return "Harga tidak sah. Kosongkan kalau belum tahu."
        if (Kongsi.hid().isEmpty()) return "Belum bersambung ke Firebase. Semak internet, kemudian cuba lagi."
        if (id != null) {
            if (Kongsi.barang.value.none { it.id == id }) return "Barang ini dah dibuang dari senarai."
            val b = Kongsi.barang.value.first { it.id == id }
            Kongsi.kemaskiniBarang(id, nama, nota, u, h, mykasih)
            if (b.dibeli != troli) Kongsi.tickBarang(id, troli)
            toast("Barang disimpan")
        } else {
            Kongsi.tambahBarang(nama, nota, u, h, mykasih, dibeli = troli)
        }
        return ""
    }

    /**
     * Barang yang ditick: rekod satu transaksi untuk barang bayar sendiri (jumlah = unit × harga),
     * kemudian buang semua barang ditick dari senarai kongsi. Barang MyKasih tidak direkod sebagai belanja.
     */
    fun rekodBelanjaBarang() {
        val ticked = Kongsi.barang.value.filter { it.dibeli }
        if (ticked.isEmpty()) { toast("Troli masih kosong"); return }
        val ids = ticked.map { it.id }
        val sendiri = ticked.filter { !it.mykasih }
        val mk = ticked.filter { it.mykasih }
        if (sendiri.isEmpty()) {
            Kongsi.selesaiBeli(ids, today())
            toast("MyKasih selesai: " + mk.size + " barang")
            return
        }
        val dapur = pg.value.pockets.find { it.id != PG.BELUM_AGIH && it.nama.contains("dapur", ignoreCase = true) }?.id ?: ""
        val catatan = if (mk.isEmpty()) "" else ("Tidak termasuk " + mk.size + " barang MyKasih (" + PG.money(PG.round2(mk.sumOf { it.jumlah })) + ")").take(120)
        newTx(Tx(jenis = "keluar", poket = dapur, perkara = Dapur.perkara(sendiri), jumlah = Dapur.jumlahRekod(ticked), catatan = catatan, kategori = "dapur"), "Belanja barang (" + sendiri.size + ")") { t ->
            Kongsi.selesaiBeli(ids, t.tarikh)
            toast(ticked.size.toString() + " barang dibuang dari senarai")
        }
    }

    /** Beli tanpa rekod dalam app ini (cth isteri yang rekod): buang barang yang ditick sahaja. */
    fun buangBarangDitick() {
        val ticked = Kongsi.barang.value.filter { it.dibeli }
        if (ticked.isEmpty()) return
        Kongsi.selesaiBeli(ticked.map { it.id }, today())
        toast(ticked.size.toString() + " barang dibuang dari senarai")
    }

    // ---------------- aset lain (kekayaan bersih) ----------------

    fun simpanAset(id: String?, nama0: String, raw: String): String {
        val nama = nama0.trim().take(30)
        val v = parseAmt(raw)
        if (nama.isEmpty()) return "Masukkan nama aset."
        if (!v.isFinite() || v < 0) return "Masukkan nilai RM0 atau lebih."
        val t = today()
        val list = com.asyraf.hadirku.pg.Kekayaan.asetDari(pg.value).toMutableList()
        val i = if (id != null) list.indexOfFirst { it.id == id } else -1
        if (i >= 0) {
            val a = list[i]
            list[i] = com.asyraf.hadirku.pg.Kekayaan.Aset(a.id, nama, (a.sejarah.filter { it.first != t } + (t to v)).sortedBy { it.first })
        } else {
            list.add(com.asyraf.hadirku.pg.Kekayaan.Aset(PG.uid("a-"), nama, listOf(t to v)))
        }
        commit { com.asyraf.hadirku.pg.Kekayaan.denganAset(it, list) }
        close(); toast(nama + " disimpan")
        return ""
    }

    fun padamAset(id: String) {
        val list = com.asyraf.hadirku.pg.Kekayaan.asetDari(pg.value).filter { it.id != id }
        commit { com.asyraf.hadirku.pg.Kekayaan.denganAset(it, list) }
        close(); toast("Aset dipadam")
    }


    /** Hantar nafkah: rekod keluar dari poket dalam app ini, kemudian isteri nampak dan tekan "Terima". */
    fun hantarNafkah() {
        if (!Kongsi.sedia()) { toast("Belum bersambung dengan app isteri. Lihat Tetapan → Kongsi dengan isteri."); return }
        newTx(Tx(jenis = "keluar", perkara = "Nafkah isteri"), "Hantar nafkah") { t ->
            Kongsi.hantarNafkah(t.jumlah, t.catatan, t.tarikh)
            toast("Nafkah " + PG.money(t.jumlah) + " dihantar ke app isteri")
        }
    }

    /** Dari notifikasi bil. */
    fun bukaDari(buka: String?) {
        if (buka == "bil" || buka == "komitmen") { close(); setBayarSeg("komitmen"); go("bayaran") }
        else if (buka == "hutang") { close(); setBayarSeg("hutang"); go("bayaran") }
        else if (buka != null && buka.startsWith("kewangan")) { close(); setKewSegMode(buka.substringAfter(':', "belanja")); go("kewangan") }
    }

    fun delTx(id: String) {
        commit { s -> s.copy(transactions = s.transactions.filter { it.id != id }) }
        close(); toast("Transaksi dipadam")
    }

    // ---------------- poket ----------------

    /** [simpan] = "bank" / "tunai" / "ewallet": di mana duit poket ini sebenarnya disimpan. */
    fun savePocket(id: String?, nama0: String, sasRaw: String, simpan: String): String {
        val s = pg.value
        val nama = nama0.trim()
        val sas = if (sasRaw.trim().isEmpty()) 0.0 else parseAmt(sasRaw)
        val dw = simpan == "tunai" || simpan == "ewallet"
        val tn = simpan == "tunai"
        val lbl = if (tn) "dompet tunai" else "e-wallet"
        var err = if (nama.isEmpty()) "Masukkan nama poket." else if (!sas.isFinite() || sas < 0) "Sasaran mesti nombor 0 atau lebih." else ""
        if (err.isEmpty() && s.pockets.any { it.nama.equals(nama, ignoreCase = true) && it.id != id }) err = "Nama poket ini sudah ada."
        if (err.isEmpty() && dw && id != null && s.debts.any { it.poket == id }) err = "Poket ini digunakan untuk bayar hutang, jadi tak boleh jadi $lbl."
        if (err.isEmpty() && dw && id != null && s.transactions.any { it.jenis == "kad" && (it.poket == id || it.ke == id) }) err = "Poket ini ada belanja guna kad kredit, jadi tak boleh jadi $lbl."
        if (err.isNotEmpty()) return err
        commit { st ->
            if (id != null) st.copy(pockets = st.pockets.map { p ->
                if (p.id != id) p else p.copy(nama = if (p.tetap) p.nama else nama, sasaran = sas, dompet = if (p.tetap) p.dompet else dw, tunai = if (p.tetap) p.tunai else tn)
            }) else st.copy(pockets = st.pockets + Pocket(PG.uid("p-"), nama, sas, dompet = dw, tunai = tn))
        }
        close(); toast("Poket disimpan")
        return ""
    }

    /** Poket terakhir yang digerakkan dalam mod Susun (untuk tanda sekejap). */
    var lastMoved by mutableStateOf<String?>(null)

    /** Gerak poket naik (dir = -1) atau turun (dir = +1). Belum Agih kekal paling atas. */
    fun movePocket(id: String, dir: Int) {
        commit { s -> PG.movePocket(s, id, dir) }
        lastMoved = id
    }

    /** Buat dompet tunai (kalau pengguna pernah padam). */
    fun createTunai() {
        commit { s -> PG.withTunai(s) }
        tunaiMain()?.let { toast(it.nama + " sedia · duit tunai diasingkan dari bank") }
    }

    /** Kiraan duit dompet terakhir: tarikh dan jumlah dikira. */
    fun tunaiKira(id: String): Pair<String, Double>? {
        val v = Repo.getStr("tunai.kira.$id")
        val i = v.indexOf('|')
        if (i <= 0) return null
        val n = v.substring(i + 1).toDoubleOrNull() ?: return null
        return v.substring(0, i) to n
    }

    /**
     * Simpan kiraan duit dalam dompet. Beza dengan baki app direkod ikut [cara]:
     * "belanja" (belanja tunai tak direkod), "pelarasan", atau "masuk" (duit masuk tak direkod).
     */
    fun saveKiraTunai(id: String, raw: String, cara: String): String {
        val v = parseAmt(raw)
        if (!v.isFinite() || v < 0) return "Masukkan jumlah duit dalam dompet (RM0 atau lebih)."
        val s = pg.value
        val bal = PG.balances(s)[id] ?: 0.0
        val d = PG.round2(v - bal)
        val t = today()
        val now = System.currentTimeMillis()
        if (Math.abs(d) >= 0.005) {
            val tx = when {
                d < 0 && cara == "belanja" -> Tx(id = PG.uid("t-"), tarikh = t, jenis = "keluar", poket = id, jumlah = -d, perkara = "Belanja tunai tak direkod", catatan = "Kiraan dompet", dibuat = now)
                d < 0 -> Tx(id = PG.uid("t-"), tarikh = t, jenis = "pelarasan-", poket = id, jumlah = -d, perkara = "Pelarasan kiraan dompet", catatan = "Kiraan dompet", dibuat = now)
                cara == "masuk" -> Tx(id = PG.uid("t-"), tarikh = t, jenis = "masuk", poket = id, jumlah = d, perkara = "Duit tunai masuk tak direkod", catatan = "Kiraan dompet", dibuat = now)
                else -> Tx(id = PG.uid("t-"), tarikh = t, jenis = "pelarasan+", poket = id, jumlah = d, perkara = "Pelarasan kiraan dompet", catatan = "Kiraan dompet", dibuat = now)
            }
            commit { st -> st.copy(transactions = st.transactions + tx) }
        }
        Repo.putStr("tunai.kira.$id", t + "|" + PG.toFixed(v, 2))
        close()
        toast(if (Math.abs(d) < 0.005) "✔ Duit dompet sama dengan app" else "Dompet dibetulkan: " + (if (d < 0) "−" else "+") + PG.money(Math.abs(d)) + " · baki tunai " + PG.money(v))
        return ""
    }

    fun delPocket(id: String) {
        commit { s -> s.copy(pockets = s.pockets.filter { it.id != id }) }
        close(); toast("Poket dipadam")
    }

    // ---------------- semakan bank ----------------

    fun saveBank(bakiRaw: String, tarikh: String, catatan: String): String {
        val v = parseAmt(bakiRaw)
        if (!v.isFinite() || tarikh.isEmpty()) return "Masukkan baki bank dan tarikh."
        commit { s -> s.copy(bankChecks = s.bankChecks + BankCheck(PG.uid("b-"), tarikh, v, catatan.trim(), System.currentTimeMillis())) }
        val bz = PG.round2(v - PG.total(pg.value, tarikh))
        close(); toast(if (Math.abs(bz) < 0.005) "Sama dengan bank" else "Semakan disimpan: beza " + PG.money(bz))
        return ""
    }

    // ---------------- komitmen ----------------

    fun saveK(id: String?, nama0: String, jumlahRaw: String, kitaran: String, poket: String, tempoRaw: String = ""): String {
        val nama = nama0.trim()
        val j = parseAmt(jumlahRaw)
        val tempo = tempoRaw.trim().toIntOrNull() ?: 0
        val err = when {
            nama.isEmpty() -> "Masukkan nama komitmen."
            !(j > 0) -> "Jumlah mesti lebih daripada RM0."
            poket.isEmpty() -> "Pilih poket."
            tempoRaw.isNotBlank() && tempo !in 1..31 -> "Hari jatuh tempo antara 1 dan 31 (atau kosongkan)."
            else -> ""
        }
        if (err.isNotEmpty()) return err
        commit { s ->
            if (id != null) s.copy(commitments = s.commitments.map { if (it.id == id) it.copy(nama = nama, jumlah = j, kitaran = kitaran, poket = poket, tempo = tempo) else it })
            else s.copy(commitments = s.commitments + Commitment(PG.uid("k-"), nama, j, kitaran, poket, tempo = tempo))
        }
        close(); toast("Komitmen disimpan")
        return ""
    }

    fun markK(id: String, on: Boolean) {
        val key = PG.commitmentPeriod(today(), 1).key
        commit { s -> s.copy(commitments = s.commitments.map { c ->
            if (c.id != id) c else c.copy(manual = LinkedHashMap(c.manual).also { if (on) it[key] = true else it.remove(key) })
        }) }
        close(); toast(if (on) "Ditanda sudah dibayar" else "Tanda dibatalkan")
    }

    fun delK(id: String) {
        commit { s -> s.copy(commitments = s.commitments.filter { it.id != id }, transactions = s.transactions.map { if (it.komitmenId == id) it.copy(komitmenId = "") else it }) }
        close(); toast("Komitmen dipadam")
    }

    fun payCommitment(id: String) {
        // ikut paparan: bila tempoh ini selesai, bayaran dikira untuk tempoh seterusnya (bayar awal)
        val c = PG.commitmentStatus(pg.value, PG.commitmentViewDate(pg.value, today())).find { it.id == id } ?: return
        newTx(Tx(jenis = "keluar", poket = c.poket, jumlah = c.baki, perkara = c.nama, komitmenId = c.id), "Bayar " + c.nama)
    }

    // ---------------- hutang ----------------

    class HInput(
        val nama: String, val jenis: String, val baki: String, val kadar: String, val minp: String, val minl: String,
        val had: String, val ans: String, val ranc: String, val poket: String, val minAsas: String = "jumlah",
        /** "%" = kadar diisi peratus; "rm" = faedah sebulan diisi nilai RM ikut penyata */
        val kadarCara: String = "%", val faedahRm: String = "",
        /** "%" = minimum diisi peratus; "rm" = bayaran minimum diisi nilai RM ikut penyata (kad sahaja) */
        val minCara: String = "%", val minRm: String = "",
        /** baki penyata untuk tukar RM → peratus (edit sahaja; hutang baru guna baki permulaan) */
        val rujuk: String = "", val rujukUbah: Boolean = false,
        /** kad: hari tarikh penyata & tarikh akhir bayar (kosong = ikut bulan kalendar) */
        val penyataHari: String = "", val bayarHari: String = "",
    )

    /** Hari dalam bulan 1–31; kosong = 0 (tidak diisi); null = tidak sah. */
    private fun hariBulan(raw: String): Int? {
        val t = raw.trim().removeSuffix("hb").trim()
        if (t.isEmpty()) return 0
        val n = t.toIntOrNull() ?: return null
        return if (n in 1..31) n else null
    }

    fun saveH(id: String?, f: HInput): String {
        fun numOr(raw: String, def: Double) = if (raw.trim().isEmpty()) def else parseAmt(raw)
        fun sama(a: Double?, b: Double) = a != null && Math.abs(a - b) < 0.005
        val nama = f.nama.trim()
        val kad = f.jenis == "kad"
        val td = today()
        val old = if (id != null) pg.value.debts.find { it.id == id } else null
        val rmF = f.kadarCara == "rm"
        val rmM = kad && f.minCara == "rm"
        val minAsas = if (f.minAsas == "biasa") "biasa" else "jumlah"
        val kadar0 = numOr(f.kadar, 0.0); val minp0 = numOr(f.minp, 5.0); val minl = numOr(f.minl, 50.0)
        val had = numOr(f.had, 0.0); val ans = numOr(f.ans, 0.0); val ranc = numOr(f.ranc, 0.0)
        val baki = if (id != null) 0.0 else numOr(f.baki, Double.NaN)
        val rujuk = if (id == null) baki else numOr(f.rujuk, Double.NaN)
        val fRm = if (rmF) numOr(f.faedahRm, Double.NaN) else 0.0
        val mRm = if (rmM) numOr(f.minRm, Double.NaN) else 0.0
        val penyataHari = if (kad) hariBulan(f.penyataHari) else 0
        val bayarHari = if (kad) hariBulan(f.bayarHari) else 0
        var err = when {
            nama.isEmpty() -> "Masukkan nama hutang."
            penyataHari == null || bayarHari == null -> "Tarikh penyata dan tarikh akhir bayar mesti hari 1 hingga 31, atau kosongkan."
            bayarHari != 0 && penyataHari == 0 -> "Isi tarikh penyata juga supaya tarikh akhir bayar boleh dikira."
            penyataHari != 0 && penyataHari == bayarHari -> "Tarikh akhir bayar tak boleh sama dengan tarikh penyata."
            id == null && !(baki > 0) -> "Masukkan baki hutang sekarang, lebih daripada RM0."
            (rmF || rmM) && !(rujuk > 0) -> "Masukkan baki penyata lebih daripada RM0 supaya nilai RM boleh ditukar kepada peratus."
            rmF && !(fRm >= 0) -> "Masukkan faedah sebulan, RM0 atau lebih."
            !rmF && !(kadar0 >= 0 && kadar0 <= 100) -> "Kadar faedah mesti antara 0 dan 100."
            rmM && !(mRm > 0) -> "Masukkan bayaran minimum lebih daripada RM0."
            kad && !rmM && (!(minp0 > 0 && minp0 <= 100) || !(minl >= 0) || !(had >= 0)) -> "Semak minimum: peratus antara 0 dan 100, RM dan had kredit 0 atau lebih."
            kad && !(had >= 0) -> "Had kredit mesti 0 atau lebih."
            !kad && !(ans >= 0) -> "Ansuran mesti 0 atau lebih."
            !(ranc >= 0) -> "Rancangan bayaran mesti 0 atau lebih."
            f.poket.isEmpty() -> "Pilih poket untuk bayar hutang ini."
            else -> ""
        }
        if (err.isNotEmpty()) return err
        // faedah: nilai RM → kadar setahun. Kalau nilai & baki tak berubah, kekalkan kadar lama (tiada hanyut).
        val ulangF = old?.faedahRm != null && sama(old.faedahRm, fRm) && !f.rujukUbah
        val kadar = if (!rmF) kadar0 else if (ulangF) old!!.kadar else PG.kadarDariRm(fRm, rujuk)
        val faedahBaki = if (!rmF) 0.0 else if (ulangF) old!!.faedahBaki else rujuk
        if (rmF && !(kadar <= 100)) err = "Faedah sebulan " + PG.money(fRm) + " terlalu besar untuk baki " + PG.money(rujuk) + ". Kadar jadi lebih 100% setahun. Semak semula."
        if (err.isNotEmpty()) return err
        // minimum: nilai RM → peratus anggaran untuk bulan lain; bulan ini guna nilai RM tepat.
        val ulangM = old?.minRm != null && sama(old.minRm, mRm) && !f.rujukUbah && old.minAsas == minAsas
        val eppPokok = if (old != null && kad) PG.eppUnbilledPokok(old, td) else 0.0
        val eppDue = if (old != null && kad) PG.eppDueIn(old, PG.debtPeriod(pg.value, old.copy(penyataHari = penyataHari ?: 0), td)) else 0.0
        val minp = if (!rmM) minp0 else if (ulangM) old!!.minPeratus else PG.minPeratusDariRm(mRm, rujuk, eppPokok, eppDue, minAsas)
        val minBaki = if (!rmM) 0.0 else if (ulangM) old!!.minBaki else rujuk
        val minTarikh = if (!rmM) "" else if (ulangM) old!!.minTarikh else td
        // mod RM: minimum terendah & cara kiraan kekal nilai lama (untuk anggaran bulan lain)
        val minlV = if (rmM) (old?.minLantai ?: 50.0) else minl
        commit { s ->
            if (id != null) s.copy(debts = s.debts.map {
                if (it.id != id) it else it.copy(
                    nama = nama, jenis = f.jenis, kadar = kadar, minPeratus = if (kad) minp else 5.0, minLantai = if (kad) minlV else 50.0,
                    hadKredit = if (kad) had else 0.0, ansuran = if (kad) 0.0 else ans, rancangan = ranc, poket = f.poket,
                    minAsas = minAsas,
                    faedahRm = if (rmF) fRm else null, faedahBaki = faedahBaki,
                    minRm = if (rmM) mRm else null, minBaki = minBaki, minTarikh = minTarikh,
                    penyataHari = penyataHari ?: 0, bayarHari = bayarHari ?: 0,
                )
            }) else s.copy(debts = s.debts + Debt(
                PG.uid("h-"), nama, f.jenis, kadar, if (kad) minp else 5.0, if (kad) minlV else 50.0, if (kad) 0.0 else ans, ranc,
                if (kad) had else 0.0, f.poket,
                log = listOf(DebtLog(PG.uid("l-"), td, "penyata", baki, "Baki permulaan", System.currentTimeMillis())),
                minAsas = minAsas,
                faedahRm = if (rmF) fRm else null, faedahBaki = faedahBaki,
                minRm = if (rmM) mRm else null, minBaki = minBaki, minTarikh = minTarikh,
                penyataHari = penyataHari ?: 0, bayarHari = bayarHari ?: 0,
            ))
        }
        tab = "bayaran"; setBayarSeg("hutang")
        close(); toast("Hutang disimpan")
        return ""
    }

    fun delH(id: String) {
        commit { s -> s.copy(debts = s.debts.filter { it.id != id }, transactions = s.transactions.map { if (it.hutangId == id) it.copy(hutangId = "") else it }) }
        close(); toast("Hutang dipadam")
    }

    fun payDebt(id: String) {
        val d = PG.debtStatus(pg.value, today()).find { it.id == id } ?: return
        if (d.jenis == "kad") { open(Sheet.CardPay(d.id)); return }
        newTx(Tx(jenis = "keluar", poket = d.poket, jumlah = if (d.bakiBayar > 0.004) d.bakiBayar else Double.NaN, perkara = "Bayar " + d.nama, hutangId = d.id), "Bayar " + d.nama)
    }

    fun payCard(debtId: String, amt: Double, poket: String, tarikh: String): String {
        val o = PG.cardPayOptions(pg.value, debtId, today()) ?: return "Kad tidak dijumpai."
        val tx = Tx(tarikh = tarikh, jenis = "keluar", poket = poket, jumlah = amt, perkara = "Bayar " + o.nama, hutangId = o.id)
        val errs = if (!(amt > 0)) listOf("Pilih atau isi jumlah bayaran.") else PG.validateTx(tx, pocketIds(pg.value))
        if (errs.isNotEmpty()) return errs.joinToString(" ")
        commit { s -> s.copy(transactions = s.transactions + tx.copy(id = PG.uid("t-"), dibuat = System.currentTimeMillis())) }
        close()
        val nb = PG.debtStatus(pg.value, today()).find { it.id == o.id }
        toast("Bayaran disimpan · baki kad " + PG.money(Math.max(0.0, nb?.baki ?: 0.0)))
        return ""
    }

    /** [ke] = "ansuran ke berapa sekarang" (masuk pelan separuh jalan); [e].mula sudah dikira daripadanya. */
    fun saveEpp(debtId: String, planId: String?, e0: Epp, ke: Int? = null): String {
        val err = PG.eppValidate(e0, ke)
        if (err.isNotEmpty()) return err
        val e = PG.eppSediaSimpan(e0, today())
        commit { s -> s.copy(debts = s.debts.map { d ->
            if (d.id != debtId) d
            else if (planId != null) d.copy(epp = d.epp.map { if (it.id == planId) e.copy(id = planId) else it })
            else d.copy(epp = d.epp + e.copy(id = PG.uid("e-")))
        }) }
        open(Sheet.HMenu(debtId)); toast("Pelan ansuran disimpan")
        return ""
    }

    fun delEpp(debtId: String, planId: String) {
        commit { s -> s.copy(debts = s.debts.map { d -> if (d.id != debtId) d else d.copy(epp = d.epp.filter { it.id != planId }) }) }
        open(Sheet.HMenu(debtId)); toast("Pelan ansuran dipadam")
    }

    fun saveHLog(id: String, jenis: String, raw: String, dt: String, catatan: String, minRaw: String = "", faedahRaw: String = ""): String {
        val v = parseAmt(raw)
        if (dt.isEmpty() || !v.isFinite() || v < 0 || (jenis != "penyata" && !(v > 0)))
            return if (jenis == "penyata") "Masukkan baki (RM0 atau lebih) dan tarikh." else "Masukkan jumlah lebih daripada RM0 dan tarikh."
        // penyata: minimum & faedah (RM) dari penyata yang sama → peratus dikira sendiri
        val mRm = if (jenis != "penyata" || minRaw.isBlank()) null else parseAmt(minRaw)
        val fRm = if (jenis != "penyata" || faedahRaw.isBlank()) null else parseAmt(faedahRaw)
        if (mRm != null && !(mRm.isFinite() && mRm > 0)) return "Bayaran minimum mesti lebih daripada RM0. Kosongkan kalau tak berubah."
        if (fRm != null && !(fRm.isFinite() && fRm >= 0)) return "Faedah mesti RM0 atau lebih. Kosongkan kalau tak berubah."
        val ada = v > 0.004
        val kadarBaru = if (fRm != null && ada) PG.kadarDariRm(fRm, v) else null
        if (kadarBaru != null && kadarBaru > 100) return "Faedah sebulan " + PG.money(fRm) + " terlalu besar untuk baki " + PG.money(v) + ". Kadar jadi lebih 100% setahun. Semak semula."
        commit { s -> s.copy(debts = s.debts.map { d ->
            if (d.id != id) d else {
                var x = d.copy(log = d.log + DebtLog(PG.uid("l-"), dt, jenis, v, catatan.trim(), System.currentTimeMillis()))
                if (kadarBaru != null && fRm != null) x = x.copy(faedahRm = fRm, faedahBaki = v, kadar = kadarBaru)
                if (mRm != null && ada && d.jenis == "kad") x = x.copy(
                    minRm = mRm, minBaki = v, minTarikh = dt,
                    minPeratus = PG.minPeratusDariRm(mRm, v, PG.eppUnbilledPokok(d, dt), PG.eppDueIn(d, PG.debtPeriod(s, d, dt)), d.minAsas),
                )
                x
            }
        }) }
        close()
        val d = pg.value.debts.find { it.id == id }
        toast(if (jenis == "penyata" && d != null) "Baki dikemas kini: " + PG.money(PG.debtBalance(pg.value, d, null, today())) else "Rekod disimpan")
        return ""
    }

    fun delHLog(debtId: String, logId: String) {
        commit { s -> s.copy(debts = s.debts.map { d -> if (d.id != debtId) d else d.copy(log = d.log.filter { it.id != logId }) }) }
        toast("Rekod dipadam")
    }

    fun budgetNow(): Double {
        val b = pg.value.settings.hutangBajet
        return if (b > 0) b else PG.debtSummary(PG.debtStatus(pg.value, today())).sasaran
    }

    fun savePlan(raw: String, strat: String): String {
        val b = parseAmt(raw)
        if (!(b >= 0)) return "Masukkan bajet RM0 atau lebih."
        commit { s -> s.copy(settings = s.settings.copy(hutangBajet = b, hutangStrategi = if (strat == "snowball") "snowball" else "avalanche")) }
        close(); toast("Pelan disimpan")
        return ""
    }

    fun planMin() {
        val p = PG.debtPlan(pg.value, 0.0, pg.value.settings.hutangStrategi, today())
        val b = Math.ceil(p.minimum)
        commit { s -> s.copy(settings = s.settings.copy(hutangBajet = b)) }
        toast("Bajet ditetapkan " + PG.money(b))
    }

    // ---------------- OT harian ----------------

    fun defaultHari(d: String): String {
        val s = settings.value
        val date = Logic.date(d)
        val r = records.value[date]
        if (r != null && r.status != com.asyraf.hadirku.data.RecordStatus.HADIR) return "tidak"
        return Logic.jenisHari(Logic.dayKind(date, s))
    }

    fun saveOtDay(date: String, jenis: String, raw: String, tutup: Boolean = true): String {
        val v = parseAmt(raw)
        if (jenis != "tidak" && (!v.isFinite() || v < 0 || v > 24)) return "Masukkan jam antara 0 dan 24."
        commit { s -> s.copy(ot = LinkedHashMap(s.ot).also { it[date] = if (jenis == "tidak") OtEntry("tidak") else OtEntry(jenis, v) }) }
        if (tutup) close()
        toast("Log OT " + PG.fmtShort(date) + " disimpan")
        return ""
    }

    fun clearOtDay(date: String) {
        commit { s -> s.copy(ot = LinkedHashMap(s.ot).also { it.remove(date) }) }
        close(); toast("Hari dikosongkan")
    }

    fun recordGaji(start: String) {
        val p = PG.parse(start)
        val c = PG.otCycle(p.y, p.m, otSd())
        val s2 = PG.otSummary(pg.value, c)
        val bp = PG.parse(c.bayarYm + "-01")
        val pay = PG.iso(bp.y, bp.m, Math.min(30, PG.lastDay(bp.y, bp.m)))
        newTx(Tx(jenis = "masuk", poket = PG.BELUM_AGIH, perkara = "Gaji " + PG.fmtMonth(c.bayarYm), jumlah = if (s2.gaji30 > 0) s2.gaji30 else Double.NaN,
            tarikh = if (pay < today()) pay else today()), "Gaji masuk")
    }

    // ---------------- tunai dari kad ----------------

    fun saveTunai(editId: String?, tx0: Tx, mode: String, nilai: Double?, feeOk: Boolean): String {
        val s = pg.value
        if (!feeOk) return "Fee mesti nombor 0 atau lebih."
        val errs = PG.validateTx(tx0, pocketIds(s), dompetIds(s))
        if (errs.isNotEmpty()) return errs.joinToString(" ")
        commit { st ->
            val st2 = st.copy(settings = st.settings.copy(tunaiFee = TunaiFee(mode, nilai)))
            if (editId != null) st2.copy(transactions = st2.transactions.map { if (it.id == editId) tx0.copy(id = it.id, dibuat = it.dibuat) else it })
            else st2.copy(transactions = st2.transactions + tx0.copy(id = PG.uid("t-"), dibuat = System.currentTimeMillis()))
        }
        if (editId == null) txYm = PG.ym(tx0.tarikh)
        close()
        val d = s.debts.find { it.id == tx0.kadId }
        toast("Tunai direkod · hutang " + (d?.nama ?: "kad") + " +" + PG.money(PG.round2(tx0.jumlah + (tx0.fee ?: 0.0))))
        return ""
    }

    /** Buat poket e-wallet Touch 'n Go (dari borang tunai). */
    fun ensureDompet(): Pocket {
        val ada = pg.value.pockets.find { it.dompet && !it.tunai }
        if (ada != null) return ada
        var nm = "Touch 'n Go"
        var n = 2
        while (pg.value.pockets.any { it.nama.equals(nm, ignoreCase = true) }) nm = "Touch 'n Go " + (n++)
        val p = Pocket(PG.uid("p-"), nm, 0.0, dompet = true)
        commit { s -> s.copy(pockets = s.pockets + p) }
        toast("Poket " + p.nama + " dibuat (e-wallet)")
        return p
    }

    // ---------------- tetapan gaji ----------------

    fun saveGaji(vals: List<String>, otdRaw: String): String {
        val nums = vals.map { if (it.trim().isEmpty()) 0.0 else parseAmt(it) }
        val otd = otdRaw.trim().toIntOrNull() ?: -1
        if (nums.any { !it.isFinite() || it < 0 } || !(nums[5] > 0) || otd !in 1..28)
            return "Semak semula nilai. Semua mesti nombor 0 atau lebih, jam normal lebih daripada 0, dan hari mula antara 1 hingga 28."
        commit { s -> s.copy(settings = s.settings.copy(gaji = Gaji(nums[0], nums[1], nums[2], nums[5], nums[6], nums[3], nums[4]), otMulaHari = otd, komitmenMulaHari = 1)) }
        resetPeriods(); toast("Tetapan disimpan")
        return ""
    }

    fun toggleOtp() {
        commit { s -> s.copy(settings = s.settings.copy(otPendapatan = !s.settings.otPendapatan)) }
        toast(if (pg.value.settings.otPendapatan) "OT dikira pendapatan ikut kitaran OT" else "Ikut duit masuk & keluar bank sahaja")
    }

    // ---------------- data ----------------

    fun confirmed(act: String) {
        when (act) {
            "sample" -> { Repo.replacePg(PgSample.sampleState(today()), fillOt = false); resetPeriods(); close(); tab = "poket" }
            "reset" -> { Repo.replacePg(PG.defaultState()); resetPeriods(); close(); tab = "poket"; toast("Semua data kewangan dipadam") }
            "start-fresh" -> {
                Repo.replacePg(Repo.freshPg()); resetPeriods(); tab = "poket"
                newTx(Tx(jenis = "baki-awal", poket = PG.BELUM_AGIH, perkara = "Baki permulaan bank"), "Baki bank sekarang")
            }
            else -> close()
        }
    }

    fun lastBackupMs(): Long = Repo.getLong("lastBackup")
    fun markBackup() = Repo.putLong("lastBackup", System.currentTimeMillis())
    fun backupDue(): Pair<Int, Boolean>? {
        val s = pg.value
        if (s.contoh || s.transactions.size < 3) return null
        val sn = Repo.getLong("backupSnooze")
        if (sn > 0 && (System.currentTimeMillis() - sn) / 86_400_000L < 7) return null
        val last = lastBackupMs()
        val ref = if (last > 0) last else s.transactions.minOf { if (it.dibuat > 0) it.dibuat else System.currentTimeMillis() }
        val d = ((System.currentTimeMillis() - ref) / 86_400_000L).toInt()
        return if (d >= 14) Pair(((System.currentTimeMillis() - last) / 86_400_000L).toInt(), last == 0L) else null
    }
    fun snoozeBackup() { Repo.putLong("backupSnooze", System.currentTimeMillis()); toast("Diingatkan semula minggu depan") }

    fun backupJson(): String {
        val base = Repo.backupJson()
        val blk = try { com.asyraf.hadirku.engine.android.EngineHub.exportBlock(ctx) } catch (e: Exception) { null } ?: return base
        return try { JSONObject(base).put("enjin", JSONObject(blk)).toString(2) } catch (e: Exception) { base }
    }
    fun backupName(): String = "duitku-salinan-" + today() + ".json"

    private suspend fun writeUri(uri: Uri, text: String): Boolean = withContext(Dispatchers.IO) {
        try {
            ctx.contentResolver.openOutputStream(uri, "wt")?.use { it.write(text.toByteArray(Charsets.UTF_8)) } != null
        } catch (e: Exception) {
            false
        }
    }

    fun saveTextTo(uri: Uri, text: String, ok: String, backup: Boolean = false) {
        viewModelScope.launch {
            if (writeUri(uri, text)) { if (backup) markBackup(); close(); toast(ok) } else toast("Gagal simpan fail")
        }
    }

    private fun fileName(uri: Uri): String {
        return try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            } ?: "fail"
        } catch (e: Exception) { "fail" }
    }

    fun importPick(uri: Uri) {
        viewModelScope.launch {
            val text = withContext(Dispatchers.IO) {
                try { ctx.contentResolver.openInputStream(uri)?.use { String(it.readBytes(), Charsets.UTF_8) } } catch (e: Exception) { null }
            }
            if (text == null) { toast("Tak dapat baca fail"); return@launch }
            val p = Repo.parseBackup(text, fileName(uri))
            if (p == null) { toast("Fail ini bukan salinan Duitku, PoketGaji atau HadirKu"); return@launch }
            pendingEnjin = try { JSONObject(text.trim().removePrefix("\uFEFF")).optJSONObject("enjin")?.toString() } catch (e: Exception) { null }
            open(Sheet.ImportAsk(p))
        }
    }

    fun applyImport(p: PendingImport) {
        Repo.applyImport(p)
        val blk = pendingEnjin
        pendingEnjin = null
        if (blk != null && !com.asyraf.hadirku.engine.android.EngineHub.importBlock(ctx, blk)) toast("Bajet & matlamat dalam salinan tidak dapat dipulihkan")
        muatEnjin()
        resetPeriods()
        close(); tick()
        toast("Data dipulihkan")
    }

    fun cfoText(mat: String, soal: String, withTx: Boolean): String {
        val m = mat.trim()
        if (m.isNotEmpty() && m != (pg.value.settings.cfoMatlamat ?: "")) commit { s -> s.copy(settings = s.settings.copy(cfoMatlamat = m)) }
        return PgCfo.cfoMarkdown(pg.value, today(), PgCfo.Opts(versi = BuildConfig.VERSION_NAME, matlamat = m, soalan = soal.trim(), transaksi = withTx))
    }

    // ---------------- AI ----------------

    fun aiSave(k: String, m: String) {
        if (k.isNotEmpty() && !k.startsWith("sk-ant-")) { aiError = "Kunci Anthropic biasanya bermula dengan sk-ant-. Semak semula."; return }
        aiError = ""
        if (k.isNotEmpty()) Ai.setKey(k)
        Ai.setModel(m)
        aiStatus = ""
        aiTick++
        toast(if (k.isNotEmpty()) "Kunci disimpan dalam telefon ini" else "Tetapan AI disimpan")
    }

    fun aiTest(k: String, m: String) {
        if (k.isNotEmpty()) { if (!k.startsWith("sk-ant-")) { aiError = "Kunci Anthropic biasanya bermula dengan sk-ant-."; return }; Ai.setKey(k) }
        Ai.setModel(m)
        aiTick++
        if (!Ai.ready()) { aiError = "Masukkan kunci API dulu."; return }
        aiTesting = true; aiError = ""; aiStatus = "Menguji kunci…"
        viewModelScope.launch {
            try { Ai.test(today()); aiStatus = "✔ Kunci berfungsi dengan model " + Ai.model() + "."; toast("Kunci API berfungsi") }
            catch (e: Exception) { aiStatus = ""; aiError = e.message ?: "Ralat AI." }
            finally { aiTesting = false; aiTick++ }
        }
    }

    fun aiDel() { Ai.deleteKey(); aiStatus = ""; aiTick++; toast("Kunci dipadam dari telefon ini") }
    fun aiToggleAuto() { Ai.setAutoKat(!Ai.autoKat()); aiTick++; toast(if (Ai.autoKat()) "Kategori automatik dihidupkan" else "Kategori automatik dimatikan") }
    fun aiSetup() { close(); tab = "tetapan"; txPocket = "" }

    fun katPerlu(s: PgState = pg.value): List<Tx> = s.transactions.filter { PG.bolehKategori(it) && !PG.katValid(it.kategori) }

    private fun applyKat(map: Map<String, String>) {
        if (map.isEmpty()) return
        commit { s -> s.copy(transactions = s.transactions.map { t ->
            val k = map[t.id]
            if (k != null && PG.bolehKategori(t) && !PG.katValid(t.kategori)) t.copy(kategori = k, katAuto = true) else t
        }) }
    }

    /** Selepas simpan belanja tanpa kategori: AI pilih di latar (senyap jika gagal). */
    private fun katAiLatar(id: String) {
        if (!Ai.ready() || !Ai.autoKat()) return
        val t = pg.value.transactions.find { it.id == id } ?: return
        if (!PG.bolehKategori(t) || PG.katValid(t.kategori)) return
        viewModelScope.launch {
            try {
                val r = Ai.kategorikan(pg.value, listOf(t), today())
                applyKat(r.kat)
                val c = pg.value.transactions.find { it.id == id }
                if (r.ai > 0 && c != null && PG.katValid(c.kategori)) toast("Kategori AI: " + PG.katLabel(c.kategori) + (if (c.perkara.isNotEmpty()) " · " + c.perkara else ""))
            } catch (e: Exception) { }
        }
    }

    fun katSemua() {
        if (katBusy) return
        if (!Ai.ready()) { aiSetup(); return }
        val all = katPerlu()
        if (all.isEmpty()) { toast("Semua belanja dah ada kategori"); return }
        close()
        katBusy = true; katProg = "Mengkategorikan…"
        viewModelScope.launch {
            var msg: String
            try {
                val r = Ai.kategorikan(pg.value, all, today()) { a, b -> katProg = "Mengkategorikan…" + if (b > 1) " ($a / $b)" else "" }
                applyKat(r.kat)
                val n = r.sejarah + r.ai
                val baki = katPerlu().size
                msg = if (r.gagal.isNotEmpty()) (if (n > 0) "$n belanja dikategorikan. " else "") + r.gagal else "$n belanja dikategorikan" + if (baki > 0) " · $baki belum" else ""
            } catch (e: Exception) { msg = e.message ?: "Ralat AI." }
            katBusy = false; katProg = ""; aiTick++
            toast(msg)
        }
    }

    /** Sediakan gambar (kecilkan, JPEG) atau PDF untuk AI. */
    suspend fun prepFile(uri: Uri): Prepared = withContext(Dispatchers.IO) {
        val cr = ctx.contentResolver
        val mime = cr.getType(uri) ?: ""
        val bytes = cr.openInputStream(uri)?.use { it.readBytes() } ?: throw Exception("Fail tak dapat dibaca.")
        val isPdf = mime == "application/pdf" || (bytes.size > 4 && bytes[0] == '%'.code.toByte() && bytes[1] == 'P'.code.toByte() && bytes[2] == 'D'.code.toByte() && bytes[3] == 'F'.code.toByte())
        if (isPdf) {
            if (bytes.size > 8 * 1024 * 1024) throw Exception("PDF terlalu besar (maksimum 8 MB).")
            if (Regex("/Encrypt\\b").containsMatchIn(String(bytes, Charsets.ISO_8859_1))) throw Exception("PDF ini berkata laluan, jadi AI tak boleh baca. Buka PDF itu, ambil tangkapan skrin, kemudian imbas gambar.")
            val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
            return@withContext Prepared(JSONObject().put("type", "document").put("source", JSONObject().put("type", "base64").put("media_type", "application/pdf").put("data", b64)), true, null)
        }
        val opt = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opt)
        if (opt.outWidth <= 0 || opt.outHeight <= 0) throw Exception("Fail tak dapat dibuka. Guna gambar (JPG atau PNG) atau PDF.")
        var sample = 1
        while (Math.max(opt.outWidth, opt.outHeight) / (sample * 2) >= 2048) sample *= 2
        val src = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
            ?: throw Exception("Fail tak dapat dibuka. Guna gambar (JPG atau PNG) atau PDF.")
        val k = Math.min(1.0, 2048.0 / Math.max(src.width, src.height))
        val w = Math.max(1, Math.round(src.width * k).toInt())
        val h = Math.max(1, Math.round(src.height * k).toInt())
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cv = Canvas(out)
        cv.drawColor(android.graphics.Color.WHITE)
        cv.drawBitmap(src, null, Rect(0, 0, w, h), null)
        val bos = ByteArrayOutputStream()
        out.compress(Bitmap.CompressFormat.JPEG, 85, bos)
        val b64 = Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
        val thumb = Bitmap.createScaledBitmap(out, Math.max(1, w * 160 / Math.max(w, h)), Math.max(1, h * 160 / Math.max(w, h)), true)
        Prepared(JSONObject().put("type", "image").put("source", JSONObject().put("type", "base64").put("media_type", "image/jpeg").put("data", b64)), false, thumb)
    }

    // ---------------- tetapan jadual (kehadiran / clock in-out telah dibuang) ----------------

    fun saveSettings(msg: String = "Tetapan disimpan", transform: (AppSettings) -> AppSettings) {
        Repo.updateSettings(transform)
        tick()
        if (msg.isNotEmpty()) toast(msg)
    }

    fun importHolidays() {
        val s = settings.value
        if (s.calendarificKey.isBlank()) { toast("Masukkan kunci API Calendarific dulu."); return }
        toast("Mengimport cuti umum…")
        viewModelScope.launch {
            val year = Logic.today(System.currentTimeMillis()).year
            val res = Api.holidays(s.calendarificKey, year, s.stateName)
            res.onSuccess { list ->
                Repo.updateSettings { st -> st.copy(holidays = st.holidays + list.map { it.first }) }
                tick()
                toast("${list.size} cuti umum $year diimport untuk ${s.stateName}")
            }.onFailure { e -> toast("Gagal import: ${e.message ?: "ralat tidak diketahui"}") }
        }
    }
}
