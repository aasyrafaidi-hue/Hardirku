package com.asyraf.hadirku.engine.category

import com.asyraf.hadirku.engine.core.Money
import com.asyraf.hadirku.engine.ledger.EntryType
import com.asyraf.hadirku.engine.ledger.LedgerBook
import com.asyraf.hadirku.pg.PG
import java.util.Locale

/* =====================================================================
 * Engine 3 — Smart Categorisation
 * Deterministic first: user override → user rule → the user's own history → built-in Malaysian
 * merchant keywords → optional AI suggestion → none. Every result records its provenance.
 * The engine only PROPOSES; it never rewrites categories of existing (historical) entries.
 * Category ids are the existing app's ids (makan, dapur, rumah, bil, minyak, kenderaan, kesihatan,
 * keluarga, diri, hiburan, sedekah, lain).
 * ===================================================================== */

enum class Provenance(val confidence: Int) { USER_OVERRIDE(100), USER_RULE(95), HISTORY(90), BUILTIN(70), AI_SUGGESTION(50), NONE(0) }
enum class MatchType { CONTAINS, EXACT, REGEX }

data class CategoryRule(val id: String, val pattern: String, val type: MatchType, val category: String, val priority: Int = 0)

data class CategorySuggestion(val category: String?, val provenance: Provenance, val ruleId: String? = null) {
    val confidence: Int get() = provenance.confidence
}

/** Optional AI hook (e.g. backed by the existing Claude categoriser or a backend). Must not throw. */
fun interface AiCategorySuggester { fun suggest(merchant: String, amount: Money?): String? }

data class Proposal(val entryId: String, val merchant: String, val suggestion: CategorySuggestion)

data class ItemLine(val name: String, val amount: Money)
data class ItemCategorisation(
    val items: List<Pair<ItemLine, CategorySuggestion>>,
    val byCategory: Map<String?, Money>,
    /** category with the largest amount */
    val dominant: String?,
    /** items span several categories with a material share (≥ 20% each) */
    val conflict: Boolean,
)

class CategoryEngine(
    /** normalised merchant → category (persisted user overrides) */
    val overrides: Map<String, String> = emptyMap(),
    val rules: List<CategoryRule> = emptyList(),
    /** normalised merchant → category from the user's own past choices (PG.kategoriSejarah) */
    val history: Map<String, String> = emptyMap(),
    val builtins: List<Pair<String, String>> = BuiltinMerchants.MY,
    private val ai: AiCategorySuggester? = null,
) {
    private val validIds = PG.KATEGORI.map { it.id }.toSet()
    private val compiled: List<Pair<CategoryRule, Regex?>> = rules.sortedByDescending { it.priority }
        .map { it to if (it.type == MatchType.REGEX) runCatching { Regex(it.pattern, RegexOption.IGNORE_CASE) }.getOrNull() else null }

    fun suggest(merchant: String, amount: Money? = null, allowAi: Boolean = true): CategorySuggestion {
        val norm = PG.normNama(merchant)
        overrides[norm]?.takeIf { it in validIds }?.let { return CategorySuggestion(it, Provenance.USER_OVERRIDE) }
        val low = merchant.lowercase(Locale.ROOT)
        for ((r, rx) in compiled) {
            if (r.category !in validIds) continue
            val hit = when (r.type) {
                MatchType.EXACT -> norm == PG.normNama(r.pattern)
                MatchType.CONTAINS -> r.pattern.isNotBlank() && low.contains(r.pattern.lowercase(Locale.ROOT))
                MatchType.REGEX -> rx?.containsMatchIn(merchant) == true
            }
            if (hit) return CategorySuggestion(r.category, Provenance.USER_RULE, r.id)
        }
        if (norm.length >= 3) history[norm]?.takeIf { it in validIds }?.let { return CategorySuggestion(it, Provenance.HISTORY) }
        BuiltinMerchants.match(low, builtins)?.let { return CategorySuggestion(it, Provenance.BUILTIN) }
        val aiHook = ai
        if (allowAi && aiHook != null) {
            val s = runCatching { aiHook.suggest(merchant, amount) }.getOrNull()
            if (s != null && s in validIds) return CategorySuggestion(s, Provenance.AI_SUGGESTION)
        }
        return CategorySuggestion(null, Provenance.NONE)
    }

    /** New engine with an extra override. Affects future suggestions only — history is untouched. */
    fun withOverride(merchant: String, category: String): CategoryEngine {
        require(category in validIds) { "unknown category" }
        return CategoryEngine(overrides + (PG.normNama(merchant) to category), rules, history, builtins, ai)
    }

    /**
     * Suggestions for UNCATEGORISED spending only. Entries that already have a category are skipped,
     * so historical categories are never silently changed. Nothing is written.
     */
    fun proposeForUncategorised(book: LedgerBook, allowAi: Boolean = false): List<Proposal> =
        book.effective().filter { it.type == EntryType.EXPENSE && it.category == null && it.memo.isNotBlank() }
            .map { Proposal(it.id, it.memo, suggest(it.memo, it.amount, allowAi)) }
            .filter { it.suggestion.category != null }

    /** Item-level categorisation of a receipt and conflict detection against a single transaction category. */
    fun categoriseItems(items: List<ItemLine>, merchant: String? = null): ItemCategorisation {
        val fallback = merchant?.let { suggest(it, allowAi = false) }
        val res = items.map { it to suggest(it.name, it.amount, allowAi = false).let { s -> if (s.category == null && fallback != null) fallback else s } }
        val by = LinkedHashMap<String?, Money>()
        res.forEach { (i, s) -> by[s.category] = (by[s.category] ?: Money.ZERO) + i.amount }
        val total = Money.sum(by.values)
        val material = by.filter { (k, v) -> k != null && total.isPositive && v.sen * 5 >= total.sen }
        val dominant = by.filterKeys { it != null }.maxByOrNull { it.value.sen }?.key
        return ItemCategorisation(res, by, dominant, material.size > 1)
    }
}

/** Built-in Malaysian merchant keywords → existing category ids. Ordered: more specific first. */
object BuiltinMerchants {
    val MY: List<Pair<String, String>> = listOf(
        // food delivery before generic "grab"
        "grabfood" to "makan", "grab food" to "makan", "foodpanda" to "makan", "shopeefood" to "makan",
        "mcdonald" to "makan", "mcd " to "makan", "kfc" to "makan", "pizza hut" to "makan", "domino" to "makan",
        "starbucks" to "makan", "zus coffee" to "makan", "tealive" to "makan", "secret recipe" to "makan",
        "marrybrown" to "makan", "subway" to "makan", "nasi kandar" to "makan", "mamak" to "makan",
        "restoran" to "makan", "restaurant" to "makan", "kopitiam" to "makan", "kedai makan" to "makan",
        "7-eleven" to "makan", "7 eleven" to "makan", "family mart" to "makan", "familymart" to "makan",
        // fuel, toll, transport
        "petronas" to "minyak", "shell" to "minyak", "petron" to "minyak", "caltex" to "minyak", "bhpetrol" to "minyak",
        "setel" to "minyak", "plus toll" to "minyak", "tol " to "minyak", "toll" to "minyak", "parking" to "minyak",
        "grab" to "minyak", "airasia ride" to "minyak", "ktm" to "minyak", "rapid" to "minyak",
        // groceries
        "99 speedmart" to "dapur", "speedmart" to "dapur", "mydin" to "dapur", "lotus" to "dapur", "tesco" to "dapur",
        "giant" to "dapur", "econsave" to "dapur", "nsk" to "dapur", "jaya grocer" to "dapur", "village grocer" to "dapur",
        "aeon big" to "dapur", "pasar" to "dapur", "kedai runcit" to "dapur", "pasaraya" to "dapur",
        // bills & utilities
        "tnb" to "bil", "tenaga nasional" to "bil", "air selangor" to "bil", "syabas" to "bil", "pba" to "bil", "saj " to "bil",
        "indah water" to "bil", "unifi" to "bil", "maxis" to "bil", "celcom" to "bil", "digi" to "bil", "umobile" to "bil",
        "u mobile" to "bil", "yes 4g" to "bil", "astro" to "bil", "time internet" to "bil", "takaful" to "bil",
        // health
        "klinik" to "kesihatan", "clinic" to "kesihatan", "hospital" to "kesihatan", "farmasi" to "kesihatan",
        "pharmacy" to "kesihatan", "guardian" to "kesihatan", "watsons" to "kesihatan", "caring" to "kesihatan",
        "alpro" to "kesihatan", "dental" to "kesihatan", "gigi" to "kesihatan",
        // vehicle
        "jpj" to "kenderaan", "cukai jalan" to "kenderaan", "road tax" to "kenderaan", "bengkel" to "kenderaan",
        "workshop" to "kenderaan", "tayar" to "kenderaan", "tyre" to "kenderaan",
        // personal
        "uniqlo" to "diri", "padini" to "diri", "bata" to "diri", "h&m" to "diri", "zara" to "diri",
        "brands outlet" to "diri", "salon" to "diri", "barber" to "diri", "gunting rambut" to "diri",
        // leisure
        "netflix" to "hiburan", "spotify" to "hiburan", "disney" to "hiburan", "youtube premium" to "hiburan",
        "gsc" to "hiburan", "tgv" to "hiburan", "mbo cinema" to "hiburan", "cinema" to "hiburan", "steam" to "hiburan",
        "agoda" to "hiburan", "booking.com" to "hiburan", "hotel" to "hiburan",
        // giving
        "masjid" to "sedekah", "surau" to "sedekah", "derma" to "sedekah", "zakat" to "sedekah", "sedekah" to "sedekah",
        // family
        "taska" to "keluarga", "tadika" to "keluarga", "yuran sekolah" to "keluarga", "mothercare" to "keluarga", "lampin" to "keluarga",
        // home
        "ikea" to "rumah", "mr diy" to "rumah", "mr. diy" to "rumah", "eco-shop" to "rumah", "senheng" to "rumah",
        "harvey norman" to "rumah", "courts" to "rumah", "sewa rumah" to "rumah",
    )

    /** First keyword contained in [lowerText] (word-start boundary) wins. */
    fun match(lowerText: String, table: List<Pair<String, String>> = MY): String? {
        val t = " " + lowerText.replace(Regex("\\s+"), " ") + " "
        for ((k, cat) in table) {
            val i = t.indexOf(k)
            if (i >= 0) {
                val before = t[i - 1]
                if (!before.isLetterOrDigit()) return cat
            }
        }
        return null
    }
}
