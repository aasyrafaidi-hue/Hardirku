package com.asyraf.hadirku.engine.core

import java.math.BigDecimal

/**
 * Small strict JSON reader/writer for engine data. Pure Kotlin (no org.json, which is an Android stub
 * in local unit tests). Numbers are parsed as BigDecimal so money never passes through Double.
 * Values: null, Boolean, String, BigDecimal, List<Any?>, Map<String, Any?> (insertion ordered).
 */
object MiniJson {
    class ParseError(msg: String, val pos: Int) : IllegalArgumentException("$msg at $pos")

    fun parse(text: String): Any? {
        val p = Parser(text)
        p.ws()
        val v = p.value(0)
        p.ws()
        if (p.i != text.length) throw ParseError("trailing characters", p.i)
        return v
    }

    @Suppress("UNCHECKED_CAST")
    fun parseObject(text: String): Map<String, Any?> =
        parse(text) as? Map<String, Any?> ?: throw ParseError("expected object", 0)

    private class Parser(val s: String) {
        var i = 0
        fun ws() { while (i < s.length && s[i].isWhitespace()) i++ }
        fun value(depth: Int): Any? {
            if (depth > 64) throw ParseError("nesting too deep", i)
            if (i >= s.length) throw ParseError("unexpected end", i)
            return when (val c = s[i]) {
                '{' -> obj(depth)
                '[' -> arr(depth)
                '"' -> str()
                't' -> lit("true", true)
                'f' -> lit("false", false)
                'n' -> lit("null", null)
                else -> if (c == '-' || c.isDigit()) num() else throw ParseError("unexpected '$c'", i)
            }
        }
        fun lit(w: String, v: Any?): Any? {
            if (!s.startsWith(w, i)) throw ParseError("bad literal", i)
            i += w.length; return v
        }
        fun num(): BigDecimal {
            val st = i
            if (s[i] == '-') i++
            while (i < s.length && (s[i].isDigit() || s[i] == '.' || s[i] == 'e' || s[i] == 'E' || s[i] == '+' || s[i] == '-')) i++
            return try { BigDecimal(s.substring(st, i)) } catch (e: NumberFormatException) { throw ParseError("bad number", st) }
        }
        fun str(): String {
            i++ // opening quote
            val sb = StringBuilder()
            while (true) {
                if (i >= s.length) throw ParseError("unterminated string", i)
                val c = s[i++]
                when (c) {
                    '"' -> return sb.toString()
                    '\\' -> {
                        if (i >= s.length) throw ParseError("bad escape", i)
                        when (val e = s[i++]) {
                            '"' -> sb.append('"'); '\\' -> sb.append('\\'); '/' -> sb.append('/')
                            'b' -> sb.append('\b'); 'f' -> sb.append('\u000C'); 'n' -> sb.append('\n')
                            'r' -> sb.append('\r'); 't' -> sb.append('\t')
                            'u' -> {
                                if (i + 4 > s.length) throw ParseError("bad unicode escape", i)
                                sb.append(s.substring(i, i + 4).toInt(16).toChar()); i += 4
                            }
                            else -> throw ParseError("bad escape '$e'", i)
                        }
                    }
                    else -> sb.append(c)
                }
            }
        }
        fun arr(depth: Int): List<Any?> {
            i++; ws()
            val out = ArrayList<Any?>()
            if (i < s.length && s[i] == ']') { i++; return out }
            while (true) {
                ws(); out.add(value(depth + 1)); ws()
                if (i >= s.length) throw ParseError("unterminated array", i)
                when (s[i++]) { ',' -> continue; ']' -> return out; else -> throw ParseError("expected , or ]", i - 1) }
            }
        }
        fun obj(depth: Int): Map<String, Any?> {
            i++; ws()
            val out = LinkedHashMap<String, Any?>()
            if (i < s.length && s[i] == '}') { i++; return out }
            while (true) {
                ws()
                if (i >= s.length || s[i] != '"') throw ParseError("expected key", i)
                val k = str(); ws()
                if (i >= s.length || s[i++] != ':') throw ParseError("expected :", i - 1)
                ws(); out[k] = value(depth + 1); ws()
                if (i >= s.length) throw ParseError("unterminated object", i)
                when (s[i++]) { ',' -> continue; '}' -> return out; else -> throw ParseError("expected , or }", i - 1) }
            }
        }
    }

    /** Serialise Map/List/String/Number/Boolean/null. Money is written as its sen Long. */
    fun write(v: Any?): String = StringBuilder().also { w(it, v) }.toString()

    private fun w(sb: StringBuilder, v: Any?) {
        when (v) {
            null -> sb.append("null")
            is Boolean -> sb.append(v)
            is Money -> sb.append(v.sen)
            is BigDecimal -> sb.append(v.toPlainString())
            is Int, is Long, is Short, is Byte -> sb.append(v)
            is Number -> sb.append(BigDecimal(v.toString()).toPlainString())
            is String -> str(sb, v)
            is Map<*, *> -> {
                sb.append('{')
                var first = true
                v.forEach { (k, x) -> if (!first) sb.append(','); first = false; str(sb, k.toString()); sb.append(':'); w(sb, x) }
                sb.append('}')
            }
            is Iterable<*> -> {
                sb.append('[')
                var first = true
                v.forEach { x -> if (!first) sb.append(','); first = false; w(sb, x) }
                sb.append(']')
            }
            else -> str(sb, v.toString())
        }
    }

    private fun str(sb: StringBuilder, s: String) {
        sb.append('"')
        for (c in s) when {
            c == '"' -> sb.append("\\\"")
            c == '\\' -> sb.append("\\\\")
            c == '\n' -> sb.append("\\n")
            c == '\r' -> sb.append("\\r")
            c == '\t' -> sb.append("\\t")
            c < ' ' -> sb.append(String.format("\\u%04x", c.code))
            else -> sb.append(c)
        }
        sb.append('"')
    }
}

/* Typed accessors for parsed maps — nullable, never throw on wrong type. */
fun Map<String, Any?>.str(k: String): String? = this[k] as? String
fun Map<String, Any?>.dec(k: String): BigDecimal? = this[k] as? BigDecimal
fun Map<String, Any?>.long(k: String): Long? = (this[k] as? BigDecimal)?.let { runCatching { it.longValueExact() }.getOrNull() }
fun Map<String, Any?>.int(k: String): Int? = long(k)?.takeIf { it in Int.MIN_VALUE..Int.MAX_VALUE }?.toInt()
fun Map<String, Any?>.bool(k: String): Boolean? = this[k] as? Boolean
@Suppress("UNCHECKED_CAST")
fun Map<String, Any?>.obj(k: String): Map<String, Any?>? = this[k] as? Map<String, Any?>
@Suppress("UNCHECKED_CAST")
fun Map<String, Any?>.list(k: String): List<Any?>? = this[k] as? List<Any?>
@Suppress("UNCHECKED_CAST")
fun Map<String, Any?>.objList(k: String): List<Map<String, Any?>> = (this[k] as? List<Any?>)?.mapNotNull { it as? Map<String, Any?> } ?: emptyList()
