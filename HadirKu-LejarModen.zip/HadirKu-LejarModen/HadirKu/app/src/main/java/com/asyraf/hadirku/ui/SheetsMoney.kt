package com.asyraf.hadirku.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.asyraf.hadirku.MainViewModel
import com.asyraf.hadirku.Sheet
import com.asyraf.hadirku.TunaiDraft
import com.asyraf.hadirku.logic.Logic
import com.asyraf.hadirku.logic.Ms
import com.asyraf.hadirku.pg.Epp
import com.asyraf.hadirku.pg.EppSemak
import com.asyraf.hadirku.pg.OtEntry
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.Tx

private fun numText(d: Double): String = if (d == 0.0) "" else PG.jsNum(d)

@Composable
internal fun autoFocus(on: Boolean): FocusRequester {
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { if (on) runCatching { fr.requestFocus() } }
    return fr
}

/* ================= poket ================= */

@Composable
fun PocketMenuSheet(vm: MainViewModel, id: String) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val p = s.pockets.find { it.id == id } ?: return
    val b = PG.balances(s)[id] ?: 0.0
    val dw = p.dompet
    val kads = s.debts.any { it.jenis == "kad" }
    if (p.tunai) {
        val kira = vm.tunaiKira(id)
        SheetBody {
            SheetTitle(p.nama, rich("Baki tunai **" + M(b) + "** · duit dalam dompet, tidak dikira dalam baki bank" +
                (if (kira != null) "\nKali terakhir dikira " + PG.fmtShort(kira.first) + " (" + M(kira.second) + ")" else "")))
            MenuBtn("Belanja tunai", { vm.newTx(Tx(jenis = "keluar", poket = id), "Belanja tunai") }, primary = true)
            MenuBtn("Ambil duit dari ATM (bank → tunai)", { vm.newTx(Tx(jenis = "pindah", poket = "", ke = id, perkara = "Keluar duit ATM"), "Ambil duit dari ATM") })
            MenuBtn("Kira duit dalam dompet", { vm.open(Sheet.KiraTunai(id)) })
            MenuBtn("Terima duit tunai", { vm.newTx(Tx(jenis = "masuk", poket = id, perkara = "Terima tunai"), "Duit tunai masuk") })
            MenuBtn("Masukkan tunai ke bank", { vm.newTx(Tx(jenis = "pindah", poket = id, ke = PG.BELUM_AGIH, perkara = "Deposit tunai ke bank"), "Masukkan tunai ke bank") })
            if (kads) MenuBtn("Keluar tunai guna kad kredit", { vm.open(Sheet.Tunai(null, null, id, null)) })
            MenuBtn("Pindah ke poket lain", { vm.newTx(Tx(jenis = "pindah", poket = id)) })
            MenuBtn("Lihat transaksi", { vm.close(); vm.txPocket = id; vm.tab = "transaksi" })
            MenuBtn("Edit poket", { vm.open(Sheet.PocketForm(id)) })
            Note("Ambil duit di ATM = pindah dari poket bank ke dompet ini. Baki bank turun, tunai naik; jumlah duit anda tak berubah.", Modifier.padding(top = 8.dp, bottom = 8.dp))
        }
        return
    }
    SheetBody {
        SheetTitle(p.nama, rich("Baki **" + M(b) + "**" + if (dw) " · e-wallet, tidak dikira dalam baki bank" else ""))
        MenuBtn("Belanja dari poket ini", { vm.newTx(Tx(jenis = "keluar", poket = id)) })
        if (dw && kads) MenuBtn("Tambah nilai guna kad kredit", { vm.open(Sheet.Tunai(null, null, id, null)) })
        if (!dw && kads) MenuBtn("Belanja guna kad kredit", { vm.newTx(Tx(jenis = "kad", poket = id, perkara = if (id == "p-minyak") "Isi minyak" else ""), "Belanja guna kad kredit") })
        if (dw) MenuBtn("Transfer ke bank", { vm.newTx(Tx(jenis = "pindah", poket = id, ke = PG.BELUM_AGIH, perkara = "Transfer ke bank"), "Pindah ke bank") })
        MenuBtn("Pindah ke poket lain", { vm.newTx(Tx(jenis = "pindah", poket = id)) })
        MenuBtn("Lihat transaksi", { vm.close(); vm.txPocket = id; vm.tab = "transaksi" })
        MenuBtn("Edit poket", { vm.open(Sheet.PocketForm(id)) })
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
fun PocketFormSheet(vm: MainViewModel, id: String?) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val p = if (id != null) s.pockets.find { it.id == id } else null
    val ct = if (id != null) PG.targetsFromCommitments(s, vm.today())[id] ?: 0.0 else 0.0
    val dipakai = id != null && PG.pocketUsage(s, id)
    var nama by remember { mutableStateOf(p?.nama ?: "") }
    var sas by remember { mutableStateOf(if ((p?.sasaran ?: 0.0) > 0) PG.jsNum(p?.sasaran ?: 0.0) else "") }
    var simpan by remember { mutableStateOf(if (p == null) "bank" else PG.simpanDi(p)) }
    var err by remember { mutableStateOf("") }
    val fr = autoFocus(id == null)
    SheetBody(actions = { SheetActions("Simpan", { err = vm.savePocket(id, nama, sas, simpan) }, { vm.close() }) }) {
        SheetTitle(if (id != null) "Edit poket" else "Poket baru")
        Form {
            FieldText("Nama poket", nama, { nama = it }, readOnly = p?.tetap == true, maxLen = 40, fr = fr,
                small = if (p?.tetap == true) "Poket ini tetap: gaji masuk ke sini dulu sebelum diagih." else null)
            FieldText("Sasaran tambahan sebulan (RM)", sas, { sas = it }, placeholder = "0.00", kb = KeyboardType.Decimal,
                small = if (ct > 0) "Komitmen dan bayaran hutang yang guna poket ini (" + M(ct) + ") ditambah sendiri ke sasaran." else "Untuk belanja seperti dapur atau minyak. Bil tetap lebih baik dimasukkan sebagai komitmen.")
            if (p?.tetap != true) FieldChips("Duit poket ini disimpan di", listOf("bank" to "Bank", "tunai" to "Tunai (dompet)", "ewallet" to "E-wallet"), simpan, { simpan = it }, note = {
                Txt(
                    when (simpan) {
                        "tunai" -> "Duit tunai fizikal dalam dompet. Tidak dikira dalam baki bank. Ambil duit di ATM = Pindah dari poket bank ke sini."
                        "ewallet" -> "Contoh Touch 'n Go. Tidak dikira dalam baki bank. Isi semula dari bank = Pindah ke poket ini; transfer ke bank = Pindah keluar."
                        else -> "Duit dalam akaun bank. Dikira dalam baki bank dan Semak baki bank."
                    } + if (dipakai && p != null && simpan != PG.simpanDi(p)) " Poket ini dah ada transaksi: menukar pilihan ini mengubah kiraan baki bank sebelum ini." else "",
                    size = 12.5f, color = pal.muted,
                )
            })
        }
        Box(Modifier.padding(horizontal = GL)) { FormError(err) }
        if (id != null && p?.tetap != true) {
            Spacer(Modifier.height(8.dp))
            DelZone("Padam poket", "Padam poket ini?", { vm.delPocket(id) },
                blocked = if (dipakai) "Poket ini ada transaksi atau komitmen, jadi tak boleh dipadam. Tukar nama sahaja." else null)
        }
    }
}

/* ================= semak bank ================= */

@Composable
fun BankSheet(vm: MainViewModel) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    var baki by remember { mutableStateOf("") }
    var tarikh by remember { mutableStateOf(vm.today()) }
    var cat by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    val fr = autoFocus(true)
    val dom = s.pockets.any { it.dompet }
    val adaTunai = s.pockets.any { it.tunai }
    val adaEw = s.pockets.any { it.dompet && !it.tunai }
    SheetBody(actions = { SheetActions("Simpan semakan", { err = vm.saveBank(baki, tarikh, cat) }, { vm.close() }) }) {
        SheetTitle("Semak baki bank", rich("Buka app bank anda dan masukkan baki akaun sekarang. App akan bandingkan dengan jumlah semua poket" +
            (if (dom) " bank (tanpa " + listOfNotNull(if (adaTunai) "duit tunai" else null, if (adaEw) "e-wallet" else null).joinToString(" dan ") + ")" else "") + "."))
        Form {
            FieldText("Baki dalam bank (RM)", baki, { baki = it }, placeholder = "0.00", kb = KeyboardType.Decimal, big = true, fr = fr)
            FieldDate("Tarikh", tarikh, { tarikh = it })
            val tr = PG.total(s, tarikh)
            val v = vm.parseAmt(baki)
            Compare {
                KvLine("Jumlah poket" + (if (dom) " bank" else "") + " pada " + PG.fmtDate(tarikh)) { Txt(M(tr), size = 14f, weight = FontWeight.SemiBold, num = true) }
                if (v.isFinite()) {
                    val bz = PG.round2(v - tr)
                    if (Math.abs(bz) < 0.005) KvLine("Keputusan") { Pill("✔ Sama", Tone.GOOD) }
                    else {
                        KvLine("Beza") { Txt(M(bz), size = 14f, weight = FontWeight.SemiBold, color = pal.bad, num = true) }
                        Txt((if (bz > 0) "Bank lebih. Mungkin ada duit masuk yang belum direkod." else "Bank kurang. Mungkin ada belanja yang belum direkod.") + " Kalau tak jumpa, rekod jenis Pelarasan.", size = 13f, color = pal.muted)
                    }
                }
            }
            FieldText("Catatan (pilihan)", cat, { cat = it }, maxLen = 120)
        }
        Box(Modifier.padding(horizontal = GL)) { FormError(err) }
    }
}

/* ================= komitmen ================= */

@Composable
fun KMenuSheet(vm: MainViewModel, id: String) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val vd = PG.commitmentViewDate(s, vm.today())
    val c = PG.commitmentStatus(s, vd).find { it.id == id } ?: return
    SheetBody {
        val due = PG.tempoDate(c.c, vd)
        SheetTitle(c.nama, rich(M(c.jumlah) + " · gaji " + c.kitaran + "hb · " + pname(s, c.poket) +
            (if (due != null) "\nJatuh tempo **" + longDate(due) + "** · " + keadaanK(c, vm.today(), vd).first else "")))
        if (c.status != "sudah") MenuBtn("Rekod bayaran " + M(c.baki), { vm.payCommitment(id) }, primary = true)
        if (c.manualTanda) MenuBtn("Batal tanda dibayar", { vm.markK(id, false) })
        else if (c.status != "sudah") MenuBtn("Tanda dibayar di luar app", { vm.markK(id, true) })
        MenuBtn("Edit komitmen", { vm.open(Sheet.KForm(id)) })
        Note("\"Tanda dibayar di luar app\" untuk bayaran yang tak lalu akaun ini, contohnya potongan gaji terus.", Modifier.padding(top = 8.dp, bottom = 8.dp))
    }
}

@Composable
fun KFormSheet(vm: MainViewModel, id: String?) {
    val s by vm.pg.collectAsState()
    val c = if (id != null) s.commitments.find { it.id == id } else null
    var nama by remember { mutableStateOf(c?.nama ?: "") }
    var jumlah by remember { mutableStateOf(if (c != null) PG.toFixed(c.jumlah, 2) else "") }
    var kit by remember { mutableStateOf(c?.kitaran ?: "30") }
    var poket by remember { mutableStateOf(c?.poket ?: (s.pockets.getOrNull(1)?.id ?: "")) }
    var tempo by remember { mutableStateOf(c?.tempo?.takeIf { it in 1..31 }?.toString() ?: "") }
    var err by remember { mutableStateOf("") }
    val fr = autoFocus(id == null)
    SheetBody(actions = { SheetActions("Simpan", { err = vm.saveK(id, nama, jumlah, kit, poket, tempo) }, { vm.close() }) }) {
        SheetTitle(if (id != null) "Edit komitmen" else "Komitmen baru")
        Form {
            FieldText("Nama", nama, { nama = it }, placeholder = "cth: Sewa rumah", maxLen = 50, fr = fr)
            FieldText("Jumlah sebulan (RM)", jumlah, { jumlah = it }, placeholder = "0.00", kb = KeyboardType.Decimal, big = true)
            FieldChips("Bayar guna gaji", listOf("15" to "15hb", "30" to "30hb"), kit, { kit = it })
            FieldText("Jatuh tempo (hari bulan)", tempo, { tempo = it.filter { ch -> ch.isDigit() }.take(2) }, placeholder = "cth: 7", kb = KeyboardType.Number,
                small = "Pilihan. Muncul dalam kalendar komitmen dan dapat peringatan 3 hari & 1 hari sebelum. Hari 29–31 jadi hari akhir untuk bulan pendek.")
            FieldGrid("Dibayar dari poket", pocketOpts(s.pockets.filter { it.id != PG.BELUM_AGIH }), poket, { poket = it })
        }
        Box(Modifier.padding(horizontal = GL)) { FormError(err) }
        if (id != null) { Spacer(Modifier.height(8.dp)); DelZone("Padam komitmen", "Padam komitmen ini? Transaksi bayaran lama kekal, cuma tak lagi dikaitkan.", { vm.delK(id) }) }
    }
}

/* ================= hutang ================= */

@Composable
fun HMenuSheet(vm: MainViewModel, id: String) {
    val s by vm.pg.collectAsState()
    val today = vm.today()
    val d = PG.debtStatus(s, today).find { it.id == id } ?: return
    if (PG.isSpl(d.d)) { SplMenuSheet(vm, d); return }
    val payLbl = if (d.jenis == "kad") "Bayar kad ini" else if (d.bakiBayar > 0.004) "Rekod bayaran " + M(d.bakiBayar) else "Rekod bayaran tambahan"
    val pal = LocalPal.current
    val kad = d.jenis == "kad"
    val t = tinggalBulanIni(d)
    val plans = remember(s, today, id) { d.d.epp.map { it to PG.eppInfo(it, today) }.filter { it.second.aktif } }
    SheetBody {
        SheetTitle(d.nama, rich(jenisHutang(d.jenis) + " · " + kadarLbl(d.d)))
        if (kad) KadVisual(
            d.nama, M(d.jumlah),
            if (d.d.penyataHari in 1..31) "Penyata " + d.d.penyataHari + "hb" + (if (d.d.bayarHari in 1..31) " · bayar " + d.d.bayarHari + "hb" else "") else kadarLbl(d.d),
            if (d.d.hadKredit > 0.004) "Had " + M(d.d.hadKredit) else null,
        )
        Column(Modifier.fillMaxWidth().padding(horizontal = GL).padding(bottom = 12.dp)) {
            // ---- hutang: jadual ringkas
            TGroup("Hutang")
            if (kad && plans.isNotEmpty()) {
                TRow("Baki kad (penyata)", M(d.baki), garis = false)
                TRow("Baki pokok ansuran", M(d.eppPokok))
                TRow("Jumlah hutang", M(d.jumlah), bold = true)
            } else TRow("Jumlah hutang", if (d.jumlah < -0.004) "Lebih " + M(-d.jumlah) else M(d.jumlah), bold = true, garis = false)
            d.guna?.let { gu -> TRow("Had kredit", M(d.d.hadKredit), sub = "dah guna " + Math.round(gu * 100) + "%", color = if (gu >= 0.9) pal.bad else null) }
            // ---- bulan ini
            if (d.status != "langsai" && (d.sasaran > 0.004 || d.dibayar > 0.004)) {
                TGroup(tempohTajuk(d))
                d.tarikhAkhir?.let { ta -> TRow("Tarikh akhir bayar", PG.fmtShort(ta) + " " + PG.parse(ta).y, sub = tempohLagi(d, today),
                    color = if (d.minTinggal > 0.004 && today > ta) pal.bad else null, garis = false) }
                TRow(if (kad) "Minimum" else "Ansuran", M(d.min), garis = d.tarikhAkhir != null)
                if (Math.abs(d.sasaran - d.min) > 0.004) TRow("Perlu bayar", M(d.sasaran))
                TRow("Dah bayar", M(d.dibayar))
                TRow("Tinggal", if (t > 0.004) M(t) else "✔ Selesai", color = if (t > 0.004) pal.bad else pal.good, bold = true)
            }
            // ---- pelan ansuran (EPP)
            if (kad && plans.isNotEmpty()) {
                TGroup("Ansuran bulanan (EPP)")
                EppJadual(vm, id, plans)
            }
        }
        if (d.baki > 0.004) MenuBtn(payLbl, { vm.payDebt(id) }, primary = true)
        if (kad) MenuBtn("+ Tambah ansuran / EPP", { vm.open(Sheet.EppForm(id, null)) })
        MenuBtn("Kemas kini baki ikut penyata", { vm.open(Sheet.HLog(id, "penyata")) })
        if (kad) MenuBtn("Belanja guna kad ini", { vm.newTx(Tx(jenis = "kad", kadId = id), "Belanja guna kad kredit") })
        else MenuBtn("Tambah jumlah hutang", { vm.open(Sheet.HLog(id, "caj")) })
        if (kad) MenuBtn("Keluarkan tunai (Touch 'n Go)", { vm.open(Sheet.Tunai(null, id, null, null)) })
        MenuBtn("Rekod faedah atau caj", { vm.open(Sheet.HLog(id, "faedah")) })
        MenuBtn("Sejarah baki", { vm.open(Sheet.HHist(id)) })
        MenuBtn("Edit hutang", { vm.open(Sheet.HForm(id)) })
    }
}

/** Jadual pelan ansuran: satu baris setiap pelan aktif + jumlah. Tekan baris untuk kemas kini ikut penyata. */
@Composable
fun EppJadual(vm: MainViewModel, debtId: String, plans: List<Pair<Epp, com.asyraf.hadirku.pg.EppInfo>>) {
    val pal = LocalPal.current
    JRow(listOf("Pelan", "Sebulan", "Baki", "Baki pokok"), header = true)
    plans.forEach { (p, e) ->
        JRow(
            listOf(p.nama, rmTanpa(e.ans), e.bakiBulan.toString() + " bln", if (e.pokokTahu) rmTanpa(e.pokokBaki) else "?"),
            onClick = { vm.open(Sheet.EppForm(debtId, p.id)) },
        )
    }
    if (plans.size > 1) {
        val semuaTahu = plans.all { it.second.pokokTahu }
        JRow(listOf("Jumlah", rmTanpa(plans.sumOf { it.second.ans }), plans.maxOf { it.second.bakiBulan }.toString() + " bln",
            (if (semuaTahu) "" else "≥") + rmTanpa(plans.filter { it.second.pokokTahu }.sumOf { it.second.pokokBaki })), total = true)
    }
    val berjadual = PG.round2(plans.sumOf { it.second.baki })
    val faedah = PG.round2(plans.filter { it.second.pokokTahu }.sumOf { it.second.faedahBaki })
    val tamat = plans.maxOf { it.second.tamat }
    Txt(
        rich("Baki ansuran berjadual **" + M(berjadual) + "**" + (if (faedah > 0.004) " (termasuk faedah/AMF " + M(faedah) + ")" else "") +
            " · tamat " + fmtYm(tamat) + (if (plans.any { !it.second.pokokTahu }) ". ? = pokok tidak diketahui." else ".")),
        Modifier.padding(top = 8.dp), size = 12f, color = pal.muted,
    )
}

@Composable
fun HFormSheet(vm: MainViewModel, id: String?) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val d = if (id != null) s.debts.find { it.id == id } else null
    if (PG.isSpl(d)) { SplFormSheet(vm, id); return }
    var nama by remember { mutableStateOf(d?.nama ?: "") }
    var jenis by remember { mutableStateOf(d?.jenis ?: "kad") }
    var baki by remember { mutableStateOf("") }
    // kadar/peratus yang dikira daripada nilai RM dipapar 2 tempat perpuluhan
    var kadar by remember { mutableStateOf(if (d != null) PG.jsNum(if (d.faedahRm != null) PG.round2(d.kadar) else d.kadar) else "18") }
    var minp by remember { mutableStateOf(if (d != null) PG.jsNum(if (d.minRm != null) PG.round2(d.minPeratus) else d.minPeratus) else "5") }
    var minl by remember { mutableStateOf(if (d != null) (d.minLantai?.let { PG.jsNum(it) } ?: "") else "50") }
    var had by remember { mutableStateOf(numText(d?.hadKredit ?: 0.0)) }
    var ans by remember { mutableStateOf(numText(d?.ansuran ?: 0.0)) }
    var ranc by remember { mutableStateOf(numText(d?.rancangan ?: 0.0)) }
    val defPoket = d?.poket ?: (if (s.pockets.any { it.id == "p-komitmen" }) "p-komitmen" else s.pockets.getOrNull(1)?.id ?: "")
    var poket by remember { mutableStateOf(defPoket) }
    var minAsas by remember { mutableStateOf(d?.minAsas ?: "jumlah") }
    // faedah & minimum boleh diisi sebagai peratus atau nilai RM ikut penyata
    var kadarCara by remember { mutableStateOf(if (d?.faedahRm != null) "rm" else "%") }
    var faedahRm by remember { mutableStateOf(d?.faedahRm?.let { PG.toFixed(it, 2) } ?: "") }
    var minCara by remember { mutableStateOf(if (d?.minRm != null) "rm" else "%") }
    var minRm by remember { mutableStateOf(d?.minRm?.let { PG.toFixed(it, 2) } ?: "") }
    var penyataHari by remember { mutableStateOf(d?.penyataHari?.takeIf { it in 1..31 }?.toString() ?: "") }
    var bayarHari by remember { mutableStateOf(d?.bayarHari?.takeIf { it in 1..31 }?.toString() ?: "") }
    val today = vm.today()
    val ds = remember(s, id) { if (id != null) PG.debtStatus(s, today).find { it.id == id } else null }
    // baki sebelum bayaran bulan ini (lebih hampir dengan baki penyata)
    val bakiKini = if (d != null) (ds?.let { Math.max(0.0, it.baki) + it.dibayar } ?: Math.max(0.0, PG.debtBalance(s, d, null, today))) else 0.0
    val rujukAwal = remember {
        when {
            d?.minRm != null && d.minBaki > 0.004 -> PG.toFixed(d.minBaki, 2)
            d?.faedahRm != null && d.faedahBaki > 0.004 -> PG.toFixed(d.faedahBaki, 2)
            d != null && bakiKini > 0.004 -> PG.toFixed(bakiKini, 2)
            else -> ""
        }
    }
    var rujuk by remember { mutableStateOf(rujukAwal) }
    var err by remember { mutableStateOf("") }
    val fr = autoFocus(id == null)
    val kad = jenis == "kad"
    val rmF = kadarCara == "rm"
    val rmM = kad && minCara == "rm"
    // baki rujukan untuk tukar RM ↔ peratus: baki permulaan (hutang baru) atau baki penyata (edit)
    val rujukN = vm.parseAmt(if (d == null) baki else rujuk).let { if (it.isFinite() && it > 0.004) it else 0.0 }
    val eppPokok = if (d != null && kad) PG.eppUnbilledPokok(d, today) else 0.0
    val eppDue = if (d != null && kad) (ds?.eppDue ?: 0.0) else 0.0
    fun pctTxt(x: Double) = PG.jsNum(PG.round2(x))
    SheetBody(actions = {
        SheetActions("Simpan", { err = vm.saveH(id, MainViewModel.HInput(nama, jenis, baki, kadar, minp, minl, had, ans, ranc, poket, minAsas,
            kadarCara = kadarCara, faedahRm = faedahRm, minCara = minCara, minRm = minRm, rujuk = rujuk, rujukUbah = rujuk.trim() != rujukAwal.trim(),
            penyataHari = penyataHari, bayarHari = bayarHari)) }, { vm.close() })
    }) {
        SheetTitle(if (id != null) "Edit hutang" else "Hutang baru")
        if (id == null && s.debts.none { PG.isSpl(it) }) Box(Modifier.padding(horizontal = GL).padding(bottom = 8.dp)) {
            LinkBtn("Guna SPayLater (Shopee)? Tekan sini untuk tetapan mudah", { vm.open(Sheet.SplForm(null)) }, size = 13.5f)
        }
        Form {
            FieldText("Nama", nama, { nama = it }, placeholder = "cth: Kad kredit Maybank", maxLen = 50, fr = fr)
            FieldChips("Jenis", PG.JENIS_HUTANG.map { it.id to it.label }, jenis, { jenis = it })
            if (d != null) {
                Column(Modifier.fillMaxWidth().background(pal.surface).hairlines(pal.line).padding(horizontal = GL, vertical = 10.dp)) {
                    Txt(rich("Baki sekarang **" + M(PG.debtBalance(s, d, null, vm.today())) + "**" + (if (d.epp.isNotEmpty()) " (tidak termasuk EPP belum dibil)" else "") + ". Untuk ubah baki, guna **Kemas kini baki ikut penyata**."), size = 13f, color = pal.muted)
                }
            } else FieldText("Baki hutang sekarang (RM)", baki, { baki = it }, placeholder = "0.00", kb = KeyboardType.Decimal, big = true, small = "Ikut penyata atau app bank yang terkini.")
            val unitOpts = listOf("%" to "%", "rm" to "RM")
            if (rmF) {
                val fv = vm.parseAmt(faedahRm)
                FieldText("Faedah sebulan (RM)", faedahRm, { faedahRm = it }, placeholder = "0.00", kb = KeyboardType.Decimal,
                    small = (if (fv.isFinite() && fv >= 0 && rujukN > 0) "≈ " + pct(PG.kadarDariRm(fv, rujukN)) + "% setahun atas baki " + M(rujukN) + ". " else "") +
                        "Ambil daripada penyata: caj kewangan / faedah bulan lepas.",
                    trailing = { UnitToggle(unitOpts, kadarCara, { c ->
                        if (fv.isFinite() && fv >= 0 && rujukN > 0) kadar = pctTxt(PG.kadarDariRm(fv, rujukN))
                        kadarCara = c
                    }) })
            } else FieldText("Kadar faedah setahun (%)", kadar, { kadar = it }, placeholder = "18", kb = KeyboardType.Decimal,
                small = "Kad kredit biasanya 15% hingga 18%. Beli dulu bayar kemudian biasanya 0% kalau bayar ikut masa. Tak pasti? Tekan RM dan isi faedah dalam penyata.",
                trailing = { UnitToggle(unitOpts, kadarCara, { c ->
                    val k = vm.parseAmt(kadar)
                    if (faedahRm.isBlank() && k.isFinite() && k >= 0 && rujukN > 0) faedahRm = PG.toFixed(PG.rmDariKadar(k, rujukN), 2)
                    kadarCara = c
                }) })
            if (kad) {
                if (rmM) {
                    val mv = vm.parseAmt(minRm)
                    FieldText("Bayaran minimum (RM)", minRm, { minRm = it }, placeholder = "0.00", kb = KeyboardType.Decimal,
                        small = (if (mv.isFinite() && mv > 0 && rujukN > 0) "≈ " + pct(PG.minPeratusDariRm(mv, rujukN, eppPokok, eppDue, minAsas)) + "% daripada baki. " else "") +
                            "Bulan ini app guna nilai ini tepat. Bulan depan dianggar ikut peratus ini sampai baki penyata baru dikemas kini.",
                        trailing = { UnitToggle(unitOpts, minCara, { c ->
                            if (mv.isFinite() && mv > 0 && rujukN > 0) minp = pctTxt(PG.minPeratusDariRm(mv, rujukN, eppPokok, eppDue, minAsas))
                            minCara = c
                        }) })
                } else {
                    FieldText("Minimum (%)", minp, { minp = it }, placeholder = "5", kb = KeyboardType.Decimal, small = "Tak pasti? Tekan RM dan isi bayaran minimum dalam penyata.",
                        trailing = { UnitToggle(unitOpts, minCara, { c ->
                            if (minRm.isBlank()) {
                                val cur = ds?.min ?: 0.0
                                val p0 = vm.parseAmt(minp).let { if (it.isFinite() && it > 0) it else 5.0 }
                                val l0 = vm.parseAmt(minl).let { if (it.isFinite() && it >= 0) it else 50.0 }
                                val anggar = if (cur > 0.004) cur else if (rujukN > 0) Math.min(rujukN, Math.max(l0, rujukN * p0 / 100)) else 0.0
                                if (anggar > 0.004) minRm = PG.toFixed(anggar, 2)
                            }
                            minCara = c
                        }) })
                    FieldChips("Minimum dikira daripada", listOf("jumlah" to "Baki kad + pokok EPP", "biasa" to "Baki biasa + ansuran EPP"), minAsas, { minAsas = it }, stack = true, note = {
                        Txt(
                            if (minAsas == "biasa") "Ansuran EPP bulan ini dibayar penuh, ditambah peratus minimum atas baki kad selebihnya."
                            else "Peratus minimum × (baki kad + pokok EPP belum dibil). Faedah EPP tidak dikira. Sekurang-kurangnya minimum terendah dan ansuran EPP bulan ini.",
                            size = 12.5f, color = pal.muted,
                        )
                    })
                    FieldText("Minimum terendah (RM)", minl, { minl = it }, placeholder = "50", kb = KeyboardType.Decimal)
                }
                FieldText("Had kredit (RM, pilihan)", had, { had = it }, placeholder = "0.00", kb = KeyboardType.Decimal)
                val ph = penyataHari.trim().toIntOrNull()?.takeIf { it in 1..31 }
                val bh = bayarHari.trim().toIntOrNull()?.takeIf { it in 1..31 }
                FieldText("Tarikh penyata (hari)", penyataHari, { penyataHari = it.filter { c -> c.isDigit() }.take(2) }, placeholder = "cth: 24", kb = KeyboardType.Number,
                    small = if (ph == null) "Kosong = kira ikut bulan (1hb hingga hujung bulan). Isi hari penyata dikeluarkan supaya bayaran dikira ikut kitaran bank."
                    else PG.kitaranPenyata(today, ph).let { k -> "Kitaran sekarang: " + PG.fmtShort(k.start) + " – " + PG.fmtShort(k.end) + ". Bayaran dalam tempoh ini dikira untuk penyata " + PG.fmtShort(k.start) + "." })
                FieldText("Tarikh akhir bayar (hari)", bayarHari, { bayarHari = it.filter { c -> c.isDigit() }.take(2) }, placeholder = "cth: 14", kb = KeyboardType.Number,
                    small = if (ph != null && bh != null && bh != ph) "Penyata " + PG.fmtShort(PG.kitaranPenyata(today, ph).start) + " perlu dibayar sebelum " +
                        (PG.tarikhAkhirBayar(PG.kitaranPenyata(today, ph).start, bh)?.let { PG.fmtShort(it) } ?: "") + ". Peringatan 3 hari & 1 hari sebelum."
                    else "Ada dalam penyata: \"Payment Due Date\".")
            } else FieldText("Ansuran sebulan (RM)", ans, { ans = it }, placeholder = "0.00", kb = KeyboardType.Decimal)
            if (d != null && (rmF || rmM)) FieldText("Baki penyata (RM)", rujuk, { rujuk = it }, placeholder = "0.00", kb = KeyboardType.Decimal,
                small = "Baki dalam penyata yang sama dengan nilai RM di atas. Dipakai untuk tukar nilai RM kepada peratus. Baki hutang dalam app tak berubah.")
            FieldText("Rancangan bayar sebulan (RM, pilihan)", ranc, { ranc = it }, placeholder = "0.00", kb = KeyboardType.Decimal, small = "Kosongkan untuk bayar minimum sahaja. Jumlah ini masuk ke sasaran poket.")
            FieldGrid("Dibayar dari poket", pocketOpts(s.pockets.filter { it.id != PG.BELUM_AGIH && !it.dompet }), poket, { poket = it })
        }
        Box(Modifier.padding(horizontal = GL)) { FormError(err) }
        if (id != null) { Spacer(Modifier.height(8.dp)); DelZone("Padam hutang", "Padam hutang ini dan semua rekod bakinya? Transaksi bayaran kekal dalam poket, cuma tak lagi dikaitkan.", { vm.delH(id) }) }
    }
}

/* ================= bayar kad ================= */

@Composable
fun CardPaySheet(vm: MainViewModel, id: String) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val o = PG.cardPayOptions(s, id, vm.today()) ?: return
    val dsMin = PG.debtStatus(s, vm.today()).find { it.id == id }
    val tl = tambahLbl(o.belanja, o.tunai)
    val lbl = mapOf("penuh" to "Bayar penuh", "syor" to (if (o.pelan > 0.004) "Pelan + $tl" else tl.replaceFirstChar { it.uppercase() }), "pelan" to "Ikut pelan", "min" to "Minimum")
    val asasLbl = if (o.asal > o.rancangan + 0.004) "Minimum" else "Rancangan"
    fun note(oid: String): String {
        if (oid == "penuh") return if (o.eppBaki > 0.004) "Baki kad jadi RM0. Ansuran EPP diteruskan." else "Baki kad jadi RM0. Tiada faedah."
        if (oid == "min") {
            val w = if (dsMin != null) minWhy(dsMin) else ""
            return (if (dsMin != null && w.isNotEmpty()) "Minimum bulan ini " + M(dsMin.min) + " = " + w + ". " else "") + "Elak caj lewat. Baki selebihnya kena faedah."
        }
        if (oid == "pelan") return if (o.dibayar <= 0.004) "$asasLbl bulan ini" + (if (asasLbl == "Minimum") " (tiada rancangan)" else "") + "." else "Baki pelan bulan ini. Bayaran " + M(o.dibayar) + " dah ditolak dari pelan."
        val parts = ArrayList<String>()
        if (o.belanja > 0.004) parts.add("belanja kad " + M(o.belanja))
        if (o.tunai > 0.004) parts.add("tunai " + M(o.tunai))
        return if (o.pelan > 0.004) (if (o.dibayar > 0.004) "Baki pelan " else "Pelan ") + M(o.pelan) + " + " + parts.joinToString(" + ") + ". Supaya hutang kad tak bertambah." else "Baki $tl bulan ini. Pelan dah dibayar."
    }
    var pilih by remember { mutableStateOf(if (o.opts.isEmpty()) "lain" else o.lalai.ifEmpty { "lain" }) }
    var lain by remember { mutableStateOf("") }
    var poket by remember { mutableStateOf(o.poket) }
    var tarikh by remember { mutableStateOf(vm.today()) }
    var err by remember { mutableStateOf("") }
    val amt = if (pilih == "lain") vm.parseAmt(lain) else o.opts.find { it.id == pilih }?.jumlah ?: Double.NaN
    val ok = amt > 0
    SheetBody(actions = { SheetActions(if (ok) "Bayar " + M(amt) else "Bayar", { err = vm.payCard(id, amt, poket, tarikh) }, { vm.close() }) }) {
        SheetTitle("Bayar " + o.nama, rich("Baki kad **" + M(o.baki) + "**" + (if (o.dibayar > 0.004) " · sudah bayar **" + M(o.dibayar) + "** " + (dsMin?.let { tempohKecil(it) } ?: "bulan ini") else "") +
            (if (o.belanja + o.tunai > 0.004 && !o.cukup) "\nBayaran ditolak dari pelan dulu, kemudian $tl." else "")))
        if (o.cukup) Notice(rich("Bayaran bulan ini sudah cukup. Bayar lagi kalau nak kurangkan baki kad."), Tone.INFO)
        Txt("Berapa nak bayar?", Modifier.padding(horizontal = GL, vertical = 8.dp), size = 14f, weight = FontWeight.Medium, color = pal.muted)
        Column(Modifier.fillMaxWidth().background(pal.surface).hairlines(pal.line, top = true, bottom = true)) {
            o.opts.forEach { op ->
                PayOpt(pilih == op.id, lbl[op.id] ?: op.id, M(op.jumlah), note(op.id)) { pilih = op.id; err = "" }
            }
            val on = pilih == "lain"
            Row(
                Modifier.fillMaxWidth().background(if (on) pal.accentSoft else Color.Transparent).clickable { pilih = "lain" }.heightIn(min = 52.dp).padding(horizontal = GL, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Radio(on)
                Spacer(Modifier.width(10.dp))
                Txt("Jumlah lain", Modifier.weight(1f), size = 15f, weight = FontWeight.SemiBold, color = if (on) pal.accentStrong else pal.ink)
                BasicTextField(
                    value = lain, onValueChange = { lain = it; pilih = "lain" },
                    modifier = Modifier.width(130.dp).hairlines(pal.line).padding(vertical = 6.dp),
                    textStyle = TextStyle(fontFamily = AppFont, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = pal.ink, textAlign = TextAlign.End, fontFeatureSettings = "tnum"),
                    singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), cursorBrush = SolidColor(pal.accent),
                    decorationBox = { inner -> Box(contentAlignment = Alignment.CenterEnd) { if (lain.isEmpty()) Txt("0.00", size = 16f, color = pal.muted); inner() } },
                )
            }
        }
        if (ok) Column(Modifier.padding(horizontal = GL, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Txt(rich("Baki kad selepas bayar: **" + M(Math.max(0.0, o.baki - amt)) + "**"), size = 13.5f)
            if (amt > o.baki + 0.004) Txt("Lebih " + M(amt - o.baki) + " daripada baki kad.", size = 13.5f, color = pal.bad)
            val pb = PG.balances(s)[poket] ?: 0.0
            if (poket.isNotEmpty() && amt > pb + 0.004) Txt("Poket " + pname(s, poket) + " ada " + M(pb) + " sahaja.", size = 13.5f, color = pal.bad)
        }
        Form {
            FieldGrid("Dari poket", pocketOpts(s.pockets), poket, { poket = it })
            FieldDate("Tarikh", tarikh, { tarikh = it })
        }
        Box(Modifier.padding(horizontal = GL)) { FormError(err) }
    }
}

@Composable
private fun Radio(on: Boolean) {
    val pal = LocalPal.current
    Box(Modifier.size(20.dp).border(2.dp, if (on) pal.accent else pal.lineStrong, CircleShape), contentAlignment = Alignment.Center) {
        if (on) Box(Modifier.size(10.dp).background(pal.accent, CircleShape))
    }
}

@Composable
private fun PayOpt(on: Boolean, title: String, amt: String, note: String, onClick: () -> Unit) {
    val pal = LocalPal.current
    Row(
        Modifier.fillMaxWidth().background(if (on) pal.accentSoft else Color.Transparent).hairlines(pal.line).clickable(onClick = onClick).padding(horizontal = GL, vertical = 11.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Box(Modifier.padding(top = 2.dp)) { Radio(on) }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Row {
                Txt(title, Modifier.weight(1f), size = 15f, weight = FontWeight.SemiBold, color = if (on) pal.accentStrong else pal.ink)
                Txt(amt, size = 15f, weight = FontWeight.SemiBold, num = true)
            }
            Txt(note, size = 12.5f, color = pal.muted)
        }
    }
}

/* ================= EPP ================= */

@Composable
fun EppListSheet(vm: MainViewModel, id: String) {
    val s by vm.pg.collectAsState()
    val today = vm.today()
    val d = s.debts.find { it.id == id } ?: return
    val all = remember(s, today, id) { d.epp.map { it to PG.eppInfo(it, today) } }
    val aktif = all.filter { it.second.aktif }
    val selesai = all.size - aktif.size
    SheetBody(actions = { SheetActions("+ Pelan baru", { vm.open(Sheet.EppForm(id, null)) }, { vm.close() }, cancel = "Tutup") }) {
        SheetTitle("Ansuran · " + d.nama, if (selesai > 0) rich("$selesai pelan sudah selesai") else null)
        Column(Modifier.padding(horizontal = GL).padding(bottom = 12.dp)) {
            if (aktif.isEmpty()) { Empty(rich("Tiada pelan ansuran aktif pada kad ini.")); return@Column }
            val tahu = aktif.filter { it.second.pokokTahu }
            TGroup("Ringkasan")
            TRow("Komitmen sebulan", M(aktif.sumOf { it.second.ans }), garis = false, bold = true)
            TRow("Baki ansuran berjadual", M(aktif.sumOf { it.second.baki }), sub = "semua bayaran yang tinggal, termasuk faedah/AMF")
            TRow("Baki pokok", (if (tahu.size < aktif.size) "≥ " else "") + M(tahu.sumOf { it.second.pokokBaki }), sub = "anggaran langsai awal · semak terma bank")
            TRow("Faedah/AMF akan datang", (if (tahu.size < aktif.size) "≥ " else "") + M(tahu.sumOf { it.second.faedahBaki }))
            val akhir = aktif.maxByOrNull { it.second.tamat }!!.second
            TRow("Tamat paling lewat", fmtYm(akhir.tamat), sub = akhir.bakiBulan.toString() + " bulan lagi")
            TGroup("Pelan")
            EppJadual(vm, id, aktif)
        }
        Note("Tekan pelan untuk kemas kini ikut penyata bulan ini.")
    }
}

private fun eppModAwal(p: Epp?): String = when {
    p == null -> "sifar"
    p.kaedah == "baki" -> "baki"
    p.kaedah == "tetap" -> "tetap"
    p.kadar > 0.0001 || (p.faedahJumlah ?: 0.0) > 0.004 -> "rata"
    else -> "sifar"
}

@Composable
fun EppFormSheet(vm: MainViewModel, debtId: String, planId: String?) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val today = vm.today()
    val d = s.debts.find { it.id == debtId } ?: return
    val p = if (planId != null) d.epp.find { it.id == planId } else null
    val e0 = remember(planId) { p?.let { PG.eppInfo(it, today) } }
    val ke0 = e0?.keSekarang?.takeIf { it >= 1 } ?: 1
    var mod by remember { mutableStateOf(eppModAwal(p)) }
    var nama by remember { mutableStateOf(p?.nama ?: "") }
    var pokok by remember { mutableStateOf(if (p != null && p.kaedah == "rata") PG.toFixed(p.pokok, 2) else "") }
    var tempohS by remember { mutableStateOf((p?.tempoh ?: 12).toString()) }
    var kadar by remember { mutableStateOf(PG.jsNum(p?.let { if (it.faedahJumlah != null) PG.round2(it.kadar) else it.kadar } ?: 0.0)) }
    var ans by remember { mutableStateOf(if ((p?.ansuran ?: 0.0) > 0) PG.toFixed(p?.ansuran ?: 0.0, 2) else "") }
    var faedahCara by remember { mutableStateOf(if (p?.faedahJumlah != null) "rm" else "%") }
    var faedahRm by remember { mutableStateOf(p?.faedahJumlah?.let { PG.toFixed(it, 2) } ?: "") }
    var keS by remember { mutableStateOf(ke0.toString()) }
    var tarikhKe by remember { mutableStateOf(e0?.dates?.getOrNull(ke0 - 1) ?: today) }
    val semak0 = p?.semak?.find { it.ke == ke0 }
    var pokokPen by remember { mutableStateOf(semak0?.let { PG.toFixed(it.pokok, 2) } ?: "") }
    var faedahPen by remember { mutableStateOf(semak0?.let { PG.toFixed(it.faedah, 2) } ?: "") }
    var err by remember { mutableStateOf("") }
    val fr = autoFocus(planId == null)
    fun numOr(raw: String, def: Double) = if (raw.trim().isEmpty()) def else vm.parseAmt(raw)
    val ke = keS.trim().toIntOrNull() ?: 0
    fun build(): Epp {
        val tp = tempohS.trim().toIntOrNull() ?: 0
        val mula = if (ke >= 1 && tarikhKe.isNotEmpty()) PG.eppMulaDariKe(tarikhKe, ke) else ""
        val cat = p?.catatan ?: ""
        return when (mod) {
            "baki" -> {
                val pk = numOr(pokokPen, Double.NaN); val fd = numOr(faedahPen, Double.NaN)
                val baru = if (pk.isFinite() && fd.isFinite()) listOf(EppSemak(ke, PG.round2(pk), PG.round2(fd), tarikhKe)) else emptyList()
                Epp("", nama.trim(), 0.0, tp, 0.0, numOr(ans, 0.0), mula, cat, kaedah = "baki",
                    semak = ((p?.semak ?: emptyList()).filter { it.ke != ke } + baru).sortedBy { it.ke })
            }
            "tetap" -> Epp("", nama.trim(), 0.0, tp, 0.0, numOr(ans, 0.0), mula, cat, kaedah = "tetap")
            "rata" -> {
                val pk = numOr(pokok, Double.NaN)
                val fj = if (faedahCara == "rm") numOr(faedahRm, 0.0) else null
                val kd = if (fj != null) (if (fj.isFinite()) PG.eppKadarDariRm(fj, pk, tp) else 0.0) else numOr(kadar, 0.0)
                Epp("", nama.trim(), pk, tp, kd, numOr(ans, 0.0), mula, cat, faedahJumlah = fj)
            }
            else -> Epp("", nama.trim(), numOr(pokok, Double.NaN), tp, 0.0, numOr(ans, 0.0), mula, cat)
        }
    }
    SheetBody(actions = { SheetActions("Simpan", { err = vm.saveEpp(debtId, planId, build(), ke) }, { vm.close() }) }) {
        SheetTitle((if (planId != null) "Kemas kini ansuran" else "Ansuran baru") + " · " + d.nama)
        Form {
            FieldChips("Jenis pelan", listOf("sifar" to "0%", "rata" to "Kadar rata", "baki" to "Baki berkurang", "tetap" to "Ansuran tetap"), mod, { mod = it },
                note = {
                    Txt(when (mod) {
                        "sifar" -> "EPP biasa tanpa faedah."
                        "rata" -> "Faedah sama setiap bulan (flat)."
                        "baki" -> "Faedah/AMF turun setiap bulan, pokok naik (cth RHB Smart Move, CashXcess)."
                        else -> "Tahu ansuran sahaja. Pokok & faedah tidak diketahui."
                    }, Modifier.padding(top = 6.dp), size = 12.5f, color = pal.muted)
                })
            FieldText("Nama pelan", nama, { nama = it }, placeholder = "cth: Smart Move, Senheng", maxLen = 50, fr = fr)
            if (mod == "sifar" || mod == "rata")
                FieldText("Jumlah pokok (RM)", pokok, { pokok = it }, placeholder = "0.00", kb = KeyboardType.Decimal, big = true, small = "Harga barang atau jumlah asal, tanpa faedah.")
            else FieldText("Ansuran sebulan (RM)", ans, { ans = it }, placeholder = "0.00", kb = KeyboardType.Decimal, big = true, small = "Jumlah ansuran dalam penyata.")
            FieldText("Tempoh (bulan)", tempohS, { tempohS = it.take(3) }, kb = KeyboardType.Number, after = {
                Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(6, 12, 24, 36, 60).forEach { n -> QBtn(n.toString(), Modifier.weight(1f)) { tempohS = n.toString() } }
                }
            })
            if (mod == "rata") {
                val unitOpts = listOf("%" to "%", "rm" to "RM")
                val pkN = numOr(pokok, Double.NaN); val tpN = tempohS.trim().toIntOrNull() ?: 0
                if (faedahCara == "rm") {
                    val fv = vm.parseAmt(faedahRm)
                    FieldText("Jumlah faedah (RM)", faedahRm, { faedahRm = it }, placeholder = "0.00", kb = KeyboardType.Decimal,
                        small = "Untuk seluruh tempoh.", trailing = { UnitToggle(unitOpts, faedahCara, { c ->
                            if (fv.isFinite() && fv >= 0 && pkN > 0 && tpN > 0) kadar = PG.jsNum(PG.round2(PG.eppKadarDariRm(fv, pkN, tpN)))
                            faedahCara = c
                        }) })
                } else FieldText("Kadar rata setahun (%)", kadar, { kadar = it }, placeholder = "0", kb = KeyboardType.Decimal,
                    trailing = { UnitToggle(unitOpts, faedahCara, { c ->
                        val k = vm.parseAmt(kadar)
                        if (faedahRm.isBlank() && k.isFinite() && k > 0 && pkN > 0 && tpN > 0) faedahRm = PG.toFixed(pkN * k / 100 * tpN / 12, 2)
                        faedahCara = c
                    }) })
            }
            FieldText("Ansuran ke berapa sekarang", keS, { keS = it.filter { c -> c.isDigit() }.take(3) }, kb = KeyboardType.Number,
                small = "Lihat penyata: cth 7/24 → isi 7. Pelan baru → 1.")
            FieldDate("Tarikh penyata ansuran ini", tarikhKe, { tarikhKe = it })
            if (mod == "baki") {
                FieldText("Pokok dalam penyata (RM)", pokokPen, { pokokPen = it }, placeholder = "0.00", kb = KeyboardType.Decimal)
                FieldText("Faedah / AMF dalam penyata (RM)", faedahPen, { faedahPen = it }, placeholder = "0.00", kb = KeyboardType.Decimal,
                    small = "Dari penyata yang sama. Pokok + faedah = ansuran.")
            }
            if (mod == "sifar" || mod == "rata")
                FieldText("Ansuran ikut penyata (RM, pilihan)", ans, { ans = it }, placeholder = "Kira sendiri", kb = KeyboardType.Decimal)
        }
        // ---- ringkasan (jadual)
        val f = build()
        val sah = PG.eppValidate(f, ke).isEmpty()
        Column(Modifier.fillMaxWidth().padding(horizontal = GL).padding(top = 4.dp, bottom = 4.dp)) {
            if (!sah) Txt("Lengkapkan maklumat untuk lihat ringkasan.", size = 13f, color = pal.muted)
            else {
                val e = PG.eppInfo(PG.eppSediaSimpan(f, today), today)
                TGroup("Ringkasan")
                TRow("Komitmen sebulan", M(e.ans), garis = false, bold = true)
                TRow("Baki bulan", e.bakiBulan.toString() + " bulan", sub = "tamat " + fmtYm(e.tamat))
                TRow("Baki pokok", if (e.pokokTahu) M(e.pokokBaki) else "Tidak diketahui", sub = if (e.pokokTahu) "anggaran langsai awal" else null)
                TRow("Baki ansuran berjadual", M(e.baki))
                TRow("Faedah/AMF akan datang", if (e.pokokTahu) M(e.faedahBaki) else "Tidak diketahui")
                if (e.kaedah == "baki") {
                    TRow("Kadar (anggaran)", "≈" + PG.toFixed(e.kadarNominal ?: 0.0, 2) + "% setahun",
                        sub = "efektif " + PG.toFixed(e.kadarEfektif ?: 0.0, 2) + "% · rata setara " + PG.toFixed(e.kadarRataSetara, 2) + "% · dikira daripada penyata, belum disahkan bank")
                    val lepas = e.banding.filter { it.ke != ke }.maxByOrNull { it.ke }
                    if (lepas != null) TRow("Semak penyata ke-" + lepas.ke, if (lepas.beza > 0.004) "beza " + M(lepas.beza) else "✔ sama",
                        sub = if (lepas.beza <= 0.02) "pembundaran bank" else "semak semula angka penyata", color = if (lepas.beza > 0.02) pal.bad else null)
                }
            }
        }
        Box(Modifier.padding(horizontal = GL)) { FormError(err) }
        if (planId != null) { Spacer(Modifier.height(8.dp)); DelZone("Padam pelan", "Padam pelan ini? Ansuran yang dah dibil kekal dalam baki kad kalau ada penyata selepasnya.", { vm.delEpp(debtId, planId) }) }
    }
}

@Composable
fun QBtn(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val pal = LocalPal.current
    Box(
        modifier.defaultMinSize(minHeight = 36.dp).border(1.dp, pal.line, RoundedCornerShape(4.dp)).pressable(onClick, scaleTo = 0.9f),
        contentAlignment = Alignment.Center,
    ) { Txt(text, size = 14f, weight = FontWeight.SemiBold, num = true) }
}

/* ================= log hutang ================= */

private val LOGTXT = mapOf(
    "penyata" to Triple("Kemas kini baki", "Masukkan baki terkini dalam penyata atau app bank. Baki ini menggantikan semua rekod sebelum tarikh itu, termasuk faedah yang belum direkod.", "Baki ikut penyata (RM)"),
    "caj" to Triple("Belanja guna kad", "Belanja guna kad tak keluar dari poket. Ia tambah baki hutang sahaja.", "Jumlah (RM)"),
    "faedah" to Triple("Faedah & caj", "Rekod faedah, caj lewat atau yuran tahunan yang dikenakan. Faedah/AMF ansuran EPP sudah termasuk dalam ansuran, jadi jangan rekod di sini.", "Jumlah (RM)"),
)

@Composable
fun HLogSheet(vm: MainViewModel, id: String, jenis: String) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val today = vm.today()
    val d = s.debts.find { it.id == id } ?: return
    val tx = LOGTXT[jenis] ?: LOGTXT.getValue("faedah")
    var v by remember { mutableStateOf("") }
    var dt by remember { mutableStateOf(today) }
    var cat by remember { mutableStateOf("") }
    var minV by remember { mutableStateOf("") }
    var fV by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    val fr = autoFocus(true)
    SheetBody(actions = { SheetActions("Simpan", { err = vm.saveHLog(id, jenis, v, dt, cat, minV, fV) }, { vm.close() }) }) {
        SheetTitle((if (jenis == "caj" && d.jenis != "kad") "Tambah hutang" else tx.first) + " · " + d.nama, rich(tx.second))
        Form {
            FieldText(tx.third, v, { v = it }, placeholder = "0.00", kb = KeyboardType.Decimal, big = true, fr = fr)
            FieldDate("Tarikh", dt, { dt = it })
            if (jenis == "penyata") {
                val cur = PG.debtBalance(s, d, dt, today)
                val n = vm.parseAmt(v)
                Compare {
                    KvLine("Baki dalam app pada " + PG.fmtDate(dt)) { Txt(M(cur), size = 14f, weight = FontWeight.SemiBold, num = true) }
                    if (n.isFinite()) {
                        val bz = PG.round2(n - cur)
                        if (Math.abs(bz) < 0.005) KvLine("Keputusan") { Pill("✔ Sama", Tone.GOOD) }
                        else {
                            KvLine("Beza") { Txt(Mp(bz), size = 14f, weight = FontWeight.SemiBold, num = true) }
                            Txt(if (bz > 0) "Biasanya faedah atau belanja kad yang belum direkod." else "Mungkin ada bayaran atau rebat yang belum direkod.", size = 13f, color = pal.muted)
                        }
                    }
                }
                // nilai dari penyata yang sama: app tukar sendiri kepada peratus
                val ds = remember(s, id) { PG.debtStatus(s, today).find { it.id == id } }
                if (d.jenis == "kad") {
                    val mv = vm.parseAmt(minV)
                    FieldText("Bayaran minimum (RM, pilihan)", minV, { minV = it }, placeholder = "Tak berubah", kb = KeyboardType.Decimal,
                        small = (if (mv.isFinite() && mv > 0 && n.isFinite() && n > 0.004) "≈ " + pct(PG.minPeratusDariRm(mv, n, PG.eppUnbilledPokok(d, dt), ds?.eppDue ?: 0.0, d.minAsas)) + "% daripada baki. " else "") +
                            "Minimum dalam app sekarang " + M(ds?.min ?: 0.0) + (if (ds?.minInfo?.cara == "penyata") " (ikut penyata)" else if (d.minRm != null) " (anggaran)" else " (" + pct(d.minPeratus) + "%)") + ".")
                }
                val fv = vm.parseAmt(fV)
                FieldText("Faedah dalam penyata (RM, pilihan)", fV, { fV = it }, placeholder = "Tak berubah", kb = KeyboardType.Decimal,
                    small = (if (fv.isFinite() && fv >= 0 && n.isFinite() && n > 0.004) "≈ " + pct(PG.kadarDariRm(fv, n)) + "% setahun. " else "") +
                        "Untuk kira kadar faedah sahaja. Tak ditambah ke baki sebab baki penyata dah termasuk faedah.")
            }
            FieldText("Catatan (pilihan)", cat, { cat = it }, placeholder = if (jenis == "caj") "cth: Belanja online" else "", maxLen = 80)
        }
        Box(Modifier.padding(horizontal = GL)) { FormError(err) }
    }
}

private val EVLBL = mapOf("penyata" to "Baki ikut penyata", "caj" to "Belanja / hutang baru", "beli" to "Belanja guna kad", "tunai" to "Tunai dari kad", "faedah" to "Faedah & caj", "bayar" to "Bayaran", "epp" to "Ansuran EPP")

@Composable
fun HHistSheet(vm: MainViewModel, id: String) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val d = s.debts.find { it.id == id } ?: return
    val ev = remember(s) { PG.debtEvents(s, d, null, vm.today()).reversed() }
    var armed by remember { mutableStateOf("") }
    SheetBody(actions = { SheetActions("Kemas kini baki", { vm.open(Sheet.HLog(id, "penyata")) }, { vm.close() }, cancel = "Tutup") }) {
        SheetTitle("Sejarah · " + d.nama, rich("Terkini di atas. Bayaran datang daripada transaksi; edit atau padam di sana."))
        if (ev.isEmpty()) Empty(rich("Tiada rekod."))
        else ListBlock {
            ev.forEach { e ->
                val amt = if (e.jenis == "penyata") "= " + M(e.jumlah) else if (e.jenis == "bayar") M(-e.jumlah) else "+" + M(e.jumlah)
                Column(Modifier.fillMaxWidth().hairlines(pal.line).padding(horizontal = GL, vertical = 11.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Txt(rich("**" + (EVLBL[e.jenis] ?: e.jenis) + "**" + if (e.catatan.isNotEmpty()) " · " + e.catatan else ""), Modifier.weight(1f), size = 14f)
                        Txt(amt, size = 14f, color = if (e.jenis == "bayar") pal.inn else pal.ink, num = true)
                    }
                    Row(Modifier.fillMaxWidth().padding(top = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                        Txt(PG.fmtDate(e.tarikh) + " · baki " + M(e.baki), Modifier.weight(1f), size = 12.5f, color = pal.muted)
                        when {
                            e.jenis == "epp" -> Txt("Dari pelan EPP", size = 12.5f, color = pal.muted)
                            e.log -> Txt(if (armed == e.id) "Tekan lagi untuk padam" else "Padam", Modifier.clickable {
                                if (armed == e.id) { vm.delHLog(id, e.id); armed = "" } else armed = e.id
                            }.padding(vertical = 4.dp), size = 12.5f, weight = FontWeight.SemiBold, color = pal.bad)
                            else -> Txt("Buka transaksi", Modifier.clickable { vm.editTx(e.id) }.padding(vertical = 4.dp), size = 12.5f, weight = FontWeight.SemiBold, color = pal.accentStrong)
                        }
                    }
                }
            }
        }
    }
}

/* ================= pelan hutang ================= */

@Composable
fun PlanFormSheet(vm: MainViewModel) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val today = vm.today()
    val plan0 = remember(s) { PG.debtPlan(s, 0.0, "avalanche", today) }
    var bajet by remember { mutableStateOf(PG.toFixed(vm.budgetNow(), 2)) }
    var strat by remember { mutableStateOf(s.settings.hutangStrategi) }
    var err by remember { mutableStateOf("") }
    SheetBody(actions = { SheetActions("Simpan pelan", { err = vm.savePlan(bajet, strat) }, { vm.close() }) }) {
        SheetTitle("Pelan bebas hutang")
        Form {
            FieldText("Bajet bayar hutang sebulan (RM)", bajet, { bajet = it }, kb = KeyboardType.Decimal, big = true,
                small = "Bayaran minimum semua hutang sekarang: " + M(plan0.minimum) + ". Lebihan bajet dibayar ke satu hutang dulu sehingga langsai, kemudian ke hutang seterusnya.")
            FieldChips("Hutang mana dulu", listOf("avalanche" to "Faedah tertinggi dulu", "snowball" to "Baki terkecil dulu"), strat, { strat = it })
        }
        Preview(rich("**Faedah tertinggi dulu** jimat faedah paling banyak. **Baki terkecil dulu** cepat langsaikan hutang pertama, jadi lebih mudah kekal bermotivasi."))
        val b = vm.parseAmt(bajet)
        if (b.isFinite()) {
            val p = PG.debtPlan(s, b, strat, today)
            Txt(
                if (p.kosong) rich("Tiada baki hutang.") else if (!p.cukup) rich("Bajet kurang daripada bayaran minimum " + M(p.minimum) + ".")
                else if (p.never) rich("Bajet ini tak cukup untuk langsaikan hutang.")
                else rich("Bebas hutang **" + monthShort(today, p.bulan) + "** (" + tempoh(p.bulan) + ") · anggaran faedah **" + M(p.faedah) + "**"),
                Modifier.padding(horizontal = GL), size = 13.5f, color = if (!p.kosong && (!p.cukup || p.never)) pal.bad else pal.muted,
            )
        }
        Box(Modifier.padding(horizontal = GL)) { FormError(err) }
    }
}

/* log OT harian: lihat OtSheet.kt (papan nombor) */

/* ================= tunai dari kad ================= */

@Composable
fun TunaiSheet(vm: MainViewModel, sh: Sheet.Tunai) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val today = vm.today()
    val t = sh.tx
    val dr = sh.draft
    var kads = s.debts.filter { it.jenis == "kad" && !PG.isSpl(it) } // SPayLater tiada pengeluaran tunai
    if (t != null && kads.none { it.id == t.kadId }) { val k0 = s.debts.find { it.id == t.kadId }; if (k0 != null) kads = kads + k0 }
    if (kads.isEmpty() && t == null) {
        SheetBody(actions = { SheetActions("", {}, { vm.close() }, cancel = "Tutup") }) {
            SheetTitle("Keluarkan tunai dari kad")
            Note("Tambah kad kredit dulu di Bayaran → Hutang.")
        }
        return
    }
    val fl = s.settings.tunaiFee
    val dom = s.pockets.filter { it.dompet && !it.tunai }
    var kadId by remember { mutableStateOf(dr?.kadId ?: t?.kadId ?: sh.kadId ?: if (kads.size == 1) kads[0].id else "") }
    var jumlah by remember { mutableStateOf(dr?.jumlah ?: t?.let { PG.toFixed(it.jumlah, 2) } ?: "") }
    var mode by remember { mutableStateOf(dr?.mode ?: if (t != null) (if (t.feePct != null) "pct" else "rm") else (if (fl?.mode == "rm") "rm" else "pct")) }
    var fee by remember { mutableStateOf(dr?.fee ?: if (t != null) (t.feePct?.let { PG.jsNum(it) } ?: PG.jsNum(t.fee ?: 0.0)) else (fl?.nilai?.let { PG.jsNum(it) } ?: "")) }
    var poket by remember { mutableStateOf(sh.poket ?: t?.poket ?: dom.firstOrNull()?.id ?: PG.BELUM_AGIH) }
    var perkara by remember { mutableStateOf(dr?.perkara ?: t?.perkara ?: "") }
    var tarikh by remember { mutableStateOf(dr?.tarikh ?: t?.tarikh ?: today) }
    var cat by remember { mutableStateOf(dr?.catatan ?: t?.catatan ?: "") }
    var err by remember { mutableStateOf("") }
    val fr = autoFocus(t == null && dr == null)
    val amt = vm.parseAmt(jumlah)
    val raw = fee.trim()
    val feeN = if (raw.isEmpty()) 0.0 else vm.parseAmt(raw)
    val feeOk = raw.isEmpty() || (feeN.isFinite() && feeN >= 0)
    val feeRm = if (!feeOk) Double.NaN else if (raw.isEmpty()) 0.0 else if (mode == "pct") (if (amt.isFinite()) PG.round2(amt * feeN / 100) else 0.0) else PG.round2(feeN)
    val d = s.debts.find { it.id == kadId }
    fun save() {
        val tx = Tx(
            tarikh = tarikh, jenis = "tunai-kad", poket = poket, kadId = kadId, jumlah = amt,
            perkara = perkara.trim().ifEmpty { "Tunai dari " + (d?.nama ?: "kad") }, catatan = cat.trim(), fee = feeRm,
            feePct = if (feeOk && mode == "pct" && raw.isNotEmpty()) feeN else null,
        )
        err = vm.saveTunai(t?.id, tx, mode, if (raw.isEmpty()) null else feeN, feeOk)
    }
    SheetBody(actions = { SheetActions("Simpan", { save() }, { vm.close() }) }) {
        SheetTitle(if (t != null) "Edit tunai dari kad" else "Keluarkan tunai dari kad", rich("Contoh tambah nilai Touch 'n Go guna kad kredit. Duit ini pinjaman: hutang kad bertambah, tapi tidak dikira pendapatan. Fee dikira perbelanjaan."))
        Form {
            FieldChips("Kad kredit", kads.map { it.id to it.nama }, kadId, { kadId = it })
            FieldText("Jumlah dikeluarkan (RM)", jumlah, { jumlah = it }, placeholder = "0.00", kb = KeyboardType.Decimal, big = true, fr = fr)
            FieldText("Fee", fee, { fee = it }, placeholder = if (mode == "pct") "contoh 1" else "0.00", kb = KeyboardType.Decimal,
                small = if (!feeOk) "Fee mesti nombor 0 atau lebih." else if (mode == "pct") (if (amt > 0 && raw.isNotEmpty()) PG.jsNum(feeN) + "% daripada " + M(amt) + " = " + M(feeRm) else "Peratus daripada jumlah dikeluarkan.") else "Fee dalam RM, ikut yang dikenakan.",
                after = {
                    Row(Modifier.padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("pct" to "%", "rm" to "RM").forEach { (m, l) ->
                            val on = mode == m
                            Box(
                                Modifier.border(1.dp, if (on) pal.accent else pal.lineStrong, RoundedCornerShape(6.dp)).background(if (on) pal.accentSoft else Color.Transparent, RoundedCornerShape(6.dp))
                                    .clickable { if (mode != m) { mode = m; fee = "" } }.padding(horizontal = 14.dp, vertical = 6.dp),
                            ) { Txt(l, size = 13f, weight = FontWeight.SemiBold, color = if (on) pal.accentStrong else pal.muted) }
                        }
                    }
                })
            FieldGrid("Masuk ke", pocketOpts(s.pockets), poket, { poket = it }, note = {
                if (vm.isTunai(poket)) Txt("Duit tunai dari ATM guna kad kredit masuk ke dompet tunai. Hutang kad bertambah; baki bank tidak berubah.", size = 12.5f, color = pal.muted)
                else if (dom.isNotEmpty()) Txt("Pilih poket e-wallet kalau duit kekal dalam Touch 'n Go. Pilih dompet tunai kalau keluar duit di ATM. Pilih poket bank (contoh Belum Agih) kalau terus transfer ke bank.", size = 12.5f, color = pal.muted)
                else Row(verticalAlignment = Alignment.CenterVertically) {
                    Txt("Tiada poket e-wallet lagi. ", size = 12.5f, color = pal.muted)
                    LinkBtn("+ Buat poket Touch 'n Go", {
                        val p = vm.ensureDompet()
                        vm.open(Sheet.Tunai(t, sh.kadId, p.id, TunaiDraft(kadId, jumlah, mode, fee, perkara, tarikh, cat)))
                    }, size = 12.5f)
                }
            })
            FieldText("Perkara", perkara, { perkara = it }, placeholder = "Tunai dari kad", maxLen = 80)
            FieldDate("Tarikh", tarikh, { tarikh = it })
            FieldText("Catatan", cat, { cat = it }, maxLen = 120)
        }
        if (amt > 0 && feeOk) Column(Modifier.padding(horizontal = GL, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            val naik = PG.round2(amt + feeRm)
            Txt(rich("Hutang " + (d?.nama ?: "kad") + " bertambah **" + M(naik) + "**" + (if (feeRm > 0) " (termasuk fee " + M(feeRm) + ")" else "") + "."), size = 13.5f)
            if (poket.isNotEmpty()) Txt(rich("Masuk ke " + pname(s, poket) + ": **+" + M(amt) + "**" + if (vm.isTunai(poket)) " · duit tunai, tidak dikira dalam baki bank." else if (vm.isDompet(poket)) " · e-wallet, tidak dikira dalam baki bank." else " · dikira dalam baki bank."), size = 13.5f)
            val perB = PG.finPeriod(today, 1)
            if (d != null && tarikh >= perB.start && tarikh <= perB.end) {
                val hyp = s.copy(transactions = s.transactions.filter { it.id != t?.id } + Tx(id = "_tunai", tarikh = tarikh, jenis = "tunai-kad", poket = poket.ifEmpty { PG.BELUM_AGIH }, kadId = d.id, jumlah = amt, fee = feeRm))
                val sb = PG.debtStatus(hyp, today).find { it.id == d.id }
                if (sb != null) Txt(rich("Bayaran " + d.nama + " bulan ini jadi **" + M(sb.sasaran) + "**: pelan " + M(sb.sasaranAsal) + (if (sb.belanjaKad > 0.004) " + belanja kad " + M(sb.belanjaKad) else "") +
                    " + tunai " + M(sb.tunaiKad) + (if (sb.dibayar > 0.004) " (dah bayar " + M(sb.dibayar) + ")" else "") + "."), size = 13.5f)
            }
            val kadar = d?.kadar ?: 0.0
            if (kadar > 0) Txt("Kalau baki kad tak dibayar penuh, faedah " + (if (d?.faedahRm != null) "≈" else "") + pct(kadar) + "% setahun (lebih kurang " + M(naik * kadar / 1200) + " sebulan untuk jumlah ini).", size = 13.5f, color = pal.bad)
        }
        Box(Modifier.padding(horizontal = GL)) { FormError(err) }
        if (t != null) { Spacer(Modifier.height(8.dp)); DelZone("Padam transaksi ini", "Padam transaksi ini? Baki poket akan dikira semula.", { vm.delTx(t.id) }) }
    }
}

/* ================= senarai kategori / poket ================= */

@Composable
fun KatListSheet(vm: MainViewModel, k: String) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val per = vm.lap
    val pm = pieModeNow(vm, s)
    // duit dipulangkan (pulangan) untuk kategori ini ditunjuk sekali dan ditolak daripada jumlah
    val list = s.transactions.filter { it.tarikh >= per.start && it.tarikh < per.endExcl && ((inPieMode(it, pm) && PG.kategoriOf(it) == k) || (PG.isPulangan(it) && it.kategori == k)) }
        .sortedWith { a, b -> val c = b.tarikh.compareTo(a.tarikh); if (c != 0) c else b.dibuat.compareTo(a.dibuat) }
    val tot = PG.round2(list.sumOf { if (PG.isPulangan(it)) -it.jumlah else it.jumlah })
    val sett = remember(s) { PG.otSettlements(s).byTx }
    SheetBody(actions = {
        SheetActions(if (k == "belum" && com.asyraf.hadirku.ai.Ai.ready() && list.isNotEmpty()) "Kategorikan dengan AI" else "", { vm.katSemua() }, { vm.close() }, cancel = "Tutup")
    }) {
        SheetTitle(PG.katLabel(k), rich(periodLabel(per) + " · " + list.size + " transaksi · **" + M(tot) + "**"))
        if (list.isNotEmpty()) ListBlock { list.forEach { TxRow(vm, s, it, akruanOn(s), sett, showDate = true) } } else Empty(rich("Tiada transaksi."))
        Note(if (k == "hutang") "Bayar hutang & kad kredit tak perlu kategori." else "Tekan transaksi untuk tukar kategori. Kategori baru juga dipakai untuk transaksi lain dengan nama sama.", Modifier.padding(top = 8.dp))
    }
}

@Composable
fun PoketListSheet(vm: MainViewModel, pid: String) {
    val s by vm.pg.collectAsState()
    val per = vm.lap
    val p = s.pockets.find { it.id == pid } ?: return
    val list = s.transactions.filter { it.poket == pid && (it.jenis == "keluar" || it.jenis == "kad" || PG.isPulangan(it)) && it.tarikh >= per.start && it.tarikh < per.endExcl }
        .sortedWith { a, b -> val c = b.tarikh.compareTo(a.tarikh); if (c != 0) c else b.dibuat.compareTo(a.dibuat) }
    val tot = PG.round2(list.sumOf { if (PG.isPulangan(it)) -it.jumlah else it.jumlah })
    val sett = remember(s) { PG.otSettlements(s).byTx }
    SheetBody(actions = { SheetActions("Semua transaksi", { vm.close(); vm.txPocket = pid; vm.tab = "transaksi" }, { vm.close() }, cancel = "Tutup") }) {
        SheetTitle(p.nama, rich("Belanja " + periodLabel(per) + " · " + list.size + " transaksi · **" + M(tot) + "**"))
        if (list.isNotEmpty()) ListBlock { list.forEach { TxRow(vm, s, it, akruanOn(s), sett, nocat = true) } } else Empty(rich("Tiada belanja dari poket ini dalam bulan ini."))
    }
}

/* ================= CFO, salinan, pengesahan ================= */

@Composable
fun CfoSheet(vm: MainViewModel) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val la = launch()
    var mat by remember { mutableStateOf(s.settings.cfoMatlamat ?: com.asyraf.hadirku.pg.PgCfo.MATLAMAT_LALAI) }
    var soal by remember { mutableStateOf("") }
    var withTx by remember { mutableStateOf(true) }
    val name = "poketgaji-cfo-" + vm.today()
    SheetBody(actions = { SheetActions("", {}, { vm.close() }, cancel = "Tutup") }) {
        SheetTitle("Fail untuk CFO (Claude)", rich("Satu fail dengan semua angka penting dan arahan untuk Claude: baki, gaji & OT, komitmen, hutang, ringkasan 6 bulan, kategori belanja dan semakan data. Hantar kepada Claude dan minta semakan."))
        Form {
            FieldText("Matlamat kewangan (diingat)", mat, { mat = it }, stack = true, lines = 3, maxLen = 400)
            FieldText("Soalan kali ini (pilihan)", soal, { soal = it }, stack = true, lines = 3, maxLen = 600, placeholder = "cth: Patut ke aku beli PC RM3,500 bulan Mac?")
            FieldCheck("Sertakan transaksi 90 hari", withTx, { withTx = it })
        }
        Note("Fail ini tiada kunci API dan tiada nombor akaun, tapi ada nama perkara transaksi. Semak dulu sebelum hantar.", Modifier.padding(vertical = 10.dp))
        MenuBtn("Kongsi ke app Claude", { la.share("$name.md", "text/plain", vm.cfoText(mat, soal, withTx), "Fail CFO PoketGaji " + PG.fmtDate(vm.today())) }, primary = true)
        MenuBtn("Simpan fail (.md)", { la.saveFile("$name.md", "text/markdown", vm.cfoText(mat, soal, withTx), "Fail CFO disimpan", false) })
        MenuBtn("Salin teks", { la.copy(vm.cfoText(mat, soal, withTx), "Teks disalin. Tampal dalam chat Claude.") })
    }
}

@Composable
fun TextOutSheet(vm: MainViewModel, title: String, text: String) {
    val pal = LocalPal.current
    val la = launch()
    SheetBody(actions = { SheetActions("Salin", { la.copy(text, "Disalin") }, { vm.close() }, cancel = "Tutup") }) {
        SheetTitle(title)
        Txt(text, Modifier.padding(horizontal = GL).fillMaxWidth().background(pal.surface2, RoundedCornerShape(8.dp)).padding(10.dp), size = 12f)
    }
}

@Composable
fun ConfirmSheet(vm: MainViewModel, c: Sheet.Confirm) {
    SheetBody(actions = { SheetActions(c.label, { vm.confirmed(c.act) }, { vm.close() }, primaryKind = BtnKind.DANGER) }) {
        SheetTitle(c.title, rich(c.body))
    }
}

@Composable
fun BackupSheet(vm: MainViewModel) {
    val la = launch()
    SheetBody(actions = { SheetActions("", {}, { vm.close() }) }) {
        SheetTitle("Simpan salinan", rich("Paling selamat: hantar ke Google Drive, emel atau WhatsApp diri sendiri, supaya salinan tetap ada walaupun telefon hilang. Salinan ini format PoketGaji (boleh dibuka dalam PoketGaji PWA) dan termasuk rekod kehadiran kerja."))
        MenuBtn("Kongsi ke Drive / emel / WhatsApp", { la.share(vm.backupName(), "application/json", vm.backupJson(), "Salinan PoketGaji " + PG.fmtDate(vm.today())); vm.markBackup(); vm.close() }, primary = true)
        MenuBtn("Simpan ke telefon (pilih folder)", { la.saveFile(vm.backupName(), "application/json", vm.backupJson(), "Salinan disimpan", true) })
        MenuBtn("Salin teks JSON", { la.copy(vm.backupJson(), "Data disalin"); vm.markBackup() })
    }
}

@Composable
fun ImportSheet(vm: MainViewModel, sh: Sheet.ImportAsk) {
    val p = sh.p
    val bits = ArrayList<String>()
    if (p.pg != null) bits.add("Semua data kewangan dalam peranti ini akan diganti dengan salinan dari fail **" + p.name + "** (" + p.txCount + " transaksi).")
    else bits.add("Fail **" + p.name + "** ialah salinan HadirKu lama. Data kewangan kekal.")
    if (p.records != null) bits.add("Rekod kehadiran: **" + p.recCount + " hari** (menggantikan rekod sekarang).") else bits.add("Rekod kehadiran dalam telefon ini kekal.")
    bits.add("Hari yang ada rekod kehadiran lengkap tapi tiada log OT akan diisi sendiri.")
    SheetBody(actions = { SheetActions("Pulihkan", { vm.applyImport(p) }, { vm.close() }, primaryKind = BtnKind.DANGER) }) {
        SheetTitle("Pulihkan salinan?", rich(bits.joinToString("\n\n")))
    }
}


