package com.asyraf.hadirku.engine.savings

import com.asyraf.hadirku.engine.core.DEFAULT_CURRENCY
import com.asyraf.hadirku.engine.core.Money
import com.asyraf.hadirku.engine.ledger.AccountKind
import com.asyraf.hadirku.engine.ledger.LedgerBook
import com.asyraf.hadirku.engine.ledger.PgLedgerAdapter
import com.asyraf.hadirku.pg.PgState
import com.asyraf.hadirku.pg.Ramalan
import java.math.RoundingMode
import java.time.LocalDate
import java.time.temporal.ChronoUnit

/* =====================================================================
 * Engine 8 — Savings Goals
 * Contributions/withdrawals are EARMARKS on an owned account, not money movements: they never
 * create cash. Earmarks on an account are capped at that account's real balance (oldest goal first),
 * so a goal can never show more money than actually exists.
 * ===================================================================== */

data class SavingsGoal(
    val id: String,
    val name: String,
    val target: Money,
    val targetDate: LocalDate? = null,
    /** ledger account holding the money (e.g. "p:<pocketId>"); null = any liquid money */
    val accountId: String? = null,
    val createdOn: LocalDate,
    val currency: String = DEFAULT_CURRENCY,
    /** derived from an existing savings pocket (read-only; its balance is the allocation) */
    val fromPocket: Boolean = false,
)

data class GoalMove(val id: String, val goalId: String, val date: LocalDate, val amount: Money /* + contribute, − withdraw */)

enum class Feasibility { DONE, FEASIBLE, TIGHT, NOT_FEASIBLE, NO_TARGET_DATE, PAST_DUE }
enum class GoalMoveIssue { UNKNOWN_GOAL, ZERO_AMOUNT, WITHDRAW_MORE_THAN_ALLOCATED, NOT_ENOUGH_FREE_BALANCE }

data class GoalProgress(
    val goal: SavingsGoal,
    /** sum of moves (what the user asked to set aside) */
    val requested: Money,
    /** what is actually backed by real money (≤ requested) */
    val allocated: Money,
    val cappedByBalance: Boolean,
    val remaining: Money,
    /** progress in basis points (10000 = 100%) */
    val progressBp: Int,
    val monthsLeft: Long?,
    val requiredMonthly: Money?,
    val feasibility: Feasibility,
)

object SavingsEngine {

    /** Existing savings pockets with a target (sasaran) become read-only goals backed by the pocket balance. */
    fun goalsFromPockets(s: PgState, today: LocalDate): List<SavingsGoal> =
        Ramalan.poketSimpanan(s).filter { it.sasaran > 0.004 }.mapNotNull { p ->
            val t = Money.fromDoubleOrNull(p.sasaran) ?: return@mapNotNull null
            SavingsGoal("pocket:" + p.id, p.nama, t, null, PgLedgerAdapter.pocketAcc(p.id), today, fromPocket = true)
        }

    fun requiredMonthly(remaining: Money, today: LocalDate, targetDate: LocalDate): Pair<Long, Money> {
        val months = ChronoUnit.MONTHS.between(today.withDayOfMonth(1), targetDate.withDayOfMonth(1)).coerceAtLeast(1)
        return months to remaining.div(months, RoundingMode.CEILING)
    }

    fun progress(
        goals: List<SavingsGoal>, moves: List<GoalMove>, book: LedgerBook, today: LocalDate,
        monthlySurplus: Money?,
    ): List<GoalProgress> {
        val bal = book.balances(today)
        val liquidTotal = Money.sum(book.accounts.values.filter { it.kind == AccountKind.ASSET }.map { bal[it.id] ?: Money.ZERO }).coerceAtLeast(Money.ZERO)
        // remaining real money per account (and in total for goals without an account)
        val freeByAccount = HashMap<String, Money>()
        var freeAny = liquidTotal
        return goals.sortedWith(compareBy({ it.createdOn }, { it.id })).map { g ->
            val requested = if (g.fromPocket) (g.accountId?.let { bal[it] } ?: Money.ZERO).coerceAtLeast(Money.ZERO)
                else Money.sum(moves.filter { it.goalId == g.id && !it.date.isAfter(today) }.map { it.amount }).coerceAtLeast(Money.ZERO)
            val acc = g.accountId
            val free = if (acc != null) freeByAccount.getOrPut(acc) { (bal[acc] ?: Money.ZERO).coerceAtLeast(Money.ZERO) } else freeAny
            val allocated = requested.min(free).min(freeAny)
            if (acc != null) freeByAccount[acc] = free - allocated
            freeAny -= allocated
            val remaining = (g.target - allocated).coerceAtLeast(Money.ZERO)
            val bp = if (!g.target.isPositive) 10000 else ((allocated.sen * 10000) / g.target.sen).coerceIn(0, 10000).toInt()
            var months: Long? = null; var need: Money? = null
            val feas = when {
                !remaining.isPositive -> Feasibility.DONE
                g.targetDate == null -> Feasibility.NO_TARGET_DATE
                g.targetDate.isBefore(today) -> Feasibility.PAST_DUE
                else -> {
                    val (m, req) = requiredMonthly(remaining, today, g.targetDate); months = m; need = req
                    when {
                        monthlySurplus == null || !monthlySurplus.isPositive -> Feasibility.NOT_FEASIBLE
                        req <= monthlySurplus.times(java.math.BigDecimal("0.8")) -> Feasibility.FEASIBLE
                        req <= monthlySurplus -> Feasibility.TIGHT
                        else -> Feasibility.NOT_FEASIBLE
                    }
                }
            }
            GoalProgress(g, requested, allocated, allocated < requested, remaining, bp, months, need, feas)
        }
    }

    /** Check a contribution/withdrawal before it is stored. */
    fun validateMove(goals: List<SavingsGoal>, moves: List<GoalMove>, book: LedgerBook, m: GoalMove): List<GoalMoveIssue> {
        val g = goals.find { it.id == m.goalId } ?: return listOf(GoalMoveIssue.UNKNOWN_GOAL)
        if (m.amount.isZero) return listOf(GoalMoveIssue.ZERO_AMOUNT)
        val cur = Money.sum(moves.filter { it.goalId == g.id }.map { it.amount })
        if (m.amount.isNegative && (cur + m.amount).isNegative) return listOf(GoalMoveIssue.WITHDRAW_MORE_THAN_ALLOCATED)
        if (m.amount.isPositive) {
            val p = progress(goals, moves, book, m.date, null)
            val free = if (g.accountId != null) {
                val used = p.filter { it.goal.accountId == g.accountId }.fold(Money.ZERO) { a, x -> a + x.allocated }
                book.balance(g.accountId, m.date) - used
            } else {
                val liquid = Money.sum(book.accounts.values.filter { it.kind == AccountKind.ASSET }.map { book.balance(it.id, m.date) })
                liquid - p.fold(Money.ZERO) { a, x -> a + x.allocated }
            }
            if (m.amount > free) return listOf(GoalMoveIssue.NOT_ENOUGH_FREE_BALANCE)
        }
        return emptyList()
    }

    fun totalEarmarked(progress: List<GoalProgress>): Money = progress.fold(Money.ZERO) { a, p -> a + p.allocated }
}
