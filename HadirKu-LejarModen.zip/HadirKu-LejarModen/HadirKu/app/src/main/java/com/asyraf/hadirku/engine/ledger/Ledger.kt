package com.asyraf.hadirku.engine.ledger

import com.asyraf.hadirku.engine.core.DEFAULT_CURRENCY
import com.asyraf.hadirku.engine.core.DateRange
import com.asyraf.hadirku.engine.core.Money
import java.time.Instant
import java.time.LocalDate

/* =====================================================================
 * Engine 0 — Transaction Ledger (foundation)
 *
 * Sign convention: every account balance is "value held".
 *   asset account  → positive = money you have
 *   liability      → negative = money you owe (a card owing RM500 has balance −500.00)
 * An entry moves [amount] (always > 0) FROM one account TO another. Either side may be null,
 * meaning "outside the tracked books" (income source, shop, bank interest, …).
 *   balance(a) = Σ amount where to = a  −  Σ amount where from = a
 * Net worth = Σ all balances, so a transfer between owned accounts never changes it.
 * ===================================================================== */

enum class AccountKind { ASSET, LIABILITY }

/** Where an asset account's money physically sits, or what kind of liability it is. */
enum class Storage { BANK, EWALLET, CASH, CREDIT_CARD, EPP, LOAN, BNPL, OTHER_LIABILITY }

data class Account(
    val id: String,
    val name: String,
    val kind: AccountKind,
    val storage: Storage,
    val currency: String = DEFAULT_CURRENCY,
    /** id in the source data (pocket id / debt id / EPP plan id) — for adapters only */
    val sourceId: String? = null,
    /** for EPP sub-accounts: the card liability that installments are billed into */
    val parentId: String? = null,
) {
    val isLiquid: Boolean get() = kind == AccountKind.ASSET
}

enum class EntryType {
    INCOME, EXPENSE, TRANSFER, DEBT_DISBURSEMENT, DEBT_REPAYMENT, REFUND, ADJUSTMENT, OPENING_BALANCE,
    /** interest or fee added to a liability (identifiable separately from principal) */
    CHARGE,
    /** reverses [Entry.reverses] exactly; both stay in the book for audit */
    REVERSAL,
}

enum class IncomeKind { SALARY, OVERTIME, OTHER }
enum class ChargeKind { INTEREST, FEE }

data class Entry(
    val id: String,
    val date: LocalDate,
    val type: EntryType,
    val amount: Money,
    val from: String? = null,
    val to: String? = null,
    val currency: String = DEFAULT_CURRENCY,
    val createdAt: Instant? = null,
    /** spending category id (EXPENSE / REFUND); null = uncategorised */
    val category: String? = null,
    val incomeKind: IncomeKind? = null,
    val chargeKind: ChargeKind? = null,
    val memo: String = "",
    val commitmentId: String? = null,
    val debtId: String? = null,
    /** id of the source record in the existing app data (Tx id, debt log id, …) */
    val sourceId: String? = null,
    /** REVERSAL: the entry being reversed */
    val reverses: String? = null,
    /** REFUND: the EXPENSE being refunded */
    val refundOf: String? = null,
    /** true when the date is in the future relative to "as of" — set by readers, not stored */
    val pendingHint: Boolean = false,
) {
    /** Signed effect on [accountId]. */
    fun effectOn(accountId: String): Money {
        var m = Money.ZERO
        if (to == accountId) m += amount
        if (from == accountId) m -= amount
        return m
    }
}

enum class AuditAction { CREATED, REVERSED, REFUNDED, ACCOUNT_ADDED, DUPLICATE_SKIPPED, REJECTED }

data class AuditEvent(val seq: Long, val at: Instant, val action: AuditAction, val entryId: String?, val ref: String? = null)

/** Machine-readable rule violations (no user-facing text is produced by the engines). */
enum class LedgerIssue {
    DUPLICATE_ID, UNKNOWN_ACCOUNT, NON_POSITIVE_AMOUNT, SAME_FROM_TO, NO_SIDE, CURRENCY_MISMATCH,
    TRANSFER_NEEDS_TWO_OWNED, EXPENSE_NEEDS_SOURCE, INCOME_NEEDS_DESTINATION, REPAYMENT_TARGET_NOT_LIABILITY,
    DISBURSEMENT_SOURCE_NOT_LIABILITY, CHARGE_SOURCE_NOT_LIABILITY, CHARGE_NEEDS_KIND,
    REVERSAL_TARGET_MISSING, ALREADY_REVERSED, REVERSAL_MISMATCH,
    REFUND_TARGET_MISSING, REFUND_TARGET_NOT_EXPENSE, REFUND_EXCEEDS_ORIGINAL,
}

/**
 * Immutable ledger book. Every mutation goes through [LedgerOps] and returns a new book
 * (copy-on-write), which makes batches atomic: either the whole batch is applied or nothing is.
 */
class LedgerBook(
    val accounts: Map<String, Account> = emptyMap(),
    val entries: List<Entry> = emptyList(),
    /** idempotency key → entry id */
    val idempotency: Map<String, String> = emptyMap(),
    val audit: List<AuditEvent> = emptyList(),
) {
    private val byId: Map<String, Entry> by lazy { entries.associateBy { it.id } }
    private val reversedIds: Set<String> by lazy { entries.mapNotNull { it.reverses }.toSet() }

    fun entry(id: String): Entry? = byId[id]
    fun isReversed(id: String): Boolean = id in reversedIds

    /** Deterministic order: date, creation time, then id. */
    fun ordered(): List<Entry> = entries.sortedWith(ENTRY_ORDER)

    /** Entries that still count for reporting: neither reversed nor a reversal. */
    fun effective(): List<Entry> = entries.filter { it.type != EntryType.REVERSAL && !isReversed(it.id) }

    fun balance(accountId: String, asOf: LocalDate? = null): Money {
        var b = Money.ZERO
        for (e in entries) if (asOf == null || !e.date.isAfter(asOf)) b += e.effectOn(accountId)
        return b
    }

    fun balances(asOf: LocalDate? = null): Map<String, Money> {
        val out = LinkedHashMap<String, Money>()
        accounts.keys.forEach { out[it] = Money.ZERO }
        for (e in entries) {
            if (asOf != null && e.date.isAfter(asOf)) continue
            e.to?.let { if (out.containsKey(it)) out[it] = out.getValue(it) + e.amount }
            e.from?.let { if (out.containsKey(it)) out[it] = out.getValue(it) - e.amount }
        }
        return out
    }

    fun netWorth(asOf: LocalDate? = null): Money = Money.sum(balances(asOf).values)

    /** Running balance of one account in deterministic order. */
    fun runningBalance(accountId: String): List<Pair<Entry, Money>> {
        var b = Money.ZERO
        return ordered().filter { it.from == accountId || it.to == accountId }.map { e -> b += e.effectOn(accountId); e to b }
    }

    /** Remaining refundable amount of an EXPENSE (original − effective refunds). */
    fun refundableLeft(expenseId: String): Money {
        val orig = entry(expenseId) ?: return Money.ZERO
        val refunded = entries.filter { it.type == EntryType.REFUND && it.refundOf == expenseId && !isReversed(it.id) }.sumOf { it.amount.sen }
        return Money(orig.amount.sen - refunded)
    }

    fun copy(
        accounts: Map<String, Account> = this.accounts,
        entries: List<Entry> = this.entries,
        idempotency: Map<String, String> = this.idempotency,
        audit: List<AuditEvent> = this.audit,
    ) = LedgerBook(accounts, entries, idempotency, audit)

    companion object {
        val ENTRY_ORDER: Comparator<Entry> = compareBy<Entry>({ it.date }, { it.createdAt ?: Instant.EPOCH }, { it.id })
    }
}

sealed class PostResult {
    data class Posted(val entry: Entry) : PostResult()
    /** Same idempotency key already posted — nothing changed. */
    data class Duplicate(val existingId: String) : PostResult()
    data class Rejected(val issues: List<LedgerIssue>) : PostResult()
}

data class BookAndResult<R>(val book: LedgerBook, val result: R)

object LedgerOps {

    fun addAccount(book: LedgerBook, account: Account, at: Instant): LedgerBook {
        if (book.accounts.containsKey(account.id)) return book
        return book.copy(
            accounts = book.accounts + (account.id to account),
            audit = book.audit + AuditEvent(nextSeq(book), at, AuditAction.ACCOUNT_ADDED, null, account.id),
        )
    }

    /** Validate an entry against the book's rules. Empty list = valid. */
    fun validate(book: LedgerBook, e: Entry): List<LedgerIssue> {
        val out = ArrayList<LedgerIssue>()
        if (book.entry(e.id) != null) out += LedgerIssue.DUPLICATE_ID
        if (!e.amount.isPositive) out += LedgerIssue.NON_POSITIVE_AMOUNT
        if (e.from == null && e.to == null) out += LedgerIssue.NO_SIDE
        if (e.from != null && e.from == e.to) out += LedgerIssue.SAME_FROM_TO
        val fa = e.from?.let { book.accounts[it] }
        val ta = e.to?.let { book.accounts[it] }
        if ((e.from != null && fa == null) || (e.to != null && ta == null)) out += LedgerIssue.UNKNOWN_ACCOUNT
        if ((fa != null && fa.currency != e.currency) || (ta != null && ta.currency != e.currency)) out += LedgerIssue.CURRENCY_MISMATCH
        when (e.type) {
            EntryType.TRANSFER -> if (fa == null || ta == null) out += LedgerIssue.TRANSFER_NEEDS_TWO_OWNED
            EntryType.EXPENSE -> if (fa == null) out += LedgerIssue.EXPENSE_NEEDS_SOURCE
            EntryType.INCOME -> if (ta == null) out += LedgerIssue.INCOME_NEEDS_DESTINATION
            EntryType.DEBT_REPAYMENT -> if (ta == null || ta.kind != AccountKind.LIABILITY) out += LedgerIssue.REPAYMENT_TARGET_NOT_LIABILITY
            EntryType.DEBT_DISBURSEMENT -> if (fa == null || fa.kind != AccountKind.LIABILITY) out += LedgerIssue.DISBURSEMENT_SOURCE_NOT_LIABILITY
            EntryType.CHARGE -> {
                if (fa == null || fa.kind != AccountKind.LIABILITY) out += LedgerIssue.CHARGE_SOURCE_NOT_LIABILITY
                if (e.chargeKind == null) out += LedgerIssue.CHARGE_NEEDS_KIND
            }
            EntryType.REVERSAL -> {
                val t = e.reverses?.let { book.entry(it) }
                if (t == null) out += LedgerIssue.REVERSAL_TARGET_MISSING
                else {
                    if (book.isReversed(t.id)) out += LedgerIssue.ALREADY_REVERSED
                    if (t.amount != e.amount || t.from != e.to || t.to != e.from) out += LedgerIssue.REVERSAL_MISMATCH
                }
            }
            EntryType.REFUND -> {
                val t = e.refundOf?.let { book.entry(it) }
                // pulangan peringkat kategori (tiada transaksi asal dipautkan) dibenarkan jika ada kategori
                if (e.refundOf == null && e.category != null) Unit
                else if (t == null) out += LedgerIssue.REFUND_TARGET_MISSING
                else if (t.type != EntryType.EXPENSE) out += LedgerIssue.REFUND_TARGET_NOT_EXPENSE
                else if (e.amount > book.refundableLeft(t.id)) out += LedgerIssue.REFUND_EXCEEDS_ORIGINAL
            }
            EntryType.ADJUSTMENT, EntryType.OPENING_BALANCE -> Unit
        }
        return out
    }

    /**
     * Post one entry. With an [idempotencyKey] already seen, nothing changes and [PostResult.Duplicate]
     * is returned (duplicate imports never create a second posted entry).
     */
    fun post(book: LedgerBook, e: Entry, at: Instant, idempotencyKey: String? = null): BookAndResult<PostResult> {
        if (idempotencyKey != null) book.idempotency[idempotencyKey]?.let { existing ->
            val b = book.copy(audit = book.audit + AuditEvent(nextSeq(book), at, AuditAction.DUPLICATE_SKIPPED, existing, idempotencyKey))
            return BookAndResult(b, PostResult.Duplicate(existing))
        }
        val issues = validate(book, e)
        if (issues.isNotEmpty()) return BookAndResult(book, PostResult.Rejected(issues))
        val posted = if (e.createdAt == null) e.copy(createdAt = at) else e
        val action = when (e.type) { EntryType.REVERSAL -> AuditAction.REVERSED; EntryType.REFUND -> AuditAction.REFUNDED; else -> AuditAction.CREATED }
        val b = book.copy(
            entries = book.entries + posted,
            idempotency = if (idempotencyKey != null) book.idempotency + (idempotencyKey to posted.id) else book.idempotency,
            audit = book.audit + AuditEvent(nextSeq(book), at, action, posted.id, e.reverses ?: e.refundOf),
        )
        return BookAndResult(b, PostResult.Posted(posted))
    }

    /**
     * Atomic batch: all entries are validated against the progressively updated book.
     * If any entry is rejected, the ORIGINAL book is returned unchanged.
     */
    fun postBatch(book: LedgerBook, items: List<Pair<Entry, String?>>, at: Instant): BookAndResult<List<PostResult>> {
        var cur = book
        val results = ArrayList<PostResult>()
        for ((e, key) in items) {
            val r = post(cur, e, at, key)
            results += r.result
            if (r.result is PostResult.Rejected) return BookAndResult(book, results)
            cur = r.book
        }
        return BookAndResult(cur, results)
    }

    /** Reverse an entry exactly (swapped sides, same amount). The original stays for audit. */
    fun reverse(book: LedgerBook, entryId: String, reversalId: String, date: LocalDate, at: Instant): BookAndResult<PostResult> {
        val t = book.entry(entryId) ?: return BookAndResult(book, PostResult.Rejected(listOf(LedgerIssue.REVERSAL_TARGET_MISSING)))
        val r = Entry(
            id = reversalId, date = date, type = EntryType.REVERSAL, amount = t.amount, from = t.to, to = t.from,
            currency = t.currency, reverses = t.id, category = t.category, debtId = t.debtId, commitmentId = t.commitmentId,
        )
        return post(book, r, at)
    }

    /**
     * Refund (full or partial) of an EXPENSE. Money returns to the account the expense came from
     * (a pocket, or the card it was charged to) unless [to] is given. Category reporting nets it off.
     */
    fun refund(book: LedgerBook, expenseId: String, amount: Money, refundId: String, date: LocalDate, at: Instant, to: String? = null): BookAndResult<PostResult> {
        val t = book.entry(expenseId) ?: return BookAndResult(book, PostResult.Rejected(listOf(LedgerIssue.REFUND_TARGET_MISSING)))
        val r = Entry(
            id = refundId, date = date, type = EntryType.REFUND, amount = amount, to = to ?: t.from,
            currency = t.currency, refundOf = t.id, category = t.category,
        )
        return post(book, r, at)
    }

    private fun nextSeq(book: LedgerBook): Long = (book.audit.lastOrNull()?.seq ?: 0L) + 1
}

/** Whole-book integrity check (used after adapters build a book and in tests). */
object LedgerIntegrity {
    data class Problem(val entryId: String?, val issue: LedgerIssue)

    fun check(book: LedgerBook): List<Problem> {
        val out = ArrayList<Problem>()
        val seen = HashSet<String>()
        var replay = LedgerBook(accounts = book.accounts)
        for (e in book.entries) {
            if (!seen.add(e.id)) { out += Problem(e.id, LedgerIssue.DUPLICATE_ID); continue }
            // validate each entry against the book as it was before it (refund/reversal targets must precede)
            val issues = LedgerOps.validate(replay, e).filter { it != LedgerIssue.DUPLICATE_ID }
            issues.forEach { out += Problem(e.id, it) }
            replay = replay.copy(entries = replay.entries + e)
        }
        return out
    }
}

/** Reporting over effective entries (reversed pairs removed, refunds netted). */
object LedgerReports {
    data class Totals(
        val income: Money, val incomeSalary: Money, val incomeOvertime: Money, val incomeOther: Money,
        /** consumption spending net of refunds (excludes transfers, repayments, disbursements, charges) */
        val expense: Money,
        val interest: Money, val fees: Money,
        val debtRepayment: Money, val debtDisbursement: Money,
        val transfers: Money, val adjustmentsIn: Money, val adjustmentsOut: Money,
    )

    fun totals(book: LedgerBook, range: DateRange? = null): Totals {
        var inc = Money.ZERO; var sal = Money.ZERO; var ot = Money.ZERO; var oth = Money.ZERO
        var exp = Money.ZERO; var intr = Money.ZERO; var fee = Money.ZERO
        var rep = Money.ZERO; var dis = Money.ZERO; var tr = Money.ZERO; var adjIn = Money.ZERO; var adjOut = Money.ZERO
        for (e in book.effective()) {
            if (range != null && e.date !in range) continue
            when (e.type) {
                EntryType.INCOME -> {
                    inc += e.amount
                    when (e.incomeKind) { IncomeKind.SALARY -> sal += e.amount; IncomeKind.OVERTIME -> ot += e.amount; else -> oth += e.amount }
                }
                EntryType.EXPENSE -> exp += e.amount
                EntryType.REFUND -> exp -= e.amount
                EntryType.CHARGE -> if (e.chargeKind == ChargeKind.INTEREST) intr += e.amount else fee += e.amount
                EntryType.DEBT_REPAYMENT -> rep += e.amount
                EntryType.DEBT_DISBURSEMENT -> dis += e.amount
                EntryType.TRANSFER -> tr += e.amount
                EntryType.ADJUSTMENT -> if (e.to != null) adjIn += e.amount else adjOut += e.amount
                EntryType.OPENING_BALANCE, EntryType.REVERSAL -> Unit
            }
        }
        return Totals(inc, sal, ot, oth, exp, intr, fee, rep, dis, tr, adjIn, adjOut)
    }

    /** Net spending per category (null key = uncategorised). Refunds reduce the original's category. */
    fun expenseByCategory(book: LedgerBook, range: DateRange? = null): Map<String?, Money> {
        val out = LinkedHashMap<String?, Money>()
        for (e in book.effective()) {
            if (range != null && e.date !in range) continue
            val sign = when (e.type) { EntryType.EXPENSE -> 1; EntryType.REFUND -> -1; else -> 0 }
            if (sign == 0) continue
            val cat = if (e.type == EntryType.REFUND) (e.refundOf?.let { book.entry(it)?.category } ?: e.category) else e.category
            out[cat] = (out[cat] ?: Money.ZERO) + (if (sign > 0) e.amount else -e.amount)
        }
        return out
    }
}
