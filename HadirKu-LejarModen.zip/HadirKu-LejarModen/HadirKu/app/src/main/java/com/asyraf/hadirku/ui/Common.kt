package com.asyraf.hadirku.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.size
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import com.asyraf.hadirku.i18n.tr
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.asyraf.hadirku.MainViewModel
import com.asyraf.hadirku.pg.KadLog
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.PgState
import com.asyraf.hadirku.pg.Tx

/* Pembantu paparan transaksi, dikongsi oleh Transaksi, Laporan, senarai kategori & poket. */

fun pname(s: PgState, id: String): String = PG.pocketName(s, id)
fun jenisLabel(id: String): String = PG.JENIS.find { it.id == id }?.label ?: id
fun hariLabel(id: String) = PG.JENIS_HARI.find { it.id == id } ?: PG.JENIS_HARI[0]
fun jenisHutang(id: String): String = PG.JENIS_HUTANG.find { it.id == id }?.label ?: "Hutang"
fun akruanOn(s: PgState): Boolean = s.settings.otPendapatan
fun longDate(d: String): String { val p = PG.parse(d); return PG.HARI_PENUH[PG.weekday(d)] + ", " + p.d + " " + PG.BULAN_PENUH[p.m - 1] + " " + p.y }
fun isKadPay(s: PgState, t: Tx): Boolean = t.jenis == "keluar" && t.hutangId.isNotEmpty() && s.debts.any { it.id == t.hutangId && it.jenis == "kad" }
fun ymAfter(today: String, n: Int): String = PG.shiftYm(PG.ym(today), n)
fun monthShort(today: String, n: Int): String { val p = ymAfter(today, n).split("-"); return PG.BULAN[p[1].toInt() - 1] + " " + p[0] }
fun tempoh(n: Int): String = if (n < 12) "$n bulan" else (n / 12).toString() + " thn" + (if (n % 12 != 0) " " + (n % 12) + " bln" else "")
fun fmtYm(s: String): String { val p = PG.parse(s); return PG.BULAN[p.m - 1] + " " + p.y }

fun txCat(s: PgState, t: Tx): String = when (t.jenis) {
    "pindah" -> "Pindah"
    "masuk" -> "Masuk"
    "baki-awal" -> "Baki awal"
    "pelarasan+", "pelarasan-" -> "Pelarasan"
    "tunai-kad" -> "Tunai kad"
    else -> pname(s, t.poket)
}

fun txSub(s: PgState, t: Tx, om: Boolean, sett: Map<String, Double>): String {
    if (t.jenis == "pindah") return pname(s, t.poket) + " → " + pname(s, t.ke)
    if (t.jenis == "kad") {
        val kc = s.debts.find { it.id == t.kadId }
        return "Guna " + (kc?.nama ?: "kad (dipadam)") + (if (t.catatan.isNotEmpty()) " · " + t.catatan else "")
    }
    if (t.jenis == "tunai-kad") {
        val kt = s.debts.find { it.id == t.kadId }
        return "Dari " + (kt?.nama ?: "kad (dipadam)") + " → " + pname(s, t.poket) + (if ((t.fee ?: 0.0) > 0) " · fee " + M(t.fee) else "") + " · pinjaman" + (if (t.catatan.isNotEmpty()) " · " + t.catatan else "")
    }
    val bits = ArrayList<String>()
    if (t.jenis != "keluar") bits.add(pname(s, t.poket))
    if (t.komitmenId.isNotEmpty() && s.commitments.any { it.id == t.komitmenId }) bits.add("Komitmen")
    if (t.hutangId.isNotEmpty()) {
        val d = s.debts.find { it.id == t.hutangId }
        if (d != null) bits.add("Hutang " + d.nama + if (om && d.jenis == "kad") " · pindah ke kad, bukan belanja" else "")
    }
    val ob = sett[t.id]
    if (t.jenis == "masuk" && om && ob != null) bits.add("termasuk OT " + M(ob))
    if (t.catatan.isNotEmpty()) bits.add(t.catatan)
    return bits.joinToString(" · ")
}

/** Jumlah transaksi berwarna: masuk hijau (+), keluar merah lembut (−), pindah kelabu. */
fun txAmount(s: PgState, t: Tx, om: Boolean, pal: Pal): Pair<String, Color> = when {
    t.jenis == "pindah" -> M(t.jumlah) to pal.muted
    t.jenis == "tunai-kad" -> "+" + M(t.jumlah) to pal.muted
    om && isKadPay(s, t) -> M(-t.jumlah) to pal.muted
    t.jenis == "kad" -> M(-t.jumlah) to pal.out
    PG.flows(t).inn != null -> "+" + M(t.jumlah) to pal.inn
    else -> M(-t.jumlah) to pal.out
}

/** Ikon kecil untuk baris istimewa (OT / kad) yang bukan transaksi biasa. */
private fun lrowVis(cat: String?, pal: Pal): Vis? = when (cat) {
    null -> null
    "OT" -> Vis(Ic.KERJA, pal.inn)
    "Kad" -> Vis(Ic.CARD, pal.out)
    else -> Vis(Ic.TAG, pal.muted)
}

/** Baris lejar (gaya Lejar Moden): ikon | nama + keterangan | jumlah. [cat] kekal sebagai label kecil. */
@Composable
fun LRow(cat: String?, title: String, sub: String?, amt: String, amtColor: Color, onClick: () -> Unit, tag: String? = null) {
    val pal = LocalPal.current
    val vis = lrowVis(cat, pal)
    val sub2 = if (cat != null && cat != "OT" && cat != "Kad") listOfNotNull(cat, sub?.ifEmpty { null }).joinToString(" · ") else sub
    LejarRow(vis, title, sub2, amt, amtColor, onClick, tag = tag)
}

/** Tag kecil untuk transaksi yang terikat kepada komitmen / hutang / kad (status sebenar, bukan rekaan). */
fun txTag(s: PgState, t: Tx): Pair<String, Tone>? = when {
    t.komitmenId.isNotEmpty() && s.commitments.any { it.id == t.komitmenId } -> "Komitmen" to Tone.INFO
    t.jenis == "keluar" && t.hutangId.isNotEmpty() -> "Hutang" to Tone.WARN
    t.jenis == "kad" -> "Kad" to Tone.NEUTRAL
    t.jenis == "tunai-kad" -> "Pinjaman kad" to Tone.WARN
    t.jenis == "pindah" -> "Pindah" to Tone.NEUTRAL
    else -> null
}

/**
 * Baris lejar asas: jubin ikon kategori, tajuk, keterangan (memo / poket), jumlah +/− berwarna.
 * Maklumat masuk/keluar juga ditanda dengan "+" / "−" (bukan warna sahaja).
 */
@Composable
fun LejarRow(
    vis: Vis?, title: String, sub: String?, amt: String, amtColor: Color, onClick: () -> Unit,
    tag: String? = null, pill: Pair<String, Tone>? = null, menu: (@Composable (dismiss: () -> Unit) -> Unit)? = null,
) {
    val pal = LocalPal.current
    Row(
        Modifier.fillMaxWidth().hairlines(pal.line).pressable(onClick, scaleTo = 0.985f).heightIn(min = 62.dp)
            .padding(start = 14.dp, end = if (menu != null) 2.dp else 14.dp, top = 10.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (vis != null) {
            IconTile(vis.ic, vis.fg, size = 42.dp, icon = 21.dp)
            Spacer(Modifier.width(12.dp))
        }
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Txt(title, Modifier.weight(1f, fill = false), size = 15f, weight = FontWeight.SemiBold, maxLines = 1)
                if (tag != null) {
                    Spacer(Modifier.width(6.dp))
                    Txt(tag, Modifier.background(pal.accentSoft, RoundedCornerShape(6.dp)).padding(horizontal = 6.dp, vertical = 1.dp), size = 11f, weight = FontWeight.SemiBold, color = pal.accentStrong)
                }
            }
            if (!sub.isNullOrEmpty()) Txt(sub, size = 12.5f, color = pal.muted, maxLines = 2, lh = 17f)
        }
        Spacer(Modifier.width(10.dp))
        Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Txt(amt, size = 15f, weight = FontWeight.Bold, color = amtColor, num = true, maxLines = 1)
            if (pill != null) Pill(pill.first, pill.second)
        }
        if (menu != null) {
            var open by remember { mutableStateOf(false) }
            Box {
                Box(
                    Modifier.size(width = 36.dp, height = 44.dp).clip(RoundedCornerShape(10.dp)).clickable { open = true }
                        .semantics { contentDescription = tr("Pilihan transaksi") },
                    contentAlignment = Alignment.Center,
                ) { Ico(Ic.DOTS, pal.muted, 18.dp) }
                DropdownMenu(expanded = open, onDismissRequest = { open = false }) { menu { open = false } }
            }
        }
    }
}

@Composable
fun TxRow(vm: MainViewModel, s: PgState, t: Tx, om: Boolean, sett: Map<String, Double>, showDate: Boolean = false, nocat: Boolean = false, menu: Boolean = false) {
    val pal = LocalPal.current
    val bits = ArrayList<String>()
    if (showDate || nocat) bits.add(PG.fmtShort(t.tarikh))
    if (nocat) bits.add(PG.katLabel(PG.kategoriOf(t)))
    // belanja: nama poket (dulu di lajur kategori) — masuk/pindah sudah ada dalam txSub
    if (!nocat && (t.jenis == "keluar" || t.jenis == "kad" || t.jenis == "pelarasan-")) bits.add(pname(s, t.poket))
    val s0 = txSub(s, t, om, sett)
    if (s0.isNotEmpty()) bits.add(s0)
    val (a, c) = txAmount(s, t, om, pal)
    val menuUi: @Composable (() -> Unit) -> Unit = { dismiss ->
        DropdownMenuItem(text = { Txt("Sunting / padam", size = 15f) }, onClick = { dismiss(); vm.editTx(t.id) })
        DropdownMenuItem(text = { Txt("Butiran hari ini", size = 15f) }, onClick = { dismiss(); vm.open(com.asyraf.hadirku.Sheet.Day(t.tarikh)) })
        if (t.jenis in setOf("masuk", "keluar", "kad", "pindah")) DropdownMenuItem(
            text = { Txt("Ulang transaksi (hari ini)", size = 15f) },
            onClick = { dismiss(); vm.newTx(t.copy(id = "", tarikh = "", dibuat = 0, otBayar = null, katAuto = false), "Ulang transaksi") },
        )
    }
    LejarRow(
        txVis(s, t, pal), t.perkara.ifEmpty { jenisLabel(t.jenis) }, bits.joinToString(" · "), a, c, { vm.editTx(t.id) },
        pill = txTag(s, t),
        menu = if (menu) menuUi else null,
    )
}

@Composable
fun KadLogRow(vm: MainViewModel, l: KadLog) {
    val pal = LocalPal.current
    val fee = l.jenis == "fee"
    LRow(
        "Kad",
        (if (fee) "Fee tunai · " else if (l.jenis == "faedah") "Faedah & caj · " else "Belanja kad · ") + l.nama,
        (if (fee) "Perbelanjaan (caj kad)" else "Rekod hutang") + if (l.catatan.isNotEmpty()) " · " + l.catatan else "",
        M(-l.jumlah), pal.out,
        { if (fee && l.txId != null) vm.editTx(l.txId) else vm.open(com.asyraf.hadirku.Sheet.HHist(l.debtId)) },
    )
}

class BarSpec(val frac: Double, val over: Boolean, val warn: Boolean)

/** Baris poket / hutang (nama kiri, jumlah kanan, keterangan di bawah). */
@Composable
fun PRow(name: String, right: String, onClick: () -> Unit, tag: String? = null, neg: Boolean = false, subs: List<String> = emptyList(), rightColor: Color? = null, bar: BarSpec? = null) {
    val pal = LocalPal.current
    Column(Modifier.fillMaxWidth().hairlines(pal.line).pressable(onClick, scaleTo = 0.985f).heightIn(min = 52.dp).padding(horizontal = GL, vertical = 13.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                Txt(name, Modifier.weight(1f, fill = false), size = 15f, weight = FontWeight.SemiBold)
                if (tag != null) { Spacer(Modifier.width(6.dp)); Txt(tag.uppercase(), size = 11f, weight = FontWeight.SemiBold, color = pal.muted) }
            }
            Spacer(Modifier.width(12.dp))
            Txt(right, size = 15f, weight = FontWeight.SemiBold, color = rightColor ?: if (neg) pal.bad else pal.ink, num = true)
            Spacer(Modifier.width(6.dp))
            Ico(Ic.CHEVRON, pal.muted, 14.dp, stroke = 2f)
        }
        if (bar != null) { Spacer(Modifier.padding(top = 6.dp)); Bar(bar.frac, over = bar.over, warn = bar.warn) }
        subs.forEach { Txt(it, Modifier.padding(top = 4.dp), size = 12.5f, color = pal.muted) }
    }
}
