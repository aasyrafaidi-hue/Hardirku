package com.asyraf.hadirku.engine.ledger

import com.asyraf.hadirku.engine.core.Money
import com.asyraf.hadirku.pg.Debt
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.PgState
import com.asyraf.hadirku.pg.Tx
import java.time.Instant
import java.time.LocalDate

/**
 * Read-only projection of the existing app data (`pg.json` → [PgState]) into a [LedgerBook].
 * The existing data stays the system of record; nothing here writes it back.
 *
 * Mapping of existing transaction types:
 *  masuk        → INCOME (split: OVERTIME = otBayar, rest SALARY if it is a salary credit, else OTHER)
 *  keluar       → EXPENSE (category, commitment link) or DEBT_REPAYMENT when linked to a debt
 *  pindah       → TRANSFER pocket → pocket
 *  pelarasan±   → ADJUSTMENT,  baki-awal → OPENING_BALANCE
 *  kad          → EXPENSE charged to the card liability (+ TRANSFER pocket → payment pocket when earmarked)
 *  tunai-kad    → DEBT_DISBURSEMENT card → pocket (+ CHARGE FEE for the withdrawal fee)
 * Debt logs: penyata → OPENING_BALANCE / ADJUSTMENT to the stated balance, faedah → CHARGE INTEREST,
 *  caj → CHARGE FEE, bayar → DEBT_REPAYMENT from outside, beli → EXPENSE on the card, tunai → DEBT_DISBURSEMENT.
 * EPP: each plan is an EPP liability opened (OPENING_BALANCE, no expense re-created) the day before its
 *  first instalment; every billed instalment moves its principal card ← EPP (TRANSFER between liabilities)
 *  and its interest is a CHARGE INTEREST on the card — so principal is never counted as spending twice.
 */
object PgLedgerAdapter {

    data class Issue(val sourceId: String, val code: String)
    data class Result(val book: LedgerBook, val issues: List<Issue>)

    fun pocketAcc(id: String) = "p:$id"
    fun debtAcc(id: String) = "d:$id"
    fun eppAcc(debtId: String, planId: String) = "e:$debtId:$planId"

    fun storageOf(debtJenis: String): Storage = when (debtJenis) {
        "kad" -> Storage.CREDIT_CARD
        "pinjaman" -> Storage.LOAN
        "bnpl" -> Storage.BNPL
        else -> Storage.OTHER_LIABILITY
    }

    fun accounts(s: PgState): Map<String, Account> {
        val acc = LinkedHashMap<String, Account>()
        s.pockets.forEach { p ->
            val st = when (PG.simpanDi(p)) { "tunai" -> Storage.CASH; "ewallet" -> Storage.EWALLET; else -> Storage.BANK }
            acc[pocketAcc(p.id)] = Account(pocketAcc(p.id), p.nama, AccountKind.ASSET, st, sourceId = p.id)
        }
        s.debts.forEach { d ->
            acc[debtAcc(d.id)] = Account(debtAcc(d.id), d.nama, AccountKind.LIABILITY, storageOf(d.jenis), sourceId = d.id)
            d.epp.forEach { e ->
                val id = eppAcc(d.id, e.id)
                acc[id] = Account(id, e.nama.ifEmpty { "EPP" }, AccountKind.LIABILITY, Storage.EPP, sourceId = e.id, parentId = debtAcc(d.id))
            }
        }
        return acc
    }

    fun build(s: PgState, today: LocalDate): Result {
        val accounts = accounts(s)
        val issues = ArrayList<Issue>()
        val entries = ArrayList<Entry>()
        s.transactions.forEach { t -> mapTx(t, s, accounts, entries, issues) }
        val todayIso = today.toString()
        s.debts.forEach { d -> mapDebt(d, s, todayIso, accounts, entries, issues) }
        val book = LedgerBook(accounts = accounts, entries = entries)
        LedgerIntegrity.check(book).forEach { issues += Issue(it.entryId ?: "-", "integrity:" + it.issue.name) }
        return Result(book, issues)
    }

    private fun created(ms: Long): Instant? = if (ms > 0) Instant.ofEpochMilli(ms) else null

    private fun mapTx(t: Tx, s: PgState, acc: Map<String, Account>, out: MutableList<Entry>, issues: MutableList<Issue>) {
        val date = try { LocalDate.parse(t.tarikh) } catch (_: Exception) { issues += Issue(t.id, "bad_date"); return }
        val amt = Money.fromDoubleOrNull(t.jumlah)
        if (amt == null || !amt.isPositive) { issues += Issue(t.id, "bad_amount"); return }
        val pocket = pocketAcc(t.poket).takeIf { acc.containsKey(it) }
        val at = created(t.dibuat)
        val base = Entry(id = "t:" + t.id, date = date, type = EntryType.ADJUSTMENT, amount = amt, createdAt = at, memo = t.perkara, sourceId = t.id)
        when (t.jenis) {
            "masuk" -> {
                if (pocket == null) { issues += Issue(t.id, "unknown_pocket"); return }
                val ot = Money.fromDoubleOrNull(t.otBayar)?.let { if (it > amt) amt else it.coerceAtLeast(Money.ZERO) } ?: Money.ZERO
                if (ot.isPositive) out += base.copy(id = "t:" + t.id + "#ot", type = EntryType.INCOME, amount = ot, to = pocket, incomeKind = IncomeKind.OVERTIME)
                val rest = amt - ot
                if (rest.isPositive) out += base.copy(type = EntryType.INCOME, amount = rest, to = pocket,
                    incomeKind = if (PG.isGajiTx(t)) IncomeKind.SALARY else IncomeKind.OTHER)
            }
            "keluar" -> {
                if (pocket == null) { issues += Issue(t.id, "unknown_pocket"); return }
                val debt = t.hutangId.takeIf { it.isNotEmpty() }?.let { debtAcc(it) }?.takeIf { acc.containsKey(it) }
                if (debt != null) out += base.copy(type = EntryType.DEBT_REPAYMENT, from = pocket, to = debt, debtId = t.hutangId)
                else {
                    if (t.hutangId.isNotEmpty()) issues += Issue(t.id, "unknown_debt")
                    out += base.copy(type = EntryType.EXPENSE, from = pocket, category = categoryOf(t), commitmentId = t.komitmenId.ifEmpty { null })
                }
            }
            "pindah" -> {
                if (pocket == null) { issues += Issue(t.id, "unknown_pocket"); return }
                val dest = pocketAcc(t.ke).takeIf { acc.containsKey(it) && it != pocket }
                if (dest != null) out += base.copy(type = EntryType.TRANSFER, from = pocket, to = dest)
                else { issues += Issue(t.id, "unknown_destination"); out += base.copy(type = EntryType.ADJUSTMENT, from = pocket) }
            }
            "pelarasan+" -> if (pocket != null) out += base.copy(type = EntryType.ADJUSTMENT, to = pocket) else issues += Issue(t.id, "unknown_pocket")
            "pelarasan-" -> if (pocket != null) out += base.copy(type = EntryType.ADJUSTMENT, from = pocket) else issues += Issue(t.id, "unknown_pocket")
            "baki-awal" -> if (pocket != null) out += base.copy(type = EntryType.OPENING_BALANCE, to = pocket) else issues += Issue(t.id, "unknown_pocket")
            "kad" -> {
                val card = debtAcc(t.kadId).takeIf { t.kadId.isNotEmpty() && acc.containsKey(it) }
                if (card != null) out += base.copy(type = EntryType.EXPENSE, from = card, category = categoryOf(t), debtId = t.kadId)
                else issues += Issue(t.id, "unknown_card")
                // earmark: the existing app moves the amount from the spending pocket to the card-payment pocket
                val dest = pocketAcc(t.ke).takeIf { t.ke.isNotEmpty() && t.ke != t.poket && acc.containsKey(it) }
                if (dest != null && pocket != null) out += base.copy(id = "t:" + t.id + "#earmark", type = EntryType.TRANSFER, from = pocket, to = dest)
            }
            "tunai-kad" -> {
                if (pocket == null) { issues += Issue(t.id, "unknown_pocket"); return }
                val card = debtAcc(t.kadId).takeIf { t.kadId.isNotEmpty() && acc.containsKey(it) }
                if (card == null) { issues += Issue(t.id, "unknown_card"); out += base.copy(type = EntryType.ADJUSTMENT, to = pocket); return }
                out += base.copy(type = EntryType.DEBT_DISBURSEMENT, from = card, to = pocket, debtId = t.kadId)
                val fee = Money.fromDoubleOrNull(t.fee) ?: Money.ZERO
                if (fee.isPositive) out += base.copy(id = "t:" + t.id + "#fee", type = EntryType.CHARGE, amount = fee, from = card, chargeKind = ChargeKind.FEE, debtId = t.kadId)
            }
            else -> issues += Issue(t.id, "unknown_type:" + t.jenis)
        }
    }

    /** Existing category id, or null when uncategorised. Debt repayments are not categorised spending. */
    fun categoryOf(t: Tx): String? = PG.kategoriOf(t).takeIf { it.isNotEmpty() && it != "belum" && it != "hutang" }

    private fun mapDebt(d: Debt, s: PgState, todayIso: String, acc: Map<String, Account>, out: MutableList<Entry>, issues: MutableList<Issue>) {
        val dAcc = debtAcc(d.id)
        // EPP liabilities: opened the day before the first instalment (pre-existing EPP → no expense re-created)
        d.epp.forEach { p ->
            val info = PG.eppInfo(p, todayIso)
            val first = runCatching { LocalDate.parse(info.dates.first()) }.getOrNull()
            val pokok = Money.fromDoubleOrNull(info.pokok)
            if (first == null || pokok == null || !pokok.isPositive) { issues += Issue(p.id, "bad_epp"); return@forEach }
            out += Entry(id = "eo:" + d.id + ":" + p.id, date = first.minusDays(1), type = EntryType.OPENING_BALANCE, amount = pokok,
                from = eppAcc(d.id, p.id), debtId = d.id, sourceId = p.id, memo = p.nama)
        }
        val events = PG.debtEvents(s, d, null, todayIso)
        var prev = Money.ZERO
        var first = true
        for (ev in events) {
            val now = Money.fromDouble(ev.baki)
            val delta = now - prev
            val date = runCatching { LocalDate.parse(ev.tarikh) }.getOrNull()
            if (date == null) { issues += Issue(ev.id, "bad_date"); prev = now; continue }
            if (ev.tx) { prev = now; first = false; continue } // already mapped from the transaction itself
            val base = Entry(id = "l:" + d.id + ":" + ev.id, date = date, type = EntryType.ADJUSTMENT, amount = delta.abs(),
                createdAt = created(ev.dibuat), debtId = d.id, sourceId = ev.id, memo = ev.catatan)
            if (ev.eppId != null) {
                val plan = d.epp.find { it.id == ev.eppId }
                val k = ev.id.substringAfterLast('-').toIntOrNull()
                if (plan == null || k == null) { issues += Issue(ev.id, "bad_epp_event"); prev = now; continue }
                val info = PG.eppInfo(plan, todayIso)
                val principal = Money.fromDouble(info.pokokAt(k))
                val interest = delta - principal
                val eId = "epp:" + d.id + ":" + ev.id
                if (principal.isPositive) out += base.copy(id = "$eId#p", type = EntryType.TRANSFER, amount = principal, from = dAcc, to = eppAcc(d.id, plan.id))
                if (interest.isPositive) out += base.copy(id = "$eId#i", type = EntryType.CHARGE, amount = interest, from = dAcc, chargeKind = ChargeKind.INTEREST)
                if (interest.isNegative) issues += Issue(ev.id, "epp_split_mismatch")
            } else if (!delta.isZero) {
                // owed increases ⇒ value leaves the liability (from); owed decreases ⇒ value enters it (to)
                val inc = delta.isPositive
                out += when (ev.jenis) {
                    "penyata" -> if (first && !prev.isPositive && inc) base.copy(type = EntryType.OPENING_BALANCE, from = dAcc)
                                 else if (inc) base.copy(type = EntryType.ADJUSTMENT, from = dAcc) else base.copy(type = EntryType.ADJUSTMENT, to = dAcc)
                    "faedah" -> if (inc) base.copy(type = EntryType.CHARGE, from = dAcc, chargeKind = ChargeKind.INTEREST) else base.copy(to = dAcc)
                    "caj" -> if (inc) base.copy(type = EntryType.CHARGE, from = dAcc, chargeKind = ChargeKind.FEE) else base.copy(to = dAcc)
                    "beli" -> if (inc) base.copy(type = EntryType.EXPENSE, from = dAcc) else base.copy(to = dAcc)
                    "tunai" -> if (inc) base.copy(type = EntryType.DEBT_DISBURSEMENT, from = dAcc) else base.copy(to = dAcc)
                    "bayar" -> if (!inc) base.copy(type = EntryType.DEBT_REPAYMENT, to = dAcc) else base.copy(from = dAcc)
                    else -> if (inc) base.copy(from = dAcc) else base.copy(to = dAcc)
                }
            }
            prev = now
            first = false
        }
    }

    /* ---------------- parity with the existing calculations ---------------- */

    data class Diff(val accountId: String, val existing: Money, val ledger: Money)

    /**
     * Compares the ledger with the existing PG calculations: pocket balances, debt balances and
     * unbilled EPP principal. An empty list means the projection is exact to the sen.
     */
    fun parity(s: PgState, book: LedgerBook, today: LocalDate): List<Diff> {
        val out = ArrayList<Diff>()
        val todayIso = today.toString()
        val bal = book.balances()
        PG.balances(s).forEach { (pid, v) ->
            val a = pocketAcc(pid); val ex = Money.fromDouble(v); val lg = bal[a] ?: Money.ZERO
            if (ex != lg) out += Diff(a, ex, lg)
        }
        s.debts.forEach { d ->
            val owed = Money.fromDouble(PG.debtBalance(s, d, null, todayIso))
            val lg = -(bal[debtAcc(d.id)] ?: Money.ZERO)
            if (owed != lg) out += Diff(debtAcc(d.id), owed, lg)
            d.epp.forEach { p ->
                val ex = Money.fromDouble(PG.eppInfo(p, todayIso).pokokBaki)
                val l = -(bal[eppAcc(d.id, p.id)] ?: Money.ZERO)
                if (ex != l) out += Diff(eppAcc(d.id, p.id), ex, l)
            }
        }
        return out
    }
}
