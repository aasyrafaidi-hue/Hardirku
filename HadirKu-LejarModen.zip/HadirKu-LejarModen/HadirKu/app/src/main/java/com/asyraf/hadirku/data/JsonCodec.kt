package com.asyraf.hadirku.data

import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

/** Tukar rekod & tetapan kehadiran ke JSON dan sebaliknya (guna org.json terbina dalam Android). */
object JsonCodec {

    fun recordToJson(r: DayRecord): JSONObject = JSONObject().apply {
        put("d", r.date.toString())
        if (r.checkIn != null) put("i", r.checkIn)
        if (r.checkOut != null) put("o", r.checkOut)
        put("s", r.status.name)
        put("m", r.method)
        put("md", r.mood)
        put("n", r.note)
    }

    fun recordFromJson(o: JSONObject): DayRecord? = try {
        DayRecord(
            date = LocalDate.parse(o.getString("d")),
            checkIn = if (o.has("i") && !o.isNull("i")) o.getLong("i") else null,
            checkOut = if (o.has("o") && !o.isNull("o")) o.getLong("o") else null,
            status = runCatching { RecordStatus.valueOf(o.optString("s", "HADIR")) }.getOrDefault(RecordStatus.HADIR),
            method = o.optString("m", "manual"),
            mood = o.optInt("md", 0),
            note = o.optString("n", ""),
        )
    } catch (e: Exception) {
        null
    }

    fun recordsToJson(records: Collection<DayRecord>): JSONArray {
        val arr = JSONArray()
        records.sortedBy { it.date.toEpochDay() }.forEach { arr.put(recordToJson(it)) }
        return arr
    }

    fun recordsFromJson(arr: JSONArray): Map<LocalDate, DayRecord> {
        val map = HashMap<LocalDate, DayRecord>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val r = recordFromJson(o) ?: continue
            map[r.date] = r
        }
        return map
    }

    private fun JSONObject.optDoubleOrNull(key: String): Double? =
        if (has(key) && !isNull(key)) optDouble(key).takeIf { !it.isNaN() } else null

    /** [withKeys] = false untuk fail salinan: kunci API kekal dalam telefon sahaja. */
    fun settingsToJson(s: AppSettings, withKeys: Boolean = true): JSONObject = JSONObject().apply {
        put("name", s.name)
        put("morningStart", s.morningStart)
        put("nightStart", s.nightStart)
        put("rotationAnchor", s.rotationAnchor.toString())
        put("weeksPerBlock", s.weeksPerBlock)
        put("workDays", JSONArray().apply { s.workDays.sorted().forEach { put(it) } })
        put("restDay", s.restDay)
        put("graceMinutes", s.graceMinutes)
        put("otRounding", s.otRounding)
        put("syncOt", s.syncOt)
        val wLat = s.workLat
        val wLng = s.workLng
        if (wLat != null) put("workLat", wLat)
        if (wLng != null) put("workLng", wLng)
        put("workRadius", s.workRadius)
        put("autoCheckIn", s.autoCheckIn)
        put("useBiometric", s.useBiometric)
        put("remindersOn", s.remindersOn)
        if (withKeys) {
            put("calendarificKey", s.calendarificKey)
        }
        put("stateName", s.stateName)
        put("themeMode", s.themeMode)
        put("holidays", JSONArray().apply { s.holidays.sortedBy { it.toEpochDay() }.forEach { put(it.toString()) } })
        val ts = s.trackingStart
        if (ts != null) put("trackingStart", ts.toString())
    }

    fun settingsFromJson(o: JSONObject): AppSettings {
        val d = AppSettings()
        val workDaysArr = o.optJSONArray("workDays")
        val workDays = if (workDaysArr != null) {
            (0 until workDaysArr.length()).map { workDaysArr.optInt(it) }.filter { it in 1..7 }.toSet()
        } else d.workDays
        val holArr = o.optJSONArray("holidays")
        val holidays = if (holArr != null) {
            (0 until holArr.length()).mapNotNull { runCatching { LocalDate.parse(holArr.optString(it)) }.getOrNull() }.toSet()
        } else emptySet()
        return AppSettings(
            name = o.optString("name", d.name),
            morningStart = o.optInt("morningStart", d.morningStart),
            nightStart = o.optInt("nightStart", d.nightStart),
            rotationAnchor = runCatching { LocalDate.parse(o.optString("rotationAnchor")) }.getOrDefault(d.rotationAnchor),
            weeksPerBlock = o.optInt("weeksPerBlock", d.weeksPerBlock).coerceIn(1, 8),
            workDays = workDays,
            restDay = o.optInt("restDay", d.restDay),
            graceMinutes = o.optInt("graceMinutes", d.graceMinutes),
            otRounding = o.optInt("otRounding", d.otRounding).coerceIn(1, 60),
            syncOt = o.optBoolean("syncOt", d.syncOt),
            workLat = o.optDoubleOrNull("workLat"),
            workLng = o.optDoubleOrNull("workLng"),
            workRadius = o.optInt("workRadius", d.workRadius),
            autoCheckIn = o.optBoolean("autoCheckIn", d.autoCheckIn),
            useBiometric = o.optBoolean("useBiometric", d.useBiometric),
            remindersOn = o.optBoolean("remindersOn", d.remindersOn),
            calendarificKey = o.optString("calendarificKey", ""),
            stateName = o.optString("stateName", d.stateName),
            themeMode = o.optInt("themeMode", d.themeMode),
            holidays = holidays,
            trackingStart = if (o.has("trackingStart")) runCatching { LocalDate.parse(o.optString("trackingStart")) }.getOrNull() else null,
        )
    }

    /** Tetapan lama HadirKu v1 (gaji, kitaran OT, kunci Claude) untuk dipindah ke PoketGaji. */
    fun legacyFromJson(o: JSONObject): Legacy = Legacy(
        basicSalary = o.optDouble("basicSalary", 0.0).takeIf { !it.isNaN() } ?: 0.0,
        cycleStartDay = o.optInt("cycleStartDay", 0),
        normalHours = o.optDouble("normalHours", 0.0).takeIf { !it.isNaN() } ?: 0.0,
        claudeKey = o.optString("claudeApiKey", ""),
        claudeModel = o.optString("claudeModel", ""),
    )

    /** Bahagian kehadiran dalam fail salinan gabungan. */
    fun hadirkuBlock(s: AppSettings, records: Collection<DayRecord>): JSONObject = JSONObject().apply {
        put("app", "Duitku")
        put("version", 2)
        put("settings", settingsToJson(s, withKeys = false))
        put("records", recordsToJson(records))
    }
}
