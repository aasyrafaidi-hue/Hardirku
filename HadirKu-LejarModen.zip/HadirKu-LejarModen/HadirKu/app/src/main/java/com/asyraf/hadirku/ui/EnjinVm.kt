package com.asyraf.hadirku.ui

import android.net.Uri
import androidx.lifecycle.viewModelScope
import com.asyraf.hadirku.MainViewModel
import com.asyraf.hadirku.Sheet
import com.asyraf.hadirku.ai.Ai
import com.asyraf.hadirku.engine.android.EngineHub
import com.asyraf.hadirku.engine.app.AppFacade
import com.asyraf.hadirku.engine.assistant.AssistantEngine
import com.asyraf.hadirku.engine.assistant.AssistantProvider
import com.asyraf.hadirku.engine.assistant.SnapshotBuilder
import com.asyraf.hadirku.engine.budget.BudgetSuggestion
import com.asyraf.hadirku.engine.budget.CarryOver
import com.asyraf.hadirku.engine.core.Money
import com.asyraf.hadirku.engine.forecast.ForecastEngine
import com.asyraf.hadirku.engine.forecast.Scenario
import com.asyraf.hadirku.engine.ledger.PgLedgerAdapter
import com.asyraf.hadirku.engine.reconcile.BankLine
import com.asyraf.hadirku.engine.reconcile.CsvBankParser
import com.asyraf.hadirku.engine.reconcile.CsvParseResult
import com.asyraf.hadirku.engine.reconcile.ReconReport
import com.asyraf.hadirku.engine.reconcile.ReconciliationEngine
import com.asyraf.hadirku.engine.store.EngineData
import com.asyraf.hadirku.i18n.Bahasa
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.Tx
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.YearMonth

/* =====================================================================
 * Tindakan skrin enjin kewangan. Semua tulisan melalui EngineStore.update (engine.json, AtomicFile).
 * pg.json (data asal) hanya diubah melalui fungsi VM sedia ada (newTx/saveTx) — enjin tidak pernah
 * menulis transaksi sendiri.
 * ===================================================================== */

/** Hasil semakan penyata bank yang sedang dipaparkan. */
class CsvLapor(val nama: String, val parse: CsvParseResult, val report: ReconReport)

private fun MainViewModel.app() = getApplication<android.app.Application>()
fun MainViewModel.hariIni(): LocalDate = LocalDate.parse(today())

fun MainViewModel.muatEnjin() {
    val r = try { EngineHub.store(app()).load() } catch (e: Exception) { null }
    if (r == null) { engineReadOnly = true; return }
    engine = r.data
    engineReadOnly = r.readOnly
}

/** Ubah engine.json. Pulang false (dengan mesej) jika tidak dapat disimpan. */
fun MainViewModel.ubahEnjin(f: (EngineData) -> EngineData): Boolean {
    if (engineReadOnly) { toast("Data enjin dari versi app lebih baru — kemas kini app dahulu"); return false }
    val ok = try { EngineHub.store(app()).update(f) } catch (e: Exception) { false }
    muatEnjin()
    if (!ok) toast("Tak dapat simpan. Cuba lagi.")
    return ok
}

private fun MainViewModel.wang(v: String): Money? {
    val d = parseAmt(v)
    return if (d.isNaN() || d <= 0.0) null else Money.fromDoubleOrNull(d)
}

// ---------------- bajet ----------------

fun MainViewModel.simpanBajet(id: String?, kat: String, jumlah: String, carry: CarryOver, asas: Boolean): String {
    val r = AppFacade.upsertBudget(engine, id, kat, wang(jumlah), carry, asas, YearMonth.from(hariIni())) { PG.uid("b-") }
    return when (r) {
        is AppFacade.Edit.Err -> r.message
        is AppFacade.Edit.Ok -> {
            val b = r.data.budgets
            if (ubahEnjin { it.copy(budgets = b) }) { close(); toast("Bajet disimpan") }
            ""
        }
    }
}

fun MainViewModel.padamBajet(id: String) {
    if (ubahEnjin { AppFacade.deleteBudget(it, id) }) { close(); toast("Bajet dipadam") }
}

fun MainViewModel.gunaCadangan(g: BudgetSuggestion) {
    if (ubahEnjin { AppFacade.applySuggestion(it, g, YearMonth.from(hariIni())) { PG.uid("b-") } }) toast("Bajet " + PG.katLabel(g.category) + " dikemas kini")
}

// ---------------- matlamat ----------------

fun MainViewModel.simpanMatlamat(id: String?, nama: String, sasaran: String, tarikh: String, poket: String): String {
    val t = tarikh.trim().takeIf { it.isNotEmpty() }?.let { runCatching { LocalDate.parse(it) }.getOrNull() ?: return "Tarikh tidak sah." }
    val acc = poket.takeIf { it.isNotEmpty() }?.let { PgLedgerAdapter.pocketAcc(it) }
    val r = AppFacade.upsertGoal(engine, id, nama, wang(sasaran), t, acc, hariIni()) { PG.uid("g-") }
    return when (r) {
        is AppFacade.Edit.Err -> r.message
        is AppFacade.Edit.Ok -> {
            val g = r.data.goals
            if (ubahEnjin { it.copy(goals = g) }) { close(); toast("Matlamat disimpan") }
            ""
        }
    }
}

fun MainViewModel.padamMatlamat(id: String) {
    if (ubahEnjin { AppFacade.deleteGoal(it, id) }) { close(); toast("Matlamat dipadam · duit dalam poket tidak berubah") }
}

fun MainViewModel.gerakMatlamat(id: String, jumlah: String, keluar: Boolean): String {
    val s = pg.value
    val today = hariIni()
    val book = PgLedgerAdapter.build(s, today).book
    val r = AppFacade.moveGoal(s, engine, book, today, id, wang(jumlah), keluar) { PG.uid("m-") }
    return when (r) {
        is AppFacade.Edit.Err -> r.message
        is AppFacade.Edit.Ok -> {
            val moves = r.data.goalMoves
            if (ubahEnjin { it.copy(goalMoves = moves) }) { close(); toast(if (keluar) "Dilepaskan daripada matlamat" else "Diasingkan untuk matlamat") }
            ""
        }
    }
}

// ---------------- semak penyata bank (CSV) ----------------

private fun MainViewModel.semakSemula(nama: String, p: CsvParseResult) {
    val today = hariIni()
    val book = PgLedgerAdapter.build(pg.value, today).book
    csvLapor = CsvLapor(nama, p, ReconciliationEngine.reconcile(p.lines, book, importedKeys = engine.importKeys.keys))
}

fun MainViewModel.csvPick(uri: Uri) {
    viewModelScope.launch {
        val text = withContext(Dispatchers.IO) {
            try { app().contentResolver.openInputStream(uri)?.use { s -> String(s.readBytes(), Charsets.UTF_8) } } catch (e: Exception) { null }
        }
        if (text == null) { toast("Tak dapat baca fail"); return@launch }
        val p = withContext(Dispatchers.Default) { runCatching { CsvBankParser.parse(text) }.getOrNull() }
        if (p == null || p.lines.isEmpty()) { toast("Tiada baris transaksi dikenali dalam fail ini"); return@launch }
        val nama = uri.lastPathSegment?.substringAfterLast('/')?.take(40) ?: "penyata.csv"
        semakSemula(nama, p)
        open(Sheet.CsvSemak)
    }
}

/** Baris bank yang tiada dalam Duitku → buka borang transaksi sedia ada (pengguna sahkan sendiri). */
fun MainViewModel.csvRekod(l: BankLine) {
    val lap = csvLapor ?: return
    val s = pg.value
    val masuk = l.amount.isPositive
    val bank = s.pockets.firstOrNull { !it.dompet && !it.tunai && it.id != PG.BELUM_AGIH }?.id ?: PG.BELUM_AGIH
    val base = Tx(
        tarikh = l.date.toString(), jenis = if (masuk) "masuk" else "keluar", poket = if (masuk) PG.BELUM_AGIH else bank,
        jumlah = l.amount.abs().toDecimal().toDouble(), perkara = l.description.take(60),
    )
    newTx(base, "Rekod dari penyata bank") { tx ->
        ubahEnjin { it.copy(importKeys = it.importKeys + (l.key to ("tx:" + tx.id))) }
        semakSemula(lap.nama, lap.parse)
        open(Sheet.CsvSemak)
    }
}

fun MainViewModel.csvAbai(l: BankLine) {
    val lap = csvLapor ?: return
    if (ubahEnjin { it.copy(importKeys = it.importKeys + (l.key to "abai")) }) semakSemula(lap.nama, lap.parse)
}

fun MainViewModel.csvBatalAbai(l: BankLine) {
    val lap = csvLapor ?: return
    if (ubahEnjin { it.copy(importKeys = it.importKeys - l.key) }) semakSemula(lap.nama, lap.parse)
}

// ---------------- tanya Duitku ----------------

fun MainViewModel.tanya(soalan: String) {
    val q = soalan.trim()
    if (q.isEmpty() || tanyaBusy) return
    tanyaBusy = true
    val s = pg.value
    val today = hariIni()
    val t = today()
    viewModelScope.launch {
        val jawapan = withContext(Dispatchers.IO) {
            try {
                val book = PgLedgerAdapter.build(s, today).book
                val snap = SnapshotBuilder.build(s, book, today, ForecastEngine.project(s, book, today, 60, Scenario.BASE))
                // AI hanya jika pengguna sudah tetapkan kunci sendiri; ia hanya menerima snapshot bersih (tiada nama akaun/perkara)
                val provider = if (Ai.ready()) AssistantProvider { qq, json ->
                    runCatching {
                        runBlocking {
                            Ai.text(
                                "Anda pembantu kewangan dalam app Duitku. Jawab " + (if (Bahasa.en) "in English" else "dalam Bahasa Melayu") +
                                    ", ringkas (maksimum 5 ayat), berdasarkan FAKTA JSON yang diberi SAHAJA. Jangan reka nombor. " +
                                    "Jika fakta tidak cukup, katakan begitu. Ini bukan nasihat kewangan profesional.",
                                "FAKTA:\n$json\n\nSOALAN: $qq", t, 500,
                            )
                        }
                    }.getOrNull()
                } else null
                AppFacade.answerText(AssistantEngine(provider).ask(q, snap))
            } catch (e: Exception) { "Tak dapat jawab sekarang. Cuba lagi." }
        }
        tanyaLog = (tanyaLog + (q to jawapan)).takeLast(12)
        tanyaBusy = false
    }
}
