package com.asyraf.hadirku.logic

import com.asyraf.hadirku.pg.PG
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.util.Locale

/** Teks dan format Bahasa Melayu. */
object Ms {
    // ikut bahasa paparan (PG.en); Isnin dulu
    val monthsLong: List<String> get() = PG.BULAN_PENUH
    val monthsShort: List<String> get() = PG.BULAN
    val daysLong: List<String> get() = PG.HARI_PENUH.let { it.drop(1) + it.first() }
    val daysShort: List<String> get() = PG.HARI.let { it.drop(1) + it.first() }
    val daysLetter: List<String> get() = if (PG.en) listOf("M", "T", "W", "T", "F", "S", "S") else listOf("I", "S", "R", "K", "J", "S", "A")

    val moods = listOf("😫 Teruk", "😕 Kurang", "😐 Biasa", "🙂 Baik", "😄 Mantap")

    val quotes = listOf(
        "Disiplin ialah jambatan antara matlamat dan pencapaian.",
        "Tak perlu bersemangat setiap hari. Cukup datang setiap hari.",
        "Hari yang paling malas biasanya hari yang paling bermakna bila kau tetap pergi.",
        "Streak dibina sehari demi sehari. Jangan putuskan hari ni.",
        "Orang yang konsisten selalu menang dengan orang yang berbakat tapi malas.",
        "Kau tak lawan orang lain. Kau lawan diri kau semalam.",
        "Rezeki tak datang pada yang menunggu di katil.",
        "Penat hari ni, puas hujung bulan.",
    )

    fun month(m: Int): String = monthsLong[m - 1]
    fun day(d: LocalDate): String = daysLong[d.dayOfWeek.value - 1]
    fun dateLong(d: LocalDate): String = "${day(d)}, ${d.dayOfMonth} ${monthsLong[d.monthValue - 1]} ${d.year}"
    fun dateShort(d: LocalDate): String = "${day(d)}, ${d.dayOfMonth} ${monthsShort[d.monthValue - 1]}"
    fun dateTiny(d: LocalDate): String = "${d.dayOfMonth} ${monthsShort[d.monthValue - 1]}"

    fun hm(minutes: Int): String {
        val m = ((minutes % 1440) + 1440) % 1440
        return String.format(Locale.US, "%02d:%02d", m / 60, m % 60)
    }

    fun time(epochMs: Long, zone: ZoneId = ZoneId.systemDefault()): String {
        val t = Instant.ofEpochMilli(epochMs).atZone(zone).toLocalTime()
        return hm(t.hour * 60 + t.minute)
    }

    fun duration(minutes: Int): String {
        val m = if (minutes < 0) 0 else minutes
        return if (m < 60) "${m}m" else "${m / 60}j ${m % 60}m"
    }

    fun hours(h: Double): String =
        if (h % 1.0 == 0.0) h.toInt().toString() else String.format(Locale.US, "%.1f", h)


    fun rm(v: Double): String = "RM " + String.format(Locale.US, "%,.2f", v)

    fun greeting(hour: Int): String = when (hour) {
        in 5..11 -> "Selamat pagi"
        in 12..13 -> "Selamat tengah hari"
        in 14..18 -> "Selamat petang"
        else -> "Selamat malam"
    }

    fun kindLabel(k: DayKind): String = when (k) {
        DayKind.KERJA -> "Hari kerja"
        DayKind.OFF_DAY -> "Off day"
        DayKind.REST_DAY -> "Rest day"
        DayKind.CUTI_UMUM -> "Cuti umum"
    }

    fun shiftLabel(t: ShiftType): String = if (t == ShiftType.PAGI) "Shift pagi" else "Shift malam"

    fun outcomeLabel(o: Outcome): String = when (o) {
        Outcome.TEPAT -> "Tepat masa"
        Outcome.LEWAT -> "Lewat"
        Outcome.TIDAK_HADIR -> "Tidak hadir"
        Outcome.CUTI -> "Cuti"
        Outcome.MC -> "MC"
        Outcome.CUTI_UMUM -> "Cuti umum"
        Outcome.HUJUNG_MINGGU -> "Hari rehat"
        Outcome.KERJA_LEBIH -> "Kerja hari rehat"
        Outcome.BELUM -> "Belum check-in"
        Outcome.AKAN_DATANG -> "Akan datang"
        Outcome.TIADA_DATA -> "Tiada data"
    }

}
