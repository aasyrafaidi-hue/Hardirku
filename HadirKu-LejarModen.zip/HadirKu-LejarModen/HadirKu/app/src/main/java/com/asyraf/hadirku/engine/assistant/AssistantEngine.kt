package com.asyraf.hadirku.engine.assistant

import com.asyraf.hadirku.engine.bills.BillEngine
import com.asyraf.hadirku.engine.core.DateRange
import com.asyraf.hadirku.engine.core.MiniJson
import com.asyraf.hadirku.engine.core.Money
import com.asyraf.hadirku.engine.debt.DebtEngine
import com.asyraf.hadirku.engine.forecast.ForecastResult
import com.asyraf.hadirku.engine.ledger.AccountKind
import com.asyraf.hadirku.engine.ledger.EntryType
import com.asyraf.hadirku.engine.ledger.IncomeKind
import com.asyraf.hadirku.engine.ledger.LedgerBook
import com.asyraf.hadirku.engine.ledger.LedgerReports
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.PgState
import java.time.LocalDate
import java.time.YearMonth
import java.util.Locale

/* =====================================================================
 * Engine 11 — AI Financial Assistant (read-only)
 * Builds a SANITISED snapshot of structured facts (no memos, no notes, no account names or numbers,
 * no receipts) where every fact keeps internal references to the ledger entry ids and date range it
 * came from. Common questions are answered deterministically; open questions may go to an optional
 * provider (backend) that only ever receives the snapshot JSON. There is no mutation API at all.
 * ===================================================================== */

data class Fact(val id: String, val kind: String, val value: String, val range: DateRange? = null, val refs: List<String> = emptyList())

data class FinancialSnapshot(val asOf: LocalDate, val currency: String, val facts: List<Fact>) {
    fun fact(id: String): Fact? = facts.find { it.id == id }

    /** What a provider is allowed to see: ids, kinds, values and ranges — never the internal entry references. */
    fun toProviderJson(): String = MiniJson.write(linkedMapOf(
        "as_of" to asOf.toString(), "currency" to currency,
        "facts" to facts.map { linkedMapOf("id" to it.id, "kind" to it.kind, "value" to it.value, "from" to it.range?.start?.toString(), "to" to it.range?.lastDay?.toString()) },
    ))
}

object SnapshotBuilder {
    fun build(s: PgState, book: LedgerBook, asOf: LocalDate, forecast: ForecastResult? = null): FinancialSnapshot {
        val facts = ArrayList<Fact>()
        val month = DateRange(YearMonth.from(asOf).atDay(1), asOf.plusDays(1))
        val eff = book.effective()
        fun refs(filter: (com.asyraf.hadirku.engine.ledger.Entry) -> Boolean) = eff.filter { it.date in month && filter(it) }.map { it.id }
        // balances by storage type (no account names)
        val bal = book.balances(asOf)
        book.accounts.values.filter { it.kind == AccountKind.ASSET }.groupBy { it.storage }.forEach { (st, accs) ->
            facts += Fact("balance.${st.name.lowercase()}", "balance", Money.sum(accs.map { bal[it.id] ?: Money.ZERO }).toDecimal().toPlainString())
        }
        facts += Fact("debt.total_owed", "debt", DebtEngine.totalOwed(book, asOf).toDecimal().toPlainString())
        // month-to-date spending by category (+ entry references)
        LedgerReports.expenseByCategory(book, month).forEach { (cat, amt) ->
            val c = cat ?: "uncategorised"
            facts += Fact("spend.mtd.$c", "spend", amt.toDecimal().toPlainString(), month,
                refs { (it.type == EntryType.EXPENSE || it.type == EntryType.REFUND) && (it.category ?: "uncategorised") == c })
        }
        val t = LedgerReports.totals(book, month)
        facts += Fact("income.mtd.salary", "income", t.incomeSalary.toDecimal().toPlainString(), month, refs { it.type == EntryType.INCOME && it.incomeKind == IncomeKind.SALARY })
        facts += Fact("income.mtd.overtime", "income", t.incomeOvertime.toDecimal().toPlainString(), month, refs { it.type == EntryType.INCOME && it.incomeKind == IncomeKind.OVERTIME })
        facts += Fact("income.mtd.other", "income", t.incomeOther.toDecimal().toPlainString(), month, refs { it.type == EntryType.INCOME && it.incomeKind == IncomeKind.OTHER })
        facts += Fact("charges.mtd.interest", "charge", t.interest.toDecimal().toPlainString(), month)
        facts += Fact("charges.mtd.fees", "charge", t.fees.toDecimal().toPlainString(), month)
        // upcoming bills (counts and totals only — bill names are not shared)
        val up = BillEngine.upcoming(s, book, asOf, 14)
        facts += Fact("bills.next14.count", "bills", up.size.toString())
        facts += Fact("bills.next14.total", "bills", Money.sum(up.map { it.remaining }).toDecimal().toPlainString())
        up.firstOrNull()?.dueDate?.let { facts += Fact("bills.next_due_date", "bills", it.toString()) }
        forecast?.let {
            facts += Fact("forecast.${it.scenario.name.lowercase()}.lowest", "forecast", it.lowest.balance.toDecimal().toPlainString(), DateRange.inclusive(asOf, it.lowest.date))
            facts += Fact("forecast.${it.scenario.name.lowercase()}.lowest_date", "forecast", it.lowest.date.toString())
        }
        return FinancialSnapshot(asOf, "MYR", facts)
    }
}

enum class Intent { SPEND_IN_CATEGORY, BALANCE, UPCOMING_BILLS, DEBT_TOTAL, INCOME_MONTH, OPEN_QUESTION }
enum class AnswerSource { DETERMINISTIC, AI, UNAVAILABLE }

/** Structured answer. [citations] are ledger entry ids; [factIds] the snapshot facts used. No actions, ever. */
data class Answer(
    val intent: Intent,
    val source: AnswerSource,
    val values: Map<String, String>,
    val factIds: List<String>,
    val citations: List<String>,
    val range: DateRange?,
    val assumptions: List<String>,
    /** only for AI answers; produced by the provider from the snapshot */
    val aiText: String? = null,
)

/** Optional backend provider. Receives the question and the sanitised snapshot JSON only. Must not throw. */
fun interface AssistantProvider { fun answer(question: String, snapshotJson: String): String? }

class AssistantEngine(private val provider: AssistantProvider? = null) {

    fun ask(question: String, snap: FinancialSnapshot): Answer {
        val q = question.lowercase(Locale.ROOT)
        val cat = PG.KATEGORI.firstOrNull { k -> q.contains(k.id) || q.contains(k.label.lowercase(Locale.ROOT)) }?.id
        fun det(intent: Intent, ids: List<String>, assumptions: List<String> = emptyList()): Answer {
            val fs = ids.mapNotNull { snap.fact(it) }
            return Answer(intent, AnswerSource.DETERMINISTIC, fs.associate { it.id to it.value }, fs.map { it.id }, fs.flatMap { it.refs }.distinct(), fs.firstNotNullOfOrNull { it.range }, assumptions)
        }
        return when {
            cat != null && (q.contains("belanja") || q.contains("spend") || q.contains("habis")) ->
                det(Intent.SPEND_IN_CATEGORY, listOf("spend.mtd.$cat"), listOf("month_to_date", "refunds_netted", "reversals_excluded")).let {
                    if (it.factIds.isEmpty()) it.copy(values = mapOf("spend.mtd.$cat" to "0.00"), assumptions = it.assumptions + "no_spending_found") else it
                }
            q.contains("hutang") || q.contains("debt") || q.contains("owe") -> det(Intent.DEBT_TOTAL, listOf("debt.total_owed"), listOf("includes_unbilled_epp_principal"))
            q.contains("bil") || q.contains("komitmen") || q.contains("bill") || q.contains("due") ->
                det(Intent.UPCOMING_BILLS, listOf("bills.next14.count", "bills.next14.total", "bills.next_due_date"), listOf("next_14_days", "unpaid_only"))
            q.contains("gaji") || q.contains("pendapatan") || q.contains("income") || q.contains("salary") || q.contains(" ot") ->
                det(Intent.INCOME_MONTH, listOf("income.mtd.salary", "income.mtd.overtime", "income.mtd.other"), listOf("month_to_date"))
            q.contains("baki") || q.contains("balance") || q.contains("duit ada") ->
                det(Intent.BALANCE, snap.facts.filter { it.kind == "balance" }.map { it.id }, listOf("posted_up_to_today"))
            else -> {
                val p = provider
                val text = if (p != null) runCatching { p.answer(question, snap.toProviderJson()) }.getOrNull() else null
                if (text.isNullOrBlank()) Answer(Intent.OPEN_QUESTION, AnswerSource.UNAVAILABLE, emptyMap(), emptyList(), emptyList(), null, listOf("ai_unavailable"))
                else Answer(Intent.OPEN_QUESTION, AnswerSource.AI, emptyMap(), snap.facts.map { it.id }, emptyList(), null, listOf("ai_generated_from_snapshot_only", "not_financial_advice"), text)
            }
        }
    }
}
