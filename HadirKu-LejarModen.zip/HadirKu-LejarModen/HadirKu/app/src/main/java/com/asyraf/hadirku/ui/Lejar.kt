package com.asyraf.hadirku.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.asyraf.hadirku.data.Repo
import com.asyraf.hadirku.i18n.tr
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.PgState
import com.asyraf.hadirku.pg.Tx

/*
 * Lejar Moden — pembantu paparan sahaja (tiada logik kewangan di sini).
 * Semua nilai datang daripada PG / MainViewModel; fail ini hanya pilih ikon, warna dan keadaan paparan.
 */

/** Keadaan paparan yang bukan data kewangan (penapis lejar, carian, sorok baki, tab asal). */
object UiState {
    /** penapis Lejar Harian: semua / masuk / keluar / hutang / komitmen / pindah */
    var txFilter by mutableStateOf("semua")
    var txCari by mutableStateOf("")
    var txCariBuka by mutableStateOf(false)
    /** bulan carta Aliran Tunai di Utama (null = bulan semasa) */
    var dashYm by mutableStateOf<String?>(null)
    /** tab bawah terakhir dibuka — untuk butang/gerak "kembali" dari OT & Senarai Barang */
    var lastTab by mutableStateOf("poket")

    /** Sorok nilai RM di Utama (privasi). Disimpan dalam peranti sahaja (Repo sudah init dalam Application.onCreate). */
    var sorok by mutableStateOf(runCatching { Repo.getStr("ui.sorok", "0") == "1" }.getOrDefault(false))
        private set
    fun tukarSorok(v: Boolean) { sorok = v; runCatching { Repo.putStr("ui.sorok", if (v) "1" else "0") } }
}

/** Tab bawah (5) — urutan juga dipakai untuk arah animasi tukar tab. */
val TAB_IDS = listOf("poket", "transaksi", "bayaran", "laporan", "tetapan")

/** Wang, atau titik-titik bila pengguna sorok baki. */
fun Mh(x: Double?, hide: Boolean, plus: Boolean = false): String = if (hide) "RM ••••" else if (plus) Mp(x) else M(x)

/* ================= ikon kategori ================= */

class Vis(val ic: Ic, val fg: Color)

private val RE_ELEKTRIK = Regex("\\b(tnb|elektrik|letrik|electric|electricity)\\b")
private val RE_AIR = Regex("\\b(air|water|syabas|pba|saj|ranhill|indah water|iwk)\\b")
private val RE_NET = Regex("\\b(internet|unifi|wifi|streamyx|fibre|fiber|broadband|time)\\b")
private val RE_TEL = Regex("\\b(telefon|phone|postpaid|prepaid|hotlink|digi|celcom|maxis|umobile|yes|tunetalk)\\b")
private val RE_INS = Regex("\\b(insurans|takaful|insurance|aia|prudential|etiqa|allianz|great eastern|zurich)\\b")
private val RE_RUMAH = Regex("\\b(sewa|rumah|rent|house|bilik)\\b")
private val RE_KENDERAAN = Regex("\\b(kereta|motor|car|kenderaan|myvi|axia|bezza)\\b")
private val RE_PINJAM = Regex("\\b(pinjaman|loan|ptptn|aeon|bnpl|spaylater|atome)\\b")

/** Ikon bil ikut nama (paparan sahaja; tidak ubah data). */
fun billIc(nama: String): Ic {
    val n = nama.lowercase()
    return when {
        RE_ELEKTRIK.containsMatchIn(n) -> Ic.BOLT
        RE_AIR.containsMatchIn(n) -> Ic.DROP
        RE_NET.containsMatchIn(n) -> Ic.WIFI
        RE_TEL.containsMatchIn(n) -> Ic.PHONE
        RE_INS.containsMatchIn(n) -> Ic.SHIELD
        RE_RUMAH.containsMatchIn(n) -> Ic.HOME
        RE_KENDERAAN.containsMatchIn(n) -> Ic.CAR
        RE_PINJAM.containsMatchIn(n) -> Ic.COINS
        else -> Ic.RECEIPT
    }
}

fun billTint(ic: Ic, pal: Pal): Color = when (ic) {
    Ic.BOLT -> pal.amber
    Ic.DROP, Ic.PHONE -> pal.p[1]
    Ic.WIFI, Ic.SHIELD -> pal.accent
    Ic.HOME -> pal.out
    Ic.COINS -> pal.amber
    else -> pal.accent
}

/** Ikon & warna untuk satu transaksi ikut jenis / kategori sedia ada. */
fun txVis(s: PgState, t: Tx, pal: Pal): Vis {
    return when (t.jenis) {
        "masuk" -> if (PG.isGajiTx(t)) Vis(Ic.BRIEFCASE, pal.inn) else Vis(Ic.ARROW_DOWN, pal.inn)
        "pindah" -> Vis(Ic.SWAP, pal.muted)
        "tunai-kad" -> Vis(Ic.CARD, pal.amber)
        "baki-awal", "pelarasan+", "pelarasan-" -> Vis(Ic.TAG, pal.muted)
        else -> {
            if (t.jenis == "keluar" && t.hutangId.isNotEmpty()) return Vis(Ic.COINS, pal.amber)
            if (t.komitmenId.isNotEmpty()) {
                val c = s.commitments.find { it.id == t.komitmenId }
                val ic = billIc(c?.nama ?: t.perkara)
                return Vis(ic, billTint(ic, pal))
            }
            when (PG.kategoriOf(t)) {
                "makan" -> Vis(Ic.FORK, pal.amber)
                "dapur" -> Vis(Ic.CART, pal.amber)
                "rumah" -> Vis(Ic.HOME, pal.out)
                "bil" -> billIc(t.perkara).let { Vis(it, billTint(it, pal)) }
                "minyak", "kenderaan" -> Vis(Ic.CAR, pal.accent)
                "kesihatan" -> Vis(Ic.PLUS, pal.out)
                "keluarga" -> Vis(Ic.HEART, pal.p[4])
                "diri" -> Vis(Ic.TAG, pal.p[3])
                "hiburan" -> Vis(Ic.SUN, pal.p[1])
                "sedekah" -> Vis(Ic.HEART, pal.accent)
                else -> if (t.jenis == "kad") Vis(Ic.CARD, pal.out) else Vis(Ic.ARROW_UP, pal.out)
            }
        }
    }
}

/** Jubin ikon: segi empat bulat lembut dengan ikon di tengah. */
@Composable
fun IconTile(ic: Ic, fg: Color, size: Dp = 40.dp, icon: Dp = 22.dp, bg: Color? = null, radius: Dp = 12.dp, stroke: Float = 1.9f) {
    Box(
        Modifier.size(size).clip(RoundedCornerShape(radius)).background(bg ?: fg.copy(alpha = 0.13f)),
        contentAlignment = Alignment.Center,
    ) { Ico(ic, fg, icon, stroke = stroke) }
}

/** Butang ikon bulat 48dp (sasaran sentuh ≥ 48dp) dengan label untuk pembaca skrin. */
@Composable
fun IconBtn(ic: Ic, desc: String, onClick: () -> Unit, tint: Color? = null, bg: Color = Color.Transparent, dot: Boolean = false, size: Dp = 48.dp) {
    val pal = LocalPal.current
    Box(
        Modifier.size(size).clip(CircleShape).background(bg).pressable(onClick, scaleTo = 0.88f).semantics { contentDescription = tr(desc) },
        contentAlignment = Alignment.Center,
    ) {
        Ico(ic, tint ?: pal.ink, 22.dp, stroke = 1.9f)
        if (dot) Box(Modifier.size(18.dp), contentAlignment = Alignment.TopEnd) {
            Box(Modifier.size(8.dp).background(pal.bad, CircleShape))
        }
    }
}

/** Ilustrasi buku lejar terbuka (hiasan sahaja). */
@Composable
fun LejarBook(modifier: Modifier = Modifier, w: Dp = 84.dp, h: Dp = 54.dp) {
    val pal = LocalPal.current
    Canvas(modifier.size(w, h)) {
        val W = size.width; val H = size.height
        val st = Stroke(width = 1.2.dp.toPx())
        val page = if (pal.dark) pal.surface2 else Color(0xFFFFFDF7)
        // bayang bawah
        drawRoundRect(pal.shadow.copy(alpha = 0.35f), topLeft = Offset(W * 0.06f, H * 0.82f), size = Size(W * 0.88f, H * 0.12f), cornerRadius = CornerRadius(H * 0.06f))
        fun halaman(kiri: Boolean) {
            val x0 = if (kiri) W * 0.05f else W * 0.5f
            val x1 = if (kiri) W * 0.5f else W * 0.95f
            val p = Path().apply {
                if (kiri) {
                    moveTo(x1, H * 0.2f); quadraticBezierTo(W * 0.3f, H * 0.08f, x0, H * 0.14f)
                    lineTo(x0, H * 0.84f); quadraticBezierTo(W * 0.3f, H * 0.78f, x1, H * 0.9f); close()
                } else {
                    moveTo(x0, H * 0.2f); quadraticBezierTo(W * 0.7f, H * 0.08f, x1, H * 0.14f)
                    lineTo(x1, H * 0.84f); quadraticBezierTo(W * 0.7f, H * 0.78f, x0, H * 0.9f); close()
                }
            }
            drawPath(p, page)
            drawPath(p, pal.border, style = st)
            // garis lejar halus
            for (k in 0 until 5) {
                val y = H * (0.32f + k * 0.11f)
                val a = if (kiri) x0 + W * 0.06f else x0 + W * 0.05f
                val b = if (kiri) x1 - W * 0.05f else x1 - W * 0.06f
                drawLine(pal.accent.copy(alpha = 0.18f), Offset(a, y), Offset(b, y), strokeWidth = 1.dp.toPx())
            }
        }
        halaman(true); halaman(false)
        drawLine(pal.border, Offset(W * 0.5f, H * 0.2f), Offset(W * 0.5f, H * 0.9f), strokeWidth = 1.4.dp.toPx())
    }
}
