package com.asyraf.hadirku.rumah

import com.asyraf.hadirku.kongsi.Barang
import com.asyraf.hadirku.pg.PG

/**
 * Kiraan senarai barang dapur: jumlah harga ikut unit, asingkan MyKasih daripada bayar sendiri.
 * Barang MyKasih dibayar guna kredit MyKasih, jadi tidak ditolak dari poket bila direkod.
 */
object Dapur {

    /** Satu bahagian senarai (bayar sendiri atau MyKasih). */
    class Bahagian(val barang: List<Barang>) {
        val jumlah: Double = PG.round2(barang.sumOf { it.jumlah })
        val bil: Int get() = barang.size
        /** Barang yang belum ada harga (tidak masuk jumlah). */
        val tanpaHarga: Int = barang.count { !it.adaHarga }
        val troli: List<Barang> get() = barang.filter { it.dibeli }
        val jumlahTroli: Double = PG.round2(barang.filter { it.dibeli }.sumOf { it.jumlah })
    }

    class Ringkasan(val sendiri: Bahagian, val mykasih: Bahagian) {
        val jumlahSemua: Double = PG.round2(sendiri.jumlah + mykasih.jumlah)
        val bil: Int get() = sendiri.bil + mykasih.bil
        val troli: List<Barang> get() = sendiri.troli + mykasih.troli
    }

    /** Susun ikut masa ditambah supaya nombor item kekal tetap bila barang ditick. */
    fun ringkasan(list: List<Barang>): Ringkasan {
        val ikutMasa = list.sortedWith(compareBy<Barang> { it.dibuat }.thenBy { it.id })
        return Ringkasan(Bahagian(ikutMasa.filter { !it.mykasih }), Bahagian(ikutMasa.filter { it.mykasih }))
    }

    /** Jumlah yang direkod sebagai belanja dari poket: barang bayar sendiri yang ditick sahaja. */
    fun jumlahRekod(list: List<Barang>): Double = PG.round2(list.filter { it.dibeli && !it.mykasih }.sumOf { it.jumlah })

    /** Unit: nombor lebih daripada 0 (boleh perpuluhan, cth 1.5 kg). Kosong = 1. Null = tidak sah. */
    fun bacaUnit(raw: String): Double? {
        val t = raw.trim().replace(',', '.')
        if (t.isEmpty()) return 1.0
        val n = t.toDoubleOrNull() ?: return null
        if (!n.isFinite() || n <= 0 || n > 9999) return null
        return Math.round(n * 1000) / 1000.0
    }

    /** Harga seunit: kosong = 0 (belum tahu). Null = tidak sah. */
    fun bacaHarga(raw: String): Double? {
        val t = raw.replace(Regex("[^0-9.,]"), "").replaceFirst(',', '.')
        if (t.isEmpty()) return if (raw.isBlank()) 0.0 else null
        val n = t.toDoubleOrNull() ?: return null
        if (!n.isFinite() || n < 0 || n > 999_999) return null
        return PG.round2(n)
    }

    /** 2.0 → "2", 1.5 → "1.5", 0.25 → "0.25". */
    fun fmtUnit(u: Double): String {
        val r = Math.round(u * 1000) / 1000.0
        return if (r == Math.floor(r)) r.toLong().toString() else r.toString().trimEnd('0').trimEnd('.')
    }

    /** Wang tanpa "RM" untuk lajur jadual (tajuk lajur sudah tulis RM). */
    fun fmtRm(x: Double): String = PG.money(x).replace("RM", "")

    /** Perkara transaksi bila rekod belanja: "Beras ×2, Minyak masak" (maks 60 aksara). */
    fun perkara(list: List<Barang>): String {
        val s = list.joinToString(", ") { if (Math.abs(it.unit - 1.0) < 0.0005) it.nama else it.nama + " ×" + fmtUnit(it.unit) }
        return if (s.length > 60) s.take(57) + "…" else s
    }
}
