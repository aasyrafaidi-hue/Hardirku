package com.asyraf.hadirku.rumah

import com.asyraf.hadirku.kongsi.Barang
import com.asyraf.hadirku.kongsi.SejarahBeli
import com.asyraf.hadirku.pg.PG

/**
 * Kiraan senarai barang dapur: jumlah harga ikut unit, asingkan MyKasih daripada bayar sendiri.
 * Barang MyKasih dibayar guna kredit MyKasih, jadi tidak ditolak dari poket bila direkod.
 */
object Dapur {

    /** Satu bahagian senarai (bayar sendiri atau MyKasih). */
    class Bahagian(val barang: List<Barang>) {
        val jumlah: Double = PG.round2(barang.sumOf { it.jumlah })
        val bil: Int get() = barang.size
        /** Barang yang belum ada harga (tidak masuk jumlah). */
        val tanpaHarga: Int = barang.count { !it.adaHarga }
        val troli: List<Barang> get() = barang.filter { it.dibeli }
        val jumlahTroli: Double = PG.round2(barang.filter { it.dibeli }.sumOf { it.jumlah })
    }

    class Ringkasan(val sendiri: Bahagian, val mykasih: Bahagian) {
        val jumlahSemua: Double = PG.round2(sendiri.jumlah + mykasih.jumlah)
        val bil: Int get() = sendiri.bil + mykasih.bil
        val troli: List<Barang> get() = sendiri.troli + mykasih.troli
    }

    /** Susun ikut masa ditambah supaya nombor item kekal tetap bila barang ditick. */
    fun ringkasan(list: List<Barang>): Ringkasan {
        val ikutMasa = list.sortedWith(compareBy<Barang> { it.dibuat }.thenBy { it.id })
        return Ringkasan(Bahagian(ikutMasa.filter { !it.mykasih }), Bahagian(ikutMasa.filter { it.mykasih }))
    }

    /** Jumlah yang direkod sebagai belanja dari poket: barang bayar sendiri yang ditick sahaja. */
    fun jumlahRekod(list: List<Barang>): Double = PG.round2(list.filter { it.dibeli && !it.mykasih }.sumOf { it.jumlah })

    /**
     * Jumlah troli bayar sendiri selepas barang [id] (null = barang baru) disimpan dengan nilai [jumlahBaru].
     * Barang MyKasih dan barang belum ambil tidak masuk troli bayar sendiri.
     */
    fun troliSelepas(list: List<Barang>, id: String?, jumlahBaru: Double, keTroli: Boolean, mykasih: Boolean): Double =
        PG.round2(list.filter { it.dibeli && !it.mykasih && it.id != id }.sumOf { it.jumlah } + if (keTroli && !mykasih) jumlahBaru else 0.0)

    /** Baki had selepas troli [troli] (negatif = melebihi had). */
    fun bakiHad(troli: Double, had: Double): Double = PG.round2(had - troli)

    /** Unit: nombor lebih daripada 0 (boleh perpuluhan, cth 1.5 kg). Kosong = 1. Null = tidak sah. */
    fun bacaUnit(raw: String): Double? {
        val t = raw.trim().replace(',', '.')
        if (t.isEmpty()) return 1.0
        val n = t.toDoubleOrNull() ?: return null
        if (!n.isFinite() || n <= 0 || n > 9999) return null
        return Math.round(n * 1000) / 1000.0
    }

    /** Harga seunit: kosong = 0 (belum tahu). Null = tidak sah. */
    fun bacaHarga(raw: String): Double? {
        val t = raw.replace(Regex("[^0-9.,]"), "").replaceFirst(',', '.')
        if (t.isEmpty()) return if (raw.isBlank()) 0.0 else null
        val n = t.toDoubleOrNull() ?: return null
        if (!n.isFinite() || n < 0 || n > 999_999) return null
        return PG.round2(n)
    }

    /** 2.0 → "2", 1.5 → "1.5", 0.25 → "0.25". */
    fun fmtUnit(u: Double): String {
        val r = Math.round(u * 1000) / 1000.0
        return if (r == Math.floor(r)) r.toLong().toString() else r.toString().trimEnd('0').trimEnd('.')
    }

    /** Wang tanpa "RM" untuk lajur jadual (tajuk lajur sudah tulis RM). */
    fun fmtRm(x: Double): String = PG.money(x).replace("RM", "")

    /** Perkara transaksi bila rekod belanja: "Beras ×2, Minyak masak" (maks 60 aksara). */
    fun perkara(list: List<Barang>): String {
        val s = list.joinToString(", ") { if (Math.abs(it.unit - 1.0) < 0.0005) it.nama else it.nama + " ×" + fmtUnit(it.unit) }
        return if (s.length > 60) s.take(57) + "…" else s
    }

    // ---------------- isi pantas (AI / teks) ----------------

    /** Barang cadangan sebelum disimpan. [harga] seunit (0 = tiada); [hargaLepas] = harga diambil daripada pembelian lepas. */
    data class Cadang(val nama: String, val unit: Double = 1.0, val harga: Double = 0.0, val mykasih: Boolean = false, val hargaLepas: Boolean = false) {
        val jumlah: Double get() = PG.round2(unit * harga)
        val adaHarga: Boolean get() = harga > 0.004
    }

    /** Bersihkan satu cadangan (dari AI atau teks). Null kalau nama kosong. Unit/harga di luar julat dibetulkan. */
    fun cadang(nama: String, unit: Double, harga: Double, mykasih: Boolean): Cadang? {
        val n = nama.replace(Regex("\\s+"), " ").trim().trim('-', ':', '=', '·', ',').trim().take(60)
        if (n.isEmpty() || !n.any { it.isLetter() }) return null
        val u = if (unit.isFinite() && unit > 0 && unit <= 999) Math.round(unit * 1000) / 1000.0 else 1.0
        val h = if (harga.isFinite() && harga > 0 && harga <= 99_999) PG.round2(harga) else 0.0
        return Cadang(n.replaceFirstChar { it.uppercaseChar() }, u, h, mykasih)
    }

    private val RX_PISAH = Regex("\\n|;|,(?!\\d)")
    private val RX_BULET = Regex("^\\s*(?:[-•*·]+|\\d{1,2}[.)])\\s+")
    private val RX_MK = Regex("\\(?\\bmy\\s?kasih\\b\\)?", RegexOption.IGNORE_CASE)
    private const val NUM = "(\\d+(?:[.,]\\d{1,2})?)"
    private val RX_KALI_HUJUNG = Regex("(?:^|\\s)(\\d+(?:[.,]\\d+)?)\\s*[x×*@]\\s*(?:rm\\s*)?$NUM\\s*$", RegexOption.IGNORE_CASE)
    private val RX_X_UNIT = Regex("\\s[x×]\\s*(\\d{1,3})\\s*$", RegexOption.IGNORE_CASE)
    private val RX_HARGA_HUJUNG = Regex("(?:^|\\s)(?:rm\\s*)?$NUM\\s*$", RegexOption.IGNORE_CASE)
    private val RX_RM = Regex("\\brm\\s*$NUM", RegexOption.IGNORE_CASE)
    private val RX_UNIT_DEPAN = Regex("^(\\d{1,3})\\s*[x×]\\s+", RegexOption.IGNORE_CASE)

    private fun nombor(t: String): Double = t.replace(',', '.').toDoubleOrNull() ?: 0.0

    /**
     * Hurai teks ringkas tanpa AI (bila tiada internet / kunci API). Satu barang setiap baris, atau dipisah koma / titik koma.
     * Format: "nama harga" — cth "Beras 10kg 32.90", "Minyak 2 x 7.50", "2x Gula 3.10", "Susu rm12 mykasih".
     * Nombor terakhir = harga seunit; "a x b" = unit a, harga b; "mykasih" = bayar guna MyKasih.
     */
    fun huraiTeks(teks: String): List<Cadang> = teks.split(RX_PISAH).mapNotNull { baris0 ->
        var b = baris0.replace(RX_BULET, "").trim()
        if (b.isEmpty()) return@mapNotNull null
        val mk = RX_MK.containsMatchIn(b)
        b = b.replace(RX_MK, " ").trim()
        var unit = 1.0
        var harga = 0.0
        val kali = RX_KALI_HUJUNG.find(b)
        if (kali != null) {
            val (x, y) = kali.groupValues[1] to kali.groupValues[2]
            // "7.50 x2" = harga 7.50 × 2 unit; "2 x 7.50" = 2 unit × harga 7.50
            val tukar = x.any { it == '.' || it == ',' } && y.none { it == '.' || it == ',' }
            unit = nombor(if (tukar) y else x); harga = nombor(if (tukar) x else y); b = b.substring(0, kali.range.first)
        } else {
            RX_X_UNIT.find(b)?.let { unit = nombor(it.groupValues[1]); b = b.substring(0, it.range.first) }
            val hj = RX_HARGA_HUJUNG.find(b)
            if (hj != null && hj.range.first > 0) { harga = nombor(hj.groupValues[1]); b = b.substring(0, hj.range.first) }
            else RX_RM.find(b)?.let { harga = nombor(it.groupValues[1]); b = b.removeRange(it.range) }
        }
        RX_UNIT_DEPAN.find(b)?.let { if (unit == 1.0) unit = nombor(it.groupValues[1]); b = b.substring(it.range.last + 1) }
        cadang(b, unit, harga, mk)
    }

    /** Isi harga kosong dengan harga pembelian lepas (barang sama ikut [kunci]); MyKasih ikut kali lepas jika tidak dinyatakan. */
    fun lengkapkan(list: List<Cadang>, sejarah: List<SejarahBeli>, kunci: (String) -> String): List<Cadang> {
        if (sejarah.isEmpty()) return list
        val lepas = HashMap<String, SejarahBeli>()
        sejarah.forEach { h -> if (h.harga > 0.004) lepas.putIfAbsent(kunci(h.nama), h) }
        return list.map { c ->
            if (c.adaHarga) c else lepas[kunci(c.nama)]?.let { h -> c.copy(harga = PG.round2(h.harga), mykasih = c.mykasih || h.mykasih, hargaLepas = true) } ?: c
        }
    }

    /** Jumlah bayar sendiri untuk cadangan yang dipilih (MyKasih tidak dikira). */
    fun jumlahCadang(list: List<Cadang>): Double = PG.round2(list.filter { !it.mykasih }.sumOf { it.jumlah })
}
