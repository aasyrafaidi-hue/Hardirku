package com.asyraf.hadirku.pg

import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

/** Data contoh 6 bulan (port terus sampleState dalam core.js; angka tetap, tiada rawak). */
object PgSample {

    private class MDebt(val base: Debt) { val log = ArrayList<DebtLog>(); val epp = ArrayList<Epp>() }

    fun sampleState(today: String): PgState {
        val base = PG.defaultState()
        val gaji = Gaji(2400.0, 100.0, 40.0, 9.0, 104.0, 500.0, 800.0)
        val settings = base.settings.copy(gaji = gaji, hutangBajet = 600.0)
        val pockets = base.pockets.map { p ->
            when (p.id) {
                "p-dapur" -> p.copy(sasaran = 600.0)
                "p-minyak" -> p.copy(sasaran = 200.0)
                "p-bebas" -> p.copy(sasaran = 300.0)
                else -> p
            }
        }
        val commitments = listOf(
            Commitment("k-sewa", "Sewa rumah", 650.0, "30", "p-komitmen", tempo = 1),
            Commitment("k-motor", "Ansuran motor", 280.0, "30", "p-komitmen", tempo = 7),
            Commitment("k-tnb", "Bil TNB", 85.0, "15", "p-komitmen", tempo = 22),
            Commitment("k-net", "Internet rumah", 99.0, "15", "p-komitmen", tempo = 18),
            Commitment("k-telefon", "Pelan telefon", 45.0, "15", "p-komitmen", tempo = 25),
        )
        val visa = MDebt(Debt("h-visa", "Kad kredit Visa", "kad", 18.0, 5.0, 50.0, 0.0, 450.0, 8000.0, "p-komitmen"))
        val master = MDebt(Debt("h-master", "Kad kredit Mastercard", "kad", 15.0, 5.0, 50.0, 0.0, 150.0, 3000.0, "p-komitmen"))
        fun wave(k: Int, j: Int, m: Int): Double = ((k * 37 + j * 53 + 11) % m).toDouble() / m

        var s = base.copy(contoh = true, settings = settings, pockets = pockets, commitments = commitments)
        val ot = LinkedHashMap<String, OtEntry>()
        val od = s.settings.otMulaHari
        val cur = PG.otCycleOf(today, od)
        val rehatArr = intArrayOf(5, 2, 4, 1, 3, 0, 2, 4)
        for (ck in 7 downTo 0) {
            val cyc = PG.shiftCycle(cur, -ck, od)
            var wk = 0
            val rehat = rehatArr[ck]
            cyc.days.forEach { dt ->
                if (dt > today) return@forEach
                val w = PG.weekday(dt)
                if (w == 0) { ot[dt] = OtEntry("tidak"); return@forEach }
                if (w == 6) { ot[dt] = if ((ck + dt.substring(8).toInt()) % 3 == 0) OtEntry("tidak") else OtEntry("off", 8.0); return@forEach }
                wk++
                ot[dt] = OtEntry("biasa", if (wk % 4 == 1 && ceil(wk / 4.0) <= rehat) 9.0 else 12.0)
            }
        }
        s = s.copy(ot = ot)

        val tx = ArrayList<Tx>()
        var n = 0
        var logN = 0
        val katBaru = PG.addDays(today, -5)
        val ks = mapOf(
            "Sewa rumah" to "rumah", "Ansuran motor" to "kenderaan", "Internet rumah" to "bil", "Pelan telefon" to "bil", "Bil TNB" to "bil",
            "Barang dapur Mydin" to "dapur", "Pasar malam" to "makan", "Barang dapur" to "dapur", "Ikan & sayur" to "dapur", "Lotus's" to "dapur", "Pasar tani" to "dapur",
            "Isi minyak" to "minyak", "Tol & parking" to "minyak", "Makan luar" to "makan", "Kedai mamak" to "makan", "Barang rumah" to "rumah",
            "Servis motor" to "kenderaan", "Klinik" to "kesihatan", "Isi minyak guna kad" to "minyak", "Barang rumah guna kad" to "rumah",
        )
        fun add(tarikh: String, perkara: String, jenis: String, poket: String, ke: String, jumlah: Double,
                komitmenId: String = "", hutangId: String = "", kadId: String = "") {
            if (tarikh > today || !(jumlah > 0)) return
            n++
            var t = Tx("t-contoh-$n", tarikh, jenis, poket, ke, PG.round2(jumlah), perkara, komitmenId, hutangId, kadId, "", n.toLong())
            val k = ks[perkara]
            if (k != null && PG.bolehKategori(t) && tarikh <= katBaru) t = t.copy(kategori = k)
            tx.add(t)
        }
        fun log(d: MDebt, tarikh: String, jenis: String, jumlah: Double, catatan: String) {
            if (tarikh > today || !(jumlah > 0)) return
            logN++; n++
            d.log.add(DebtLog("l-contoh-$logN", tarikh, jenis, PG.round2(jumlah), catatan, n.toLong()))
        }
        val m0 = PG.ym(today) + "-01"
        val first = PG.addMonths(m0, -5)
        fun gajiDate(mo: String): String { val p2 = PG.parse(mo); val last = PG.lastDay(p2.y, p2.m); return PG.iso(p2.y, p2.m, min(30, last)) }
        val eppMula = PG.addDays(PG.addMonths(m0, -3), 24)
        visa.epp.add(Epp("e-contoh-1", "Telefon baru", 1200.0, 12, 0.0, 0.0, eppMula, ""))
        val B = PG.BELUM_AGIH
        fun payGaji(dt: String, latest: Boolean) {
            if (dt > today) return
            val py = PG.parse(dt)
            val pcY = if (py.m == 1) py.y - 1 else py.y
            val pcM = if (py.m == 1) 12 else py.m - 1
            val g = max(1500.0, PG.otSummary(s, PG.otCycle(pcY, pcM, od)).gaji30)
            add(dt, "Gaji 30hb", "masuk", B, "", g)
            var rest = PG.round2(g)
            fun alloc(to: String, amt: Double, label: String) {
                val a2 = PG.round2(min(rest, amt)); rest = PG.round2(rest - a2); add(dt, label, "pindah", B, to, a2)
            }
            alloc("p-komitmen", 1159.0 + 600 + 20, "Agih komitmen & hutang")
            alloc("p-dapur", 430.0, "Agih dapur")
            alloc("p-minyak", 180.0, "Agih minyak")
            alloc("p-bebas", 170.0, "Duit belanja")
            alloc("p-kecemasan", if (latest) max(0.0, rest - 180) else rest, if (latest) "Simpan ke kecemasan" else "Simpan baki ke kecemasan")
        }
        val g0 = gajiDate(PG.addMonths(first, -1))
        add(PG.addDays(g0, -1), "Baki permulaan bank", "baki-awal", B, "", 1200.0)
        add(PG.addDays(g0, -1), "Mula dana kecemasan", "pindah", B, "p-kecemasan", 1200.0)
        log(visa, PG.addDays(g0, -5), "penyata", 6400.0, "Penyata bulan lalu")
        log(master, PG.addDays(g0, -5), "penyata", 1900.0, "Penyata bulan lalu")
        payGaji(g0, false)
        var vb = 6400.0
        var mb = 1900.0
        val adv = gaji.advance
        for (k in 5 downTo 0) {
            val mo = PG.addMonths(m0, -k)
            fun day(d2: Int) = PG.addDays(mo, d2 - 1)
            add(day(1), "Sewa rumah", "keluar", "p-komitmen", "", 650.0, komitmenId = "k-sewa")
            add(day(2), "Ansuran motor", "keluar", "p-komitmen", "", 280.0, komitmenId = "k-motor")
            add(day(3), "Bayar kad Visa", "keluar", "p-komitmen", "", 450.0, hutangId = "h-visa")
            add(day(4), "Bayar kad Mastercard", "keluar", "p-komitmen", "", 150.0, hutangId = "h-master")
            if (day(3) <= today) vb -= 450
            if (day(4) <= today) mb -= 150
            add(day(15), "Advance 15hb", "masuk", B, "", adv)
            add(day(15), "Agih dapur", "pindah", B, "p-dapur", 220.0)
            add(day(15), "Agih minyak", "pindah", B, "p-minyak", 80.0)
            add(day(15), "Duit belanja", "pindah", B, "p-bebas", 150.0)
            add(day(15), "Simpan ke kecemasan", "pindah", B, "p-kecemasan", adv - 450)
            add(day(15), "Internet rumah", "keluar", "p-komitmen", "", 99.0, komitmenId = "k-net")
            add(day(15), "Pelan telefon", "keluar", "p-komitmen", "", 45.0, komitmenId = "k-telefon")
            add(day(22), "Bil TNB", "keluar", "p-komitmen", "", 85 + PG.jsRound(wave(k, 1, 7) * 14), komitmenId = "k-tnb")
            val dapur = listOf("Barang dapur Mydin", "Pasar malam", "Barang dapur", "Ikan & sayur", "Lotus's", "Pasar tani", "Barang dapur")
            listOf(3, 7, 10, 14, 19, 24, 28).forEachIndexed { j, o -> add(day(o), dapur[j], "keluar", "p-dapur", "", 62 + wave(k, j, 13) * 48 + (if (k == 1) 14 else 0)) }
            listOf(2, 7, 12, 17, 22, 27).forEachIndexed { j, o -> add(day(o), "Isi minyak", "keluar", "p-minyak", "", 30 + PG.jsRound(wave(k, j, 5) * 6)) }
            add(day(13), "Tol & parking", "keluar", "p-minyak", "", 12.6)
            val bebas = listOf("Makan luar", "Kedai mamak", "Barang rumah", "Makan luar")
            listOf(5, 11, 18, 25).forEachIndexed { j, o -> add(day(o), bebas[j], "keluar", "p-bebas", "", 28 + wave(k, j, 11) * 52 + (if (k == 2 && j == 2) 95 else 0)) }
            if (k == 3) add(day(16), "Servis motor", "keluar", "p-kecemasan", "", 168.0)
            if (k == 1) add(day(9), "Klinik", "keluar", "p-kecemasan", "", 55.0)
            listOf(8, 20).forEachIndexed { j, o ->
                val amt = if (j == 0) PG.round2(38 + wave(k, j + 3, 9) * 10) else PG.round2(45 + wave(k, j + 3, 9) * 40)
                val dt = day(o)
                add(dt, listOf("Isi minyak guna kad", "Barang rumah guna kad")[j], "kad", listOf("p-minyak", "p-bebas")[j], "p-komitmen", amt, kadId = "h-visa")
                if (dt <= today) vb += amt
            }
            if (day(25) <= today) {
                val fv = PG.round2(vb * 0.18 / 12)
                val fm = PG.round2(mb * 0.15 / 12)
                log(visa, day(25), "faedah", fv, "Faedah bulanan"); vb += fv
                log(master, day(25), "faedah", fm, "Faedah bulanan"); mb += fm
                if (day(25) >= eppMula) vb += 100
            }
            payGaji(gajiDate(mo), gajiDate(PG.addMonths(mo, 1)) > today)
        }
        val debts = listOf(visa, master).map { it.base.copy(log = it.log.toList(), epp = it.epp.toList()) }
        s = s.copy(transactions = tx, debts = debts)
        val lastTx = tx.fold(tx[0].tarikh) { m, t -> if (t.tarikh > m) t.tarikh else m }
        val midCheck = PG.addDays(m0, -10)
        s = s.copy(bankChecks = listOf(
            BankCheck("b-contoh-1", midCheck, PG.total(s, midCheck), "", 1),
            BankCheck("b-contoh-2", lastTx, PG.total(s, lastTx), "", 2),
        ))
        return s
    }
}
