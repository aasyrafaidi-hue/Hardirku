package com.asyraf.hadirku.kongsi

import com.asyraf.hadirku.pg.PG

/* Data senarai barang dapur yang dikongsi (Firestore). Diasingkan daripada Kongsi.kt supaya boleh diuji tanpa Firebase. */

/**
 * Satu barang dalam senarai dapur.
 * [unit] = berapa unit (lalai 1), [harga] = harga seunit (0 = belum tahu),
 * [mykasih] = dibayar guna kredit MyKasih (bukan duit poket).
 * Barang lama / barang yang ditambah dari app isteri tanpa medan ini dibaca sebagai 1 unit, harga 0, bukan MyKasih.
 */
data class Barang(
    val id: String,
    val nama: String,
    val nota: String,
    val dibeli: Boolean,
    val oleh: String,
    val dibuat: Long,
    val unit: Double = 1.0,
    val harga: Double = 0.0,
    val mykasih: Boolean = false,
) {
    /** Jumlah harga = unit × harga seunit. */
    val jumlah: Double get() = PG.round2(unit * harga)
    val adaHarga: Boolean get() = harga > 0.004
}

/** Tarikh setiap kali barang dibeli, serta harga seunit & cara bayar yang terakhir (untuk isi semula). */
data class SejarahBeli(
    val id: String,
    val nama: String,
    val tarikh: List<String>,
    val harga: Double = 0.0,
    val mykasih: Boolean = false,
)
