package com.asyraf.hadirku.kongsi

import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.PgState
import com.asyraf.hadirku.pg.Tx

/* Data senarai barang dapur yang dikongsi (Firestore). Diasingkan daripada Kongsi.kt supaya boleh diuji tanpa Firebase. */

/**
 * Satu barang dalam senarai dapur.
 * [unit] = berapa unit (lalai 1), [harga] = harga seunit (0 = belum tahu),
 * [mykasih] = dibayar guna kredit MyKasih (bukan duit poket).
 * Barang lama / barang yang ditambah dari app isteri tanpa medan ini dibaca sebagai 1 unit, harga 0, bukan MyKasih.
 */
data class Barang(
    val id: String,
    val nama: String,
    val nota: String,
    val dibeli: Boolean,
    val oleh: String,
    val dibuat: Long,
    val unit: Double = 1.0,
    val harga: Double = 0.0,
    val mykasih: Boolean = false,
) {
    /** Jumlah harga = unit × harga seunit. */
    val jumlah: Double get() = PG.round2(unit * harga)
    val adaHarga: Boolean get() = harga > 0.004
}

/** Tarikh setiap kali barang dibeli, serta harga seunit & cara bayar yang terakhir (untuk isi semula). */
data class SejarahBeli(
    val id: String,
    val nama: String,
    val tarikh: List<String>,
    val harga: Double = 0.0,
    val mykasih: Boolean = false,
)

/**
 * Duit yang suami hantar kepada isteri (rumah/{id}/nafkah). Dokumen lama hanya ada medan asal; medan baharu
 * dibaca dengan nilai lalai, jadi data lama tetap sah.
 *
 * [jenis]   "nafkah" (lalai) atau "dapur" (duit dapur — isteri belanja, baki boleh dipulangkan)
 * [minta]   "" = dihantar suami; "tunggu" = isteri minta, belum dijawab; "tolak" = suami tolak; "lulus" = diluluskan & dihantar
 * [peminta] uid isteri yang minta (permintaan sahaja)
 * [guna]    duit dapur: belanja dapur isteri sejak terima (dikira & dikemas kini oleh app isteri)
 * [pulang]  duit dapur: baki yang isteri pulangkan; [pulangTx] = id transaksi pulang dalam app isteri
 * [pulangDiterima] suami sudah rekod pulangan dalam app dia; [selesai] = duit dapur ditutup
 */
data class Nafkah(
    val id: String,
    val jumlah: Double,
    val catatan: String,
    val dari: String,
    val tarikh: String,
    val diterima: Boolean,
    val dibuat: Long,
    val jenis: String = "nafkah",
    val minta: String = "",
    val peminta: String = "",
    val diterimaTarikh: String = "",
    val guna: Double = 0.0,
    val pulang: Double = 0.0,
    val pulangTx: String = "",
    val pulangDiterima: Boolean = false,
    val selesai: Boolean = false,
) {
    val dapur: Boolean get() = jenis == "dapur"
    /** Duit yang benar-benar dihantar (bukan permintaan yang belum/tidak diluluskan). */
    val dihantar: Boolean get() = dari.isNotEmpty() && minta != "tunggu" && minta != "tolak"
    val tungguJawapan: Boolean get() = minta == "tunggu"
    /** Duit dapur yang sedang digunakan isteri. */
    val dapurAktif: Boolean get() = dapur && dihantar && diterima && !selesai
    /** Baki duit dapur = jumlah − belanja − dipulangkan (tidak negatif). */
    val baki: Double get() = PG.round2(maxOf(0.0, jumlah - guna - pulang))
    /** Pulangan duit dapur yang suami belum rekod. */
    val pulangBelumDirekod: Boolean get() = dapur && pulang > 0.004 && !pulangDiterima
}

/** Nafkah bulanan yang suami tetapkan (rumah/{id}/tetapan/nafkah). [hari] 1–31 (31 = hari terakhir bulan). */
data class JadualNafkah(val jumlah: Double, val hari: Int)

/**
 * Tabung bersama (rumah/{id}/tabung): [ahli] = sumbangan setiap telefon (uid → RM), iaitu baki poket tabung
 * dalam telefon itu. Jumlah = semua sumbangan.
 */
data class Tabung(
    val id: String,
    val nama: String,
    val sasaran: Double,
    val tarikh: String,
    val ahli: Map<String, Double>,
    val dibuat: Long,
) {
    val jumlah: Double get() = PG.round2(ahli.values.sum())
    val peratus: Double get() = if (sasaran > 0.004) (jumlah / sasaran).coerceIn(0.0, 1.0) else 0.0
}

/** Kiraan rumah tangga yang dikongsi (tanpa Firebase, boleh diuji). */
object Rumahtangga {

    /**
     * Belanja dapur isteri bagi setiap duit dapur aktif (id → RM). Belanja kategori "dapur" (keluar & guna kad) sejak
     * tarikh terima diagih ikut giliran (duit dapur paling awal dulu), tidak melebihi jumlah setiap satu.
     * Duit dipulangkan (refund dapur) mengurangkan belanja. Transaksi pulang baki ke suami tidak dikira.
     */
    fun gunaDapur(s: PgState, sampul: List<Nafkah>): Map<String, Double> {
        val aktif = sampul.filter { it.dapurAktif && it.diterimaTarikh.isNotEmpty() }
            .sortedWith(compareBy<Nafkah> { it.diterimaTarikh }.thenBy { it.dibuat })
        if (aktif.isEmpty()) return emptyMap()
        val kecuali = sampul.map { it.pulangTx }.filter { it.isNotEmpty() }.toSet()
        val mula = aktif.first().diterimaTarikh
        val guna = LinkedHashMap<String, Double>().apply { aktif.forEach { put(it.id, 0.0) } }
        val tx = s.transactions.filter { t ->
            t.id !in kecuali && t.kategori == "dapur" && t.tarikh >= mula &&
                ((t.jenis == "keluar" && t.hutangId.isEmpty() && t.komitmenId.isEmpty()) || t.jenis == "kad" || PG.isPulangan(t))
        }.sortedWith(compareBy<Tx> { it.tarikh }.thenBy { it.dibuat })
        for (t in tx) {
            if (PG.isPulangan(t)) {
                // refund: kurangkan daripada duit dapur terkini yang sudah ada belanja
                var r = t.jumlah
                for (n in aktif.reversed()) {
                    if (r <= 0.004) break
                    val g = guna.getValue(n.id)
                    val kurang = minOf(g, r)
                    guna[n.id] = g - kurang; r -= kurang
                }
                continue
            }
            var x = t.jumlah
            for (n in aktif) {
                if (x <= 0.004) break
                if (t.tarikh < n.diterimaTarikh) continue
                val ruang = n.jumlah - n.pulang - guna.getValue(n.id)
                if (ruang <= 0.004) continue
                val ambil = minOf(ruang, x)
                guna[n.id] = guna.getValue(n.id) + ambil; x -= ambil
            }
        }
        return guna.mapValues { PG.round2(it.value) }
    }

    /** Baki semua duit dapur aktif (untuk had troli dalam app isteri). null = tiada duit dapur aktif. */
    fun bakiDapur(sampul: List<Nafkah>): Double? {
        val a = sampul.filter { it.dapurAktif }
        return if (a.isEmpty()) null else PG.round2(a.sumOf { it.baki })
    }

    /** Tarikh nafkah bulanan dalam bulan [ym] (hari 31 → hari terakhir bulan). */
    fun tarikhNafkah(j: JadualNafkah, ym: String): String {
        val y = ym.substring(0, 4).toInt(); val m = ym.substring(5, 7).toInt()
        return PG.iso(y, m, minOf(j.hari, java.time.YearMonth.of(y, m).lengthOfMonth()))
    }

    /**
     * App suami: perlu ingatkan nafkah bulanan? Ya jika hari ini sudah sampai tarikh nafkah bulan ini dan nafkah
     * (bukan duit dapur) yang dihantar bulan ini masih kurang daripada separuh jumlah jadual.
     */
    fun perluHantarNafkah(j: JadualNafkah?, dihantar: List<Nafkah>, today: String): Boolean {
        if (j == null || j.jumlah <= 0.004) return false
        val ym = today.substring(0, 7)
        if (today < tarikhNafkah(j, ym)) return false
        val bulanIni = dihantar.filter { it.dihantar && !it.dapur && it.tarikh.startsWith(ym) }.sumOf { it.jumlah }
        return bulanIni < j.jumlah * 0.5
    }
}
