package com.asyraf.hadirku.ui

import androidx.compose.foundation.background
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.sp
import com.asyraf.hadirku.i18n.tr
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.asyraf.hadirku.MainViewModel
import com.asyraf.hadirku.Sheet
import com.asyraf.hadirku.pg.DailySummary
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.PgState
import com.asyraf.hadirku.pg.Tx

private val byNewest = Comparator<Tx> { a, b ->
    val c = b.tarikh.compareTo(a.tarikh)
    if (c != 0) c else b.dibuat.compareTo(a.dibuat)
}

/** Penapis Lejar Harian — dipetakan terus kepada medan transaksi sedia ada (tiada kategori rekaan). */
private val PENAPIS = listOf(
    Triple("semua", "Semua", null),
    Triple("masuk", "Masuk", Ic.ARROW_DOWN),
    Triple("keluar", "Keluar", Ic.ARROW_UP),
    Triple("hutang", "Hutang & kad", Ic.CARD),
    Triple("komitmen", "Komitmen", Ic.CALENDAR),
    Triple("pindah", "Pindah", Ic.SWAP),
)

private fun ikutPenapis(t: Tx, f: String): Boolean = when (f) {
    "masuk" -> t.jenis == "masuk"
    "keluar" -> t.jenis == "keluar" || t.jenis == "kad"
    "hutang" -> (t.jenis == "keluar" && t.hutangId.isNotEmpty()) || t.jenis == "kad" || t.jenis == "tunai-kad"
    "komitmen" -> t.komitmenId.isNotEmpty()
    "pindah" -> t.jenis == "pindah"
    else -> true
}

private fun padanCarian(s: PgState, t: Tx, q: String): Boolean {
    if (q.isEmpty()) return true
    val hay = buildString {
        append(t.perkara).append(' ').append(t.catatan).append(' ')
        append(pname(s, t.poket)).append(' ')
        if (t.ke.isNotEmpty()) append(pname(s, t.ke)).append(' ')
        if (PG.bolehKategori(t)) append(PG.katLabel(PG.kategoriOf(t))).append(' ')
        append(jenisLabel(t.jenis)).append(' ')
        append(PG.money(t.jumlah)).append(' ').append(PG.toFixed(t.jumlah, 2))
    }.lowercase()
    return q.lowercase().split(' ').filter { it.isNotBlank() }.all { it in hay }
}

/** Tab Lejar Harian: penapis, carian, bulan, ringkasan; paparan Senarai | Kalendar (asal). */
@Composable
fun TransaksiScreen(vm: MainViewModel) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val ym = vm.txYm
    val pk = vm.txPocket
    val ds = remember(s, ym, pk) { PG.dailySummary(s, ym, pk.ifEmpty { null }) }
    val om = akruanOn(s) && pk.isEmpty()
    val sett = remember(s) { PG.otSettlements(s).byTx }
    val cari = UiState.txCariBuka
    val q = if (cari) UiState.txCari.trim() else ""
    val senarai = vm.txView != "kalendar" || cari
    val f = if (senarai) UiState.txFilter else "semua"
    val tapis = f != "semua" || q.isNotEmpty()
    val monthTx = remember(s, ym, pk) {
        s.transactions.filter { PG.ym(it.tarikh) == ym && (pk.isEmpty() || it.poket == pk || it.ke == pk) }.sortedWith(byNewest)
    }
    val shown = remember(monthTx, f, q) { monthTx.filter { ikutPenapis(it, f) && padanCarian(s, it, q) } }

    // ---------- keterangan + Senarai | Kalendar ----------
    Row(Modifier.fillMaxWidth().padding(start = GL + 4.dp, end = GL), verticalAlignment = Alignment.CenterVertically) {
        Txt("Rekod semua transaksi masuk dan keluar anda", Modifier.weight(1f), size = 13.5f, color = pal.muted)
        Spacer(Modifier.width(10.dp))
        ViewToggle(if (senarai) "senarai" else "kalendar") { v ->
            if (v == "kalendar") { UiState.txCariBuka = false; UiState.txCari = "" }
            vm.setTxViewMode(v)
        }
    }

    // ---------- carian ----------
    AnimatedVisibility(visible = cari, enter = expandVertically(tween(200)) + fadeIn(tween(180)), exit = shrinkVertically(tween(180)) + fadeOut(tween(120))) {
        CariField()
    }

    // ---------- penapis ----------
    if (senarai) Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = GL),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        PENAPIS.forEach { (id, label, ic) ->
            FilterChipL(label, ic, id == f) { UiState.txFilter = id }
        }
    }

    // ---------- bulan + ringkasan ----------
    val (inLbl, outLbl, inV, outV) = when {
        tapis -> {
            var mi = 0.0; var mk = 0.0
            shown.forEach { t -> if (PG.isPulangan(t)) mk -= t.jumlah else if (t.jenis == "masuk") mi += t.jumlah; if (t.jenis == "keluar" || t.jenis == "kad") mk += t.jumlah }
            Quad("Masuk", "Keluar", PG.round2(mi), PG.round2(mk))
        }
        om -> {
            val rb = remember(s, ym) { PG.periodReport(s, PG.finPeriod("$ym-01", 1)) }
            Quad("Pendapatan", "Perbelanjaan", rb.pend, rb.belanja)
        }
        else -> Quad("Masuk", "Keluar", ds.masuk, ds.keluar)
    }
    BoxWithConstraints(Modifier.fillMaxWidth().padding(horizontal = GL)) {
        val wide = maxWidth >= 380.dp
        val chip: @Composable () -> Unit = { MonthChip(ym) { vm.txYm = it } }
        val sum: @Composable (Modifier) -> Unit = { m -> SumLines(inLbl, inV, outLbl, outV, m) }
        if (wide) Row(verticalAlignment = Alignment.CenterVertically) { chip(); Spacer(Modifier.weight(1f)); sum(Modifier) }
        else Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { chip(); sum(Modifier.fillMaxWidth()) }
    }
    if (tapis) Note((if (q.isNotEmpty()) "Jumlah ikut penapis dan carian" else "Jumlah ikut penapis") + " · keluar termasuk guna kad · " + shown.size + " transaksi")
    else if (om) {
        val rb = remember(s, ym) { PG.periodReport(s, PG.finPeriod("$ym-01", 1)) }
        val k = rb.otKitaran
        if (k != null) Note("OT dalam pendapatan bulan ini: kitaran " + PG.fmtShort(k.start) + " – " + PG.fmtShort(k.end))
    }
    if (pk.isNotEmpty()) {
        Row(Modifier.padding(horizontal = GL), verticalAlignment = Alignment.CenterVertically) {
            Txt("Poket:", size = 13f, color = pal.muted)
            Spacer(Modifier.width(8.dp))
            Row(
                Modifier.clip(RoundedCornerShape(50)).border(1.dp, pal.accent, RoundedCornerShape(50)).background(pal.accentSoft)
                    .clickable { vm.txPocket = "" }.heightIn(min = 36.dp).padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Txt(pname(s, pk), size = 13f, weight = FontWeight.SemiBold, color = pal.accentStrong)
                Spacer(Modifier.width(6.dp))
                Ico(Ic.CLOSE, pal.accentStrong, 14.dp, stroke = 2.2f, desc = "Buang penapis poket")
            }
        }
    }
    if (!senarai) Kalendar(vm, s, ds, om)
    else Senarai(vm, s, ds, om, sett, monthTx, shown, tapis)
}

private data class Quad(val a: String, val b: String, val c: Double, val d: Double)

@Composable
private fun ViewToggle(cur: String, onSel: (String) -> Unit) {
    val pal = LocalPal.current
    val tick = rememberTick()
    val shape = RoundedCornerShape(12.dp)
    Row(Modifier.clip(shape).background(pal.surface2).border(1.dp, pal.border, shape).padding(3.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        listOf(Triple("senarai", Ic.LIST, "Paparan senarai"), Triple("kalendar", Ic.CALENDAR, "Paparan kalendar")).forEach { (id, ic, d) ->
            val on = id == cur
            Box(
                Modifier.size(width = 42.dp, height = 38.dp).clip(RoundedCornerShape(9.dp))
                    .background(if (on) (if (pal.dark) pal.accentSoft else pal.surface) else Color.Transparent)
                    .clickable { if (!on) { tick(); onSel(id) } }
                    .semantics { contentDescription = tr(d); selected = on },
                contentAlignment = Alignment.Center,
            ) { Ico(ic, if (on) pal.accent else pal.muted, 19.dp, stroke = if (on) 2.1f else 1.8f) }
        }
    }
}

@Composable
private fun FilterChipL(label: String, ic: Ic?, on: Boolean, onClick: () -> Unit) {
    val pal = LocalPal.current
    val tick = rememberTick()
    val bg by animateColorAsState(if (on) pal.accent else pal.surface, tween(160), label = "fc")
    val fg by animateColorAsState(if (on) pal.accentInk else pal.ink, tween(160), label = "fcf")
    val shape = RoundedCornerShape(R_CHIP)
    Row(
        Modifier.pressable({ if (!on) tick(); onClick() }, scaleTo = 0.95f)
            .then(if (on) Modifier.shadow(3.dp, shape, ambientColor = pal.shadow, spotColor = pal.shadow) else Modifier)
            .clip(shape).background(bg).border(1.dp, if (on) Color.Transparent else pal.border, shape)
            .heightIn(min = 40.dp).padding(horizontal = 14.dp)
            .semantics { selected = on },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (ic != null) {
            Ico(ic, if (on) fg else when (ic) { Ic.ARROW_DOWN -> pal.inn; Ic.ARROW_UP -> pal.out; else -> pal.muted }, 16.dp, stroke = 2.1f)
            Spacer(Modifier.width(6.dp))
        }
        Txt(label, size = 13.5f, weight = if (on) FontWeight.SemiBold else FontWeight.Medium, color = fg, maxLines = 1)
    }
}

@Composable
private fun CariField() {
    val pal = LocalPal.current
    val fr = autoFocus(true)
    val shape = RoundedCornerShape(R_CHIP)
    Row(
        Modifier.fillMaxWidth().padding(horizontal = GL).clip(shape).background(pal.surface).border(1.5.dp, pal.accent.copy(alpha = 0.5f), shape)
            .heightIn(min = 48.dp).padding(start = 14.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Ico(Ic.SEARCH, pal.muted, 18.dp, stroke = 2f)
        Spacer(Modifier.width(10.dp))
        val ts = TextStyle(fontFamily = AppFont, fontSize = 15.sp, color = pal.ink)
        BasicTextField(
            value = UiState.txCari,
            onValueChange = { UiState.txCari = it.take(60) },
            modifier = Modifier.weight(1f).focusRequester(fr),
            singleLine = true,
            textStyle = ts,
            cursorBrush = SolidColor(pal.accent),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            decorationBox = { inner ->
                Box(Modifier.fillMaxWidth().padding(vertical = 12.dp), contentAlignment = Alignment.CenterStart) {
                    if (UiState.txCari.isEmpty()) Text(tr("Cari perkara, poket, catatan atau jumlah"), style = ts.copy(color = pal.muted.copy(alpha = 0.8f)), maxLines = 1)
                    inner()
                }
            },
        )
        if (UiState.txCari.isNotEmpty()) IconBtn(Ic.CLOSE, "Padam carian", { UiState.txCari = "" }, tint = pal.muted, size = 40.dp)
    }
}

@Composable
private fun MonthChip(ym: String, onPick: (String) -> Unit) {
    val pal = LocalPal.current
    var open by remember { mutableStateOf(false) }
    val cur = PG.ym(PG.todayISO())
    Box {
        Row(
            Modifier.pressable({ open = true }, scaleTo = 0.97f).lejarCard(pal, radius = R_CHIP, elevation = 1.dp)
                .heightIn(min = 46.dp).padding(horizontal = 12.dp)
                .semantics { contentDescription = tr("Pilih bulan") + ": " + PG.fmtMonth(ym) },
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Ico(Ic.CALENDAR, pal.accent, 18.dp, stroke = 2f)
            Spacer(Modifier.width(8.dp))
            Txt(PG.fmtMonth(ym), size = 14.5f, weight = FontWeight.SemiBold, maxLines = 1)
            Spacer(Modifier.width(6.dp))
            Ico(Ic.DOWN, pal.muted, 16.dp, stroke = 2.2f)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            // bulan depan (komitmen / transaksi dijadualkan) hingga 2 tahun lepas
            (-1 until 24).forEach { i ->
                val m = PG.shiftYm(cur, -i)
                DropdownMenuItem(
                    text = { Txt(PG.fmtMonth(m), size = 15f, weight = if (m == ym) FontWeight.SemiBold else FontWeight.Normal, color = if (m == ym) pal.accent else pal.ink) },
                    onClick = { open = false; onPick(m) },
                )
            }
        }
    }
}

@Composable
private fun SumLines(inLbl: String, inV: Double, outLbl: String, outV: Double, modifier: Modifier) {
    val pal = LocalPal.current
    Column(modifier, horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Txt(inLbl, size = 13f, color = pal.muted, maxLines = 1)
            Spacer(Modifier.width(10.dp))
            MoneyAnim(inV, 14.5f, weight = FontWeight.Bold, color = pal.inn, plus = true)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Txt(outLbl, size = 13f, color = pal.muted, maxLines = 1)
            Spacer(Modifier.width(10.dp))
            MoneyAnim(-outV, 14.5f, weight = FontWeight.Bold, color = pal.out)
        }
    }
}

@Composable
private fun Senarai(
    vm: MainViewModel, s: PgState, ds: DailySummary, om: Boolean, sett: Map<String, Double>,
    monthTx: List<Tx>, shown: List<Tx>, tapis: Boolean,
) {
    val pal = LocalPal.current
    val ym = vm.txYm
    val pk = vm.txPocket
    val byDay = LinkedHashMap<String, MutableList<Tx>>()
    shown.forEach { byDay.getOrPut(it.tarikh) { ArrayList() }.add(it) }
    val dates = ArrayList(byDay.keys)
    val logs = HashMap<String, MutableList<com.asyraf.hadirku.pg.KadLog>>()
    // baris OT / kad (mod pendapatan) hanya bila tiada penapis — ia bukan transaksi
    val pseudo = om && !tapis
    if (pseudo) {
        ds.days.forEach { x -> if ((x.ot > 0 || x.kadLog > 0) && !byDay.containsKey(x.tarikh)) { byDay[x.tarikh] = ArrayList(); dates.add(x.tarikh) } }
        PG.kadLogs(s, ds.days[0].tarikh, PG.addDays(ds.days[ds.days.size - 1].tarikh, 1)).forEach { l -> logs.getOrPut(l.tarikh) { ArrayList() }.add(l) }
        dates.sortDescending()
    }
    if (dates.isEmpty()) {
        if (tapis && monthTx.isNotEmpty()) {
            val qq = if (UiState.txCariBuka) UiState.txCari.trim() else ""
            Empty(rich(if (qq.isNotEmpty()) "Tiada hasil carian untuk **" + qq + "**." else "Tiada transaksi untuk penapis ini pada " + PG.fmtMonth(ym) + "."))
            Btn("Padam penapis & carian", { UiState.txFilter = "semua"; UiState.txCari = "" }, Modifier.fillMaxWidth().padding(horizontal = GL))
        } else {
            Empty(rich("Tiada transaksi " + (if (pk.isNotEmpty()) "untuk poket ini " else "") + "pada " + PG.fmtMonth(ym) + ". Tekan **+** di atas untuk rekod yang pertama, atau imbas resit dalam borang transaksi."))
        }
        return
    }
    dates.forEach { d ->
        val p = PG.parse(d)
        val day = ds.days[p.d - 1]
        val n = byDay[d]?.size ?: 0
        Column(Modifier.fillMaxWidth().padding(horizontal = GL).lejarCard(pal)) {
            // kepala tarikh (gaya halaman lejar)
            Row(
                Modifier.fillMaxWidth().background(pal.paperHead).clickable { vm.open(Sheet.Day(d)) }
                    .heightIn(min = 40.dp).padding(horizontal = 14.dp, vertical = 8.dp)
                    .semantics(mergeDescendants = true) { },
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Txt(PG.HARI_PENUH[PG.weekday(d)] + ", " + p.d + " " + PG.BULAN[p.m - 1] + " " + p.y, Modifier.weight(1f), size = 13.5f, weight = FontWeight.SemiBold, maxLines = 1)
                Txt(if (n > 0) "$n transaksi" else "Tiada transaksi", size = 12.5f, color = pal.muted, maxLines = 1)
            }
            if (pseudo && day.ot > 0) {
                val cy = PG.otCycleOf(d, vm.otSd())
                LRow("OT", "OT diperoleh", otParts(s, d).joinToString(" + ") + " · masuk gaji " + PG.fmtMonth(cy.bayarYm), "+" + M(day.ot), pal.inn, { vm.open(Sheet.OtDay(d)) })
            }
            byDay[d]?.forEach { t ->
                TxRow(vm, s, t, om, sett, menu = true)
                val amt = sett[t.id]
                if (pseudo && amt != null) {
                    val pc = PG.prevCycleOf(t.tarikh, vm.otSd())
                    LRow("OT", "Tolak OT dalam gaji", "OT " + PG.fmtShort(pc.start) + " – " + PG.fmtShort(pc.end) + " dah dikira berasingan sebagai OT", M(-amt), pal.muted, { vm.editTx(t.id) })
                }
            }
            if (pseudo) logs[d]?.forEach { KadLogRow(vm, it) }
        }
    }
    Note("Tekan kepala tarikh untuk ringkasan hari itu. Tekan transaksi untuk sunting atau padam.", Modifier.fillMaxWidth().padding(top = 2.dp), align = TextAlign.Center)
}

fun otParts(s: PgState, d: String): List<String> {
    val ov = PG.otValue(s, d)
    val parts = ArrayList<String>()
    if (ov.h15 > 0) parts.add(fmtH(ov.h15) + "j × 1.5")
    if (ov.h20 > 0) parts.add(fmtH(ov.h20) + "j × 2.0")
    if (ov.h30 > 0) parts.add(fmtH(ov.h30) + "j × 3.0")
    return parts
}

private fun calNum(v: Double): String {
    val a = Math.abs(v)
    return if (a >= 1000) (if (a >= 10000) Math.round(a / 1000).toString() else (Math.round(a / 100) / 10.0).toString()) + "K" else Math.round(a).toString()
}

@Composable
private fun Kalendar(vm: MainViewModel, s: PgState, ds: DailySummary, om: Boolean) {
    val pal = LocalPal.current
    val today = vm.today()
    val first = ds.days[0].tarikh
    val lead = (PG.weekday(first) + 6) % 7
    val past = ds.days.filter { it.tarikh <= today }
    if (om) {
        val lebih = past.count { it.harian > it.ot + 0.004 }
        CalSum(
            M(ds.bakiOt), "OT harian − belanja harian, 1–" + ds.days.size + " " + PG.BULAN[PG.parse(first).m - 1], ds.bakiOt < -0.004,
            "$lebih hari", "Belanja melebihi OT", lebih > 0,
        )
    } else {
        val hb = ds.days.count { it.keluar > 0 && it.tarikh <= today }
        CalSum(if (past.isNotEmpty()) M(ds.keluar / Math.max(1, past.size)) else "–", "Purata belanja sehari", false, "$hb/${past.size}", "Hari ada belanja", false)
    }
    Column(Modifier.fillMaxWidth().padding(horizontal = GL).lejarCard(pal)) {
        Row(Modifier.fillMaxWidth().background(pal.paperHead).hairlines(pal.line)) {
            listOf("Isn", "Sel", "Rab", "Kha", "Jum", "Sab", "Ahd").forEachIndexed { k, h ->
                Txt(h, Modifier.weight(1f).padding(vertical = 7.dp), size = 11.5f, weight = FontWeight.SemiBold, color = if (k >= 5) pal.accentStrong else pal.muted, align = TextAlign.Center)
            }
        }
        val cells: List<com.asyraf.hadirku.pg.DayRow?> = List(lead) { null } + ds.days
        Column(Modifier.fillMaxWidth().background(pal.line), verticalArrangement = Arrangement.spacedBy(1.dp)) {
            cells.chunked(7).forEach { week ->
                Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(1.dp)) {
                    (0 until 7).forEach { i ->
                        val x = week.getOrNull(i)
                        if (x == null) Box(Modifier.weight(1f).fillMaxHeight().heightIn(min = 66.dp).background(pal.surface2))
                        else {
                            val p = PG.parse(x.tarikh)
                            val fut = x.tarikh > today
                            val inc = if (om) x.pend else x.masuk
                            val out = if (om) x.belanja else x.keluar
                            val bz = if (om) x.bersihL else x.bersih
                            val aktif = inc > 0 || out > 0
                            val lebihOt = om && !fut && x.harian > x.ot + 0.004
                            val gaji = vm.txPocket.isEmpty() && x.masuk > 0
                            Column(
                                Modifier.weight(1f).fillMaxHeight().heightIn(min = 66.dp)
                                    .background(if (gaji) pal.inSoft else pal.surface)
                                    .then(if (x.tarikh == today) Modifier.border(2.dp, pal.accent, RoundedCornerShape(6.dp)) else Modifier)
                                    .clickable { vm.open(Sheet.Day(x.tarikh)) }
                                    .padding(start = 4.dp, end = 4.dp, top = 4.dp, bottom = 5.dp),
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Txt(p.d.toString(), size = 12f, weight = FontWeight.SemiBold, color = if (fut) pal.muted else pal.ink)
                                    if (lebihOt) { Spacer(Modifier.width(4.dp)); Box(Modifier.size(6.dp).background(pal.out, CircleShape)) }
                                }
                                Spacer(Modifier.weight(1f))
                                if (inc > 0) Txt("+" + calNum(inc), Modifier.fillMaxWidth(), size = 10.5f, weight = FontWeight.SemiBold, color = pal.inn, align = TextAlign.End, num = true, maxLines = 1)
                                if (out > 0) Txt("−" + calNum(out), Modifier.fillMaxWidth(), size = 10.5f, color = pal.out, align = TextAlign.End, num = true, maxLines = 1)
                                if (aktif) Txt(
                                    (if (bz > 0.004) "+" else if (bz < -0.004) "−" else "") + calNum(bz), Modifier.fillMaxWidth(), size = 10.5f, weight = FontWeight.SemiBold,
                                    color = if (bz > 0.004) pal.inn else if (bz < -0.004) pal.out else pal.ink, align = TextAlign.End, num = true, maxLines = 1,
                                )
                            }
                        }
                    }
                }
            }
        }
        Column(Modifier.fillMaxWidth().hairlines(pal.line, top = true, bottom = false).padding(start = GL, end = GL, top = 8.dp, bottom = 10.dp)) {
            if (om) {
                Txt(rich("**+** pendapatan (OT + duit masuk)   **−** perbelanjaan", pal.inn), size = 12f, color = pal.muted)
                Txt("Angka bawah: baki hari itu. Titik merah: belanja harian melebihi OT. Latar biru: hari gaji masuk (OT dalam gaji tak dikira lagi).", size = 12f, color = pal.muted)
            } else {
                Txt(rich("**+** masuk   **−** keluar", pal.inn), size = 12f, color = pal.muted)
                Txt("Angka bawah: baki hari itu (masuk − keluar)", size = 12f, color = pal.muted)
            }
        }
    }
    Note("Tekan mana-mana hari untuk lihat butiran dan tambah transaksi.", Modifier.fillMaxWidth(), align = TextAlign.Center)
}

@Composable
private fun CalSum(v1: String, l1: String, neg1: Boolean, v2: String, l2: String, neg2: Boolean) {
    val pal = LocalPal.current
    Row(Modifier.fillMaxWidth().padding(horizontal = GL).lejarCard(pal).height(IntrinsicSize.Min)) {
        listOf(Triple(v1, l1, neg1), Triple(v2, l2, neg2)).forEachIndexed { i, (v, l, n) ->
            if (i > 0) Box(Modifier.width(1.dp).fillMaxHeight().padding(vertical = 10.dp).background(pal.line))
            Column(Modifier.weight(1f).fillMaxHeight().padding(horizontal = 14.dp, vertical = 11.dp)) {
                Txt(v, size = 14f, weight = FontWeight.SemiBold, color = if (n) pal.bad else pal.ink, num = true, maxLines = 1)
                Txt(l, size = 11.5f, color = pal.muted)
            }
        }
    }
}

/** Helaian butiran satu hari (openDay PoketGaji). */
@Composable
fun DaySheet(vm: MainViewModel, d: String) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val pk = vm.txPocket
    val ds = remember(s, d, pk) { PG.dailySummary(s, PG.ym(d), pk.ifEmpty { null }) }
    val x = ds.days.firstOrNull { it.tarikh == d } ?: return
    val om = akruanOn(s) && pk.isEmpty()
    val sett = remember(s) { PG.otSettlements(s).byTx }
    val list = s.transactions.filter { it.tarikh == d && (pk.isEmpty() || it.poket == pk || it.ke == pk) }.sortedBy { it.dibuat }
    SheetBody(actions = {
        SheetActions("+ Transaksi", { vm.newTx(Tx(tarikh = d, poket = pk)) }, { vm.close() }, cancel = "Tutup",
            extra = if (om) "Isi OT" else null, onExtra = { vm.open(Sheet.OtDay(d)) })
    }) {
        SheetTitle(longDate(d), if (pk.isNotEmpty()) rich("Poket " + pname(s, pk) + " sahaja") else null)
        Column(Modifier.padding(horizontal = GL).padding(bottom = 10.dp)) {
            if (om) {
                val ov = PG.otValue(s, d)
                val parts = otParts(s, d)
                val komit = PG.round2(x.tetap - x.bayarKad)
                val rows = ArrayList<Triple<androidx.compose.ui.text.AnnotatedString, String, Color?>>()
                val strong = HashSet<Int>()
                if (x.ot > 0 || ov.recorded) rows.add(Triple(two("OT diperoleh", parts.joinToString(" + "), pal.muted), "+" + M(x.ot), pal.inn))
                if (x.masuk > 0) rows.add(Triple(rich("Duit masuk"), "+" + M(x.masuk), pal.inn))
                if (x.otBayar > 0) rows.add(Triple(two("Tolak OT dalam gaji", "dah dikira pada hari kerja", pal.muted), M(-x.otBayar), pal.muted))
                strong.add(rows.size); rows.add(Triple(rich("Pendapatan"), Mp(x.pend), if (x.pend > 0.004) pal.inn else null))
                if (x.tunai > 0) rows.add(Triple(two("Tunai dari kad", "pinjaman, bukan pendapatan", pal.muted), "+" + M(x.tunai), pal.muted))
                if (x.harian > 0) rows.add(Triple(two("Belanja harian", "termasuk guna kad", pal.muted), M(-x.harian), pal.out))
                if (komit > 0) rows.add(Triple(rich("Komitmen & ansuran"), M(-komit), pal.out))
                if (x.kadLog > 0) rows.add(Triple(rich("Faedah, caj & fee kad"), M(-x.kadLog), pal.out))
                strong.add(rows.size); rows.add(Triple(rich("Perbelanjaan"), M(-x.belanja), if (x.belanja > 0.004) pal.out else null))
                strong.add(rows.size); rows.add(Triple(rich("Baki hari ini"), Mp(x.bersihL), if (x.bersihL < -0.004) pal.out else if (x.bersihL > 0.004) pal.inn else null))
                Kvl(rows, strong)
                if (x.ot > 0 || x.harian > 0) Txt(
                    if (x.harian > x.ot + 0.004) "Belanja harian " + M(x.harian) + " melebihi OT " + M(x.ot) + " sebanyak " + M(x.harian - x.ot) + "."
                    else "Belanja harian " + M(x.harian) + " dalam had OT " + M(x.ot) + ".",
                    Modifier.padding(top = 6.dp), size = 13f, color = if (x.harian > x.ot + 0.004) pal.bad else pal.muted,
                )
                if (x.bayarKad > 0) Txt("Bayar kad kredit " + M(x.bayarKad) + " tidak dikira belanja: belanja guna kad sudah dikira pada hari beli.", Modifier.padding(top = 6.dp), size = 13f, color = pal.muted)
            } else {
                val rows = ArrayList<Triple<androidx.compose.ui.text.AnnotatedString, String, Color?>>()
                rows.add(Triple(rich("Duit masuk"), "+" + M(x.masuk), pal.inn))
                if (x.tunai > 0) rows.add(Triple(two("Tunai dari kad", "pinjaman, bukan duit masuk", pal.muted), "+" + M(x.tunai), pal.muted))
                rows.add(Triple(rich("Belanja"), M(-x.keluar), pal.out))
                rows.add(Triple(two("Baki hari ini", "masuk − keluar", pal.muted), Mp(x.bersih), if (x.bersih < -0.004) pal.out else if (x.bersih > 0.004) pal.inn else null))
                Kvl(rows, setOf(rows.size - 1))
            }
        }
        if (list.isNotEmpty()) ListBlock { list.forEach { TxRow(vm, s, it, om, sett) } }
        else Empty(rich("Tiada transaksi pada hari ini."))
    }
}
