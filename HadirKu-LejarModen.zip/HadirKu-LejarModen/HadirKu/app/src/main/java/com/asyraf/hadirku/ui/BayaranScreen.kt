package com.asyraf.hadirku.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.asyraf.hadirku.MainViewModel
import com.asyraf.hadirku.Sheet
import com.asyraf.hadirku.pg.CommitStat
import com.asyraf.hadirku.pg.DebtPlan
import com.asyraf.hadirku.pg.DebtStat
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.PgState

@Composable
fun BayaranScreen(vm: MainViewModel) {
    // "projek" lama (dah dibuang) → Ringkasan
    val seg = if (vm.bayar in setOf("ringkasan", "komitmen", "hutang")) vm.bayar else "ringkasan"
    Seg(listOf("ringkasan" to "Ringkasan", "komitmen" to "Komitmen", "hutang" to "Hutang"), seg) { vm.setBayarSeg(it) }
    when (seg) {
        "hutang" -> HutangView(vm)
        "komitmen" -> KomitmenView(vm)
        else -> RingkasanView(vm)
    }
}

/* ================= Ringkasan (Lejar Moden): Hutang · EPP · Bil Bulanan ================= */

/**
 * Definisi (semua daripada PG, tiada formula kewangan baharu):
 *  - Hutang: baki hutang = jumlah baki penyata setiap hutang aktif (TANPA EPP belum dibil, supaya tidak dikira dua kali
 *    dengan kad EPP). Kemajuan = bayaran hutang bulan ini (PG.debtSummary: dibayar ÷ perlu bayar) — jumlah pokok asal tidak
 *    direkod dalam app, jadi tiada "% langsai" palsu.
 *  - EPP: jadual EPP terikat pada kad kredit sedia ada (PG.eppInfo). Kemajuan = ansuran yang sudah dibil ÷ jumlah bayaran pelan.
 *  - Bil Bulanan = Komitmen sedia ada (PG.commitmentStatus), bukan modul baharu.
 */
@Composable
private fun RingkasanView(vm: MainViewModel) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val today = vm.today()
    val dl = remember(s, today) { PG.debtStatus(s, today) }
    val sm = PG.debtSummary(dl)
    // semua komitmen tempoh ini selesai → paparan terus ke tempoh seterusnya (unjuran bulan depan)
    val vd = remember(s, today) { PG.commitmentViewDate(s, today) }
    val kl = remember(s, vd) { PG.commitmentStatus(s, vd) }
    val ks = PG.commitmentSummary(kl)
    val per = PG.commitmentPeriodOf(s, vd)

    Txt("Urus hutang, EPP dan bil bulanan anda di satu tempat.", Modifier.fillMaxWidth().padding(horizontal = GL + 4.dp), size = 13.5f, color = pal.muted)
    if (sm.baki > 0.004) Txt(
        rich("Jumlah hutang keseluruhan **" + M(sm.baki) + "**" + if (sm.epp > 0.004) " · termasuk EPP belum dibil " + M(sm.epp) else ""),
        Modifier.fillMaxWidth().padding(horizontal = GL + 4.dp), size = 13f, color = pal.muted,
    )

    // ---------- Hutang ----------
    val aktif = dl.filter { it.jumlah > 0.004 }
    val bakiHutang = PG.round2(aktif.sumOf { Math.max(0.0, it.baki) })
    val nHutang = dl.count { it.status != "langsai" }
    RingkasCard(Ic.LAYERS, "Hutang", if (dl.isEmpty()) "Tambah" else "$nHutang hutang", { if (dl.isEmpty()) vm.open(Sheet.HForm(null)) else vm.setBayarSeg("hutang") }) {
        if (dl.isEmpty()) {
            Txt("Belum ada hutang direkod. Tambah kad kredit, pinjaman atau BNPL untuk jejak baki dan bayaran bulanan.", Modifier.padding(14.dp), size = 13.5f, color = pal.muted)
            return@RingkasCard
        }
        DuaNilai(Ic.MONEYBAG, pal.amber, "Baki hutang", M(bakiHutang), "Perlu bayar bulan ini", M(sm.sasaran))
        if (sm.sasaran > 0.004) Progres(
            pct(Math.min(100.0, sm.dibayar / sm.sasaran * 100)) + "% dibayar bulan ini",
            if (sm.sasaran > 0) sm.dibayar / sm.sasaran else 0.0,
            "Telah bayar: " + M(sm.dibayar), "Perlu bayar: " + M(sm.sasaran),
        ) else Txt(if (bakiHutang <= 0.004) "✔ Semua hutang langsai" else "✔ Tiada bayaran hutang bulan ini", Modifier.padding(start = 14.dp, end = 14.dp, bottom = 12.dp), size = 13.5f, color = pal.good)
        if (sm.epp > 0.004) Txt("Baki di atas tidak termasuk EPP belum dibil (lihat EPP). Perlu bayar sudah termasuk ansuran EPP kad bulan ini.", Modifier.padding(start = 14.dp, end = 14.dp, bottom = 12.dp), size = 12f, color = pal.muted)
    }

    // ---------- EPP ----------
    val kadEpp = s.debts.filter { it.jenis == "kad" && it.epp.isNotEmpty() }
    val infos = remember(s, today) { kadEpp.flatMap { d -> d.epp.map { PG.eppInfo(it, today) } }.filter { it.aktif } }
    val nEpp = infos.size
    val eppJumlah = PG.round2(infos.sumOf { it.jumlahBayar })
    val eppDibil = PG.round2(infos.sumOf { it.jumlahBayar - it.baki })
    val eppDue = PG.round2(dl.sumOf { it.eppDue })
    val kadAktif = kadEpp.filter { d -> d.epp.any { PG.eppInfo(it, today).aktif } }
    val bukaEpp: () -> Unit = {
        when {
            kadAktif.size == 1 -> vm.open(Sheet.EppList(kadAktif[0].id))
            kadAktif.isEmpty() && s.debts.count { it.jenis == "kad" } == 1 -> vm.open(Sheet.EppList(s.debts.first { it.jenis == "kad" }.id))
            else -> vm.setBayarSeg("hutang")
        }
    }
    RingkasCard(Ic.CARD, "EPP", if (nEpp > 0) "$nEpp pelan aktif" else "Tiada", bukaEpp) {
        if (nEpp == 0) {
            Txt(
                if (s.debts.any { it.jenis == "kad" }) "Tiada pelan EPP aktif. EPP direkod pada kad kredit (Hutang → kad → EPP)."
                else "Tiada pelan EPP. Tambah kad kredit dahulu di tab Hutang, kemudian rekod EPP pada kad itu.",
                Modifier.padding(14.dp), size = 13.5f, color = pal.muted,
            )
            return@RingkasCard
        }
        DuaNilai(Ic.CART, pal.amber, "Ansuran sebulan", M(infos.sumOf { it.ans }), "Baki berjadual", M(sm.epp))
        Progres(
            pct(if (eppJumlah > 0) Math.min(100.0, eppDibil / eppJumlah * 100) else 0.0) + "% dibil",
            if (eppJumlah > 0) eppDibil / eppJumlah else 0.0,
            "Telah dibil: " + M(eppDibil), "Jumlah pelan: " + M(eppJumlah),
        )
        Txt("Ansuran EPP dibayar melalui kad kredit — tidak dikira sebagai hutang berasingan.", Modifier.padding(start = 14.dp, end = 14.dp, bottom = 12.dp), size = 12f, color = pal.muted)
    }

    // ---------- Bil Bulanan (= Komitmen) ----------
    val urut = kl.sortedWith(compareBy<CommitStat>({ if (it.status == "sudah") 1 else 0 }, { PG.tempoDate(it.c, vd) ?: "9999" }))
    RingkasCard(Ic.CALENDAR, "Bil Bulanan", if (kl.isEmpty()) "Tambah" else "${kl.size} komitmen", { if (kl.isEmpty()) vm.open(Sheet.KForm(null)) else vm.setBayarSeg("komitmen") }) {
        if (kl.isEmpty()) {
            Txt("Belum ada bil bulanan. Tambah sewa, TNB, air, internet dengan tarikh tempo untuk dapat peringatan 3 hari & 1 hari sebelum.", Modifier.padding(14.dp), size = 13.5f, color = pal.muted)
            return@RingkasCard
        }
        Column(Modifier.padding(start = 14.dp, end = 14.dp, top = 10.dp, bottom = 8.dp)) {
            if (vd != today) Txt("✔ Bulan ini selesai · kini unjuran bulan depan", Modifier.padding(bottom = 6.dp), size = 12.5f, weight = FontWeight.SemiBold, color = pal.good)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Txt("Komitmen " + periodLabel(per), Modifier.weight(1f), size = 12.5f, color = pal.muted, maxLines = 1)
                Txt(rich("**" + M(ks.dibayar) + "** / " + M(ks.jumlah)), size = 12.5f, color = pal.muted)
            }
            Spacer(Modifier.height(6.dp))
            Bar(if (ks.jumlah > 0) ks.dibayar / ks.jumlah else 0.0, h = 8.dp)
        }
        urut.take(6).forEach { c -> BilRow(vm, c, today, vd) }
        if (urut.size > 6) Txt(
            "Lihat semua " + urut.size + " komitmen", Modifier.fillMaxWidth().clickable { vm.setBayarSeg("komitmen") }.padding(14.dp),
            size = 14f, weight = FontWeight.SemiBold, color = pal.accent, align = TextAlign.Center,
        )
    }
    Note("Bil Bulanan ialah senarai Komitmen anda. Hijau = dah bayar · perang = 3 hari lagi · merah = hari ini / lewat.")
}

/** Label tempo untuk paparan bil: "9 hari lagi", "Esok", "Lewat 2 hari", "✔ Sudah" (ikut keadaan sebenar). */
private fun labelBil(c: CommitStat, today: String, ref: String = today): Pair<String, Tone> {
    if (c.status == "sudah") return (if (c.manualTanda) "✔ Ditanda" else "✔ Sudah") to Tone.GOOD
    val due = PG.tempoDate(c.c, ref) ?: return keadaanK(c, today, ref)
    val n = PG.hariAntara(today, due)
    val pre = if (c.status == "separuh") "Separuh · " else ""
    return when {
        n < 0 -> pre + "Lewat " + (-n) + " hari" to Tone.BAD
        n == 0 -> pre + "Hari ini" to Tone.BAD
        n == 1 -> pre + "Esok" to Tone.WARN
        n <= 3 -> pre + n + " hari lagi" to Tone.WARN
        else -> pre + n + " hari lagi" to Tone.INFO
    }
}

@Composable
private fun BilRow(vm: MainViewModel, c: CommitStat, today: String, ref: String = today) {
    val pal = LocalPal.current
    val (lbl, tone) = labelBil(c, today, ref)
    val due = PG.tempoDate(c.c, ref)
    val ic = billIc(c.nama)
    Row(
        Modifier.fillMaxWidth().hairlines(pal.line, top = true, bottom = false).pressable({ vm.open(Sheet.KMenu(c.id)) }, scaleTo = 0.985f)
            .heightIn(min = 60.dp).padding(start = 14.dp, end = 10.dp, top = 9.dp, bottom = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconTile(ic, billTint(ic, pal), size = 38.dp, icon = 20.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Txt(c.nama, size = 14.5f, weight = FontWeight.SemiBold, maxLines = 1)
            Txt(
                if (due != null) "Tarikh akhir: " + PG.fmtShort(due) + " " + PG.parse(due).y else "Bayar guna gaji " + c.kitaran + "hb",
                size = 12f, color = pal.muted, maxLines = 1,
            )
        }
        Spacer(Modifier.width(8.dp))
        Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Txt(M(if (c.status == "separuh") c.baki else c.jumlah), size = 14.5f, weight = FontWeight.Bold, num = true, maxLines = 1)
            Pill(lbl, tone)
        }
        Spacer(Modifier.width(4.dp))
        Ico(Ic.CHEVRON, pal.muted, 16.dp, stroke = 2f)
    }
}

@Composable
private fun RingkasCard(ic: Ic, title: String, right: String, onHead: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    val pal = LocalPal.current
    Column(Modifier.fillMaxWidth().padding(horizontal = GL).lejarCard(pal)) {
        Row(
            Modifier.fillMaxWidth().background(pal.mintWash).clickable(onClick = onHead).heightIn(min = 52.dp).padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Ico(ic, pal.accent, 22.dp, stroke = 2f)
            Spacer(Modifier.width(10.dp))
            Txt(title, Modifier.weight(1f), size = 17f, weight = FontWeight.Bold, maxLines = 1)
            Txt(right, size = 13.5f, weight = FontWeight.SemiBold, maxLines = 1)
            Spacer(Modifier.width(4.dp))
            Ico(Ic.CHEVRON, pal.muted, 16.dp, stroke = 2f)
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(pal.line))
        content()
    }
}

/** Dua nilai sebelah-menyebelah dengan jubin ikon (cth Baki | Bayaran bulan ini). Tersusun menegak di skrin sempit. */
@Composable
private fun DuaNilai(ic: Ic, tint: Color, l1: String, v1: String, l2: String, v2: String) {
    val pal = LocalPal.current
    BoxWithConstraints(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp)) {
        val narrow = maxWidth < 280.dp
        if (narrow) Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconTile(ic, tint, size = 44.dp, icon = 24.dp)
                Spacer(Modifier.width(12.dp))
                Column { Txt(l1, size = 12.5f, color = pal.muted); AutoMoney(v1, 20f) }
            }
            Column { Txt(l2, size = 12.5f, color = pal.muted); AutoMoney(v2, 16f, weight = FontWeight.SemiBold) }
        } else Row(Modifier.height(IntrinsicSize.Min), verticalAlignment = Alignment.CenterVertically) {
            IconTile(ic, tint, size = 44.dp, icon = 24.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1.25f)) { Txt(l1, size = 12.5f, color = pal.muted, maxLines = 1); AutoMoney(v1, 20f) }
            Box(Modifier.width(1.dp).fillMaxHeight().padding(vertical = 2.dp).background(pal.line))
            Column(Modifier.weight(1f).padding(start = 12.dp)) { Txt(l2, size = 12.5f, color = pal.muted, maxLines = 2, lh = 16f); AutoMoney(v2, 16f, weight = FontWeight.SemiBold) }
        }
    }
}

@Composable
private fun Progres(pctLbl: String, frac: Double, top: String, bot: String) {
    val pal = LocalPal.current
    Column(Modifier.padding(start = 14.dp, end = 14.dp, bottom = 12.dp)) {
        Row(verticalAlignment = Alignment.Bottom) {
            Txt(pctLbl, Modifier.weight(1f), size = 13.5f, weight = FontWeight.SemiBold, maxLines = 2)
            Column(horizontalAlignment = Alignment.End) {
                Txt(top, size = 11.5f, color = pal.muted, num = true, maxLines = 1)
                Txt(bot, size = 11.5f, color = pal.muted, num = true, maxLines = 1)
            }
        }
        Spacer(Modifier.height(6.dp))
        Bar(frac, h = 10.dp)
    }
}

@Composable
fun StatusPill(status: String) = when (status) {
    "sudah" -> Pill("✔ Sudah", Tone.GOOD)
    "separuh" -> Pill("Separuh", Tone.WARN)
    else -> Pill("Belum", Tone.BAD)
}

@Composable
private fun KomitmenView(vm: MainViewModel) {
    val s by vm.pg.collectAsState()
    val today = vm.today()
    val vd = remember(s, today) { PG.commitmentViewDate(s, today) }
    val per = PG.commitmentPeriodOf(s, vd)
    val list = remember(s, vd) { PG.commitmentStatus(s, vd) }
    val sm = PG.commitmentSummary(list)
    if (list.isEmpty()) {
        Empty(rich("Belum ada komitmen. Tambah sewa, ansuran, TNB, air dan internet dengan **tarikh jatuh tempo** supaya status bayaran dijejak sendiri setiap bulan, nampak dalam kalendar, dan dapat peringatan 3 hari & 1 hari sebelum."))
        Btn("Tambah komitmen", { vm.open(Sheet.KForm(null)) }, Modifier.fillMaxWidth().padding(horizontal = GL), kind = BtnKind.PRIMARY)
        NafkahBlock(vm)
        return
    }
    if (vd != today) Notice(rich("✔ Semua komitmen bulan ini sudah dibayar. Paparan kini **" + periodLabel(per) + "**."), Tone.GOOD)
    SummaryCard(
        "Komitmen " + periodLabel(per), sm.dibayar, sm.jumlah, if (sm.jumlah > 0) sm.dibayar / sm.jumlah else 0.0,
        rich(if (sm.belum > 0) sm.belum.toString() + " komitmen belum selesai · baki " + M(sm.baki) else "✔ Semua komitmen bulan ini sudah dibayar"), sm.belum > 0,
    )
    KomitmenKalendar(vm, list, today, vd)
    listOf("15" to "Bayar guna gaji 15hb", "30" to "Bayar guna gaji 30hb").forEach { (k, title) ->
        val items = list.filter { it.kitaran == k }.sortedBy { it.c.tempo.takeIf { t -> t in 1..31 } ?: 99 }
        if (items.isEmpty()) return@forEach
        SecHead(title, right = M(items.sumOf { it.jumlah }))
        ListBlock { items.forEach { c -> KRow(vm, s, c, today, vd) } }
    }
    Btn("+ Tambah komitmen", { vm.open(Sheet.KForm(null)) }, Modifier.fillMaxWidth().padding(horizontal = GL))
    NafkahBlock(vm)
}

/** Keadaan komitmen bulan ini: label & nada (ikut tarikh jatuh tempo kalau ada). */
fun keadaanK(c: CommitStat, today: String, ref: String = today): Pair<String, Tone> {
    if (c.status == "sudah") return (if (c.manualTanda) "✔ Ditanda" else "✔ Sudah") to Tone.GOOD
    val pre = if (c.status == "separuh") "Separuh · " else ""
    val due = PG.tempoDate(c.c, ref) ?: return (if (c.status == "separuh") "Separuh" else "Belum") to (if (c.status == "separuh") Tone.WARN else Tone.BAD)
    val n = PG.hariAntara(today, due)
    return when {
        n < 0 -> pre + "Lewat " + (-n) + " hari" to Tone.BAD
        n == 0 -> pre + "Hari ini" to Tone.BAD
        n == 1 -> pre + "Esok" to Tone.WARN
        n <= 3 -> pre + "H-" + n to Tone.WARN
        else -> pre + "Belum" to Tone.NEUTRAL
    }
}

@Composable
private fun KRow(vm: MainViewModel, s: PgState, c: CommitStat, today: String, ref: String = today) {
    val pal = LocalPal.current
    val (lbl, tone) = keadaanK(c, today, ref)
    val due = PG.tempoDate(c.c, ref)
    val ic = billIc(c.nama)
    Row(
        Modifier.fillMaxWidth().hairlines(pal.line).pressable({ vm.open(Sheet.KMenu(c.id)) }, scaleTo = 0.985f).heightIn(min = 60.dp).padding(start = 14.dp, end = GL, top = 10.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconTile(ic, billTint(ic, pal), size = 38.dp, icon = 20.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Txt(c.nama, size = 15f, weight = FontWeight.SemiBold)
            Txt(
                (if (due != null) "Tempo " + PG.fmtShort(due) + " · " else "") + pname(s, c.poket) +
                    (if (c.status == "separuh") " · baki " + M(c.baki) else "") + (if (c.manualTanda) " · ditanda di luar app" else ""),
                size = 12.5f, color = pal.muted,
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Txt(M(c.jumlah), size = 15f, num = true)
            Pill(lbl, tone)
        }
    }
}

/** Kalendar bulan ini: komitmen pada hari jatuh tempo, berwarna ikut keadaan. Tekan hari → menu komitmen. */
@Composable
private fun KomitmenKalendar(vm: MainViewModel, list: List<CommitStat>, today: String, ref: String = today) {
    val pal = LocalPal.current
    val p = PG.parse(ref)
    val n = PG.lastDay(p.y, p.m)
    val lead = (PG.weekday(PG.iso(p.y, p.m, 1)) + 6) % 7
    val byDay = list.mapNotNull { c -> PG.tempoDate(c.c, ref)?.let { PG.parse(it).d to c } }.groupBy({ it.first }, { it.second })
    val tiada = list.count { PG.tempoDate(it.c, ref) == null }
    SecHead("Kalendar " + PG.fmtMonth(PG.ym(ref)))
    Column(Modifier.fillMaxWidth().padding(horizontal = GL).lejarCard(pal)) {
        Row(Modifier.fillMaxWidth().background(pal.paperHead).hairlines(pal.line)) {
            listOf("Isn", "Sel", "Rab", "Kha", "Jum", "Sab", "Ahd").forEach { h ->
                Txt(h, Modifier.weight(1f).padding(vertical = 6.dp), size = 11.5f, weight = FontWeight.SemiBold, color = pal.muted, align = TextAlign.Center)
            }
        }
        val cells: List<Int?> = List(lead) { null } + (1..n).toList()
        Column(Modifier.fillMaxWidth().background(pal.line), verticalArrangement = Arrangement.spacedBy(1.dp)) {
            cells.chunked(7).forEach { week ->
                Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(1.dp)) {
                    (0 until 7).forEach { i ->
                        val d = week.getOrNull(i)
                        val items = if (d != null) byDay[d].orEmpty() else emptyList()
                        val iso = if (d != null) PG.iso(p.y, p.m, d) else ""
                        Column(
                            Modifier.weight(1f).fillMaxHeight().defaultMinSize(minHeight = 52.dp)
                                .background(if (d == null) pal.surface2 else pal.surface)
                                .then(if (d != null && iso == today) Modifier.border(2.dp, pal.accent, androidx.compose.foundation.shape.RoundedCornerShape(6.dp)) else Modifier)
                                .then(if (items.isNotEmpty()) Modifier.clickable { vm.open(Sheet.KMenu(items[0].id)) } else Modifier)
                                .padding(3.dp),
                        ) {
                            if (d != null) {
                                Txt(d.toString(), size = 11.5f, weight = FontWeight.SemiBold, color = if (iso < today) pal.muted else pal.ink)
                                items.take(2).forEach { c ->
                                    val col = when (keadaanK(c, today, ref).second) { Tone.GOOD -> pal.good; Tone.BAD -> pal.bad; Tone.WARN -> pal.warn; else -> pal.accentStrong }
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(Modifier.size(5.dp).background(col, CircleShape))
                                        Spacer(Modifier.width(2.dp))
                                        Txt(c.nama, size = 9.5f, color = col, maxLines = 1)
                                    }
                                }
                                if (items.size > 2) Txt("+" + (items.size - 2), size = 9.5f, color = pal.muted)
                            }
                        }
                    }
                }
            }
        }
    }
    Txt("Hijau: dah bayar · Perang: 3 hari lagi · Merah: hari ini / lewat", Modifier.padding(horizontal = GL + 4.dp), size = 12f, color = pal.muted)
    if (tiada > 0) Note(tiada.toString() + " komitmen belum ada tarikh tempo. Tekan komitmen itu → Edit komitmen untuk tambah, supaya muncul dalam kalendar & dapat peringatan.")
}

fun tambahLbl(belanja: Double, tunai: Double): String =
    if (belanja > 0.004 && tunai > 0.004) "belanja & tunai kad" else if (tunai > 0.004) "tunai kad" else "belanja kad"

fun bulanIniLine(d: DebtStat): String {
    if (d.jenis != "kad" || !(d.tambahan > 0.004) || d.status == "sudah" || d.status == "langsai") return ""
    val parts = ArrayList<String>()
    if (d.belanjaKad > 0.004) parts.add("belanja kad " + M(d.belanjaKad))
    if (d.tunaiKad > 0.004) parts.add("tunai " + M(d.tunaiKad))
    if (d.dibayar <= 0.004) return "Bulan ini: pelan " + M(d.sasaranAsal) + " + " + parts.joinToString(" + ")
    if (d.status != "pelan") return "Bayaran ditolak dari pelan dulu: baki pelan " + M(d.pelanBaki) + ", kemudian " + parts.joinToString(" + ")
    return "✔ Pelan " + M(d.sasaranAsal) + " dah dibayar · baki " + tambahLbl(d.belanjaKad, d.tunaiKad) + " " + M(d.tambahanBaki)
}

/** Sebab/asas bayaran minimum dalam ayat ringkas, cth "5% × pokok RM9,252.96 (sebelum bayaran RM14.86)". */
fun minWhy(d: DebtStat): String {
    val mi = d.minInfo ?: return ""
    if (mi.cara == "penyata") return if (mi.sebab == "baki") "baki kad penuh" else "nilai penyata (" + PG.fmtDate(d.d.minTarikh) + ")"
    val w = minWhyFormula(d, mi)
    // minimum pernah diisi RM ikut penyata, tapi penyata bulan ini belum dikemas kini → anggaran ikut peratus yang dikira
    return if (w.isNotEmpty() && d.d.minRm != null) w + " · anggaran, kemas kini ikut penyata baru" else w
}

/** Label kadar faedah: "18% setahun", atau "≈18.5% setahun" kalau dikira daripada nilai RM penyata. */
fun kadarLbl(d: com.asyraf.hadirku.pg.Debt): String = if (PG.isSpl(d)) "Bayar penuh setiap bil" else (if (d.faedahRm != null) "≈" else "") + pct(d.kadar) + "% setahun"

private fun minWhyFormula(d: DebtStat, mi: com.asyraf.hadirku.pg.MinDetail): String {
    val pc = pct(mi.peratus) + "%"
    val epp = d.eppPokok > 0.004 || d.eppDue > 0.004
    val sebelum = if (d.dibayar > 0.004) " (sebelum bayaran " + M(d.dibayar) + ")" else ""
    if (mi.cara == "biasa") return when (mi.sebab) {
        "ansuran" -> "ansuran EPP bulan ini"
        "baki" -> if (mi.ansuran > 0.004) "ansuran EPP " + M(mi.ansuran) + " + baki biasa penuh" else "baki kad penuh"
        else -> (if (mi.ansuran > 0.004) "ansuran EPP " + M(mi.ansuran) + " + " else "") +
            (if (mi.sebab == "lantai") "minimum terendah " + M(mi.lantai) else pc + " × baki biasa " + M(mi.asas) + sebelum)
    }
    val asasLbl = if (epp) "pokok" else "baki kad"
    return when (mi.sebab) {
        "peratus" -> pc + " × " + asasLbl + " " + M(mi.asas) + sebelum
        "lantai" -> "minimum terendah (" + pc + " × " + asasLbl + " cuma " + M(PG.round2(mi.asas * mi.peratus / 100)) + ")"
        "ansuran" -> "ansuran EPP bulan ini (lebih besar daripada " + pc + " × pokok)"
        "baki" -> "baki kad penuh"
        else -> ""
    }
}

/** "Minimum RMx = 5% × pokok RMy" — untuk kad kredit sahaja. */
fun minLine(d: DebtStat): String {
    val mi = d.minInfo ?: return ""
    if (d.jenis != "kad" || mi.jumlah <= 0.004 || d.status == "langsai") return ""
    if (PG.isSpl(d.d)) return "Bil **" + M(mi.jumlah) + "** mesti dibayar penuh" + (if (d.belanjaKad > 0.004) " · belanja " + M(d.belanjaKad) + " masuk bil seterusnya" else "")
    val w = minWhy(d)
    return "Minimum **" + M(mi.jumlah) + "**" + if (w.isNotEmpty()) " = " + w else ""
}

/** Pecahan hutang kad: pokok (baki kad + pokok EPP) diasingkan daripada faedah EPP yang belum dibil. */
fun kadLines(d: DebtStat): List<String> {
    if (d.jenis != "kad") return emptyList()
    val out = ArrayList<String>()
    if (d.eppBaki > 0.004) {
        out.add("Pokok **" + M(d.pokok) + "** (kad " + M(d.baki) + " + EPP " + M(d.eppPokok) + ")")
        out.add((if (d.eppFaedah > 0.004) "Faedah EPP belum dibil **" + M(d.eppFaedah) + "**" else "EPP 0% faedah") +
            " · " + d.eppAktif + " pelan, ansuran " + M(d.eppDue) + " bulan ini")
    }
    val ml = minLine(d)
    if (ml.isNotEmpty()) out.add(ml)
    return out
}

/** (faedah sebulan, baki kad selepas minimum) — anggaran faedah kad kalau bayar minimum sahaja. null kalau tiada. */
fun faedahKadAnggar(d: DebtStat): Pair<Double, Double>? {
    if (d.jenis != "kad" || !(d.d.kadar > 0) || d.baki <= 0.004) return null
    val lepasMin = Math.max(0.0, d.baki - Math.max(0.0, d.min - d.dibayar))
    if (lepasMin <= 0.004) return null
    return PG.round2(lepasMin * d.d.kadar / 1200) to lepasMin
}

/** Anggaran faedah kad (kadar tahunan kad) atas baki kad selepas bayar minimum — berasingan daripada faedah EPP. */
fun faedahKadLine(d: DebtStat): String {
    if (d.jenis != "kad" || !(d.d.kadar > 0) || d.baki <= 0.004) return ""
    val lepasMin = Math.max(0.0, d.baki - Math.max(0.0, d.min - d.dibayar))
    if (lepasMin <= 0.004) return ""
    val f = PG.round2(lepasMin * d.d.kadar / 1200)
    return "Faedah kad ~" + M(f) + " sebulan kalau bayar minimum sahaja (" + kadarLbl(d.d) + " atas baki kad " + M(lepasMin) +
        (if (d.eppPokok > 0.004) ", bukan atas pokok EPP belum dibil" else "") + ")"
}

/** Apa yang terkandung dalam "Perlu bayar bulan ini", dalam kata mudah. */
fun perluSub(d: DebtStat): String {
    val pelan = d.sasaranAsal > d.min + 0.004
    if (PG.isSpl(d.d)) return "bil penuh"
    val asas = if (pelan) "pelan" else if (d.jenis == "kad") "minimum" else "ansuran"
    return if (d.jenis == "kad" && d.tambahan > 0.004) asas + " + " + tambahLbl(d.belanjaKad, d.tunaiKad) + " " + M(d.tambahan)
    else if (pelan) "ikut pelan" else asas
}

/** Baki yang masih perlu dibayar bulan ini. */
fun tinggalBulanIni(d: DebtStat): Double = Math.max(0.0, PG.round2(d.sasaran - d.dibayar))

/** Tajuk tempoh bayaran: "Bulan ini", atau "Penyata 24 Nov – 23 Dis" untuk kad ikut kitaran bank. */
fun tempohTajuk(d: DebtStat): String = if (PG.isSpl(d.d)) "Bil " + PG.fmtShort(d.perMula) else if (d.kitaranBank) "Penyata " + PG.fmtShort(d.perMula) + " – " + PG.fmtShort(d.perAkhir) else "Bulan ini"

/** "bulan ini" / "untuk penyata 24 Nov" (dalam ayat). */
fun tempohKecil(d: DebtStat): String = if (PG.isSpl(d.d)) "untuk bil " + PG.fmtShort(d.perMula) else if (d.kitaranBank) "untuk penyata " + PG.fmtShort(d.perMula) else "bulan ini"

/** Keadaan tarikh akhir bayar: "18 hari lagi", "Esok", "Hari ini", "Lewat 2 hari", atau "✔ Minimum dah dibayar". */
fun tempohLagi(d: DebtStat, today: String): String? {
    val ta = d.tarikhAkhir ?: return null
    val spl = PG.isSpl(d.d)
    if (d.minTinggal <= 0.004) return if (spl) "✔ Bil dah dibayar" else "✔ Minimum dah dibayar"
    val n = PG.hariAntara(today, ta)
    val apa = (if (spl) "bil belum bayar " else "minimum belum bayar ") + M(d.minTinggal)
    return when {
        n > 1 -> "$n hari lagi · $apa"
        n == 1 -> "Esok · $apa"
        n == 0 -> "Hari ini · $apa"
        else -> "Lewat " + (-n) + " hari · $apa"
    }
}

/** Baris kecil di bawah nama hutang: kadar · minimum · guna had. */
fun hutangSub(d: DebtStat): String {
    if (d.status == "langsai") return "✔ Langsai"
    val parts = arrayListOf(kadarLbl(d.d))
    if (d.min > 0.004) parts.add((if (PG.isSpl(d.d)) "bil " else if (d.jenis == "kad") "minimum " else "ansuran ") + M(d.min))
    d.tarikhAkhir?.let { if (d.minTinggal > 0.004) parts.add("akhir bayar " + PG.fmtShort(it)) }
    d.guna?.let { parts.add("guna had " + Math.round(it * 100) + "%") }
    return parts.joinToString(" · ")
}

internal fun rmTanpa(x: Double): String = M(x).replace("RM", "")

/** Jadual bayaran bulan ini: setiap hutang — perlu bayar, dah bayar, tinggal. */
@Composable
private fun BayarBulanIni(vm: MainViewModel, list: List<DebtStat>, sm: com.asyraf.hadirku.pg.DebtSummary) {
    val pal = LocalPal.current
    val rows = list.filter { it.status != "langsai" && (it.sasaran > 0.004 || it.dibayar > 0.004) }
    val tinggalJ = Math.max(0.0, PG.round2(sm.sasaran - sm.dibayar))
    Block {
        Txt("Bayaran hutang bulan ini", size = 12f, color = pal.muted)
        Spacer(Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            MoneyAnim(sm.dibayar, 22f)
            Spacer(Modifier.weight(1f))
            Txt(rich("daripada **" + M(sm.sasaran) + "**"), size = 13f, color = pal.muted)
        }
        Spacer(Modifier.height(8.dp))
        Bar(if (sm.sasaran > 0) sm.dibayar / sm.sasaran else 0.0, h = 8.dp)
        Spacer(Modifier.height(10.dp))
        if (rows.isEmpty()) {
            Txt("✔ Tiada bayaran hutang bulan ini.", size = 13.5f, color = pal.good)
            return@Block
        }
        JRow(listOf("Hutang", "Perlu bayar", "Dah bayar", "Tinggal"), header = true)
        rows.forEach { d ->
            val t = tinggalBulanIni(d)
            JRow(
                listOf(d.nama, rmTanpa(d.sasaran), rmTanpa(d.dibayar), if (t > 0.004) rmTanpa(t) else "✔"),
                warnaAkhir = if (t > 0.004) pal.bad else pal.good, onClick = { vm.open(Sheet.HMenu(d.id)) },
            )
        }
        if (rows.size > 1) JRow(
            listOf("Jumlah", rmTanpa(sm.sasaran), rmTanpa(sm.dibayar), if (tinggalJ > 0.004) rmTanpa(tinggalJ) else "✔"),
            total = true, warnaAkhir = if (tinggalJ > 0.004) pal.bad else pal.good,
        )
        Txt("Nilai dalam RM. Perlu bayar = minimum atau pelan, campur belanja kad bulan ini. Tekan hutang untuk butiran." +
            (if (rows.any { it.kitaranBank }) " Kad yang ada tarikh penyata dikira ikut kitaran penyata bank, bukan 1hb." else ""),
            Modifier.padding(top = 8.dp), size = 12f, color = pal.muted)
    }
}

@Composable
internal fun JRow(cells: List<String>, header: Boolean = false, total: Boolean = false, warnaAkhir: Color? = null, onClick: (() -> Unit)? = null) {
    val pal = LocalPal.current
    Row(
        Modifier.fillMaxWidth()
            .then(if (total) Modifier.hairlines(pal.lineStrong, top = true, bottom = false) else Modifier.hairlines(pal.line))
            .then(if (onClick != null) Modifier.pressable(onClick, scaleTo = 0.985f) else Modifier)
            .padding(vertical = if (header) 6.dp else 9.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        cells.forEachIndexed { i, c ->
            Txt(
                c, Modifier.weight(if (i == 0) 1.35f else 1f).padding(start = if (i == 0) 0.dp else 6.dp),
                size = if (header) 11.5f else 13f,
                weight = if (header) FontWeight.Medium else if (total || i == cells.size - 1) FontWeight.SemiBold else FontWeight.Normal,
                color = when { header -> pal.muted; i == cells.size - 1 && warnaAkhir != null -> warnaAkhir; else -> pal.ink },
                align = if (i == 0) TextAlign.Start else TextAlign.End,
                maxLines = if (i == 0 || header) 2 else 1, num = i > 0,
            )
        }
    }
}

@Composable
fun HutangPill(status: String) = when (status) {
    "langsai" -> Pill("✔ Langsai", Tone.GOOD)
    "sudah" -> Pill("✔ Sudah", Tone.GOOD)
    "pelan" -> Pill("✔ Pelan", Tone.GOOD)
    "min" -> Pill("Minimum", Tone.WARN)
    "separuh" -> Pill("Separuh", Tone.WARN)
    else -> Pill("Belum", Tone.BAD)
}

@Composable
private fun HutangView(vm: MainViewModel) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val today = vm.today()
    val list = remember(s, today) { PG.debtStatus(s, today) }
    val sm = PG.debtSummary(list)
    if (list.isEmpty()) {
        Empty(rich("Belum ada hutang direkod. Tambah kad kredit, pinjaman peribadi atau beli dulu bayar kemudian (contohnya SPayLater atau Atome) untuk jejak baki, bayaran bulanan dan tarikh bebas hutang."))
        Btn("Tambah hutang", { vm.open(Sheet.HForm(null)) }, Modifier.fillMaxWidth().padding(horizontal = GL), kind = BtnKind.PRIMARY)
        Btn("Tambah SPayLater", { vm.open(Sheet.SplForm(null)) }, Modifier.fillMaxWidth().padding(horizontal = GL).padding(top = 8.dp))
        return
    }
    val plan = remember(s, today) { PG.debtPlan(s, vm.budgetNow(), s.settings.hutangStrategi, today) }
    Hero("Jumlah hutang", sm.baki) {
        when {
            sm.baki <= 0.004 -> Pill("✔ Semua hutang langsai", Tone.GOOD)
            !plan.kosong && !plan.cukup -> Pill("Bajet bawah bayaran minimum", Tone.WARN)
            plan.cukup && !plan.never -> Pill("Bebas hutang " + monthShort(today, plan.bulan), Tone.GOOD)
            else -> Pill("Bayaran tak cukup tampung faedah", Tone.BAD)
        }
    }
    BayarBulanIni(vm, list, sm)
    SecHead("Senarai hutang", "+ Hutang") { vm.open(Sheet.HForm(null)) }
    if (list.none { PG.isSpl(it.d) }) Box(Modifier.padding(horizontal = GL).padding(bottom = 6.dp)) { LinkBtn("+ Tambah SPayLater (Shopee)", { vm.open(Sheet.SplForm(null)) }) }
    ListBlock {
        list.forEach { d ->
            Row(
                Modifier.fillMaxWidth().hairlines(pal.line).pressable({ vm.open(Sheet.HMenu(d.id)) }, scaleTo = 0.985f).heightIn(min = 60.dp).padding(start = 14.dp, end = GL, top = 10.dp, bottom = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconTile(when { PG.isSpl(d.d) -> Ic.CART; else -> when (d.jenis) { "kad" -> Ic.CARD; "pinjaman" -> Ic.COINS; "bnpl" -> Ic.CART; else -> Ic.RECEIPT } }, pal.amber, size = 38.dp, icon = 20.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Txt(d.nama, size = 15f, weight = FontWeight.SemiBold, maxLines = 1)
                    Spacer(Modifier.height(2.dp))
                    Txt(hutangSub(d), size = 12.5f, color = pal.muted)
                }
                Spacer(Modifier.width(10.dp))
                Txt(if (d.jumlah < -0.004) "Lebih " + M(-d.jumlah) else M(d.jumlah), size = 15f, weight = FontWeight.SemiBold, num = true)
                Spacer(Modifier.width(6.dp))
                Ico(Ic.CHEVRON, pal.muted, 16.dp, stroke = 2f)
            }
        }
    }
    PlanSection(vm, s, plan, today)
}

@Composable
private fun PlanSection(vm: MainViewModel, s: PgState, plan: DebtPlan, today: String) {
    val pal = LocalPal.current
    if (plan.kosong) return
    SecHead("Pelan bebas hutang", "Ubah pelan") { vm.open(Sheet.PlanForm) }
    Block {
        Txt(rich("Bajet **" + M(vm.budgetNow()) + "** sebulan · " + if (s.settings.hutangStrategi == "snowball") "baki terkecil dulu" else "faedah tertinggi dulu"), size = 14f)
        Spacer(Modifier.height(10.dp))
        if (!plan.cukup) {
            Column(Modifier.fillMaxWidth().background(pal.warnSoft, androidx.compose.foundation.shape.RoundedCornerShape(12.dp)).padding(12.dp)) {
                Txt(rich("Bajet kurang daripada jumlah bayaran minimum **" + M(plan.minimum) + "**. Naikkan bajet supaya pelan boleh dikira."), size = 14f, color = pal.warn)
                Spacer(Modifier.height(8.dp))
                Btn("Guna " + M(plan.minimum), { vm.planMin() }, kind = BtnKind.SMALL, color = pal.warn)
            }
            return@Block
        }
        val a = plan.asas ?: return@Block
        val cap = 120
        val planVals = plan.siri
        val minVals = a.siri.take(cap + 1)
        val n = Math.max(planVals.size, minVals.size) - 1
        val titles = (0..n).map { if (it == 0) "Sekarang" else PG.fmtMonth(ymAfter(today, it)) }
        val ticks = arrayListOf(0 to "Kini")
        val years = (1..n).filter { ymAfter(today, it).substring(5) == "01" }
        val step = Math.max(1, Math.ceil(years.size / 5.0).toInt())
        years.forEachIndexed { k, yi -> if (k % step == 0 && yi > n * 0.08 && yi < n * 0.97) ticks.add(yi to ymAfter(today, yi).substring(0, 4)) }
        Kvl(listOf(
            Triple(rich("Bebas hutang"), if (plan.never) "Tak langsai" else monthShort(today, plan.bulan), null),
            Triple(rich("Tempoh"), if (plan.never) "—" else tempoh(plan.bulan), null),
            Triple(rich("Anggaran faedah"), M(plan.faedah), null),
        ))
        Spacer(Modifier.height(6.dp))
        Txt(
            if (a.never) rich("Kalau bayar minimum sahaja, baki hampir tak berkurang kerana faedah.")
            else rich("Kalau bayar minimum sahaja: " + tempoh(a.bulan) + " dan faedah " + M(a.faedah) + ". Pelan ini jimat **" + M(plan.jimatFaedah) + "** faedah dan " + tempoh(Math.max(0, plan.jimatBulan ?: 0)) + "."),
            size = 14f,
        )
        Spacer(Modifier.height(10.dp))
        Txt("Unjuran baki hutang", size = 15f, weight = FontWeight.Bold)
        Txt("Tarikh di hujung garis ialah bulan langsai. Sentuh atau leret carta untuk lihat setiap bulan.", size = 12.5f, color = pal.muted)
        Spacer(Modifier.height(8.dp))
        LineChart(
            listOf(
                LSeries("Ikut pelan", pal.c1, planVals, if (plan.never) "Tak langsai" else monthShort(today, plan.bulan)),
                LSeries("Bayar minimum sahaja", pal.c2, minVals, if (a.never) "Tak langsai" else if (a.bulan > cap) "10 thn +" else monthShort(today, a.bulan)),
            ),
            titles, ticks,
        )
        Spacer(Modifier.height(6.dp))
        Legend(listOf(LegItem("Ikut pelan", pal.c1, true), LegItem("Bayar minimum sahaja", pal.c2, true)))
        val trows = ArrayList<List<String>>()
        var t = 0
        while (t <= n) { trows.add(listOf(titles[t], planVals.getOrNull(t)?.let { M(it) } ?: "Langsai", minVals.getOrNull(t)?.let { M(it) } ?: "Langsai")); t += if (n > 36) 12 else 6 }
        TableView(listOf("Bulan", "Ikut pelan", "Minimum sahaja"), trows)
        Spacer(Modifier.height(10.dp))
        Txt("Turutan langsai", size = 13f, color = pal.muted)
        Spacer(Modifier.height(6.dp))
        plan.urutan.forEachIndexed { i, u ->
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(24.dp).background(pal.surface2, CircleShape).border(1.dp, pal.line, CircleShape), contentAlignment = Alignment.Center) {
                    Txt((i + 1).toString(), size = 12f, weight = FontWeight.Bold, color = pal.muted, align = TextAlign.Center)
                }
                Spacer(Modifier.width(10.dp))
                Txt(u.nama, Modifier.weight(1f), size = 14f)
                Txt(u.bulan?.let { monthShort(today, it) } ?: "—", size = 13f, color = pal.muted, num = true)
            }
        }
        Spacer(Modifier.height(6.dp))
        Txt("Anggaran: faedah dikira setiap bulan atas baki kad. Ansuran EPP yang tinggal dimasukkan ikut jadual; belanja baru guna kad tidak dimasukkan.", size = 12.5f, color = pal.muted)
    }
}
