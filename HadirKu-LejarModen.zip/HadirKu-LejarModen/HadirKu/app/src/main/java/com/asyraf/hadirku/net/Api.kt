package com.asyraf.hadirku.net

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.time.LocalDate

object Api {

    private class HttpResult(val code: Int, val body: String)

    private fun request(
        url: String,
        method: String = "GET",
        headers: Map<String, String> = emptyMap(),
        body: String? = null,
        readTimeoutMs: Int = 15_000,
    ): HttpResult {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = method
            conn.connectTimeout = 10_000
            conn.readTimeout = readTimeoutMs
            headers.forEach { (k, v) -> conn.setRequestProperty(k, v) }
            if (body != null) {
                conn.doOutput = true
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            return HttpResult(code, text)
        } finally {
            conn.disconnect()
        }
    }

    // ---------------- Cuti umum: Calendarific (perlu kunci) ----------------

    suspend fun holidays(key: String, year: Int, state: String): Result<List<Pair<LocalDate, String>>> =
        withContext(Dispatchers.IO) {
            try {
                val url = "https://calendarific.com/api/v2/holidays?api_key=" +
                    URLEncoder.encode(key, "UTF-8") + "&country=MY&year=$year"
                val res = request(url)
                if (res.code != 200) return@withContext Result.failure(Exception("Calendarific balas kod ${res.code}"))
                val arr = JSONObject(res.body).optJSONObject("response")?.optJSONArray("holidays")
                    ?: return@withContext Result.failure(Exception("Format jawapan tak dijangka"))
                val wanted = state.trim().lowercase()
                val out = ArrayList<Pair<LocalDate, String>>()
                for (i in 0 until arr.length()) {
                    val h = arr.optJSONObject(i) ?: continue
                    val types = h.optJSONArray("type")
                    val typeText = if (types != null) (0 until types.length()).joinToString(" ") { types.optString(it) }.lowercase() else ""
                    val isPublic = typeText.contains("national") || typeText.contains("public") ||
                        (typeText.contains("local") && !typeText.contains("observance"))
                    if (!isPublic) continue
                    val statesAny = h.opt("states")
                    val inState = when (statesAny) {
                        is String -> statesAny.equals("All", ignoreCase = true)
                        is JSONArray -> wanted.isNotEmpty() && (0 until statesAny.length()).any { idx ->
                            val n = statesAny.optJSONObject(idx)?.optString("name", "")?.lowercase() ?: ""
                            n.isNotEmpty() && (n.contains(wanted) || wanted.contains(n))
                        }
                        else -> true
                    }
                    if (!inState) continue
                    val iso = h.optJSONObject("date")?.optString("iso", "") ?: ""
                    val date = runCatching { LocalDate.parse(iso.take(10)) }.getOrNull() ?: continue
                    out.add(date to h.optString("name", ""))
                }
                Result.success(out.distinctBy { it.first })
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    // ---------------- Anthropic Claude API ----------------

    class AiHttp(val code: Int, val body: String)

    /** POST mentah ke /v1/messages. Pulang kod & badan jawapan; IOException jika tiada sambungan. */
    fun anthropicRaw(key: String, body: String, timeoutMs: Int): AiHttp {
        val res = request(
            "https://api.anthropic.com/v1/messages", "POST",
            mapOf(
                "x-api-key" to key,
                "anthropic-version" to "2023-06-01",
                "content-type" to "application/json",
            ),
            body,
            readTimeoutMs = timeoutMs,
        )
        return AiHttp(res.code, res.body)
    }

    suspend fun askClaude(key: String, model: String, system: String, prompt: String): Result<String> =
        withContext(Dispatchers.IO) {
            try {
                val body = JSONObject()
                    .put("model", model)
                    .put("max_tokens", 900)
                    .put("system", system)
                    .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
                    .toString()
                val res = request(
                    "https://api.anthropic.com/v1/messages", "POST",
                    mapOf(
                        "x-api-key" to key,
                        "anthropic-version" to "2023-06-01",
                        "content-type" to "application/json",
                    ),
                    body,
                    readTimeoutMs = 60_000,
                )
                val o = JSONObject(res.body.ifBlank { "{}" })
                if (res.code !in 200..299) {
                    val msg = o.optJSONObject("error")?.optString("message", "") ?: ""
                    return@withContext Result.failure(Exception("Ralat ${res.code}${if (msg.isNotBlank()) ": $msg" else ""}"))
                }
                val content = o.optJSONArray("content") ?: return@withContext Result.failure(Exception("Jawapan kosong"))
                val text = (0 until content.length()).mapNotNull { i ->
                    val c = content.optJSONObject(i)
                    if (c != null && c.optString("type", "") == "text") c.optString("text", "") else null
                }.joinToString("\n").trim()
                if (text.isBlank()) Result.failure(Exception("Jawapan kosong")) else Result.success(text)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
}
