package com.asyraf.hadirku.engine.core

import java.math.BigDecimal
import java.math.RoundingMode

/**
 * Money in integer minor units (sen). Never Float/Double inside the engines.
 * All arithmetic is overflow-checked (ArithmeticException on overflow).
 * Currency is carried by accounts/entries, not by this value; engines refuse to mix currencies.
 */
@JvmInline
value class Money(val sen: Long) : Comparable<Money> {
    operator fun plus(o: Money): Money = Money(Math.addExact(sen, o.sen))
    operator fun minus(o: Money): Money = Money(Math.subtractExact(sen, o.sen))
    operator fun unaryMinus(): Money = Money(Math.negateExact(sen))
    operator fun times(n: Long): Money = Money(Math.multiplyExact(sen, n))
    operator fun times(n: Int): Money = times(n.toLong())
    override fun compareTo(other: Money): Int = sen.compareTo(other.sen)

    val isZero: Boolean get() = sen == 0L
    val isPositive: Boolean get() = sen > 0L
    val isNegative: Boolean get() = sen < 0L
    fun abs(): Money = if (sen < 0) -this else this
    fun max(o: Money): Money = if (this >= o) this else o
    fun min(o: Money): Money = if (this <= o) this else o
    fun coerceAtLeast(o: Money): Money = max(o)

    /** Exact decimal value in major units (RM), scale 2. */
    fun toDecimal(): BigDecimal = BigDecimal.valueOf(sen, 2)

    /** Multiply by a decimal ratio (e.g. 0.05 for 5%) with explicit rounding to the sen. */
    fun times(ratio: BigDecimal, mode: RoundingMode = RoundingMode.HALF_UP): Money =
        Money(toDecimal().multiply(ratio).setScale(2, mode).movePointRight(2).longValueExact())

    /** Divide by [n] parts (n ≥ 1), rounding to sen. */
    fun div(n: Long, mode: RoundingMode = RoundingMode.HALF_UP): Money {
        require(n > 0) { "divisor must be > 0" }
        return Money(BigDecimal.valueOf(sen).divide(BigDecimal.valueOf(n), 0, mode).longValueExact())
    }

    /**
     * Split into [parts] amounts that sum exactly to this value. The remainder sen go to the LAST part
     * (matches flat-rate instalment practice: equal instalments, last one absorbs rounding).
     */
    fun splitEven(parts: Int): List<Money> {
        require(parts > 0) { "parts must be > 0" }
        val base = sen / parts
        val rem = sen - base * parts
        return List(parts) { i -> Money(if (i == parts - 1) base + rem else base) }
    }

    /** Debug/test representation only — not a user-facing string. */
    override fun toString(): String = "RM" + toDecimal().toPlainString()

    companion object {
        val ZERO = Money(0L)
        fun ofSen(sen: Long) = Money(sen)

        /** Parse a decimal string in major units ("12.30", "-5", "1,234.50"). More than 2 decimals → HALF_UP. */
        fun parse(text: String): Money {
            val clean = text.trim().replace(",", "")
            require(clean.isNotEmpty()) { "empty amount" }
            return of(BigDecimal(clean))
        }

        fun of(major: BigDecimal, mode: RoundingMode = RoundingMode.HALF_UP): Money =
            Money(major.setScale(2, mode).movePointRight(2).longValueExact())

        /**
         * Boundary conversion from the existing app's Double RM values. Uses the shortest decimal
         * representation of the double (BigDecimal.valueOf) so 12.3 → 1230 sen exactly.
         * NaN/Infinity are rejected; callers decide how to report them.
         */
        fun fromDouble(rm: Double): Money {
            require(rm.isFinite()) { "non-finite amount" }
            return of(BigDecimal.valueOf(rm))
        }

        fun fromDoubleOrNull(rm: Double?): Money? = if (rm == null || !rm.isFinite()) null else of(BigDecimal.valueOf(rm))

        fun sum(items: Iterable<Money>): Money = items.fold(ZERO) { a, b -> a + b }
    }
}

inline fun <T> Iterable<T>.sumMoney(f: (T) -> Money): Money {
    var acc = Money.ZERO
    for (x in this) acc += f(x)
    return acc
}

/** Default currency of the app. Persistence models keep a currency field instead of assuming this. */
const val DEFAULT_CURRENCY = "MYR"
