package com.asyraf.hadirku.rumah

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.asyraf.hadirku.MainActivity
import com.asyraf.hadirku.R
import com.asyraf.hadirku.data.Repo
import com.asyraf.hadirku.i18n.tr
import com.asyraf.hadirku.pg.PG
import java.time.Duration
import java.time.LocalDateTime
import java.util.concurrent.TimeUnit

/** Peringatan komitmen: 3 hari dan 1 hari sebelum tarikh jatuh tempo (komitmen yang ada tempo sahaja). */
object Peringatan {
    // id saluran & nama kerja dikekalkan supaya tetapan notifikasi dan jadual lama terus berfungsi
    const val CH_BIL = "bil-rumah"
    const val CH_KEW = "kewangan"
    const val EXTRA_BUKA = "buka"

    fun saluran(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(NotificationChannel(CH_BIL, tr("Komitmen"), NotificationManager.IMPORTANCE_DEFAULT).apply {
            description = tr("Komitmen yang hampir jatuh tempo (3 hari & 1 hari sebelum)")
        })
        nm.createNotificationChannel(NotificationChannel(CH_KEW, tr("Kewangan"), NotificationManager.IMPORTANCE_DEFAULT).apply {
            description = tr("Bajet terlebih, amaran aliran tunai & matlamat simpanan tercapai")
        })
    }

    private fun boleh(ctx: Context): Boolean =
        (Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) &&
            NotificationManagerCompat.from(ctx).areNotificationsEnabled()

    private fun tunjuk(ctx: Context, id: Int, tajuk: String, teks: String, ch: String = CH_BIL, buka: String = "komitmen") {
        if (!boleh(ctx)) return
        val i = Intent(ctx, MainActivity::class.java).putExtra(EXTRA_BUKA, buka)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pi = PendingIntent.getActivity(ctx, id, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(ctx, ch)
            .setSmallIcon(R.drawable.ic_stat_hadir)
            .setContentTitle(tr(tajuk))
            .setContentText(tr(teks))
            .setStyle(NotificationCompat.BigTextStyle().bigText(tr(teks)))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        try { NotificationManagerCompat.from(ctx).notify(id, n) } catch (e: SecurityException) { }
    }

    /** Komitmen belum dibayar yang jatuh tempo 3 hari atau 1 hari lagi (sekali setiap komitmen, setiap tahap). */
    fun semakKomitmen(ctx: Context, today: String) {
        if (!Repo.getBool("ingat.bil", true)) return
        val s = Repo.pg.value
        semakKad(ctx, s, today)
        if (s.commitments.none { it.tempo in 1..31 }) return
        val p = PG.parse(today)
        // bulan ini dan bulan depan (tempo awal bulan depan boleh jatuh dalam 3 hari)
        listOf(today, PG.iso(p.y, p.m + 1, 1)).forEach { ref ->
            PG.commitmentStatus(s, ref).forEach { c ->
                if (c.status == "sudah") return@forEach
                val due = PG.tempoDate(c.c, ref) ?: return@forEach
                val n = PG.hariAntara(today, due)
                if (n != 3 && n != 1) return@forEach
                val key = "komitmen.notis.${c.id}.$due.$n"
                if (Repo.getBool(key, false)) return@forEach
                Repo.putBool(key, true)
                tunjuk(
                    ctx, 3000 + ((c.id + due).hashCode() and 0xfff),
                    c.nama + " " + (if (n == 1) "esok" else "3 hari lagi"),
                    c.nama + " " + PG.money(c.baki) + " jatuh tempo " + PG.fmtShort(due) + (if (n == 1) " (esok)." else " (3 hari lagi).") + " Tekan untuk rekod bayaran.",
                )
            }
        }
    }

    /** Kad kredit dengan tarikh akhir bayar: minimum belum dibayar 3 hari / 1 hari sebelum tarikh akhir (sekali setiap penyata, setiap tahap). */
    private fun semakKad(ctx: Context, s: com.asyraf.hadirku.pg.PgState, today: String) {
        if (s.debts.none { it.jenis == "kad" && it.bayarHari in 1..31 && it.penyataHari in 1..31 }) return
        PG.debtStatus(s, today).forEach { d ->
            val due = d.tarikhAkhir ?: return@forEach
            if (d.minTinggal <= 0.004) return@forEach
            val n = PG.hariAntara(today, due)
            if (n != 3 && n != 1) return@forEach
            val key = "kad.notis.${d.id}.$due.$n"
            if (Repo.getBool(key, false)) return@forEach
            Repo.putBool(key, true)
            tunjuk(
                ctx, 4000 + ((d.id + due).hashCode() and 0xfff),
                d.nama + ": akhir bayar " + (if (n == 1) "esok" else "3 hari lagi"),
                "Minimum belum dibayar " + PG.money(d.minTinggal) + " untuk penyata " + PG.fmtShort(d.perMula) + ". Tarikh akhir bayar " + PG.fmtShort(due) +
                    (if (n == 1) " (esok)." else " (3 hari lagi).") + " Tekan untuk bayar.",
                buka = "hutang",
            )
        }
    }

    /**
     * Notifikasi enjin kewangan (sekali sahaja bagi setiap kejadian — kunci disimpan dalam engine.json):
     * bajet terlebih bulan ini, amaran aliran tunai tahap WARNING (sekali sebulan) dan matlamat 50% / 100%.
     */
    fun semakKewangan(ctx: Context, today: String) {
        if (!Repo.getBool("ingat.kewangan", true)) return
        try {
            val td = java.time.LocalDate.parse(today)
            val store = com.asyraf.hadirku.engine.android.EngineHub.store(ctx)
            val lr = store.load()
            if (lr.readOnly) return
            val d = lr.data
            val s = Repo.pg.value
            if (s.transactions.isEmpty()) return
            val sum = com.asyraf.hadirku.engine.app.AppFacade.summary(s, d, td)
            val teks = HashMap<String, Triple<String, String, String>>()
            val ev = ArrayList<com.asyraf.hadirku.engine.notify.NotifEvent>()
            com.asyraf.hadirku.engine.notify.NotificationEngine.fromBudgetLines(sum.budgets, td).forEach { e ->
                ev += e
                teks[e.key] = Triple(
                    "Bajet terlebih: " + PG.katLabel(e.params["category"]),
                    "Lebih " + PG.money(e.params["over"]?.toDoubleOrNull()) + " bulan ini. Tekan untuk lihat bajet.", "kewangan:bajet",
                )
            }
            val bahaya = com.asyraf.hadirku.engine.app.AppFacade.distinctRisks(sum.risks).filter { it.severity == com.asyraf.hadirku.engine.risk.Severity.WARNING }
            com.asyraf.hadirku.engine.notify.NotificationEngine.fromRisk(bahaya, td).forEachIndexed { k, e ->
                ev += e
                val t = com.asyraf.hadirku.engine.app.AppFacade.riskText(bahaya[k], s)
                teks[e.key] = Triple(t.title, t.body, "kewangan:belanja")
            }
            val goals = sum.goals.filter { !it.goal.fromPocket }
            com.asyraf.hadirku.engine.notify.NotificationEngine.fromGoals(goals, td).forEach { e ->
                ev += e
                val g = goals.find { it.goal.id == e.subjectId }?.goal?.name ?: "Matlamat"
                val full = e.params["milestone_bp"] == "10000"
                teks[e.key] = Triple(
                    if (full) "Matlamat tercapai: $g" else "Separuh jalan: $g",
                    if (full) "Tahniah! Sasaran simpanan sudah cukup." else "50% daripada sasaran sudah diasingkan. Teruskan!", "kewangan:matlamat",
                )
            }
            if (ev.isEmpty()) return
            val eng = com.asyraf.hadirku.engine.notify.NotificationEngine(d.notifPrefs, com.asyraf.hadirku.engine.android.EngineHub.clock)
            val sink = object : com.asyraf.hadirku.engine.notify.NotificationSink {
                override fun canPost(): Boolean = boleh(ctx)
                override fun post(event: com.asyraf.hadirku.engine.notify.NotifEvent): Boolean {
                    val t = teks[event.key] ?: return false
                    tunjuk(ctx, 5000 + (event.key.hashCode() and 0xfff), t.first, t.second, CH_KEW, t.third)
                    return true
                }
            }
            val res = eng.dispatch(ev, d.notificationsSent, sink)
            if (res.posted.isNotEmpty()) store.update { it.copy(notificationsSent = eng.prune(it.notificationsSent + res.sent)) }
        } catch (e: Exception) { }
    }

    /** Semakan setiap pagi ~8:00 (WorkManager kekalkan selepas telefon dihidupkan semula). */
    fun pasang(ctx: Context) {
        val now = LocalDateTime.now()
        var pagi = now.withHour(8).withMinute(0).withSecond(0).withNano(0)
        if (!pagi.isAfter(now)) pagi = pagi.plusDays(1)
        val delay = Duration.between(now, pagi).toMinutes().coerceAtLeast(1)
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(
            "bil-rumah", ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<BilWorker>(1, TimeUnit.DAYS).setInitialDelay(delay, TimeUnit.MINUTES).build(),
        )
    }
}

class BilWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        Repo.init(applicationContext)
        Peringatan.semakKomitmen(applicationContext, PG.todayISO())
        Peringatan.semakKewangan(applicationContext, PG.todayISO())
        return Result.success()
    }
}
