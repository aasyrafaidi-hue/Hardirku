package com.asyraf.hadirku.rumah

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.asyraf.hadirku.MainActivity
import com.asyraf.hadirku.R
import com.asyraf.hadirku.data.Repo
import com.asyraf.hadirku.i18n.tr
import com.asyraf.hadirku.pg.PG
import java.time.Duration
import java.time.LocalDateTime
import java.util.concurrent.TimeUnit

/** Peringatan komitmen: 3 hari dan 1 hari sebelum tarikh jatuh tempo (komitmen yang ada tempo sahaja). */
object Peringatan {
    // id saluran & nama kerja dikekalkan supaya tetapan notifikasi dan jadual lama terus berfungsi
    const val CH_BIL = "bil-rumah"
    const val EXTRA_BUKA = "buka"

    fun saluran(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(NotificationChannel(CH_BIL, tr("Komitmen"), NotificationManager.IMPORTANCE_DEFAULT).apply {
            description = tr("Komitmen yang hampir jatuh tempo (3 hari & 1 hari sebelum)")
        })
    }

    private fun boleh(ctx: Context): Boolean =
        (Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) &&
            NotificationManagerCompat.from(ctx).areNotificationsEnabled()

    private fun tunjuk(ctx: Context, id: Int, tajuk: String, teks: String) {
        if (!boleh(ctx)) return
        val i = Intent(ctx, MainActivity::class.java).putExtra(EXTRA_BUKA, "komitmen")
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pi = PendingIntent.getActivity(ctx, id, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(ctx, CH_BIL)
            .setSmallIcon(R.drawable.ic_stat_hadir)
            .setContentTitle(tr(tajuk))
            .setContentText(tr(teks))
            .setStyle(NotificationCompat.BigTextStyle().bigText(tr(teks)))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        try { NotificationManagerCompat.from(ctx).notify(id, n) } catch (e: SecurityException) { }
    }

    /** Komitmen belum dibayar yang jatuh tempo 3 hari atau 1 hari lagi (sekali setiap komitmen, setiap tahap). */
    fun semakKomitmen(ctx: Context, today: String) {
        if (!Repo.getBool("ingat.bil", true)) return
        val s = Repo.pg.value
        if (s.commitments.none { it.tempo in 1..31 }) return
        val p = PG.parse(today)
        // bulan ini dan bulan depan (tempo awal bulan depan boleh jatuh dalam 3 hari)
        listOf(today, PG.iso(p.y, p.m + 1, 1)).forEach { ref ->
            PG.commitmentStatus(s, ref).forEach { c ->
                if (c.status == "sudah") return@forEach
                val due = PG.tempoDate(c.c, ref) ?: return@forEach
                val n = PG.hariAntara(today, due)
                if (n != 3 && n != 1) return@forEach
                val key = "komitmen.notis.${c.id}.$due.$n"
                if (Repo.getBool(key, false)) return@forEach
                Repo.putBool(key, true)
                tunjuk(
                    ctx, 3000 + ((c.id + due).hashCode() and 0xfff),
                    c.nama + " " + (if (n == 1) "esok" else "3 hari lagi"),
                    c.nama + " " + PG.money(c.baki) + " jatuh tempo " + PG.fmtShort(due) + (if (n == 1) " (esok)." else " (3 hari lagi).") + " Tekan untuk rekod bayaran.",
                )
            }
        }
    }

    /** Semakan setiap pagi ~8:00 (WorkManager kekalkan selepas telefon dihidupkan semula). */
    fun pasang(ctx: Context) {
        val now = LocalDateTime.now()
        var pagi = now.withHour(8).withMinute(0).withSecond(0).withNano(0)
        if (!pagi.isAfter(now)) pagi = pagi.plusDays(1)
        val delay = Duration.between(now, pagi).toMinutes().coerceAtLeast(1)
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(
            "bil-rumah", ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<BilWorker>(1, TimeUnit.DAYS).setInitialDelay(delay, TimeUnit.MINUTES).build(),
        )
    }
}

class BilWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        Repo.init(applicationContext)
        Peringatan.semakKomitmen(applicationContext, PG.todayISO())
        return Result.success()
    }
}
