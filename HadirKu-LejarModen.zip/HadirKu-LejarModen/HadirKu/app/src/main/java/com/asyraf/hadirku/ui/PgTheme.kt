package com.asyraf.hadirku.ui

import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import com.asyraf.hadirku.R
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.sp

/**
 * Token warna Duitku — "Soft Violet" (tema DuitkuIsteri): ungu lembut, latar lavender pucat, tinta ungu gelap.
 * Masuk = hijau, keluar = merah jambu lembut; maklumat tidak bergantung pada warna sahaja (tanda +/−, label, ikon).
 * Medan asal (bg, surface, accent, inn, out, …) dikekalkan supaya semua skrin lama terus berfungsi.
 */
class Pal(
    val dark: Boolean,
    val bg: Color, val surface: Color, val surface2: Color, val track: Color,
    val ink: Color, val muted: Color, val line: Color, val lineStrong: Color,
    val accent: Color, val accentStrong: Color, val accentInk: Color, val accentSoft: Color,
    val good: Color, val goodSoft: Color, val warn: Color, val warnSoft: Color,
    val bad: Color, val badSoft: Color, val badInk: Color,
    val inn: Color, val inSoft: Color, val out: Color,
    val p: List<Color>, val pu: Color,
    val c1: Color, val c2: Color, val c1Wash: Color, val grid: Color, val scrim: Color,
    // ---- tambahan Lejar Moden ----
    /** gradien kad hero (atas-kiri → bawah-kanan) */
    val heroA: Color, val heroB: Color, val heroInk: Color,
    /** kertas lejar & kepala kumpulan tarikh */
    val paper: Color, val paperHead: Color,
    /** hijau pucat & sangat pucat (latar ikon, chip aktif) */
    val mint: Color, val mintWash: Color,
    /** oren-perang lembut (bil akan datang) — bukan kuning terang */
    val amber: Color, val amberSoft: Color,
    /** garis tepi kad & warna bayang */
    val border: Color, val shadow: Color,
    /** warna kecil ikon kategori (latar, tulisan) */
    val outSoft: Color,
) {
    /** Warna poket / kategori: slot 1..6. */
    fun slot(i: Int): Color = p[(i - 1).coerceIn(0, 5)]
}

private fun c(hex: Long): Color = Color(hex or 0xFF000000L)

/* Rujukan templat: #9254DF (ungu), #7840CE (ungu dalam), #F3EDFF (lavender), #21183D (tinta), #00865D (hijau). */
val LightPal = Pal(
    dark = false,
    bg = c(0xF6F1FD), surface = c(0xFFFFFF), surface2 = c(0xF8F4FF), track = c(0xE6DCF5),
    ink = c(0x21183D), muted = c(0x736886), line = c(0xEDE6F5), lineStrong = c(0xD8CBEC),
    accent = c(0x7840CE), accentStrong = c(0x5D2DB0), accentInk = c(0xFFFFFF), accentSoft = c(0xEDE3FC),
    good = c(0x00865D), goodSoft = c(0xDDF6EC), warn = c(0xB85B16), warnSoft = c(0xFFF0DE),
    bad = c(0xC63A56), badSoft = c(0xFFE5E9), badInk = c(0xFFFFFF),
    inn = c(0x00865D), inSoft = c(0xEAF8F2), out = c(0xC63A56),
    p = listOf(c(0x9254DF), c(0x3FA98F), c(0xE08A4F), c(0xD9689A), c(0x6E7FE0), c(0xA79BBB)), pu = c(0xE8DFF6),
    c1 = c(0xB67AF1), c2 = c(0xF08FB0), c1Wash = Color(0x1F9254DF), grid = c(0xF1EBF9), scrim = Color(0x7321183D),
    heroA = c(0xA76CDE), heroB = c(0x4A2C93), heroInk = c(0xFFFFFF),
    paper = c(0xFCFAFF), paperHead = c(0xF3EDFF),
    mint = c(0xEDE3FC), mintWash = c(0xF5EFFF),
    amber = c(0xB85B16), amberSoft = c(0xFFF0DE),
    border = c(0xF0E9F8), shadow = Color(0x2E51317C),
    outSoft = c(0xFFE5E9),
)

val DarkPal = Pal(
    dark = true,
    bg = c(0x1A1528), surface = c(0x2A2240), surface2 = c(0x32294A), track = c(0x3E3456),
    ink = c(0xF5EFFF), muted = c(0xC2B5D6), line = c(0x392F50), lineStrong = c(0x4E4268),
    accent = c(0xBB8EF3), accentStrong = c(0xD3B4FA), accentInk = c(0x1D1236), accentSoft = c(0x3B2D5E),
    good = c(0x6FD3A8), goodSoft = c(0x1E3B33), warn = c(0xF0B27A), warnSoft = c(0x3F2F24),
    bad = c(0xF4909F), badSoft = c(0x46252F), badInk = c(0x1C0E13),
    inn = c(0x6FD3A8), inSoft = c(0x1B342D), out = c(0xF4909F),
    p = listOf(c(0xB98AF0), c(0x6CCFB5), c(0xF0A877), c(0xEC8FB6), c(0x95A3F2), c(0x8C819F)), pu = c(0x3A3052),
    c1 = c(0xB98AF0), c2 = c(0xEC8FB6), c1Wash = Color(0x26B98AF0), grid = c(0x30283F), scrim = Color(0x99000000),
    heroA = c(0x7A4AC2), heroB = c(0x34206B), heroInk = c(0xF8F3FF),
    paper = c(0x2A2240), paperHead = c(0x32294A),
    mint = c(0x3B2D5E), mintWash = c(0x30264A),
    amber = c(0xF0B27A), amberSoft = c(0x3F2F24),
    border = c(0x3A3052), shadow = Color(0x66000000),
    outSoft = c(0x46252F),
)

/** Fon Inter (lesen OFL, assets/lesen/Inter-OFL.txt) — 4 berat statik; glyph tiada (cth ✔, emoji) guna fon sistem. */
val AppFont = FontFamily(
    Font(R.font.inter_regular, FontWeight.Normal),
    Font(R.font.inter_medium, FontWeight.Medium),
    Font(R.font.inter_semibold, FontWeight.SemiBold),
    Font(R.font.inter_bold, FontWeight.Bold),
    Font(R.font.inter_bold, FontWeight.ExtraBold),
)

/** Gradien utama (butang, + tengah, bar): ungu cerah → ungu dalam, ikut templat. */
fun violetBrush(pal: Pal): Brush = if (pal.dark) Brush.linearGradient(listOf(c(0x9A66E4), c(0x6B3CC0)))
    else Brush.linearGradient(listOf(c(0xB77AF0), c(0x7840CE)))

/** Latar halaman: lavender sangat pucat ke lavender (cerah) / ungu malam (gelap). */
fun pageBrush(pal: Pal): Brush = if (pal.dark) Brush.verticalGradient(listOf(c(0x1E1830), c(0x17122A)))
    else Brush.verticalGradient(listOf(c(0xFAF7FF), c(0xEEE6FA)))

val LocalPal = staticCompositionLocalOf { LightPal }

/** Tema app: warna Soft Violet + fon Inter + saiz tulisan pengguna (10–20px, asal 15px). */
@Composable
fun PgTheme(dark: Boolean, saiz: Int, content: @Composable () -> Unit) {
    val pal = if (dark) DarkPal else LightPal
    val scheme = if (dark) darkColorScheme(
        primary = pal.accent, onPrimary = pal.accentInk, primaryContainer = pal.accentSoft, onPrimaryContainer = pal.accentStrong,
        secondary = pal.accentStrong, onSecondary = pal.accentInk, background = pal.bg, onBackground = pal.ink,
        surface = pal.surface, onSurface = pal.ink, surfaceVariant = pal.surface2, onSurfaceVariant = pal.muted,
        outline = pal.lineStrong, outlineVariant = pal.line, error = pal.bad, onError = pal.badInk,
        surfaceContainer = pal.surface, surfaceContainerHigh = pal.surface, surfaceContainerHighest = pal.surface2,
        surfaceContainerLow = pal.surface, surfaceContainerLowest = pal.surface,
    ) else lightColorScheme(
        primary = pal.accent, onPrimary = pal.accentInk, primaryContainer = pal.accentSoft, onPrimaryContainer = pal.accentStrong,
        secondary = pal.accentStrong, onSecondary = pal.accentInk, background = pal.bg, onBackground = pal.ink,
        surface = pal.surface, onSurface = pal.ink, surfaceVariant = pal.surface2, onSurfaceVariant = pal.muted,
        outline = pal.lineStrong, outlineVariant = pal.line, error = pal.bad, onError = pal.badInk,
        surfaceContainer = pal.surface, surfaceContainerHigh = pal.surface, surfaceContainerHighest = pal.surface2,
        surfaceContainerLow = pal.surface, surfaceContainerLowest = pal.surface,
    )
    val d = LocalDensity.current
    val fz = saiz.coerceIn(10, 20) / 15f
    val ty = Typography().let { t ->
        t.copy(
            displayLarge = t.displayLarge.copy(fontFamily = AppFont), displayMedium = t.displayMedium.copy(fontFamily = AppFont), displaySmall = t.displaySmall.copy(fontFamily = AppFont),
            headlineLarge = t.headlineLarge.copy(fontFamily = AppFont), headlineMedium = t.headlineMedium.copy(fontFamily = AppFont), headlineSmall = t.headlineSmall.copy(fontFamily = AppFont),
            titleLarge = t.titleLarge.copy(fontFamily = AppFont), titleMedium = t.titleMedium.copy(fontFamily = AppFont), titleSmall = t.titleSmall.copy(fontFamily = AppFont),
            bodyLarge = t.bodyLarge.copy(fontFamily = AppFont), bodyMedium = t.bodyMedium.copy(fontFamily = AppFont), bodySmall = t.bodySmall.copy(fontFamily = AppFont),
            labelLarge = t.labelLarge.copy(fontFamily = AppFont), labelMedium = t.labelMedium.copy(fontFamily = AppFont), labelSmall = t.labelSmall.copy(fontFamily = AppFont),
        )
    }
    MaterialTheme(colorScheme = scheme, typography = ty) {
        CompositionLocalProvider(
            LocalPal provides pal,
            LocalDensity provides Density(d.density, d.fontScale * fz),
            LocalContentColor provides pal.ink,
            LocalTextStyle provides TextStyle(fontFamily = AppFont, fontSize = 15.sp, color = pal.ink, lineHeight = 21.sp),
        ) {
            content()
        }
    }
}
