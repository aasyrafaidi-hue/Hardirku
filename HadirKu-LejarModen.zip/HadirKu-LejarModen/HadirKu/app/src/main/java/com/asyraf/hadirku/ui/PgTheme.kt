package com.asyraf.hadirku.ui

import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.sp

/**
 * Token warna Duitku — "Lejar Moden": kertas putih lembut, hijau zamrud, merah lembut.
 * Masuk = hijau, keluar = merah lembut; maklumat tidak bergantung pada warna sahaja (tanda +/−, label, ikon).
 * Medan asal (bg, surface, accent, inn, out, …) dikekalkan supaya semua skrin lama terus berfungsi.
 */
class Pal(
    val dark: Boolean,
    val bg: Color, val surface: Color, val surface2: Color, val track: Color,
    val ink: Color, val muted: Color, val line: Color, val lineStrong: Color,
    val accent: Color, val accentStrong: Color, val accentInk: Color, val accentSoft: Color,
    val good: Color, val goodSoft: Color, val warn: Color, val warnSoft: Color,
    val bad: Color, val badSoft: Color, val badInk: Color,
    val inn: Color, val inSoft: Color, val out: Color,
    val p: List<Color>, val pu: Color,
    val c1: Color, val c2: Color, val c1Wash: Color, val grid: Color, val scrim: Color,
    // ---- tambahan Lejar Moden ----
    /** gradien kad hero (atas-kiri → bawah-kanan) */
    val heroA: Color, val heroB: Color, val heroInk: Color,
    /** kertas lejar & kepala kumpulan tarikh */
    val paper: Color, val paperHead: Color,
    /** hijau pucat & sangat pucat (latar ikon, chip aktif) */
    val mint: Color, val mintWash: Color,
    /** oren-perang lembut (bil akan datang) — bukan kuning terang */
    val amber: Color, val amberSoft: Color,
    /** garis tepi kad & warna bayang */
    val border: Color, val shadow: Color,
    /** warna kecil ikon kategori (latar, tulisan) */
    val outSoft: Color,
) {
    /** Warna poket / kategori: slot 1..6. */
    fun slot(i: Int): Color = p[(i - 1).coerceIn(0, 5)]
}

private fun c(hex: Long): Color = Color(hex or 0xFF000000L)

val LightPal = Pal(
    dark = false,
    bg = c(0xF7F9F6), surface = c(0xFFFFFF), surface2 = c(0xF3F6F1), track = c(0xE4EBE5),
    ink = c(0x1C2C28), muted = c(0x64746E), line = c(0xE7ECE7), lineStrong = c(0xC9D6CD),
    accent = c(0x075B46), accentStrong = c(0x074537), accentInk = c(0xFFFFFF), accentSoft = c(0xDDF0E5),
    good = c(0x168359), goodSoft = c(0xE2F4E6), warn = c(0xA56B25), warnSoft = c(0xFFF3E1),
    bad = c(0xB64949), badSoft = c(0xFBEAE8), badInk = c(0xFFFFFF),
    inn = c(0x168359), inSoft = c(0xEDF7F0), out = c(0xB64949),
    p = listOf(c(0x168362), c(0x4F7CAC), c(0xB8742B), c(0x7A68B0), c(0xC2668A), c(0x9AA8A2)), pu = c(0xDCE4DE),
    c1 = c(0x5DB58E), c2 = c(0xE28A82), c1Wash = Color(0x1A5DB58E), grid = c(0xEEF2EE), scrim = Color(0x730B1A15),
    heroA = c(0x0B6B52), heroB = c(0x06493A), heroInk = c(0xFFFFFF),
    paper = c(0xFAF9F4), paperHead = c(0xF3F1E8),
    mint = c(0xDDF0E5), mintWash = c(0xEDF7F0),
    amber = c(0xA56B25), amberSoft = c(0xFFF3E1),
    border = c(0xDEE7DE), shadow = Color(0x290B3A2C),
    outSoft = c(0xFBEAE8),
)

val DarkPal = Pal(
    dark = true,
    bg = c(0x101816), surface = c(0x192521), surface2 = c(0x22302B), track = c(0x2B3C34),
    ink = c(0xEAF4EE), muted = c(0xADBCB3), line = c(0x2B3C34), lineStrong = c(0x3F5348),
    accent = c(0x75C4A1), accentStrong = c(0x85D7B4), accentInk = c(0x06281E), accentSoft = c(0x244537),
    good = c(0x81D6A6), goodSoft = c(0x244537), warn = c(0xE4BC76), warnSoft = c(0x453825),
    bad = c(0xF09794), badSoft = c(0x432927), badInk = c(0x1A0E0E),
    inn = c(0x81D6A6), inSoft = c(0x1B3329), out = c(0xF09794),
    p = listOf(c(0x5FBF92), c(0x7FA6D6), c(0xD59A5B), c(0xA291DA), c(0xD88AA8), c(0x6E7D76)), pu = c(0x2F3E37),
    c1 = c(0x5FBF92), c2 = c(0xE58C86), c1Wash = Color(0x1F5FBF92), grid = c(0x22302B), scrim = Color(0x99000000),
    heroA = c(0x1F5A47), heroB = c(0x123A2F), heroInk = c(0xF2FBF6),
    paper = c(0x1D2925), paperHead = c(0x22302B),
    mint = c(0x244537), mintWash = c(0x1B3329),
    amber = c(0xE4BC76), amberSoft = c(0x3A3122),
    border = c(0x35473E), shadow = Color(0x66000000),
    outSoft = c(0x432927),
)

val LocalPal = staticCompositionLocalOf { LightPal }

/** Tema app: warna Lejar Moden + saiz tulisan pengguna (10–20px, asal 15px). */
@Composable
fun PgTheme(dark: Boolean, saiz: Int, content: @Composable () -> Unit) {
    val pal = if (dark) DarkPal else LightPal
    val scheme = if (dark) darkColorScheme(
        primary = pal.accent, onPrimary = pal.accentInk, primaryContainer = pal.accentSoft, onPrimaryContainer = pal.accentStrong,
        secondary = pal.accentStrong, onSecondary = pal.accentInk, background = pal.bg, onBackground = pal.ink,
        surface = pal.surface, onSurface = pal.ink, surfaceVariant = pal.surface2, onSurfaceVariant = pal.muted,
        outline = pal.lineStrong, outlineVariant = pal.line, error = pal.bad, onError = pal.badInk,
        surfaceContainer = pal.surface, surfaceContainerHigh = pal.surface, surfaceContainerHighest = pal.surface2,
        surfaceContainerLow = pal.surface, surfaceContainerLowest = pal.surface,
    ) else lightColorScheme(
        primary = pal.accent, onPrimary = pal.accentInk, primaryContainer = pal.accentSoft, onPrimaryContainer = pal.accentStrong,
        secondary = pal.accentStrong, onSecondary = pal.accentInk, background = pal.bg, onBackground = pal.ink,
        surface = pal.surface, onSurface = pal.ink, surfaceVariant = pal.surface2, onSurfaceVariant = pal.muted,
        outline = pal.lineStrong, outlineVariant = pal.line, error = pal.bad, onError = pal.badInk,
        surfaceContainer = pal.surface, surfaceContainerHigh = pal.surface, surfaceContainerHighest = pal.surface2,
        surfaceContainerLow = pal.surface, surfaceContainerLowest = pal.surface,
    )
    val d = LocalDensity.current
    val fz = saiz.coerceIn(10, 20) / 15f
    MaterialTheme(colorScheme = scheme) {
        CompositionLocalProvider(
            LocalPal provides pal,
            LocalDensity provides Density(d.density, d.fontScale * fz),
            LocalContentColor provides pal.ink,
            LocalTextStyle provides TextStyle(fontSize = 15.sp, color = pal.ink, lineHeight = 21.sp),
        ) {
            content()
        }
    }
}
