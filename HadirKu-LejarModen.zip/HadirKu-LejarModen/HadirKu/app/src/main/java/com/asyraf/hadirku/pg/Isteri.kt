package com.asyraf.hadirku.pg

/**
 * Versi isteri (Duitku Isteri, suri rumah): tiada gaji tetap, OT atau kitaran kerja.
 * Duit masuk ialah nafkah dan duit belanja, jadi tetapan gaji (yang tersembunyi dan tidak boleh diubah
 * dalam app isteri) dikosongkan supaya ramalan tidak menjangka "gaji 30hb" yang tidak wujud.
 * Poket, transaksi, komitmen dan hutang tidak disentuh.
 */
object Isteri {

    /** Nama duit masuk utama dalam data contoh versi isteri. */
    const val NAFKAH = "Nafkah dari suami"

    fun sesuaikan(s: PgState): PgState {
        val g = s.settings.gaji
        val gaji0 = g.copy(basic = 0.0, night = 0.0, transport = 0.0, potongan = 0.0, advance = 0.0)
        val tx = if (s.contoh) s.transactions.map { t ->
            if (t.jenis == "masuk" && t.perkara.startsWith("Gaji")) t.copy(perkara = NAFKAH) else t
        } else s.transactions
        val out = s.copy(
            settings = s.settings.copy(gaji = gaji0, otPendapatan = false),
            ot = emptyMap(),
            transactions = tx,
        )
        return if (out == s) s else out
    }
}
