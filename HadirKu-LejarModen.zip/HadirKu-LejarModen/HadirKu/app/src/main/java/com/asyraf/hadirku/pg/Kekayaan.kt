package com.asyraf.hadirku.pg

import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.max

/**
 * Kekayaan bersih = semua duit (bank + tunai + e-wallet) + aset lain (KWSP, ASB, Tabung Haji, emas…) − semua hutang.
 *
 * Aset lain disimpan dalam settings.extraJson kunci "aset" supaya ikut masuk fail salinan
 * (PoketGaji PWA abaikan kunci ini tapi kekalkannya). Setiap aset ada sejarah nilai bertarikh,
 * jadi nilai pada hujung setiap bulan boleh dikira semula.
 */
object Kekayaan {

    class Aset(val id: String, val nama: String, val sejarah: List<Pair<String, Double>>) {
        val nilai: Double get() = sejarah.maxByOrNull { it.first }?.second ?: 0.0
        val dikemas: String get() = sejarah.maxByOrNull { it.first }?.first ?: ""
        /** Nilai pada tarikh [d]. Sebelum rekod pertama → guna nilai pertama (aset itu sudah wujud, cuma baru direkod),
         *  supaya menambah KWSP hari ini tidak nampak macam kekayaan "melonjak" bulan ini. */
        fun nilaiPada(d: String): Double = sejarah.filter { it.first <= d }.maxByOrNull { it.first }?.second ?: sejarah.firstOrNull()?.second ?: 0.0
    }

    class Titik(val tarikh: String, val duit: Double, val aset: Double, val hutang: Double) {
        val bersih: Double get() = PG.round2(duit + aset - hutang)
    }

    class Ringkas(
        val titik: List<Titik>,
        val kini: Titik,
        val bulanIni: Double?,
        val purataSebulan: Double?,
        val bulanDikira: Int,
    )

    // ---------------- aset lain ----------------

    fun asetDari(s: PgState): List<Aset> = try {
        val ex = s.settings.extraJson?.let { JSONObject(it) }
        val a = ex?.optJSONArray("aset") ?: JSONArray()
        (0 until a.length()).mapNotNull { i ->
            val o = a.optJSONObject(i) ?: return@mapNotNull null
            val sj = o.optJSONArray("sejarah") ?: JSONArray()
            val list = (0 until sj.length()).mapNotNull { k ->
                val e = sj.optJSONObject(k) ?: return@mapNotNull null
                val t = e.optString("t")
                val v = e.optDouble("v", Double.NaN)
                if (t.length == 10 && v.isFinite()) t to v else null
            }.sortedBy { it.first }
            Aset(o.optString("id").ifEmpty { "a-$i" }, o.optString("nama").ifEmpty { "Aset" }, list)
        }
    } catch (e: Exception) { emptyList() }

    fun denganAset(s: PgState, list: List<Aset>): PgState {
        val ex = try { s.settings.extraJson?.let { JSONObject(it) } ?: JSONObject() } catch (e: Exception) { JSONObject() }
        val a = JSONArray()
        list.forEach { x ->
            a.put(JSONObject().put("id", x.id).put("nama", x.nama).put("sejarah", JSONArray().also { sj ->
                x.sejarah.forEach { (t, v) -> sj.put(JSONObject().put("t", t).put("v", v)) }
            }))
        }
        if (list.isEmpty()) ex.remove("aset") else ex.put("aset", a)
        val json = if (ex.length() == 0) null else ex.toString()
        return s.copy(settings = s.settings.copy(extraJson = json))
    }

    // ---------------- kira ----------------

    fun duitPada(s: PgState, d: String): Double = PG.round2(PG.total(s, d) + PG.totalDompet(s, d))

    fun hutangPada(s: PgState, d: String): Double = PG.round2(s.debts.sumOf { x ->
        max(0.0, PG.debtBalance(s, x, d, d)) + (if (x.jenis == "kad") PG.eppUnbilledPokok(x, d) else 0.0)
    })

    fun titikPada(s: PgState, d: String, aset: List<Aset>): Titik =
        Titik(d, duitPada(s, d), PG.round2(aset.sumOf { it.nilaiPada(d) }), hutangPada(s, d))

    /** Tarikh data pertama (transaksi, log hutang atau nilai aset). */
    private fun mulaData(s: PgState, aset: List<Aset>): String? {
        val c = ArrayList<String>()
        s.transactions.minOfOrNull { it.tarikh }?.let { c.add(it) }
        s.debts.forEach { d -> d.log.minOfOrNull { it.tarikh }?.let { c.add(it) } }
        if (c.isEmpty()) aset.forEach { a -> a.sejarah.firstOrNull()?.first?.let { c.add(it) } }
        return c.minOrNull()
    }

    /** Hujung setiap bulan untuk [bulan] bulan lepas + hari ini. */
    fun siri(s: PgState, today: String, bulan: Int): Ringkas {
        val aset = asetDari(s)
        val mula = mulaData(s, aset)
        val out = ArrayList<Titik>()
        val ymNow = PG.ym(today)
        for (k in bulan downTo 1) {
            val ym = PG.shiftYm(ymNow, -k)
            val p = PG.parse("$ym-01")
            val akhir = PG.iso(p.y, p.m, PG.lastDay(p.y, p.m))
            if (mula == null || akhir < mula) continue
            out.add(titikPada(s, akhir, aset))
        }
        val kini = titikPada(s, today, aset)
        out.add(kini)
        val lepas = if (out.size >= 2) out[out.size - 2] else null
        val bulanIni = lepas?.let { PG.round2(kini.bersih - it.bersih) }
        // purata perubahan sebulan (hujung bulan ke hujung bulan; bulan semasa yang belum habis tidak dikira)
        val penuh = out.dropLast(1)
        val purata = if (penuh.size >= 2) PG.round2((penuh.last().bersih - penuh.first().bersih) / (penuh.size - 1)) else null
        return Ringkas(out, kini, bulanIni, purata, max(0, penuh.size - 1))
    }
}
