package com.asyraf.hadirku.engine.debt

import com.asyraf.hadirku.engine.core.Money
import com.asyraf.hadirku.engine.ledger.AccountKind
import com.asyraf.hadirku.engine.ledger.ChargeKind
import com.asyraf.hadirku.engine.ledger.Entry
import com.asyraf.hadirku.engine.ledger.EntryType
import com.asyraf.hadirku.engine.ledger.LedgerBook
import com.asyraf.hadirku.engine.ledger.PgLedgerAdapter
import com.asyraf.hadirku.engine.ledger.Storage
import com.asyraf.hadirku.pg.Epp
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.PgState
import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode
import java.time.LocalDate

/* =====================================================================
 * Engine 5 — Debt & EPP
 * Schedules (flat / reducing), pre-existing loans imported mid-term (opening balance + remaining
 * schedule only — no history re-created), fees, partial payments and early-settlement quotes.
 * Debt-side events (charges, EPP billing) are kept apart from cash payments (DEBT_REPAYMENT).
 * ===================================================================== */

enum class RateMethod { NONE, FLAT, REDUCING }

data class Installment(
    val n: Int,
    val dueDate: LocalDate,
    val principal: Money,
    /** null when unknown (e.g. flat loan imported mid-term without its rate) */
    val interest: Money?,
    val total: Money,
)

enum class EarlySettlementPolicy {
    /** pay outstanding principal only, no future interest (typical for EPP 0% / modern loans) */
    REMAINING_PRINCIPAL,
    /** Rule of 78 rebate of unearned interest (older flat-rate hire-purchase style) */
    RULE_OF_78,
}

data class Allocation(val toFees: Money, val toInterest: Money, val toPrincipal: Money, val unapplied: Money)

data class EppProfile(
    val debtId: String,
    val planId: String,
    val name: String,
    val principal: Money,
    val annualFlatRatePct: BigDecimal,
    val totalInterest: Money,
    val schedule: List<Installment>,
    val billed: Int,
    val remaining: Int,
    val outstandingPrincipal: Money,
    val unbilledInterest: Money,
    val nextDue: LocalDate?,
)

data class DebtProfile(
    val debtId: String,
    val creditor: String,
    val kind: Storage,
    val annualRatePct: BigDecimal,
    val method: RateMethod,
    val openingOutstanding: Money?,
    val openingDate: LocalDate?,
    val outstanding: Money,
    val interestCharged: Money,
    val feesCharged: Money,
    val repayments: List<Entry>,
    /** repayments in the current period smaller than the period's minimum (partial) */
    val partialThisPeriod: Boolean,
    val epp: List<EppProfile>,
)

object DebtEngine {
    private val MC = MathContext.DECIMAL64
    private val HUNDRED = BigDecimal(100)
    private val TWELVE_HUNDRED = BigDecimal(1200)

    /**
     * Flat-rate schedule (EPP / hire-purchase style). Same arithmetic as the existing app (PG.eppInfo):
     * total interest = P × rate% × months/12; equal instalments rounded to sen, last absorbs rounding;
     * principal per instalment = P ÷ months, last absorbs rounding. Optional fixed instalment or
     * explicit total interest override the rate (statement values win).
     */
    fun flatSchedule(
        principal: Money, annualRatePct: BigDecimal, months: Int, firstDue: LocalDate,
        fixedInstallment: Money? = null, totalInterestOverride: Money? = null,
    ): List<Installment> {
        require(months >= 1) { "months must be ≥ 1" }
        var total = principal + (totalInterestOverride ?: principal.times(annualRatePct.multiply(BigDecimal(months)).divide(TWELVE_HUNDRED, MC)))
        var inst = total.div(months.toLong())
        if (fixedInstallment != null && fixedInstallment.isPositive) { inst = fixedInstallment; total = fixedInstallment * months }
        val last = total - inst * (months - 1)
        val pp = principal.div(months.toLong())
        val ppLast = principal - pp * (months - 1)
        return (0 until months).map { k ->
            val amt = if (k == months - 1) last else inst
            val p = (if (k == months - 1) ppLast else pp).min(amt).coerceAtLeast(Money.ZERO)
            Installment(k + 1, firstDue.plusMonths(k.toLong()), p, amt - p, amt)
        }
    }

    /** Reducing-balance (annuity) schedule; interest each month = balance × rate/12, last payment clears exactly. */
    fun reducingSchedule(principal: Money, annualRatePct: BigDecimal, months: Int, firstDue: LocalDate): List<Installment> {
        require(months >= 1) { "months must be ≥ 1" }
        val r = annualRatePct.divide(TWELVE_HUNDRED, MC)
        val pay: Money = if (r.signum() == 0) principal.div(months.toLong()) else {
            val p = principal.toDecimal()
            val denom = BigDecimal.ONE.subtract(BigDecimal.ONE.add(r).pow(-months, MC), MC)
            Money.of(p.multiply(r, MC).divide(denom, MC))
        }
        var bal = principal
        return (0 until months).map { k ->
            val interest = bal.times(r)
            val isLast = k == months - 1
            val princ = if (isLast) bal else (pay - interest).min(bal).coerceAtLeast(Money.ZERO)
            bal -= princ
            Installment(k + 1, firstDue.plusMonths(k.toLong()), princ, interest, princ + interest)
        }
    }

    /**
     * Pre-existing loan/EPP imported half-way: only the opening outstanding and the REMAINING schedule are
     * modelled. Flat with known instalment → equal instalments of [installment] (interest split unknown unless
     * a rate is given); reducing → annuity over the remaining months on the outstanding principal.
     */
    fun importMidTerm(
        openingOutstanding: Money, remainingMonths: Int, nextDue: LocalDate, method: RateMethod,
        annualRatePct: BigDecimal = BigDecimal.ZERO, installment: Money? = null,
    ): List<Installment> = when (method) {
        RateMethod.REDUCING -> reducingSchedule(openingOutstanding, annualRatePct, remainingMonths, nextDue)
        RateMethod.FLAT, RateMethod.NONE -> {
            val parts = if (installment != null && installment.isPositive) {
                List(remainingMonths) { k -> if (k == remainingMonths - 1) openingOutstanding - installment * (remainingMonths - 1) else installment }
            } else openingOutstanding.splitEven(remainingMonths)
            parts.mapIndexed { k, amt -> Installment(k + 1, nextDue.plusMonths(k.toLong()), amt, if (method == RateMethod.NONE) Money.ZERO else null, amt) }
        }
    }

    /** Allocation of a (possibly partial) payment: fees, then interest, then principal. */
    fun allocate(payment: Money, dueFees: Money, dueInterest: Money, duePrincipal: Money): Allocation {
        var left = payment
        val f = left.min(dueFees); left -= f
        val i = left.min(dueInterest); left -= i
        val p = left.min(duePrincipal); left -= p
        return Allocation(f, i, p, left)
    }

    /** Early settlement amount for the not-yet-billed part of a schedule as of [asOf]. */
    fun earlySettlement(schedule: List<Installment>, asOf: LocalDate, policy: EarlySettlementPolicy): Money {
        val rest = schedule.filter { it.dueDate.isAfter(asOf) }
        val remainingPrincipal = Money.sum(rest.map { it.principal })
        return when (policy) {
            EarlySettlementPolicy.REMAINING_PRINCIPAL -> remainingPrincipal
            EarlySettlementPolicy.RULE_OF_78 -> {
                val n = schedule.size.toLong(); val k = rest.size.toLong()
                val totalInterest = Money.sum(schedule.mapNotNull { it.interest })
                val unearnedInterest = totalInterest.times(BigDecimal(k * (k + 1)).divide(BigDecimal(n * (n + 1)), MC))
                Money.sum(rest.map { it.total }) - unearnedInterest
            }
        }
    }

    fun eppProfile(debtId: String, plan: Epp, today: LocalDate, book: LedgerBook?): EppProfile {
        val info = PG.eppInfo(plan, today.toString())
        val principal = Money.fromDouble(info.pokok)
        val first = LocalDate.parse(info.dates.first())
        val schedule = if (plan.kaedah == "baki" || plan.kaedah == "tetap") {
            // jadual daripada PG.eppInfo (sumber tunggal); pecahan tidak diketahui → faedah null
            info.dates.indices.map { k ->
                val amt = Money.fromDouble(info.amountAt(k)); val p = Money.fromDouble(info.pokokAt(k))
                Installment(k + 1, LocalDate.parse(info.dates[k]), p, if (info.pokokTahu) amt - p else null, amt)
            }
        } else flatSchedule(
            principal, BigDecimal.valueOf(plan.kadar), info.tempoh, first,
            fixedInstallment = Money.fromDoubleOrNull(plan.ansuran)?.takeIf { it.isPositive },
            totalInterestOverride = Money.fromDoubleOrNull(plan.faedahJumlah)?.takeIf { !it.isNegative },
        ).mapIndexed { k, i -> i.copy(dueDate = LocalDate.parse(info.dates[k])) } // existing month-end clamping
        val billed = schedule.count { !it.dueDate.isAfter(today) }
        val unbilled = schedule.drop(billed)
        val outPrincipal = book?.let { -(it.balance(PgLedgerAdapter.eppAcc(debtId, plan.id))) } ?: Money.sum(unbilled.map { it.principal })
        return EppProfile(
            debtId, plan.id, plan.nama, principal, BigDecimal.valueOf(plan.kadar), Money.sum(schedule.mapNotNull { it.interest }),
            schedule, billed, schedule.size - billed, outPrincipal, Money.sum(unbilled.mapNotNull { it.interest }), unbilled.firstOrNull()?.dueDate,
        )
    }

    fun profiles(s: PgState, book: LedgerBook, today: LocalDate): List<DebtProfile> {
        val status = PG.debtStatus(s, today.toString()).associateBy { it.id }
        val per = PG.commitmentPeriod(today.toString(), s.settings.komitmenMulaHari.takeIf { it > 0 } ?: 1)
        return s.debts.map { d ->
            val acc = PgLedgerAdapter.debtAcc(d.id)
            val mine = book.effective().filter { it.from == acc || it.to == acc }
            val opening = mine.filter { it.type == EntryType.OPENING_BALANCE }.minByOrNull { it.date }
            val reps = mine.filter { it.type == EntryType.DEBT_REPAYMENT }.sortedBy { it.date }
            val thisPeriod = reps.filter { it.date.toString() >= per.start && it.date.toString() < per.endExcl }
            val min = status[d.id]?.min?.let { Money.fromDouble(it) } ?: Money.ZERO
            val paidNow = Money.sum(thisPeriod.map { it.amount })
            DebtProfile(
                debtId = d.id, creditor = d.nama, kind = PgLedgerAdapter.storageOf(d.jenis),
                annualRatePct = BigDecimal.valueOf(d.kadar),
                method = if (d.kadar > 0) RateMethod.REDUCING else RateMethod.NONE,
                openingOutstanding = opening?.amount, openingDate = opening?.date,
                outstanding = -book.balance(acc),
                interestCharged = Money.sum(mine.filter { it.type == EntryType.CHARGE && it.chargeKind == ChargeKind.INTEREST }.map { it.amount }),
                feesCharged = Money.sum(mine.filter { it.type == EntryType.CHARGE && it.chargeKind == ChargeKind.FEE }.map { it.amount }),
                repayments = reps,
                partialThisPeriod = paidNow.isPositive && paidNow < min,
                epp = d.epp.map { eppProfile(d.id, it, today, book) },
            )
        }
    }

    /** Debt-side (non-cash) events of a liability, separated from cash repayments. */
    fun nonCashEvents(book: LedgerBook, debtAccount: String): List<Entry> =
        book.effective().filter { (it.from == debtAccount || it.to == debtAccount) && it.type != EntryType.DEBT_REPAYMENT }
            .filter { e -> book.accounts[if (e.from == debtAccount) e.to ?: "" else e.from ?: ""]?.kind != AccountKind.ASSET }

    /** Total liabilities (positive number owed) across all debt and EPP accounts. */
    fun totalOwed(book: LedgerBook, asOf: LocalDate? = null): Money {
        val bal = book.balances(asOf)
        return Money.sum(book.accounts.values.filter { it.kind == AccountKind.LIABILITY }.map { -(bal[it.id] ?: Money.ZERO) })
    }
}
