package com.asyraf.hadirku.engine.android

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.util.AtomicFile
import com.asyraf.hadirku.data.Repo
import com.asyraf.hadirku.engine.assistant.FinancialSnapshot
import com.asyraf.hadirku.engine.assistant.SnapshotBuilder
import com.asyraf.hadirku.engine.cashflow.CashFlowEngine
import com.asyraf.hadirku.engine.cashflow.CashFlowReport
import com.asyraf.hadirku.engine.category.CategoryEngine
import com.asyraf.hadirku.engine.core.EngineClock
import com.asyraf.hadirku.engine.core.int
import com.asyraf.hadirku.engine.core.SystemEngineClock
import com.asyraf.hadirku.engine.forecast.ForecastEngine
import com.asyraf.hadirku.engine.forecast.ForecastResult
import com.asyraf.hadirku.engine.forecast.Scenario
import com.asyraf.hadirku.engine.ledger.PgLedgerAdapter
import com.asyraf.hadirku.engine.receipt.ImagePolicy
import com.asyraf.hadirku.engine.risk.RiskAlert
import com.asyraf.hadirku.engine.risk.RiskEngine
import com.asyraf.hadirku.engine.savings.SavingsEngine
import com.asyraf.hadirku.engine.store.EngineStore
import com.asyraf.hadirku.engine.store.TextIo
import com.asyraf.hadirku.pg.PG
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.time.LocalDate

/* =====================================================================
 * Android glue for the engines. Used by the Pusat Kewangan screens (ui/KewanganScreen.kt, ui/EnjinVm.kt),
 * the backup file ("enjin" block) and the daily worker (Peringatan.semakKewangan). It only READS
 * Repo.pg (the existing data) and writes its own `engine.json`.
 * ===================================================================== */

/** engine.json through AtomicFile (same safe-write approach as Repo). Backups sit next to it. */
class AtomicFileTextIo(private val file: File) : TextIo {
    private val af = AtomicFile(file)
    override fun read(): String? = try { if (file.exists()) String(af.readFully(), Charsets.UTF_8) else null } catch (e: Exception) { null }
    override fun write(text: String): Boolean {
        val out = try { af.startWrite() } catch (e: Exception) { return false }
        return try { out.write(text.toByteArray(Charsets.UTF_8)); af.finishWrite(out); true } catch (e: Exception) { af.failWrite(out); false }
    }
    override fun backup(tag: String, text: String): Boolean = try {
        File(file.parentFile, file.name + ".bak-" + tag.replace(Regex("[^A-Za-z0-9._-]"), "_")).writeText(text, Charsets.UTF_8); true
    } catch (e: Exception) { false }
}

object EngineHub {
    @Volatile private var store: EngineStore? = null
    var clock: EngineClock = SystemEngineClock

    fun store(ctx: Context): EngineStore = store ?: synchronized(this) {
        store ?: EngineStore(AtomicFileTextIo(File(ctx.applicationContext.filesDir, "engine.json")), clock).also { store = it }
    }

    private fun today(): LocalDate = clock.today()

    /** Ledger projected from the CURRENT existing data. Read-only. */
    fun ledger(today: LocalDate = today()): PgLedgerAdapter.Result = PgLedgerAdapter.build(Repo.pg.value, today)

    fun cashFlow(ctx: Context, today: LocalDate = today()): CashFlowReport {
        val s = Repo.pg.value
        val book = ledger(today).book
        val d = store(ctx).load().data
        val goals = d.goals + SavingsEngine.goalsFromPockets(s, today)
        val earmarked = SavingsEngine.totalEarmarked(SavingsEngine.progress(goals, d.goalMoves, book, today, null))
        return CashFlowEngine.report(s, book, today, earmarked = earmarked)
    }

    fun forecast(scenario: Scenario = Scenario.BASE, days: Int = 90, today: LocalDate = today()): ForecastResult =
        ForecastEngine.project(Repo.pg.value, ledger(today).book, today, days, scenario)

    fun risks(ctx: Context, today: LocalDate = today()): List<RiskAlert> {
        val s = Repo.pg.value
        val book = ledger(today).book
        val d = store(ctx).load().data
        val goals = d.goals + SavingsEngine.goalsFromPockets(s, today)
        val reserve = SavingsEngine.totalEarmarked(SavingsEngine.progress(goals, d.goalMoves, book, today, null))
        val f = ForecastEngine.project(s, book, today, 45, Scenario.CONSERVATIVE)
        return RiskEngine.evaluate(RiskEngine.inputFrom(s, book, today, f, reserve, reserve))
    }

    fun categories(ctx: Context): CategoryEngine {
        val d = store(ctx).load().data
        return CategoryEngine(d.categoryOverrides, d.categoryRules, PG.kategoriSejarah(Repo.pg.value))
    }

    /** engine.json semasa (untuk dimasukkan ke dalam fail salinan sebagai blok "enjin"). Null jika tiada data. */
    fun exportBlock(ctx: Context): String? {
        val r = store(ctx).load()
        val d = r.data
        if (d.budgets.isEmpty() && d.goals.isEmpty() && d.goalMoves.isEmpty() && d.categoryRules.isEmpty() &&
            d.categoryOverrides.isEmpty() && d.importKeys.isEmpty() && d.knownReceipts.isEmpty()) return null
        return com.asyraf.hadirku.engine.store.EngineCodec.encode(d)
    }

    /**
     * Pulihkan blok "enjin" daripada fail salinan. Fail lama (tiada blok) tidak memanggil fungsi ini,
     * jadi bajet/matlamat sedia ada kekal. Versi lebih baru daripada app ini → ditolak (false).
     */
    fun importBlock(ctx: Context, json: String): Boolean {
        val map = try { com.asyraf.hadirku.engine.core.MiniJson.parseObject(json) } catch (e: Exception) { return false }
        val ver = map.int("version") ?: 0
        if (ver > EngineStore.CURRENT_VERSION) return false
        val d = com.asyraf.hadirku.engine.store.EngineCodec.decode(
            if (ver < EngineStore.CURRENT_VERSION) com.asyraf.hadirku.engine.store.Migrations.toCurrent(map, ver) else map,
        )
        // simpan salinan engine.json semasa dahulu (boleh dipulihkan manual)
        val io = AtomicFileTextIo(File(ctx.applicationContext.filesDir, "engine.json"))
        io.read()?.let { io.backup("sebelum-pulih-" + today(), it) }
        return store(ctx).update { cur -> d.copy(notificationsSent = cur.notificationsSent + d.notificationsSent) }
    }

    fun snapshot(today: LocalDate = today()): FinancialSnapshot {
        val s = Repo.pg.value
        val book = ledger(today).book
        return SnapshotBuilder.build(s, book, today, ForecastEngine.project(s, book, today, 60, Scenario.BASE))
    }
}

/**
 * Receipt image preparation before any upload: EXIF rotation, downscale to [ImagePolicy.maxDimension],
 * JPEG re-compression under [ImagePolicy.maxBytes]. PDFs pass through only if small enough.
 * Returns null when the file cannot be made acceptable.
 */
object ReceiptImagePrep {
    fun prepare(bytes: ByteArray, mime: String, policy: ImagePolicy = ImagePolicy()): Pair<ByteArray, String>? {
        if (mime == "application/pdf") return if (bytes.size in 1..policy.maxBytes) bytes to mime else null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= policy.maxDimension) sample *= 2
        val src = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return null
        val rot = try {
            when (ExifInterface(ByteArrayInputStream(bytes)).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f; ExifInterface.ORIENTATION_ROTATE_180 -> 180f; ExifInterface.ORIENTATION_ROTATE_270 -> 270f; else -> 0f
            }
        } catch (e: Exception) { 0f }
        val scale = minOf(1f, policy.maxDimension.toFloat() / maxOf(src.width, src.height))
        val m = Matrix().apply { if (scale < 1f) postScale(scale, scale); if (rot != 0f) postRotate(rot) }
        val out = if (scale < 1f || rot != 0f) Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true) else src
        for (q in listOf(85, 70, 55)) {
            val bos = ByteArrayOutputStream()
            out.compress(Bitmap.CompressFormat.JPEG, q, bos)
            if (bos.size() <= policy.maxBytes) return bos.toByteArray() to "image/jpeg"
        }
        return null
    }
}
