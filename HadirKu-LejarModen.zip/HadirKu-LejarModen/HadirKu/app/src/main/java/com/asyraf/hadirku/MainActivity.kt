package com.asyraf.hadirku

import android.app.Application
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.fragment.app.FragmentActivity
import com.asyraf.hadirku.data.Repo
import com.asyraf.hadirku.logic.Logic
import com.asyraf.hadirku.logic.ShiftType
import com.asyraf.hadirku.system.Cleanup
import android.content.Intent
import com.asyraf.hadirku.kongsi.Kongsi
import com.asyraf.hadirku.kongsi.Status
import com.asyraf.hadirku.rumah.Peringatan
import com.asyraf.hadirku.ui.HadirApp
import com.asyraf.hadirku.ui.PgTheme

class HadirKuApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        Repo.init(this)
        com.asyraf.hadirku.i18n.Bahasa.init(this)
        com.asyraf.hadirku.system.Jaga.mula(this)
        Cleanup.lama(this)
        Peringatan.saluran(this)
        Peringatan.pasang(this)
    }
}

class MainActivity : FragmentActivity() {
    private val vm: MainViewModel by viewModels()
    /** true = skrin laporan ranap sedang dipapar (Compose & ViewModel tidak disentuh langsung). */
    private var selamat = false

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        Repo.init(this)
        // App tertutup sebab ralat pada bukaan lepas → tunjuk laporan dengan View biasa dulu,
        // supaya laporan boleh disalin walaupun ralat berlaku pada skrin pertama Compose.
        val ranap = com.asyraf.hadirku.system.Jaga.ranapBaru(this)
        if (ranap != null) { skrinRanap(ranap); return }
        setContent {
            val s by vm.settings.collectAsState()
            val now by vm.now.collectAsState()
            val systemDark = isSystemInDarkTheme()
            val dark = when (s.themeMode) {
                1 -> false
                2 -> true
                3 -> Logic.shiftType(Logic.today(now), s) == ShiftType.MALAM
                else -> systemDark
            }
            val view = LocalView.current
            SideEffect {
                // ikon bar status diurus HadirApp (putih di atas ilustrasi Utama, gelap di skrin lain)
                val controller = WindowCompat.getInsetsController(window, view)
                controller.isAppearanceLightNavigationBars = !dark
            }
            PgTheme(dark = dark, saiz = vm.saiz) {
                // tukar bahasa → bina semula seluruh paparan supaya semua teks & tarikh ikut bahasa baru
                androidx.compose.runtime.key(vm.bahasa) {
                    HadirApp(vm, this@MainActivity)
                }
            }
        }
        if (savedInstanceState == null) vm.bukaDari(intent?.getStringExtra(Peringatan.EXTRA_BUKA))
    }

    /** Notifikasi bil ditekan semasa app sudah terbuka. */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (selamat) return
        vm.bukaDari(intent.getStringExtra(Peringatan.EXTRA_BUKA))
    }

    /** Skrin ringkas (Android View, bukan Compose): laporan ranap + Salin / Kongsi / Buka app. */
    private fun skrinRanap(lapor: String) {
        selamat = true
        val tr = com.asyraf.hadirku.i18n.Bahasa::t
        val dp = resources.displayMetrics.density
        val pad = (16 * dp).toInt()
        val malam = (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES
        val bg = if (malam) 0xFF0F1A17.toInt() else 0xFFF3F6F4.toInt()
        val ink = if (malam) 0xFFE6EFEB.toInt() else 0xFF15302A.toInt()
        val muted = if (malam) 0xFF9FB3AC.toInt() else 0xFF5B6E68.toInt()
        val kotak = if (malam) 0xFF16241F.toInt() else 0xFFFFFFFF.toInt()
        val luar = android.widget.FrameLayout(this).apply { fitsSystemWindows = true; setBackgroundColor(bg) }
        val root = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        root.addView(android.widget.TextView(this).apply {
            text = tr("Duitku tertutup sebab ralat"); textSize = 20f; setTextColor(ink)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        root.addView(android.widget.TextView(this).apply {
            text = tr("Salin laporan di bawah dan hantar kepada Claude supaya punca boleh dibaiki. Lepas itu tekan Buka app.")
            textSize = 14f; setTextColor(muted); setPadding(0, pad / 2, 0, pad / 2)
        })
        val isi = android.widget.TextView(this).apply {
            text = lapor; textSize = 11f; setTextColor(ink); typeface = android.graphics.Typeface.MONOSPACE
            setTextIsSelectable(true); setPadding(pad / 2, pad / 2, pad / 2, pad / 2)
        }
        root.addView(android.widget.ScrollView(this).apply { setBackgroundColor(kotak); addView(isi) },
            android.widget.LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        val baris = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL; setPadding(0, pad / 2, 0, 0)
        }
        fun butang(t: String, f: () -> Unit) = android.widget.Button(this).apply {
            text = tr(t); isAllCaps = false; setOnClickListener { f() }
        }
        val lp = { android.widget.LinearLayout.LayoutParams(0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f) }
        baris.addView(butang("Salin laporan") {
            val cm = getSystemService(android.content.ClipboardManager::class.java)
            cm?.setPrimaryClip(android.content.ClipData.newPlainText("Laporan Duitku", lapor))
            android.widget.Toast.makeText(this, tr("Laporan disalin"), android.widget.Toast.LENGTH_SHORT).show()
        }, lp())
        baris.addView(butang("Kongsi") {
            try {
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, lapor), null))
            } catch (_: Exception) { }
        }, lp())
        baris.addView(butang("Buka app") {
            com.asyraf.hadirku.system.Jaga.lepasRanap(this)
            recreate()
        }, lp())
        root.addView(baris)
        luar.addView(root)
        setContentView(luar)
    }

    override fun onStop() {
        super.onStop()
        // pastikan data terkini sudah ditulis ke pg.json sebelum app mungkin ditutup oleh sistem
        com.asyraf.hadirku.data.Repo.flushPg()
    }

    override fun onResume() {
        super.onResume()
        if (selamat) return
        vm.tick()
        vm.semakJaga()
        if (Kongsi.status.value == Status.RALAT) Kongsi.cubaLagi()
    }
}
