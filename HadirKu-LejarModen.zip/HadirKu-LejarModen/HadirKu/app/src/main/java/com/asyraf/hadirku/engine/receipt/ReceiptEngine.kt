package com.asyraf.hadirku.engine.receipt

import com.asyraf.hadirku.engine.core.Dates
import com.asyraf.hadirku.engine.core.Money
import com.asyraf.hadirku.engine.ledger.Entry
import com.asyraf.hadirku.engine.ledger.EntryType
import com.asyraf.hadirku.engine.ledger.LedgerBook
import com.asyraf.hadirku.pg.PG
import java.security.MessageDigest
import java.time.LocalDate

/* =====================================================================
 * Engine 1 — Receipt Intelligence: deterministic checks, duplicates, drafts
 * AI output is never trusted for money: totals are recomputed and discrepancies are FLAGGED, never
 * corrected. Duplicates are reported, never deleted. A receipt becomes a ledger entry only through
 * [ReceiptEngine.confirm] (explicit user confirmation) with an idempotency key.
 * ===================================================================== */

enum class CheckCode {
    TOTAL_MISSING, DATE_MISSING, MERCHANT_MISSING, CURRENCY_NOT_MYR,
    ITEMS_SUBTOTAL_MISMATCH, ITEM_LINE_MISMATCH, TOTAL_MISMATCH, NEGATIVE_TOTAL, FUTURE_DATE,
}

data class CheckFlag(val code: CheckCode, val expected: Money? = null, val claimed: Money? = null, val ref: String? = null)

data class Verification(val flags: List<CheckFlag>, val uncertainFields: List<String>) {
    val consistent: Boolean get() = flags.none { it.code in MISMATCH }
    companion object { val MISMATCH = setOf(CheckCode.ITEMS_SUBTOTAL_MISMATCH, CheckCode.ITEM_LINE_MISMATCH, CheckCode.TOTAL_MISMATCH) }
}

enum class DuplicateKind { SAME_RECEIPT_ID, FUZZY_RECEIPT, LEDGER_ENTRY }
data class DuplicateCandidate(val kind: DuplicateKind, val refId: String, val score: Int)

/** A receipt already known to the app (previous drafts/confirmed receipts). */
data class KnownReceipt(val id: String, val merchant: String?, val date: LocalDate?, val total: Money?, val receiptId: String?, val itemNames: List<String> = emptyList())

enum class DraftStatus { READY_FOR_REVIEW, NEEDS_REVIEW, DUPLICATE_SUSPECTED, UNREADABLE }
enum class ImageRetention { DISCARD, KEEP_WITH_CONSENT }

data class ReceiptDraft(
    val id: String,
    val data: ReceiptData,
    val verification: Verification,
    val duplicates: List<DuplicateCandidate>,
    val status: DraftStatus,
    val idempotencyKey: String?,
    val imageRetention: ImageRetention,
)

/** What the user confirmed in the existing review flow. Values the user typed win over the AI's. */
data class ReceiptConfirmation(
    val accountId: String,
    val amount: Money? = null,
    val date: LocalDate? = null,
    val category: String? = null,
    val memo: String? = null,
)

/** Upload limits applied before anything is sent anywhere. */
data class ImagePolicy(
    val maxBytes: Int = 4_000_000,
    val maxDimension: Int = 1600,
    val allowedMime: Set<String> = setOf("image/jpeg", "image/png", "image/webp", "application/pdf"),
)

enum class UploadIssue { EMPTY, TOO_LARGE, UNSUPPORTED_TYPE }

object ReceiptEngine {

    fun validateUpload(mime: String, size: Int, policy: ImagePolicy = ImagePolicy()): List<UploadIssue> = buildList {
        if (size <= 0) add(UploadIssue.EMPTY)
        if (size > policy.maxBytes) add(UploadIssue.TOO_LARGE)
        if (mime.lowercase() !in policy.allowedMime) add(UploadIssue.UNSUPPORTED_TYPE)
    }

    /** Deterministic recomputation. One sen tolerance per line for unit-price rounding. */
    fun verify(d: ReceiptData, today: LocalDate? = null): Verification {
        val f = ArrayList<CheckFlag>()
        val total = d.total.value
        if (total == null) f += CheckFlag(CheckCode.TOTAL_MISSING) else if (total.isNegative) f += CheckFlag(CheckCode.NEGATIVE_TOTAL, claimed = total)
        if (d.date.value == null) f += CheckFlag(CheckCode.DATE_MISSING)
        else if (today != null && d.date.value.isAfter(today.plusDays(1))) f += CheckFlag(CheckCode.FUTURE_DATE)
        if (d.merchant.value == null) f += CheckFlag(CheckCode.MERCHANT_MISSING)
        d.currency.value?.let { if (!it.equals("MYR", true) && !it.equals("RM", true)) f += CheckFlag(CheckCode.CURRENCY_NOT_MYR) }

        d.items.forEachIndexed { i, it ->
            val q = it.quantity.value; val u = it.unitPrice.value; val lt = it.lineTotal.value
            if (q != null && u != null && lt != null) {
                val exp = u.times(q)
                if ((exp - lt).abs() > Money(1)) f += CheckFlag(CheckCode.ITEM_LINE_MISMATCH, exp, lt, "items[$i]")
            }
        }
        val lines = d.items.mapNotNull { it.lineTotal.value }
        val sub = d.subtotal.value
        if (sub != null && lines.isNotEmpty() && lines.size == d.items.size) {
            val s = Money.sum(lines)
            if (s != sub) f += CheckFlag(CheckCode.ITEMS_SUBTOTAL_MISMATCH, s, sub)
        }
        // total = subtotal − discount + service + tax + rounding (absent components count as 0 only when subtotal exists)
        if (sub != null && total != null) {
            val exp = sub - (d.discount.value ?: Money.ZERO) + (d.serviceCharge.value ?: Money.ZERO) + (d.tax.value ?: Money.ZERO) + (d.rounding.value ?: Money.ZERO)
            if (exp != total) f += CheckFlag(CheckCode.TOTAL_MISMATCH, exp, total)
        }
        val uncertain = buildList {
            listOf("merchant" to d.merchant, "date" to d.date, "total" to d.total, "subtotal" to d.subtotal, "receipt_id" to d.receiptId)
                .forEach { (n, x) -> if (x.present && x.uncertain) add(n) }
            d.items.forEachIndexed { i, it -> if (it.lineTotal.present && it.lineTotal.uncertain) add("items[$i].line_total") }
        }
        return Verification(f, uncertain)
    }

    fun idempotencyKey(d: ReceiptData): String? {
        val rid = d.receiptId.value?.let { normId(it) }?.takeIf { it.length >= 4 }
        val m = d.merchant.value?.let { PG.normNama(it) }
        if (rid != null) return "receipt:id:" + sha((m ?: "") + "|" + rid)
        val date = d.date.value ?: return null
        val total = d.total.value ?: return null
        return "receipt:fp:" + sha((m ?: "") + "|" + date + "|" + total.sen)
    }

    fun duplicates(d: ReceiptData, known: List<KnownReceipt>, book: LedgerBook?): List<DuplicateCandidate> {
        val out = ArrayList<DuplicateCandidate>()
        val m = d.merchant.value?.let { PG.normNama(it) }.orEmpty()
        val rid = d.receiptId.value?.let { normId(it) }
        for (k in known) {
            val km = k.merchant?.let { PG.normNama(it) }.orEmpty()
            val sameMerchant = m.isNotEmpty() && km.isNotEmpty() && (m == km || m.contains(km) || km.contains(m))
            if (rid != null && rid.length >= 4 && k.receiptId?.let { normId(it) } == rid && (sameMerchant || m.isEmpty() || km.isEmpty())) {
                out += DuplicateCandidate(DuplicateKind.SAME_RECEIPT_ID, k.id, 100); continue
            }
            val d0 = d.date.value; val t0 = d.total.value
            if (sameMerchant && d0 != null && k.date != null && t0 != null && t0 == k.total && kotlin.math.abs(Dates.daysBetween(d0, k.date)) <= 1) {
                val names = d.items.mapNotNull { it.name.value?.lowercase() }.toSet()
                val overlap = if (names.isEmpty() || k.itemNames.isEmpty()) 0 else names.intersect(k.itemNames.map { it.lowercase() }.toSet()).size * 20 / names.size
                out += DuplicateCandidate(DuplicateKind.FUZZY_RECEIPT, k.id, (80 + overlap).coerceAtMost(99))
            }
        }
        if (book != null) {
            val d0 = d.date.value; val t0 = d.total.value
            if (d0 != null && t0 != null) book.effective().filter {
                it.type == EntryType.EXPENSE && it.amount == t0 && kotlin.math.abs(Dates.daysBetween(it.date, d0)) <= 1 &&
                    (m.isEmpty() || PG.normNama(it.memo).let { e -> e.isNotEmpty() && (e.contains(m) || m.contains(e)) })
            }.forEach { out += DuplicateCandidate(DuplicateKind.LEDGER_ENTRY, it.id, 70) }
        }
        return out
    }

    /** Build a reviewable draft. Never saves anything. */
    fun draft(
        id: String, d: ReceiptData, known: List<KnownReceipt>, book: LedgerBook?, today: LocalDate,
        retention: ImageRetention = ImageRetention.DISCARD,
    ): ReceiptDraft {
        val v = verify(d, today)
        val dup = duplicates(d, known, book)
        val unreadable = d.total.value == null && d.merchant.value == null && d.items.isEmpty()
        val status = when {
            unreadable -> DraftStatus.UNREADABLE
            dup.isNotEmpty() -> DraftStatus.DUPLICATE_SUSPECTED
            !v.consistent || v.uncertainFields.isNotEmpty() || v.flags.isNotEmpty() -> DraftStatus.NEEDS_REVIEW
            else -> DraftStatus.READY_FOR_REVIEW
        }
        return ReceiptDraft(id, d, v, dup, status, idempotencyKey(d), retention)
    }

    /**
     * The only way a receipt reaches the ledger: an explicit confirmation. The returned entry must be posted
     * with [ReceiptDraft.idempotencyKey] so a second import of the same receipt is a no-op.
     * Returns null when the amount or date is still unknown (the user must type them).
     */
    fun confirm(draft: ReceiptDraft, c: ReceiptConfirmation, entryId: String): Entry? {
        val amount = c.amount ?: draft.data.total.value ?: return null
        val date = c.date ?: draft.data.date.value ?: return null
        if (!amount.isPositive) return null
        return Entry(
            id = entryId, date = date, type = EntryType.EXPENSE, amount = amount, from = c.accountId,
            category = c.category, memo = c.memo ?: draft.data.merchant.value.orEmpty(), sourceId = "receipt:" + draft.id,
        )
    }

    private fun normId(s: String) = s.uppercase().replace(Regex("[^A-Z0-9]"), "")
    private fun sha(s: String) = MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }.take(32)
}
