package com.asyraf.hadirku.logic

import com.asyraf.hadirku.data.AppSettings
import com.asyraf.hadirku.data.DayRecord
import com.asyraf.hadirku.data.RecordStatus
import com.asyraf.hadirku.pg.Gaji
import com.asyraf.hadirku.pg.OtCycle
import com.asyraf.hadirku.pg.OtEntry
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.PgSettings
import com.asyraf.hadirku.pg.PgState
import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

enum class ShiftType { PAGI, MALAM }
enum class DayKind { KERJA, OFF_DAY, REST_DAY, CUTI_UMUM }
enum class Outcome { TEPAT, LEWAT, TIDAK_HADIR, CUTI, MC, CUTI_UMUM, HUJUNG_MINGGU, KERJA_LEBIH, BELUM, AKAN_DATANG, TIADA_DATA }

/** Tetapan kehadiran + tetapan gaji PoketGaji (jam normal & hari mula kitaran OT datang dari PoketGaji). */
class Cfg(val s: AppSettings, val g: PgSettings) {
    val jamNormal: Double get() = if (g.gaji.jamNormal > 0) g.gaji.jamNormal else 9.0
    val otMula: Int get() = g.otMulaHari.coerceIn(1, 28)
    val gaji: Gaji get() = g.gaji
}

/** Jam OT ikut kadar PoketGaji: 1.5x, 2.0x, 3.0x. */
data class OtJam(val h15: Double = 0.0, val h20: Double = 0.0, val h30: Double = 0.0) {
    val total: Double get() = h15 + h20 + h30
    operator fun plus(o: OtJam) = OtJam(h15 + o.h15, h20 + o.h20, h30 + o.h30)
    fun nilai(g: Gaji): Double = (h15 * 1.5 + h20 * 2 + h30 * 3) * PG.hrp(g)
}

data class DayEval(
    val date: LocalDate,
    val kind: DayKind,
    val shift: ShiftType,
    val record: DayRecord?,
    val outcome: Outcome,
    val lateMinutes: Int,
    /** Minit tiba sebelum shift mula (positif = awal, negatif = lewat). Null kalau tiada. */
    val arrivalDelta: Int?,
    val workedMinutes: Int,
    val ot: OtJam,
)

data class PeriodSummary(
    val scheduled: Int = 0,
    val attended: Int = 0,
    val onTime: Int = 0,
    val late: Int = 0,
    val lateMinutes: Int = 0,
    val absent: Int = 0,
    val cuti: Int = 0,
    val mc: Int = 0,
    val holidays: Int = 0,
    val extraDays: Int = 0,
    val pending: Int = 0,
    val ot: OtJam = OtJam(),
    val workedMinutes: Int = 0,
    val avgArrival: Int? = null,
    val earlyDays: Int = 0,
    val score: Int = 100,
    val grade: String = "–",
) {
    val onTimeRate: Int? get() = if (onTime + late > 0) (onTime * 100) / (onTime + late) else null
}

data class Streaks(val attend: Int = 0, val onTime: Int = 0, val bestAttend: Int = 0, val bestOnTime: Int = 0)

data class Achievement(
    val id: String,
    val title: String,
    val desc: String,
    val progress: Int,
    val target: Int,
) {
    val unlocked: Boolean get() = progress >= target
}

object Logic {
    private const val MIN = 60_000L
    private const val HOUR = 3_600_000L

    fun zone(): ZoneId = ZoneId.systemDefault()

    fun today(nowMs: Long, zone: ZoneId = zone()): LocalDate = Instant.ofEpochMilli(nowMs).atZone(zone).toLocalDate()

    fun iso(d: LocalDate): String = PG.iso(d.year, d.monthValue, d.dayOfMonth)
    fun date(iso: String): LocalDate { val p = PG.parse(iso); return LocalDate.of(p.y, p.m, p.d) }

    // ---------------- Jadual ----------------

    fun shiftType(date: LocalDate, s: AppSettings): ShiftType {
        val weeks = ChronoUnit.WEEKS.between(s.rotationAnchor.with(DayOfWeek.MONDAY), date.with(DayOfWeek.MONDAY))
        val block = Math.floorDiv(weeks, s.weeksPerBlock.coerceAtLeast(1).toLong())
        return if (Math.floorMod(block, 2L) == 0L) ShiftType.PAGI else ShiftType.MALAM
    }

    /** Minggu ke berapa dalam blok semasa (bermula 1). */
    fun weekInBlock(date: LocalDate, s: AppSettings): Int {
        val weeks = ChronoUnit.WEEKS.between(s.rotationAnchor.with(DayOfWeek.MONDAY), date.with(DayOfWeek.MONDAY))
        return (Math.floorMod(weeks, s.weeksPerBlock.coerceAtLeast(1).toLong()) + 1L).toInt()
    }

    /** Kira tarikh rujukan putaran daripada "minggu ini shift apa, minggu ke berapa". */
    fun anchorFor(today: LocalDate, pagiNow: Boolean, weekInBlock: Int, weeksPerBlock: Int): LocalDate {
        val monday = today.with(DayOfWeek.MONDAY)
        val offset = (weekInBlock - 1).coerceAtLeast(0) + if (pagiNow) 0 else weeksPerBlock.coerceAtLeast(1)
        return monday.minusWeeks(offset.toLong())
    }

    fun dayKind(date: LocalDate, s: AppSettings): DayKind = when {
        date in s.holidays -> DayKind.CUTI_UMUM
        date.dayOfWeek.value in s.workDays -> DayKind.KERJA
        date.dayOfWeek.value == s.restDay -> DayKind.REST_DAY
        else -> DayKind.OFF_DAY
    }

    /** Jenis hari PoketGaji (log OT) untuk satu tarikh ikut jadual shift. */
    fun jenisHari(kind: DayKind): String = when (kind) {
        DayKind.KERJA -> "biasa"
        DayKind.OFF_DAY -> "off"
        DayKind.REST_DAY -> "rest"
        DayKind.CUTI_UMUM -> "umum"
    }

    fun shiftStartMinutes(date: LocalDate, s: AppSettings): Int =
        if (shiftType(date, s) == ShiftType.PAGI) s.morningStart else s.nightStart

    fun shiftStartMs(date: LocalDate, s: AppSettings, zone: ZoneId = zone()): Long =
        date.atStartOfDay(zone).plusMinutes(shiftStartMinutes(date, s).toLong()).toInstant().toEpochMilli()

    fun shiftLengthMs(c: Cfg): Long = (c.jamNormal * 60).toLong() * MIN

    /** Cari hari kerja seterusnya yang (mula shift + offset) masih selepas sekarang. */
    fun nextWorkStart(s: AppSettings, nowMs: Long, offsetMs: Long, zone: ZoneId = zone()): Pair<LocalDate, Long>? {
        val today = today(nowMs, zone)
        for (i in 0..21) {
            val d = today.plusDays(i.toLong())
            if (dayKind(d, s) != DayKind.KERJA) continue
            val st = shiftStartMs(d, s, zone)
            if (st + offsetMs > nowMs) return d to st
        }
        return null
    }

    // ---------------- Jam kerja → log OT PoketGaji ----------------

    /** Jam di tempat kerja (masuk sampai keluar, termasuk rehat), dibundar ke bawah ikut tetapan. */
    fun jamKerja(workedMin: Int, rounding: Int): Double {
        if (workedMin <= 0) return 0.0
        val step = rounding.coerceIn(1, 60)
        val m = (workedMin / step) * step
        return floor(m / 60.0 * 100 + 1e-9) / 100
    }

    fun otJam(kind: DayKind, workedMin: Int, c: Cfg): OtJam {
        if (workedMin <= 0) return OtJam()
        val h = PG.otHours(OtEntry(jenisHari(kind), jamKerja(workedMin, c.s.otRounding)), c.jamNormal)
        return OtJam(h.h15, h.h20, h.h30)
    }

    /** Entri log OT yang sepadan dengan rekod kehadiran, atau null kalau rekod belum lengkap. */
    fun otEntryFor(rec: DayRecord, s: AppSettings): OtEntry? {
        if (rec.status != RecordStatus.HADIR) return OtEntry("tidak")
        val i = rec.checkIn ?: return null
        val o = rec.checkOut ?: return null
        if (o <= i) return null
        val worked = ((o - i) / MIN).toInt()
        return OtEntry(jenisHari(dayKind(rec.date, s)), jamKerja(worked, s.otRounding))
    }

    // ---------------- Penilaian hari ----------------

    fun evaluate(date: LocalDate, rec: DayRecord?, c: Cfg, nowMs: Long, zone: ZoneId = zone()): DayEval {
        val s = c.s
        val kind = dayKind(date, s)
        val shift = shiftType(date, s)
        val start = shiftStartMs(date, s, zone)
        val end = start + shiftLengthMs(c)

        if (rec != null && rec.status != RecordStatus.HADIR) {
            val o = if (rec.status == RecordStatus.CUTI) Outcome.CUTI else Outcome.MC
            return DayEval(date, kind, shift, rec, o, 0, null, 0, OtJam())
        }
        if (rec != null && rec.checkIn != null) {
            val inMs: Long = rec.checkIn
            val outMs: Long? = rec.checkOut
            val worked = if (outMs != null && outMs > inMs) ((outMs - inMs) / MIN).toInt() else 0
            val ot = if (outMs != null) otJam(kind, worked, c) else OtJam()
            return if (kind == DayKind.KERJA) {
                val diff = ((inMs - start) / MIN).toInt()
                val late = inMs > start + s.graceMinutes * MIN
                DayEval(date, kind, shift, rec, if (late) Outcome.LEWAT else Outcome.TEPAT,
                    if (late) max(diff, 1) else 0, -diff, worked, ot)
            } else {
                DayEval(date, kind, shift, rec, Outcome.KERJA_LEBIH, 0, null, worked, ot)
            }
        }
        val tracking = s.trackingStart
        val o = if (tracking != null && date.isBefore(tracking)) {
            Outcome.TIADA_DATA
        } else when (kind) {
            DayKind.CUTI_UMUM -> Outcome.CUTI_UMUM
            DayKind.OFF_DAY, DayKind.REST_DAY -> Outcome.HUJUNG_MINGGU
            DayKind.KERJA -> when {
                nowMs < start + s.graceMinutes * MIN -> Outcome.AKAN_DATANG
                nowMs < end -> Outcome.BELUM
                else -> Outcome.TIDAK_HADIR
            }
        }
        return DayEval(date, kind, shift, null, o, 0, null, 0, OtJam())
    }

    fun evalRange(
        from: LocalDate, to: LocalDate, records: Map<LocalDate, DayRecord>,
        c: Cfg, nowMs: Long, zone: ZoneId = zone(),
    ): List<DayEval> {
        val out = ArrayList<DayEval>()
        var d = from
        while (!d.isAfter(to)) {
            out.add(evaluate(d, records[d], c, nowMs, zone))
            d = d.plusDays(1)
        }
        return out
    }

    // ---------------- Kitaran (sama dengan kitaran OT PoketGaji) ----------------

    fun cycleOf(date: LocalDate, c: Cfg): OtCycle = PG.otCycleOf(iso(date), c.otMula)
    fun cycleStart(cy: OtCycle): LocalDate = date(cy.start)
    fun cycleEnd(cy: OtCycle): LocalDate = date(cy.end)
    fun cycleLabel(cy: OtCycle): String = PG.fmtShort(cy.start) + " – " + PG.fmtShort(cy.end)

    // ---------------- Ringkasan & skor ----------------

    fun gradeFor(score: Int): String = when {
        score >= 95 -> "A+"
        score >= 90 -> "A"
        score >= 85 -> "A−"
        score >= 80 -> "B+"
        score >= 75 -> "B"
        score >= 70 -> "B−"
        score >= 60 -> "C"
        score >= 50 -> "D"
        else -> "E"
    }

    fun summarize(evals: List<DayEval>): PeriodSummary {
        var scheduled = 0; var attended = 0; var onTime = 0; var late = 0; var lateMin = 0
        var absent = 0; var cuti = 0; var mc = 0; var hol = 0; var extra = 0; var pending = 0
        var ot = OtJam(); var worked = 0; var early = 0
        val deltas = ArrayList<Int>()
        for (e in evals) {
            when (e.outcome) {
                Outcome.TEPAT -> { scheduled++; attended++; onTime++ }
                Outcome.LEWAT -> { scheduled++; attended++; late++; lateMin += e.lateMinutes }
                Outcome.TIDAK_HADIR -> { scheduled++; absent++ }
                Outcome.CUTI -> cuti++
                Outcome.MC -> mc++
                Outcome.CUTI_UMUM -> hol++
                Outcome.KERJA_LEBIH -> extra++
                Outcome.BELUM -> pending++
                else -> {}
            }
            ot += e.ot
            worked += e.workedMinutes
            val dl = e.arrivalDelta
            if (dl != null) { deltas.add(dl); if (dl >= 15) early++ }
        }
        val hasData = scheduled + cuti + mc + extra > 0
        val score = (100 - absent * 15 - late * 5 - max(0, mc - 1) * 3).coerceIn(0, 100)
        return PeriodSummary(
            scheduled, attended, onTime, late, lateMin, absent, cuti, mc, hol, extra, pending,
            ot, worked, if (deltas.isEmpty()) null else deltas.sum() / deltas.size, early,
            score, if (hasData) gradeFor(score) else "–",
        )
    }

    fun trackingStartOf(records: Map<LocalDate, DayRecord>, s: AppSettings): LocalDate? {
        val firstRecord = records.keys.minByOrNull { it.toEpochDay() }
        val t = s.trackingStart
        return when {
            firstRecord == null -> t
            t == null -> firstRecord
            firstRecord.isBefore(t) -> firstRecord
            else -> t
        }
    }

    fun streaks(records: Map<LocalDate, DayRecord>, c: Cfg, nowMs: Long, zone: ZoneId = zone()): Streaks {
        val first = trackingStartOf(records, c.s) ?: return Streaks()
        val today = today(nowMs, zone)
        var a = 0; var t = 0; var ba = 0; var bt = 0
        var d = first
        while (!d.isAfter(today)) {
            when (evaluate(d, records[d], c, nowMs, zone).outcome) {
                Outcome.TEPAT -> { a++; t++ }
                Outcome.LEWAT -> { a++; t = 0 }
                Outcome.TIDAK_HADIR -> { a = 0; t = 0 }
                else -> {}
            }
            ba = max(ba, a); bt = max(bt, t)
            d = d.plusDays(1)
        }
        return Streaks(a, t, ba, bt)
    }

    // ---------------- Pencapaian ----------------

    fun achievements(records: Map<LocalDate, DayRecord>, c: Cfg, pg: PgState, nowMs: Long, zone: ZoneId = zone()): List<Achievement> {
        val st = streaks(records, c, nowMs, zone)
        val checkIns = records.values.count { it.checkIn != null }
        val journal = records.values.count { it.mood > 0 || it.note.isNotBlank() }
        val today = today(nowMs, zone)
        var maxOt = 0.0; var perfect = 0; var gradeA = 0; var early = 0
        // OT terbanyak satu kitaran: ikut log OT PoketGaji (termasuk OT yang direkod sebelum guna HadirKu)
        val otDates = pg.ot.keys.sorted()
        if (otDates.isNotEmpty()) {
            var cy = PG.otCycleOf(otDates.first(), c.otMula)
            var guard = 0
            while (cy.start <= iso(today) && guard < 240) {
                val sm = PG.otSummary(pg, cy)
                maxOt = max(maxOt, sm.h15 + sm.h20 + sm.h30)
                cy = PG.shiftCycle(cy, 1, c.otMula)
                guard++
            }
        }
        val first = trackingStartOf(records, c.s)
        if (first != null) {
            var cy = cycleOf(first, c)
            var guard = 0
            while (!cycleStart(cy).isAfter(today) && guard < 240) {
                val end = cycleEnd(cy)
                val to = if (end.isAfter(today)) today else end
                val sum = summarize(evalRange(cycleStart(cy), to, records, c, nowMs, zone))
                early += sum.earlyDays
                val done = end.isBefore(today)
                if (done && sum.scheduled >= 15 && sum.absent == 0 && sum.late == 0) perfect++
                if (done && sum.scheduled >= 10 && sum.score >= 90) gradeA++
                cy = PG.shiftCycle(cy, 1, c.otMula)
                guard++
            }
        }
        return listOf(
            Achievement("first", "Langkah pertama", "Check-in buat kali pertama", min(checkIns, 1), 1),
            Achievement("ontime5", "Seminggu mantap", "5 hari kerja berturut tepat masa", st.bestOnTime, 5),
            Achievement("ontime10", "Dua minggu cun", "10 hari kerja berturut tepat masa", st.bestOnTime, 10),
            Achievement("ontime22", "Sebulan tanpa lewat", "22 hari kerja berturut tepat masa", st.bestOnTime, 22),
            Achievement("attend50", "Streak 50", "50 hari kerja berturut hadir", st.bestAttend, 50),
            Achievement("attend100", "Streak 100", "100 hari kerja berturut hadir", st.bestAttend, 100),
            Achievement("ot40", "Pahlawan OT", "40 jam OT dalam satu kitaran", maxOt.toInt(), 40),
            Achievement("ot80", "Raja OT", "80 jam OT dalam satu kitaran", maxOt.toInt(), 80),
            Achievement("perfect", "Kitaran sempurna", "Satu kitaran penuh: hadir semua, tiada lewat", perfect, 1),
            Achievement("early", "Burung awal", "Tiba 15 minit awal sebanyak 20 kali", early, 20),
            Achievement("journal", "Penulis jurnal", "Isi mood atau nota selepas shift 10 kali", journal, 10),
            Achievement("gradeA", "Gred A berganda", "3 kitaran dengan skor 90 ke atas", gradeA, 3),
        )
    }

    // ---------------- Check-in / check-out ----------------

    /** Rekod yang sudah check-in tapi belum check-out (hari ini atau semalam, < 20 jam). */
    fun openRecord(records: Map<LocalDate, DayRecord>, nowMs: Long, zone: ZoneId = zone()): DayRecord? {
        val today = today(nowMs, zone)
        return listOf(today, today.minusDays(1)).mapNotNull { records[it] }.firstOrNull { r ->
            val ci = r.checkIn
            r.status == RecordStatus.HADIR && ci != null && r.checkOut == null && nowMs - ci < 20 * HOUR
        }
    }

    /** Waktu yang munasabah untuk check-in automatik (geofence): 3 jam sebelum mula hingga tamat shift. */
    fun inArrivalWindow(date: LocalDate, c: Cfg, nowMs: Long, zone: ZoneId = zone()): Boolean {
        if (dayKind(date, c.s) != DayKind.KERJA) return false
        val start = shiftStartMs(date, c.s, zone)
        return nowMs >= start - 3 * HOUR && nowMs <= start + shiftLengthMs(c)
    }

    // ---------------- Eksport ----------------

    private fun esc(v: String): String =
        if (v.contains(',') || v.contains('"') || v.contains('\n')) "\"" + v.replace("\"", "\"\"") + "\"" else v

    fun csv(evals: List<DayEval>, c: Cfg, pg: PgState, zone: ZoneId = zone()): String {
        val sb = StringBuilder()
        sb.append("tarikh,hari,jenis_hari,shift,status,masuk,keluar,jam_kerja,log_ot_jenis,log_ot_jam,ot_1.5x,ot_2.0x,ot_3.0x,nilai_ot_rm,kitaran_ot,mood,nota\n")
        for (e in evals) {
            val r = e.record
            val key = iso(e.date)
            val log = pg.ot[key]
            val skip = r == null && log == null && e.outcome in setOf(Outcome.HUJUNG_MINGGU, Outcome.AKAN_DATANG, Outcome.TIADA_DATA, Outcome.BELUM)
            if (skip) continue
            val ov = PG.otValue(pg, key)
            val cyc = cycleOf(e.date, c)
            val cols = listOf(
                key,
                Ms.day(e.date),
                Ms.kindLabel(e.kind),
                if (e.shift == ShiftType.PAGI) "Pagi" else "Malam",
                Ms.outcomeLabel(e.outcome),
                r?.checkIn?.let { Ms.time(it, zone) } ?: "",
                r?.checkOut?.let { Ms.time(it, zone) } ?: "",
                Ms.hours(Math.round(e.workedMinutes / 60.0 * 10) / 10.0),
                log?.jenis ?: "",
                log?.jam?.let { Ms.hours(it) } ?: "",
                Ms.hours(ov.h15),
                Ms.hours(ov.h20),
                Ms.hours(ov.h30),
                String.format(java.util.Locale.US, "%.2f", ov.nilai),
                cycleLabel(cyc),
                if (r != null && r.mood in 1..5) Ms.moods[r.mood - 1].substringAfter(' ') else "",
                r?.note ?: "",
            )
            sb.append(cols.joinToString(",") { esc(it) }).append('\n')
        }
        return sb.toString()
    }

    // ---------------- Prompt untuk Claude ----------------

    fun coachPrompt(cy: OtCycle, evals: List<DayEval>, sum: PeriodSummary, st: Streaks, c: Cfg, otJam: Double, zone: ZoneId = zone()): String {
        val s = c.s
        val sb = StringBuilder()
        sb.append("Data kehadiran kerja aku untuk kitaran ${cycleLabel(cy)} (dibayar dalam gaji ${PG.fmtMonth(cy.bayarYm)}).\n")
        sb.append("Corak shift: berpusing ${s.weeksPerBlock} minggu pagi (mula ${Ms.hm(s.morningStart)}) dan ${s.weeksPerBlock} minggu malam (mula ${Ms.hm(s.nightStart)}).\n\n")
        sb.append("Ringkasan: hari kerja dijadualkan ${sum.scheduled}, hadir ${sum.attended}, tepat masa ${sum.onTime}, lewat ${sum.late} (jumlah ${sum.lateMinutes} minit), tidak hadir ${sum.absent}, cuti ${sum.cuti}, MC ${sum.mc}, kerja hari rehat ${sum.extraDays}.\n")
        sb.append("Skor disiplin ${sum.score}/100 (gred ${sum.grade}). OT ${Ms.hours(otJam)} jam.")
        val avg = sum.avgArrival
        if (avg != null) sb.append(" Purata tiba $avg minit sebelum shift.")
        sb.append("\nStreak hadir semasa ${st.attend} hari (terbaik ${st.bestAttend}), streak tepat masa ${st.onTime} hari.\n\nButiran hari:\n")
        for (e in evals) {
            val r = e.record
            if (r == null && e.outcome != Outcome.TIDAK_HADIR) continue
            val line = StringBuilder("- ${Ms.dateShort(e.date)} (${if (e.shift == ShiftType.PAGI) "pagi" else "malam"}, ${Ms.kindLabel(e.kind)}): ${Ms.outcomeLabel(e.outcome)}")
            if (r != null) {
                r.checkIn?.let { line.append(", masuk ${Ms.time(it, zone)}") }
                r.checkOut?.let { line.append(", keluar ${Ms.time(it, zone)}") }
                if (e.lateMinutes > 0) line.append(", lewat ${e.lateMinutes} minit")
                if (e.ot.total > 0) line.append(", OT ${Ms.hours(e.ot.total)}j")
                if (r.mood in 1..5) line.append(", mood ${Ms.moods[r.mood - 1].substringAfter(' ')}")
                if (r.note.isNotBlank()) line.append(", nota: \"${r.note.take(120)}\"")
            }
            sb.append(line).append('\n')
        }
        return sb.toString()
    }

    const val COACH_SYSTEM = "Kau jurulatih disiplin kerja yang mesra untuk seorang juruteknik kilang di Malaysia yang kerja shift berpusing. " +
        "Jawab dalam Bahasa Melayu santai (guna 'kau' dan 'aku'), padat dan jujur. Susun jawapan kepada tiga bahagian bertajuk: " +
        "'Yang bagus', 'Corak yang perlu dibaiki' (sebut hari, shift atau masa yang spesifik daripada data), dan " +
        "'Langkah untuk kitaran depan' (2 hingga 3 langkah praktikal). Jangan reka data yang tiada. Maksimum 220 patah perkataan."
}
