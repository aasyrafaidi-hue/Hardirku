package com.asyraf.hadirku.engine.reconcile

import com.asyraf.hadirku.engine.core.DateRange
import com.asyraf.hadirku.engine.core.Dates
import com.asyraf.hadirku.engine.core.Money
import com.asyraf.hadirku.engine.ledger.Entry
import com.asyraf.hadirku.engine.ledger.EntryType
import com.asyraf.hadirku.engine.ledger.LedgerBook
import com.asyraf.hadirku.engine.ledger.Storage
import java.math.BigDecimal
import java.security.MessageDigest
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

/* =====================================================================
 * Engine 9 — Reconciliation (CSV)
 * Parses a bank CSV export, normalises dates/amounts/descriptions and compares it with the ledger.
 * Exact and fuzzy matches are REPORTED; nothing is merged or posted automatically. There is no
 * direct bank connection — import is file based only.
 * Dates are read day-first (Malaysian banks: dd/MM/yyyy).
 * ===================================================================== */

data class BankLine(
    val row: Int,
    val date: LocalDate,
    val description: String,
    /** signed: + money in, − money out */
    val amount: Money,
    val reference: String?,
    /** stable idempotency key: hash(date|amount|normalised description|occurrence) */
    val key: String,
    /** another line in the same file has identical date, amount and description */
    val possibleDuplicate: Boolean,
)

enum class RowIssue { EMPTY, BAD_DATE, BAD_AMOUNT, NO_AMOUNT }
data class RowError(val row: Int, val issue: RowIssue, val raw: String)

data class ColumnMapping(
    val date: Int, val description: Int, val amount: Int? = null, val debit: Int? = null, val credit: Int? = null,
    val reference: Int? = null, val headerRow: Int = 0,
)

data class CsvParseResult(val mapping: ColumnMapping?, val lines: List<BankLine>, val errors: List<RowError>)

object CsvBankParser {
    private val DATE_FORMATS = listOf(
        "d/M/yyyy", "d/M/yy", "yyyy-MM-dd", "d-M-yyyy", "d-M-yy", "d.M.yyyy",
        "d MMM yyyy", "d-MMM-yyyy", "d-MMM-yy", "d MMM yy", "dd MMM yyyy",
    ).map { DateTimeFormatter.ofPattern(it, Locale.ENGLISH) }
    private val MALAY_MONTHS = mapOf("mac" to "Mar", "mei" to "May", "ogo" to "Aug", "ogos" to "Aug", "okt" to "Oct", "dis" to "Dec", "jul" to "Jul", "jun" to "Jun")

    fun splitRows(text: String): List<List<String>> {
        val rows = ArrayList<List<String>>()
        val delim = detectDelimiter(text)
        var field = StringBuilder(); var row = ArrayList<String>(); var quoted = false; var i = 0
        while (i < text.length) {
            val c = text[i]
            if (quoted) {
                if (c == '"') { if (i + 1 < text.length && text[i + 1] == '"') { field.append('"'); i++ } else quoted = false }
                else field.append(c)
            } else when (c) {
                '"' -> quoted = true
                delim -> { row.add(field.toString().trim()); field = StringBuilder() }
                '\r' -> Unit
                '\n' -> { row.add(field.toString().trim()); rows.add(row); row = ArrayList(); field = StringBuilder() }
                else -> field.append(c)
            }
            i++
        }
        if (field.isNotEmpty() || row.isNotEmpty()) { row.add(field.toString().trim()); rows.add(row) }
        return rows
    }

    private fun detectDelimiter(text: String): Char {
        val head = text.lineSequence().take(5).joinToString("\n")
        return listOf(',', ';', '\t').maxBy { d -> head.count { it == d } }
    }

    fun parseDate(raw: String): LocalDate? {
        var s = raw.trim().replace(Regex("\\s+"), " ")
        if (s.isEmpty()) return null
        s = s.split(" ").joinToString(" ") { w -> MALAY_MONTHS[w.lowercase(Locale.ROOT)] ?: w }
        s = s.replace(Regex("(?i)-(mac|mei|ogos|ogo|okt|dis)-")) { m -> "-" + MALAY_MONTHS.getValue(m.groupValues[1].lowercase(Locale.ROOT)) + "-" }
        s = s.split(" ").take(3).joinToString(" ").substringBefore("T")
        for (f in DATE_FORMATS) {
            val d = runCatching { LocalDate.parse(s, f) }.getOrNull() ?: continue
            return if (d.year < 100) d.plusYears(2000) else d
        }
        return null
    }

    /** "1,234.50", "-12.30", "(12.30)", "12.30 DR", "12.30-", "RM 5.00" → signed Money. */
    fun parseAmount(raw: String): Money? {
        var s = raw.trim().uppercase(Locale.ROOT).replace("RM", "").replace("MYR", "").replace(",", "").replace(" ", "")
        if (s.isEmpty() || s == "-") return null
        var neg = false
        if (s.startsWith("(") && s.endsWith(")")) { neg = true; s = s.substring(1, s.length - 1) }
        if (s.endsWith("DR")) { neg = true; s = s.dropLast(2) } else if (s.endsWith("CR")) s = s.dropLast(2)
        if (s.endsWith("-")) { neg = !neg; s = s.dropLast(1) }
        if (s.startsWith("+")) s = s.drop(1)
        if (s.startsWith("-")) { neg = !neg; s = s.drop(1) }
        val v = runCatching { BigDecimal(s) }.getOrNull() ?: return null
        val m = Money.of(v)
        return if (neg) -m else m
    }

    fun detectMapping(rows: List<List<String>>): ColumnMapping? {
        for ((r, row) in rows.take(15).withIndex()) {
            val h = row.map { it.lowercase(Locale.ROOT) }
            fun find(vararg keys: String) = h.indexOfFirst { c -> keys.any { c.contains(it) } }.takeIf { it >= 0 }
            val date = find("date", "tarikh") ?: continue
            val desc = find("description", "keterangan", "details", "butiran", "transaction", "particular", "narration") ?: continue
            val debit = find("debit", "withdrawal", "pengeluaran", "keluar")
            val credit = find("credit", "deposit", "kredit", "masuk")
            val amount = find("amount", "amaun", "jumlah")
            val ref = find("reference", "rujukan", "ref")
            if (amount == null && (debit == null || credit == null)) continue
            return ColumnMapping(date, desc, if (debit != null && credit != null) null else amount, debit, credit, ref, r)
        }
        return null
    }

    fun parse(text: String, mapping: ColumnMapping? = null): CsvParseResult {
        val rows = splitRows(text)
        val map = mapping ?: detectMapping(rows) ?: return CsvParseResult(null, emptyList(), listOf(RowError(0, RowIssue.EMPTY, "")))
        val errors = ArrayList<RowError>()
        data class Raw(val row: Int, val date: LocalDate, val desc: String, val amt: Money, val ref: String?)
        val raws = ArrayList<Raw>()
        for (r in (map.headerRow + 1) until rows.size) {
            val cells = rows[r]
            if (cells.all { it.isBlank() }) continue
            fun cell(i: Int?) = i?.let { cells.getOrNull(it) }.orEmpty()
            val date = parseDate(cell(map.date)) ?: run { errors += RowError(r, RowIssue.BAD_DATE, cells.joinToString("|")); null } ?: continue
            val amt: Money? = if (map.amount != null) parseAmount(cell(map.amount)) else {
                val d = parseAmount(cell(map.debit)); val c = parseAmount(cell(map.credit))
                when { d != null && !d.isZero -> -d.abs(); c != null && !c.isZero -> c.abs(); else -> null }
            }
            if (amt == null || amt.isZero) { errors += RowError(r, if (amt == null) RowIssue.NO_AMOUNT else RowIssue.BAD_AMOUNT, cells.joinToString("|")); continue }
            raws += Raw(r, date, cell(map.description), amt, cell(map.reference).ifBlank { null })
        }
        val seen = HashMap<String, Int>()
        val lines = raws.map { x ->
            val base = x.date.toString() + "|" + x.amt.sen + "|" + normalise(x.desc)
            val n = seen.merge(base, 1, Int::plus)!!
            BankLine(x.row, x.date, x.desc, x.amt, x.ref, sha(base + "|" + n), possibleDuplicate = false) to base
        }
        val counts = lines.groupingBy { it.second }.eachCount()
        return CsvParseResult(map, lines.map { (l, base) -> l.copy(possibleDuplicate = (counts[base] ?: 0) > 1) }, errors)
    }

    fun normalise(desc: String): String = desc.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9 ]+"), " ").replace(Regex("\\s+"), " ").trim()

    private fun sha(s: String): String =
        MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }.take(32)
}

enum class MatchStatus { EXACT, FUZZY_REVIEW, UNMATCHED_BANK, UNMATCHED_LEDGER, ALREADY_IMPORTED }

data class MatchRow(
    val status: MatchStatus,
    val line: BankLine?,
    val entryId: String?,
    /** 0..100 */
    val score: Int,
    val dateDiffDays: Long? = null,
)

data class ReconReport(val range: DateRange, val rows: List<MatchRow>) {
    fun count(s: MatchStatus) = rows.count { it.status == s }
}

object ReconciliationEngine {

    /** Net effect of an entry on the given accounts (transfers inside the set net to zero). */
    private fun effect(e: Entry, accounts: Set<String>): Money = Money.sum(accounts.map { e.effectOn(it) })

    fun bankAccounts(book: LedgerBook): Set<String> = book.accounts.values.filter { it.storage == Storage.BANK }.map { it.id }.toSet()

    fun reconcile(
        lines: List<BankLine>, book: LedgerBook, accounts: Set<String> = bankAccounts(book),
        importedKeys: Set<String> = emptySet(), toleranceDays: Long = 3,
    ): ReconReport {
        if (lines.isEmpty()) return ReconReport(DateRange(LocalDate.now(), LocalDate.now()), emptyList())
        val range = DateRange.inclusive(lines.minOf { it.date }, lines.maxOf { it.date })
        val wide = DateRange(range.start.minusDays(toleranceDays), range.endExclusive.plusDays(toleranceDays))
        val candidates = book.effective().filter { it.date in wide && it.type != EntryType.OPENING_BALANCE }
            .mapNotNull { e -> effect(e, accounts).takeIf { !it.isZero }?.let { e to it } }
            .toMutableList()
        val rows = ArrayList<MatchRow>()
        for (l in lines.sortedWith(compareBy({ it.date }, { it.row }))) {
            if (l.key in importedKeys) { rows += MatchRow(MatchStatus.ALREADY_IMPORTED, l, null, 100); continue }
            val same = candidates.filter { it.second == l.amount }
            val sameDay = same.filter { it.first.date == l.date }
            val pick: Pair<Entry, Money>?
            val status: MatchStatus
            if (sameDay.size == 1) { pick = sameDay[0]; status = MatchStatus.EXACT }
            else {
                pick = same.filter { kotlin.math.abs(Dates.daysBetween(it.first.date, l.date)) <= toleranceDays }
                    .minWithOrNull(compareBy<Pair<Entry, Money>>({ kotlin.math.abs(Dates.daysBetween(it.first.date, l.date)) }, { -similarity(it.first.memo, l.description) }))
                status = MatchStatus.FUZZY_REVIEW
            }
            if (pick == null) { rows += MatchRow(MatchStatus.UNMATCHED_BANK, l, null, 0); continue }
            candidates.remove(pick)
            val dd = Dates.daysBetween(pick.first.date, l.date)
            val score = if (status == MatchStatus.EXACT) 100 else (80 - 10 * kotlin.math.abs(dd).toInt() + similarity(pick.first.memo, l.description) / 5).coerceIn(1, 99)
            rows += MatchRow(status, l, pick.first.id, score, dd)
        }
        candidates.filter { it.first.date in range }.forEach { (e, _) -> rows += MatchRow(MatchStatus.UNMATCHED_LEDGER, null, e.id, 0) }
        return ReconReport(range, rows)
    }

    /** Token Jaccard similarity of two descriptions, 0..100. */
    fun similarity(a: String, b: String): Int {
        val ta = CsvBankParser.normalise(a).split(' ').filter { it.length >= 3 }.toSet()
        val tb = CsvBankParser.normalise(b).split(' ').filter { it.length >= 3 }.toSet()
        if (ta.isEmpty() || tb.isEmpty()) return 0
        return (ta.intersect(tb).size * 100) / ta.union(tb).size
    }
}
