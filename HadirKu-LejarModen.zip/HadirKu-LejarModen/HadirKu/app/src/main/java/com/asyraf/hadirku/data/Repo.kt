package com.asyraf.hadirku.data

import android.content.Context
import android.content.SharedPreferences
import android.util.AtomicFile
import com.asyraf.hadirku.BuildConfig
import com.asyraf.hadirku.logic.Cfg
import com.asyraf.hadirku.logic.Logic
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.PgJson
import com.asyraf.hadirku.pg.PgSample
import com.asyraf.hadirku.pg.PgState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.LocalDate

/** Fail salinan yang sudah dibaca dan menunggu pengesahan pengguna. */
class PendingImport(
    val pg: PgState?,
    val settings: AppSettings?,
    val records: Map<LocalDate, DayRecord>?,
    val name: String,
) {
    val txCount: Int get() = pg?.transactions?.size ?: 0
    val recCount: Int get() = records?.size ?: 0
}

/**
 * Simpanan tempatan: rekod kehadiran, tetapan kehadiran dan data PoketGaji (satu fail JSON
 * format salinan PoketGaji v2). Satu instance untuk seluruh proses supaya skrin, notifikasi
 * dan geofence sentiasa nampak data yang sama.
 */
object Repo {
    private val lock = Any()
    @Volatile private var ready = false
    private lateinit var recordsFile: AtomicFile
    private lateinit var settingsFile: AtomicFile
    private lateinit var pgFile: AtomicFile
    lateinit var prefs: SharedPreferences
        private set

    private val _records = MutableStateFlow<Map<LocalDate, DayRecord>>(emptyMap())
    val records: StateFlow<Map<LocalDate, DayRecord>> = _records.asStateFlow()

    private val _settings = MutableStateFlow(AppSettings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private val _pg = MutableStateFlow(PG.defaultState())
    val pg: StateFlow<PgState> = _pg.asStateFlow()

    /** Tetapan lama HadirKu v1 (gaji & kitaran OT) untuk dipakai bila mula dengan data sendiri. */
    var legacy: Legacy = Legacy()
        private set

    fun cfg(): Cfg = Cfg(_settings.value, _pg.value.settings)

    fun init(context: Context) {
        if (ready) return
        synchronized(lock) {
            if (ready) return
            val app = context.applicationContext
            val dir = app.filesDir
            prefs = app.getSharedPreferences("hadirku", Context.MODE_PRIVATE)
            recordsFile = AtomicFile(File(dir, "records.json"))
            settingsFile = AtomicFile(File(dir, "settings.json"))
            pgFile = AtomicFile(File(dir, "pg.json"))
            _records.value = readText(recordsFile)?.let {
                runCatching { JsonCodec.recordsFromJson(JSONArray(it)) }.getOrNull()
            } ?: emptyMap()
            val settingsJson = readText(settingsFile)?.let { runCatching { JSONObject(it) }.getOrNull() }
            var s = settingsJson?.let { runCatching { JsonCodec.settingsFromJson(it) }.getOrNull() } ?: AppSettings()
            if (settingsJson != null) legacy = JsonCodec.legacyFromJson(settingsJson)
            if (s.trackingStart == null) {
                val earliest = _records.value.keys.minByOrNull { it.toEpochDay() }
                s = s.copy(trackingStart = earliest ?: LocalDate.now())
            }
            _settings.value = s
            writeText(settingsFile, JsonCodec.settingsToJson(s).toString())
            // kunci Claude lama dipindah ke tetapan AI (kekal dalam telefon, tidak masuk salinan)
            if (legacy.claudeKey.isNotBlank() && prefs.getString("ai.key", "").isNullOrBlank()) {
                prefs.edit().putString("ai.key", legacy.claudeKey)
                    .putString("ai.model", legacy.claudeModel.ifBlank { "claude-haiku-5-5" }).apply()
            }
            val pgText = readText(pgFile)
            val loaded = pgText?.let { runCatching { PgJson.parseState(JSONObject(it)) }.getOrNull() }
            if (loaded != null) {
                _pg.value = untukApp(loaded)
                if (_pg.value !== loaded) writeText(pgFile, PgJson.toJson(_pg.value).toString())
            } else {
                // kali pertama: data contoh macam PoketGaji, sehingga pengguna mula dengan data sendiri atau pulihkan salinan
                _pg.value = untukApp(PgSample.sampleState(PG.todayISO()))
                writeText(pgFile, PgJson.toJson(_pg.value).toString())
            }
            // dompet tunai (asing dari bank) ditambah sekali sahaja; kalau pengguna padam, ia tak muncul semula
            if (!prefs.getBoolean("tunai.auto", false)) {
                val t = PG.withTunai(_pg.value)
                if (t != _pg.value) { _pg.value = t; writeText(pgFile, PgJson.toJson(t).toString()) }
                prefs.edit().putBoolean("tunai.auto", true).apply()
            }
            ready = true
        }
    }

    private fun readText(f: AtomicFile): String? = try {
        String(f.readFully(), Charsets.UTF_8)
    } catch (e: Exception) {
        null
    }

    private fun writeText(f: AtomicFile, text: String) {
        val out = try { f.startWrite() } catch (e: Exception) { return }
        try {
            out.write(text.toByteArray(Charsets.UTF_8))
            f.finishWrite(out)
        } catch (e: Exception) {
            f.failWrite(out)
        }
    }

    private fun saveRecords(map: Map<LocalDate, DayRecord>) {
        _records.value = map
        writeText(recordsFile, JsonCodec.recordsToJson(map.values).toString())
    }

    // pg.json ditulis di latar belakang: skrin dikemas kini serta-merta, fail ditulis tanpa menahan UI.
    // Simpanan berturut-turut digabung (hanya keadaan terkini ditulis). AtomicFile elak fail rosak.
    private val pgWriter = java.util.concurrent.Executors.newSingleThreadExecutor { r -> Thread(r, "pg-simpan").apply { isDaemon = true } }
    private val pgPending = java.util.concurrent.atomic.AtomicReference<PgState?>(null)

    private fun savePg(state: PgState) {
        _pg.value = state
        if (pgPending.getAndSet(state) == null) pgWriter.execute { tulisPgTertunda() }
    }

    private fun tulisPgTertunda() {
        val st = pgPending.getAndSet(null) ?: return
        writeText(pgFile, PgJson.toJson(st).toString())
    }

    /** Tunggu simpanan pg.json selesai (dipanggil bila app ke latar belakang). */
    fun flushPg(timeoutMs: Long = 3000) {
        if (!::pgFile.isInitialized) return
        try { pgWriter.submit { tulisPgTertunda() }.get(timeoutMs, java.util.concurrent.TimeUnit.MILLISECONDS) } catch (e: Exception) { }
    }

    // ---------------- PoketGaji ----------------

    fun updatePg(transform: (PgState) -> PgState) {
        synchronized(lock) { savePg(transform(_pg.value)) }
    }

    /** Ganti semua data PoketGaji (mula semula, data contoh, pulihkan). */
    /** App isteri: tiada gaji & OT (lihat [com.asyraf.hadirku.pg.Isteri]). App suami: tiada perubahan. */
    fun untukApp(state: PgState): PgState = if (BuildConfig.ISTERI) com.asyraf.hadirku.pg.Isteri.sesuaikan(state) else state

    fun replacePg(state: PgState, fillOt: Boolean = true) {
        synchronized(lock) {
            savePg(PG.withTunai(untukApp(state)))
            if (fillOt && !BuildConfig.ISTERI) fillMissingOt()
        }
    }

    /** Keadaan kosong untuk "mula dengan data sendiri": guna gaji & kitaran dari HadirKu lama kalau ada. */
    fun freshPg(): PgState {
        val d = PG.defaultState()
        val lg = legacy
        val g = d.settings.gaji.copy(
            basic = if (lg.basicSalary > 0) lg.basicSalary else d.settings.gaji.basic,
            jamNormal = if (lg.normalHours > 0) lg.normalHours else d.settings.gaji.jamNormal,
        )
        val sd = if (lg.cycleStartDay in 1..28) lg.cycleStartDay else d.settings.otMulaHari
        return untukApp(d.copy(settings = d.settings.copy(gaji = g, otMulaHari = sd)))
    }

    // ---------------- Kehadiran ↔ log OT ----------------

    private fun syncOt(old: DayRecord?, new: DayRecord?) {
        val s = _settings.value
        if (!s.syncOt || BuildConfig.ISTERI) return
        val date = (new ?: old)?.date ?: return
        val key = Logic.iso(date)
        val newE = if (new != null) Logic.otEntryFor(new, s) else null
        val oldE = if (old != null) Logic.otEntryFor(old, s) else null
        val cur = _pg.value.ot[key]
        if (newE != null) {
            if (cur != newE) savePg(_pg.value.copy(ot = LinkedHashMap(_pg.value.ot).also { it[key] = newE }))
        } else if (oldE != null && cur == oldE) {
            savePg(_pg.value.copy(ot = LinkedHashMap(_pg.value.ot).also { it.remove(key) }))
        }
    }

    /** Isi log OT untuk hari yang ada rekod kehadiran lengkap tapi belum ada log (selepas pulihkan salinan). */
    fun fillMissingOt(): Int {
        synchronized(lock) {
            val s = _settings.value
            if (!s.syncOt) return 0
            val ot = LinkedHashMap(_pg.value.ot)
            var n = 0
            _records.value.values.sortedBy { it.date.toEpochDay() }.forEach { r ->
                val key = Logic.iso(r.date)
                if (ot[key] == null) {
                    val e = Logic.otEntryFor(r, s)
                    if (e != null) { ot[key] = e; n++ }
                }
            }
            if (n > 0) savePg(_pg.value.copy(ot = ot))
            return n
        }
    }

    fun upsert(record: DayRecord) {
        synchronized(lock) {
            val map = HashMap(_records.value)
            val old = map[record.date]
            map[record.date] = record
            saveRecords(map)
            val t = _settings.value.trackingStart
            if (t == null || record.date.isBefore(t)) {
                updateSettings { it.copy(trackingStart = record.date) }
            }
            syncOt(old, record)
        }
    }

    fun delete(date: LocalDate) {
        synchronized(lock) {
            val map = HashMap(_records.value)
            val old = map.remove(date)
            if (old != null) {
                saveRecords(map)
                syncOt(old, null)
            }
        }
    }

    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        synchronized(lock) {
            val s = transform(_settings.value)
            _settings.value = s
            writeText(settingsFile, JsonCodec.settingsToJson(s).toString())
        }
    }

    // ---------------- Salinan ----------------

    /** Salinan gabungan: format PoketGaji v2 (boleh dibaca PoketGaji PWA) + bahagian "hadirku". */
    fun backupJson(): String {
        val o = PgJson.toJson(_pg.value)
        o.put("hadirku", JsonCodec.hadirkuBlock(_settings.value, _records.value.values))
        return o.toString(2)
    }

    /** Baca fail salinan: PoketGaji, gabungan, atau HadirKu lama. Null jika fail tak dikenali. */
    fun parseBackup(text: String, name: String): PendingImport? {
        val o = try { JSONObject(text.trim().removePrefix("\uFEFF")) } catch (e: Exception) { return null }
        var pg: PgState? = null
        var hk: JSONObject? = null
        if (PgJson.isPoketGaji(o)) {
            pg = try { PgJson.parseState(o) } catch (e: Exception) { return null }
            hk = o.optJSONObject("hadirku")
        } else if (o.optJSONArray("records") != null) {
            hk = o
        }
        if (pg == null && hk == null) return null
        var st: AppSettings? = null
        var recs: Map<LocalDate, DayRecord>? = null
        if (hk != null) {
            val arr = hk.optJSONArray("records")
            if (arr != null) recs = JsonCodec.recordsFromJson(arr)
            val so = hk.optJSONObject("settings")
            if (so != null) {
                val cur = _settings.value
                val imp = JsonCodec.settingsFromJson(so)
                st = imp.copy(
                    calendarificKey = imp.calendarificKey.ifBlank { cur.calendarificKey },
                )
                if (pg == null && !so.has("syncOt")) {
                    // salinan HadirKu v1: gaji & kitaran lama dipindah bila sesuai
                    legacy = JsonCodec.legacyFromJson(so)
                }
            }
        }
        return PendingImport(pg, st, recs, name)
    }

    fun applyImport(p: PendingImport) {
        synchronized(lock) {
            val st = p.settings
            if (st != null) updateSettings { st }
            val recs = p.records
            if (recs != null) saveRecords(recs)
            val pg = p.pg
            if (pg != null) savePg(PG.withTunai(untukApp(pg)))
            if (!BuildConfig.ISTERI) fillMissingOt()
        }
    }

    // ---------------- Pilihan kecil (paparan, AI, tarikh salinan) ----------------

    fun getStr(key: String, def: String = ""): String = prefs.getString(key, def) ?: def
    fun putStr(key: String, v: String) { prefs.edit().putString(key, v).apply() }
    fun getInt(key: String, def: Int): Int = prefs.getInt(key, def)
    fun putInt(key: String, v: Int) { prefs.edit().putInt(key, v).apply() }
    fun getLong(key: String, def: Long = 0L): Long = prefs.getLong(key, def)
    fun putLong(key: String, v: Long) { prefs.edit().putLong(key, v).apply() }
    fun getBool(key: String, def: Boolean): Boolean = prefs.getBoolean(key, def)
    fun putBool(key: String, v: Boolean) { prefs.edit().putBoolean(key, v).apply() }
    fun remove(key: String) { prefs.edit().remove(key).apply() }
}
