package com.asyraf.hadirku.i18n

import android.content.Context
import com.asyraf.hadirku.data.Repo
import com.asyraf.hadirku.pg.PG

/**
 * Pilihan bahasa app: Bahasa Melayu (asal) atau English (UK).
 *
 * Semua teks app ditulis dalam Bahasa Melayu dalam kod. Bila English dipilih, [t] terjemah teks
 * semasa dipaparkan (dipanggil dari Txt / rich / placeholder / notifikasi), guna kamus
 * assets/i18n/en.tsv:
 *  1. padanan penuh ayat, kemudian
 *  2. corak nombor ("3 hari lagi", "15hb", "Lewat 2 hari"...), kemudian
 *  3. cebisan ayat (ayat yang dicantum dengan nombor / tarikh / nama), padanan terpanjang dulu.
 * Data pengguna (nama poket, perkara transaksi) biasanya tiada dalam kamus, jadi kekal seperti asal.
 * Nama bulan & hari ditukar terus dalam PG (PG.en).
 */
object Bahasa {
    const val KUNCI = "ui.bahasa"

    @Volatile var en: Boolean = false
        private set

    private val penuh = HashMap<String, String>(4096)
    private val cebis = HashMap<String, MutableList<Pair<String, String>>>(2048)
    @Volatile private var dimuat = false
    private val cache = object : LinkedHashMap<String, String>(512, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?): Boolean = size > 4000
    }

    /** Panggil sekali selepas Repo.init (Application.onCreate). */
    fun init(ctx: Context) {
        muat(ctx)
        en = Repo.getStr(KUNCI, "ms") == "en"
        PG.en = en
    }

    fun kod(): String = if (en) "en" else "ms"

    fun pilih(kod: String) {
        Repo.putStr(KUNCI, kod)
        en = kod == "en"
        PG.en = en
        synchronized(cache) { cache.clear() }
    }

    private fun unesc(s: String) = s.replace("\\n", "\n").replace("\\t", "\t")

    private fun tokenAwal(s: String): String {
        var i = 0
        while (i < s.length && !s[i].isLetterOrDigit()) i++
        var j = i
        while (j < s.length && s[j].isLetterOrDigit()) j++
        return s.substring(i, j).lowercase()
    }

    @Synchronized private fun muat(ctx: Context) {
        if (dimuat) return
        try {
            ctx.applicationContext.assets.open("i18n/en.tsv").bufferedReader(Charsets.UTF_8).useLines { muatBaris(it) }
        } catch (_: Exception) { }
        dimuat = true
    }

    /** Muat kamus daripada baris TSV (juga dipakai ujian). */
    fun muatBaris(lines: Sequence<String>) {
                lines.forEach { l ->
                    if (l.isBlank() || l.startsWith("#")) return@forEach
                    val p = l.split('\t')
                    if (p.size < 2) return@forEach
                    val ms = unesc(p[0]).trim()
                    val e = unesc(p[1]).trim()
                    if (ms.isEmpty()) return@forEach
                    penuh[ms] = e
                    // cebisan: buang tanda di hujung yang sama dalam kedua-dua bahasa (cth "· baki" → "baki")
                    var a = ms; var b = e
                    while (a.isNotEmpty() && !a.first().isLetterOrDigit() && b.isNotEmpty() && a.first() == b.first()) { a = a.substring(1).trimStart(); b = b.substring(1).trimStart() }
                    while (a.isNotEmpty() && !a.last().isLetterOrDigit() && b.isNotEmpty() && a.last() == b.last()) { a = a.dropLast(1).trimEnd(); b = b.dropLast(1).trimEnd() }
                    if (a.isEmpty() || !a.first().isLetterOrDigit()) return@forEach
                    val kata = a.split(Regex("[^\\p{L}\\p{N}]+")).count { it.isNotEmpty() }
                    if (kata >= 2 || p.getOrNull(2) == "f") cebis.getOrPut(tokenAwal(a)) { ArrayList() }.add(a to b)
                }
            cebis.values.forEach { it.sortByDescending { x -> x.first.length } }
    }

    /** Untuk ujian: hidupkan English tanpa Repo. */
    fun ujiEn() { en = true; PG.en = true; synchronized(cache) { cache.clear() } }

    /** Terjemah teks paparan (Melayu → English bila English dipilih). */
    fun t(s: String): String {
        if (!en || s.isEmpty()) return s
        if (!adaPerkataan(s)) return s
        synchronized(cache) { cache[s]?.let { return it } }
        val r = terjemah(s)
        synchronized(cache) { cache[s] = r }
        return r
    }

    /** Ada huruf selain "RM"? (nombor & wang sahaja tak perlu diterjemah) */
    private fun adaPerkataan(s: String): Boolean {
        for (i in s.indices) {
            val c = s[i]
            if (!c.isLetter()) continue
            if (c == 'R' && i + 1 < s.length && s[i + 1] == 'M') continue
            if (c == 'M' && i > 0 && s[i - 1] == 'R') continue
            return true
        }
        return false
    }

    private fun bungkus(asal: String, isi: String): String {
        val a = asal.length - asal.trimStart().length
        val b = asal.length - asal.trimEnd().length
        return asal.substring(0, a) + isi + asal.substring(asal.length - b)
    }

    private fun terjemah(s: String): String {
        val tr = s.trim()
        penuh[tr]?.let { return bungkus(s, it) }
        val r = corak(s)
        penuh[r.trim()]?.let { return bungkus(r, it) }
        return tunggal(unit(cebisan(r)))
    }

    // ---------- corak nombor ----------
    private fun ordinal(n: Int): String = n.toString() + when {
        n % 100 in 11..13 -> "th"
        n % 10 == 1 -> "st"
        n % 10 == 2 -> "nd"
        n % 10 == 3 -> "rd"
        else -> "th"
    }

    private val R_HB = Regex("(\\d+)hb\\b")
    private val R_LEWAT = Regex("\\b[Ll]ewat (\\d+) hari\\b")
    private val R_H = Regex("\\bH-(\\d+)\\b")
    private val R_LAGI = Regex("(\\d+) (hari|bulan|tahun|minggu) lagi\\b")
    private val R_LEPAS = Regex("(\\d+) (hari|bulan|tahun|minggu) lepas\\b")
    private val R_J = Regex("(\\d+(?:\\.\\d+)?)j\\b")
    private val R_UNIT = Regex("(\\d+(?:[.,]\\d+)?) ?(hari|bulan|bln|tahun|thn|minggu|kali|minit|jam|transaksi|barang|poket|komitmen|hutang)\\b")
    private val UNIT = mapOf(
        "hari" to "days", "bulan" to "months", "bln" to "mo", "tahun" to "years", "thn" to "yrs", "minggu" to "weeks", "kali" to "times",
        "minit" to "min", "jam" to "hrs", "transaksi" to "transactions", "item" to "items", "barang" to "items", "poket" to "pockets",
        "komitmen" to "commitments", "hutang" to "debts",
    )

    private fun corak(s0: String): String {
        var s = s0
        if (s.contains("hb")) s = R_HB.replace(s) { ordinal(it.groupValues[1].toInt()) }
        s = R_LEWAT.replace(s) { it.groupValues[1] + " days late" }
        s = R_H.replace(s) { it.groupValues[1] + " days left" }
        s = R_LAGI.replace(s) { "in " + it.groupValues[1] + " " + UNIT[it.groupValues[2]] }
        s = R_LEPAS.replace(s) { "last " + it.groupValues[1] + " " + UNIT[it.groupValues[2]] }
        s = R_J.replace(s) { it.groupValues[1] + "h" }
        return s
    }

    /** Unit selepas nombor yang masih tinggal selepas cebisan (cth "11 jam", "6 bulan"). */
    private fun unit(s: String): String = R_UNIT.replace(s) { it.groupValues[1] + " " + UNIT[it.groupValues[2]] }

    private val R_SATU = Regex("\\b1 (days|months|years|weeks|times|hrs|yrs|transactions|items|pockets|commitments|debts)\\b")
    private fun tunggal(s: String): String = R_SATU.replace(s) { m ->
        "1 " + when (val u = m.groupValues[1]) { "hrs" -> "hr"; "yrs" -> "yr"; else -> u.dropLast(1) }
    }

    // ---------- cebisan ayat ----------
    private fun ikutHuruf(src: Char, en: String): String {
        if (en.isEmpty()) return en
        val akronim = en.length > 1 && en[1].isUpperCase()
        return when {
            src.isUpperCase() && en[0].isLowerCase() -> en[0].uppercaseChar() + en.substring(1)
            src.isLowerCase() && en[0].isUpperCase() && !akronim -> en[0].lowercaseChar() + en.substring(1)
            else -> en
        }
    }

    private fun cebisan(s: String): String {
        val n = s.length
        val sb = StringBuilder(n + 16)
        var i = 0
        while (i < n) {
            val c = s[i]
            if (c.isLetterOrDigit() && (i == 0 || !s[i - 1].isLetterOrDigit())) {
                var j = i
                while (j < n && s[j].isLetterOrDigit()) j++
                val calon = cebis[s.substring(i, j).lowercase()]
                var kena = false
                if (calon != null) {
                    for ((k, v) in calon) {
                        val L = k.length
                        if (i + L > n || !s.regionMatches(i, k, 0, L, ignoreCase = true)) continue
                        val akhir = i + L
                        if (akhir < n && k.last().isLetterOrDigit() && s[akhir].isLetterOrDigit()) continue
                        sb.append(ikutHuruf(c, v)); i = akhir; kena = true; break
                    }
                }
                if (!kena) { sb.append(s, i, j); i = j }
            } else {
                sb.append(c); i++
            }
        }
        return sb.toString()
    }
}

/** Singkatan untuk teks paparan. */
fun tr(s: String): String = Bahasa.t(s)
