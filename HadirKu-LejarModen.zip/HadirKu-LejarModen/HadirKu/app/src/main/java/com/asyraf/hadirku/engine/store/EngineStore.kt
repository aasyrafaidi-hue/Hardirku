package com.asyraf.hadirku.engine.store

import com.asyraf.hadirku.engine.budget.Budget
import com.asyraf.hadirku.engine.budget.CarryOver
import com.asyraf.hadirku.engine.category.CategoryRule
import com.asyraf.hadirku.engine.category.MatchType
import com.asyraf.hadirku.engine.core.EngineClock
import com.asyraf.hadirku.engine.core.MiniJson
import com.asyraf.hadirku.engine.core.Money
import com.asyraf.hadirku.engine.core.bool
import com.asyraf.hadirku.engine.core.int
import com.asyraf.hadirku.engine.core.long
import com.asyraf.hadirku.engine.core.obj
import com.asyraf.hadirku.engine.core.objList
import com.asyraf.hadirku.engine.core.str
import com.asyraf.hadirku.engine.notify.NotifKind
import com.asyraf.hadirku.engine.notify.NotifPrefs
import com.asyraf.hadirku.engine.receipt.KnownReceipt
import com.asyraf.hadirku.engine.savings.GoalMove
import com.asyraf.hadirku.engine.savings.SavingsGoal
import java.time.LocalDate
import java.time.LocalTime
import java.time.YearMonth

/* =====================================================================
 * Persistence for NEW engine data only — `engine.json`, separate from the existing `pg.json`
 * (which the engines never write). Versioned; older versions are backed up before migration;
 * a file written by a NEWER app version is opened read-only and never overwritten; a corrupt file
 * is backed up before anything else happens. Unknown top-level keys are preserved on save.
 * ===================================================================== */

interface TextIo {
    fun read(): String?
    fun write(text: String): Boolean
    /** Keep a copy of [text] under [tag] (e.g. "v0-2026-11-17"). */
    fun backup(tag: String, text: String): Boolean
}

class MemoryTextIo(var text: String? = null) : TextIo {
    val backups = LinkedHashMap<String, String>()
    override fun read() = text
    override fun write(text: String): Boolean { this.text = text; return true }
    override fun backup(tag: String, text: String): Boolean { backups[tag] = text; return true }
}

data class EngineData(
    val version: Int = EngineStore.CURRENT_VERSION,
    val categoryOverrides: Map<String, String> = emptyMap(),
    val categoryRules: List<CategoryRule> = emptyList(),
    val budgets: List<Budget> = emptyList(),
    val goals: List<SavingsGoal> = emptyList(),
    val goalMoves: List<GoalMove> = emptyList(),
    /** notification dedup key → ISO date delivered */
    val notificationsSent: Map<String, String> = emptyMap(),
    /** import idempotency key → ledger entry id / source id */
    val importKeys: Map<String, String> = emptyMap(),
    val knownReceipts: List<KnownReceipt> = emptyList(),
    val notifPrefs: NotifPrefs = NotifPrefs(),
    /** top-level keys this version does not understand — written back unchanged */
    val unknown: Map<String, Any?> = emptyMap(),
)

data class LoadResult(val data: EngineData, val migratedFrom: Int?, val readOnly: Boolean, val backupTag: String?)

class EngineStore(private val io: TextIo, private val clock: EngineClock) {
    companion object {
        const val CURRENT_VERSION = 1
    }

    @Volatile private var readOnly = false

    fun load(): LoadResult {
        val text = io.read() ?: return LoadResult(EngineData(), null, false, null).also { readOnly = false }
        val map = try { MiniJson.parseObject(text) } catch (e: Exception) {
            val tag = "corrupt-" + clock.today()
            io.backup(tag, text)
            readOnly = false
            return LoadResult(EngineData(), null, false, tag)
        }
        val ver = map.int("version") ?: 0
        if (ver > CURRENT_VERSION) { readOnly = true; return LoadResult(EngineCodec.decode(map), null, true, null) }
        if (ver < CURRENT_VERSION) {
            val tag = "v$ver-" + clock.today()
            io.backup(tag, text)
            readOnly = false
            return LoadResult(EngineCodec.decode(Migrations.toCurrent(map, ver)), ver, false, tag)
        }
        readOnly = false
        return LoadResult(EngineCodec.decode(map), null, false, null)
    }

    /** Refuses to overwrite a file produced by a newer version. */
    fun save(d: EngineData): Boolean {
        if (readOnly) return false
        return io.write(EngineCodec.encode(d.copy(version = CURRENT_VERSION)))
    }

    @Synchronized
    fun update(f: (EngineData) -> EngineData): Boolean {
        val cur = load()
        if (cur.readOnly) return false
        return save(f(cur.data))
    }
}

object Migrations {
    /**
     * v0 = development format without a "version" key (never shipped): `overrides` and `sent`.
     * Each step only adds/renames — no record is ever dropped.
     */
    fun toCurrent(map: Map<String, Any?>, from: Int): Map<String, Any?> {
        var m = LinkedHashMap(map)
        if (from < 1) {
            m = LinkedHashMap(m)
            m.remove("overrides")?.let { m.putIfAbsent("categoryOverrides", it) }
            m.remove("sent")?.let { m.putIfAbsent("notificationsSent", it) }
            m["version"] = 1
        }
        return m
    }
}

object EngineCodec {
    private val KNOWN = setOf("version", "categoryOverrides", "categoryRules", "budgets", "goals", "goalMoves",
        "notificationsSent", "importKeys", "knownReceipts", "notifPrefs")

    fun encode(d: EngineData): String {
        val m = LinkedHashMap<String, Any?>()
        m.putAll(d.unknown)
        m["version"] = d.version
        m["categoryOverrides"] = d.categoryOverrides
        m["categoryRules"] = d.categoryRules.map { linkedMapOf("id" to it.id, "pattern" to it.pattern, "type" to it.type.name, "category" to it.category, "priority" to it.priority) }
        m["budgets"] = d.budgets.map { linkedMapOf("id" to it.id, "category" to it.category, "amount_sen" to it.amount.sen, "start" to it.startMonth.toString(), "carry" to it.carryOver.name, "essential" to it.essential) }
        m["goals"] = d.goals.filter { !it.fromPocket }.map { linkedMapOf("id" to it.id, "name" to it.name, "target_sen" to it.target.sen, "target_date" to it.targetDate?.toString(), "account" to it.accountId, "created" to it.createdOn.toString(), "currency" to it.currency) }
        m["goalMoves"] = d.goalMoves.map { linkedMapOf("id" to it.id, "goal" to it.goalId, "date" to it.date.toString(), "amount_sen" to it.amount.sen) }
        m["notificationsSent"] = d.notificationsSent
        m["importKeys"] = d.importKeys
        m["knownReceipts"] = d.knownReceipts.map { linkedMapOf("id" to it.id, "merchant" to it.merchant, "date" to it.date?.toString(), "total_sen" to it.total?.sen, "receipt_id" to it.receiptId, "items" to it.itemNames) }
        m["notifPrefs"] = linkedMapOf("enabled" to d.notifPrefs.enabled.map { it.name }, "quiet_start" to d.notifPrefs.quietStart?.toString(), "quiet_end" to d.notifPrefs.quietEnd?.toString(), "max_per_run" to d.notifPrefs.maxPerRun)
        return MiniJson.write(m)
    }

    private fun date(s: String?): LocalDate? = s?.let { runCatching { LocalDate.parse(it) }.getOrNull() }

    @Suppress("UNCHECKED_CAST")
    fun decode(m: Map<String, Any?>): EngineData {
        fun strMap(k: String) = (m[k] as? Map<String, Any?>)?.mapNotNull { (a, b) -> (b as? String)?.let { a to it } }?.toMap() ?: emptyMap()
        val prefs = m.obj("notifPrefs")?.let { p ->
            NotifPrefs(
                enabled = ((p["enabled"] as? List<Any?>)?.mapNotNull { n -> NotifKind.entries.find { it.name == n } }?.toSet()) ?: NotifKind.entries.toSet(),
                quietStart = p.str("quiet_start")?.let { runCatching { LocalTime.parse(it) }.getOrNull() },
                quietEnd = p.str("quiet_end")?.let { runCatching { LocalTime.parse(it) }.getOrNull() },
                maxPerRun = p.int("max_per_run") ?: 5,
            )
        } ?: NotifPrefs()
        return EngineData(
            version = m.int("version") ?: CURRENT,
            categoryOverrides = strMap("categoryOverrides"),
            categoryRules = m.objList("categoryRules").mapNotNull { r ->
                CategoryRule(r.str("id") ?: return@mapNotNull null, r.str("pattern") ?: return@mapNotNull null,
                    MatchType.entries.find { it.name == r.str("type") } ?: MatchType.CONTAINS, r.str("category") ?: return@mapNotNull null, r.int("priority") ?: 0)
            },
            budgets = m.objList("budgets").mapNotNull { b ->
                Budget(b.str("id") ?: return@mapNotNull null, b.str("category") ?: return@mapNotNull null, Money(b.long("amount_sen") ?: return@mapNotNull null),
                    runCatching { YearMonth.parse(b.str("start")) }.getOrNull() ?: return@mapNotNull null,
                    CarryOver.entries.find { it.name == b.str("carry") } ?: CarryOver.NONE, b.bool("essential") ?: false)
            },
            goals = m.objList("goals").mapNotNull { g ->
                SavingsGoal(g.str("id") ?: return@mapNotNull null, g.str("name") ?: "", Money(g.long("target_sen") ?: return@mapNotNull null),
                    date(g.str("target_date")), g.str("account"), date(g.str("created")) ?: return@mapNotNull null, g.str("currency") ?: "MYR")
            },
            goalMoves = m.objList("goalMoves").mapNotNull { x ->
                GoalMove(x.str("id") ?: return@mapNotNull null, x.str("goal") ?: return@mapNotNull null, date(x.str("date")) ?: return@mapNotNull null, Money(x.long("amount_sen") ?: return@mapNotNull null))
            },
            notificationsSent = strMap("notificationsSent"),
            importKeys = strMap("importKeys"),
            knownReceipts = m.objList("knownReceipts").mapNotNull { k ->
                KnownReceipt(k.str("id") ?: return@mapNotNull null, k.str("merchant"), date(k.str("date")), k.long("total_sen")?.let { Money(it) },
                    k.str("receipt_id"), (k["items"] as? List<Any?>)?.mapNotNull { it as? String } ?: emptyList())
            },
            notifPrefs = prefs,
            unknown = m.filterKeys { it !in KNOWN },
        )
    }

    private const val CURRENT = EngineStore.CURRENT_VERSION
}
