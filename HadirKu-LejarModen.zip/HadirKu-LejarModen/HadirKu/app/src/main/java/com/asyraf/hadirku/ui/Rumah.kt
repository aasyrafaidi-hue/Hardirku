@file:OptIn(ExperimentalLayoutApi::class)

package com.asyraf.hadirku.ui

import com.asyraf.hadirku.BuildConfig
import com.asyraf.hadirku.ai.Ai
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.focus.FocusRequester
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.asyraf.hadirku.MainViewModel
import com.asyraf.hadirku.Sheet
import com.asyraf.hadirku.kongsi.Barang
import com.asyraf.hadirku.kongsi.Kongsi
import com.asyraf.hadirku.kongsi.Status
import com.asyraf.hadirku.rumah.Belanja
import com.asyraf.hadirku.rumah.Dapur
import com.asyraf.hadirku.rumah.Peringatan
import com.asyraf.hadirku.pg.PG
import kotlinx.coroutines.launch
import java.time.YearMonth

/* ======================================================================
 *  Rumah tangga: senarai barang dapur (unit, harga, MyKasih), nafkah
 *  dan sambungan kongsi dengan isteri.
 * ====================================================================== */

/** Notis status sambungan Firebase (hanya bila belum sedia). */
@Composable
fun KongsiStatusNotice() {
    val st by Kongsi.status.collectAsState()
    val ralat by Kongsi.ralat.collectAsState()
    when (st) {
        Status.SEDIA -> {}
        Status.SAMBUNG, Status.MATI -> Notice(rich("Menyambung ke Firebase untuk kongsi dengan suami…"), Tone.INFO)
        Status.RALAT -> Notice(rich(ralat.ifEmpty { "Tak dapat bersambung." }), Tone.WARN, "Cuba lagi") { Kongsi.cubaLagi() }
    }
}

// ---------------- Barang dapur (senarai beli, dikongsi dengan isteri) ----------------

// lebar lajur jadual barang (kepala & baris mesti sama)
private val W_TICK = 40.dp
private val W_UNIT = 34.dp
private val W_JUM = 72.dp
private val COL_GAP = 6.dp

// had disimpan dalam prefs telefon ini; versi ini memaksa skrin dikira semula selepas had diubah
private val dapurVer = androidx.compose.runtime.mutableIntStateOf(0)
/** Had belanja dapur sendiri (RM) — null kalau tiada (guna bajet dapur Pusat Kewangan). */
private fun hadSendiri(): Double? = com.asyraf.hadirku.data.Repo.getStr("dapur.had").toDoubleOrNull()?.takeIf { it > 0.004 }
private fun bakiMyKasih(): Double? = com.asyraf.hadirku.data.Repo.getStr("dapur.mykasih").toDoubleOrNull()?.takeIf { it > 0.004 }

/** Baki bajet kategori "dapur" bulan ini (RM), null kalau tiada bajet dapur. */
@Composable
private fun rememberBajetDapur(vm: MainViewModel): Double? {
    val s by vm.pg.collectAsState()
    val bajet = rememberRingkasanEnjin(vm, s)?.budgets?.find { it.budget.category == "dapur" } ?: return null
    return Math.max(0L, bajet.remaining.sen) / 100.0
}

/** Had yang digunakan + sumbernya: had sendiri, atau baki bajet dapur bulan ini. */
@Composable
private fun rememberHad(vm: MainViewModel): Pair<Double?, String> {
    dapurVer.intValue
    val bajet = rememberBajetDapur(vm)
    val sendiri = hadSendiri()
    // app isteri: baki duit dapur dari suami jadi had troli (live)
    val nf by Kongsi.nafkah.collectAsState()
    val dapur = if (BuildConfig.ISTERI) com.asyraf.hadirku.kongsi.Rumahtangga.bakiDapur(nf.filter { it.dari != Kongsi.uid() }) else null
    return when {
        sendiri != null -> sendiri to "had anda"
        dapur != null -> dapur to "baki duit dapur"
        bajet != null -> bajet to "baki bajet dapur bulan ini"
        else -> null to ""
    }
}

/**
 * Senarai barang dapur — troli ringkas untuk dibawa ke kedai: ambil barang → catat harga → nampak jumlah vs had
 * supaya tidak terlebih belanja. Barang MyKasih dikira berasingan (kredit MyKasih, bukan duit poket).
 */
@Composable
fun SenaraiScreen(vm: MainViewModel) {
    val pal = LocalPal.current
    val list by Kongsi.barang.collectAsState()
    val sej by Kongsi.sejarah.collectAsState()
    val today = vm.today()
    KongsiStatusNotice()
    val r = remember(list) { Dapur.ringkasan(list) }
    val troli = remember(list) { list.filter { it.dibeli } }
    val belum = remember(list) { list.filter { !it.dibeli } }
    val (had, sumberHad) = rememberHad(vm)
    val mkBaki = run { dapurVer.intValue; bakiMyKasih() }
    val tro = r.sendiri.jumlahTroli
    val mkTro = r.mykasih.jumlahTroli
    val baki = if (had != null) Dapur.bakiHad(tro, had) else 0.0
    val lebih = had != null && baki < -0.004

    // ---------- kepala: jumlah troli vs had ----------
    Block(Modifier.pressable({ vm.open(Sheet.DapurHad) }, scaleTo = 0.99f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Txt("Dalam troli (duit sendiri)", size = 12.5f, color = pal.muted)
                AutoMoney(M(tro), 26f, Modifier.fillMaxWidth(), color = if (lebih) pal.bad else Color.Unspecified)
            }
            Column(horizontalAlignment = Alignment.End) {
                Txt("Had", size = 12f, color = pal.muted)
                Txt(if (had != null) M(had) else "Tetapkan", size = 15f, weight = FontWeight.SemiBold, color = if (had != null) pal.ink else pal.accent, num = true)
            }
        }
        if (had != null) {
            Spacer(Modifier.height(8.dp))
            Bar(if (had > 0) tro / had else 1.0, over = lebih, warn = !lebih && tro > had * 0.85)
            Spacer(Modifier.height(6.dp))
            Txt(
                if (lebih) "Melebihi had " + M(-baki) else "Boleh belanja lagi " + M(baki) + " · " + sumberHad,
                size = 13f, weight = if (lebih) FontWeight.SemiBold else FontWeight.Normal, color = if (lebih) pal.bad else pal.muted,
            )
        }
        if (mkTro > 0.004 || mkBaki != null) {
            Spacer(Modifier.height(8.dp))
            val mkLebih = mkBaki != null && mkTro > mkBaki + 0.004
            KvLine("MyKasih") { Txt(M(mkTro) + (if (mkBaki != null) " / " + M(mkBaki) else ""), size = 13.5f, num = true, color = if (mkLebih) pal.bad else pal.ink) }
        }
    }

    // duit dapur dari suami: guna & baki live
    DuitDapurCard(vm)

    // ---------- troli ----------
    if (troli.isNotEmpty()) {
        SecHead("Troli", right = troli.size.toString() + " barang")
        ListBlock {
            TroliKepala()
            troli.forEach { b -> TroliRow(vm, b) }
            Row(Modifier.fillMaxWidth().background(pal.surface2).padding(start = 12.dp, end = 12.dp, top = 10.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Txt("Jumlah", Modifier.weight(1f), size = 14f, weight = FontWeight.SemiBold)
                Txt(M(PG.round2(tro + mkTro)), size = 15f, weight = FontWeight.Bold, num = true)
            }
        }
        val tanpa = troli.count { !it.adaHarga }
        if (tanpa > 0) Note("Ada barang dalam troli belum ada harga. Tekan barang itu untuk isi harga.")
        if (r.sendiri.troli.isNotEmpty()) {
            Btn("Selesai · rekod belanja " + M(tro), { vm.rekodBelanjaBarang() }, Modifier.fillMaxWidth().padding(horizontal = GL), kind = BtnKind.PRIMARY)
            Btn("Selesai tanpa rekod", { vm.buangBarangDitick() }, Modifier.fillMaxWidth().padding(horizontal = GL))
        } else Btn("Selesai beli MyKasih (" + troli.size + ")", { vm.buangBarangDitick() }, Modifier.fillMaxWidth().padding(horizontal = GL), kind = BtnKind.PRIMARY)
    } else if (belum.isEmpty()) {
        Empty(rich("Troli kosong. Di kedai, tekan **Ambil barang** setiap kali masukkan barang ke troli. Jumlah dan baki had dikira terus supaya tak terlebih belanja."))
    }

    // ---------- senarai belum ambil (dari isteri / dirancang) ----------
    if (belum.isNotEmpty()) {
        SecHead("Belum ambil", right = belum.size.toString())
        ListBlock { belum.forEach { b -> BelumRow(vm, b) } }
    }

    // ---------- beli semula (automatik dari sejarah) ----------
    val ada = remember(list) { list.map { Kongsi.kunciBarang(it.nama) }.toSet() }
    val cad = remember(sej, ada, today) { Belanja.cadangan(sej, ada, today) { Kongsi.kunciBarang(it) } }
    if (cad.isNotEmpty()) {
        SecHead("Biasa dibeli")
        ListBlock {
            cad.take(5).forEach { c ->
                Row(Modifier.fillMaxWidth().hairlines(pal.line).padding(horizontal = GL, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Txt(c.nama + (if (c.harga > 0.004) " · " + M(c.harga) else "") + (if (c.mykasih) " · MyKasih" else ""), Modifier.weight(1f), size = 14f, maxLines = 1)
                    Btn("+ Senarai", { Kongsi.tambahBarang(c.nama, harga = c.harga, mykasih = c.mykasih); vm.toast(c.nama + " ditambah") }, kind = BtnKind.SMALL)
                }
            }
        }
    }
}

@Composable
private fun TroliKepala() {
    val pal = LocalPal.current
    Row(
        Modifier.fillMaxWidth().background(pal.surface2).hairlines(pal.line).padding(start = 12.dp, end = 12.dp, top = 7.dp, bottom = 7.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(COL_GAP),
    ) {
        Kepala("Barang", Modifier.weight(1f))
        Kepala("Unit", Modifier.width(W_UNIT), TextAlign.End)
        Kepala("RM", Modifier.width(W_JUM), TextAlign.End)
    }
}

@Composable
private fun Kepala(t: String, m: Modifier, align: TextAlign = TextAlign.Start) {
    Txt(t, m, size = 11.5f, weight = FontWeight.SemiBold, color = LocalPal.current.muted, align = align, maxLines = 1)
}

/** Satu baris troli: Barang | Unit | RM. Tekan untuk ubah / buang. */
@Composable
private fun TroliRow(vm: MainViewModel, b: Barang) {
    val pal = LocalPal.current
    Row(
        Modifier.fillMaxWidth().hairlines(pal.line).pressable({ vm.open(Sheet.BarangForm(b.id)) }, scaleTo = 0.985f).heightIn(min = 46.dp).padding(start = 12.dp, end = 12.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(COL_GAP),
    ) {
        Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
            Txt(b.nama, Modifier.weight(1f, fill = false), size = 14f, weight = FontWeight.Medium, maxLines = 2)
            if (b.mykasih) { Spacer(Modifier.width(6.dp)); Pill("MyKasih", Tone.INFO) }
        }
        Txt(Dapur.fmtUnit(b.unit), Modifier.width(W_UNIT), size = 13f, align = TextAlign.End, num = true, maxLines = 1)
        Txt(if (b.adaHarga) Dapur.fmtRm(b.jumlah) else "–", Modifier.width(W_JUM), size = 13.5f, weight = FontWeight.SemiBold,
            color = if (b.adaHarga) pal.ink else pal.muted, align = TextAlign.End, num = true, maxLines = 1)
    }
}

/** Barang dirancang (belum ambil): tekan kotak untuk masuk troli (tiada harga → terus buka untuk isi harga). */
@Composable
private fun BelumRow(vm: MainViewModel, b: Barang) {
    val pal = LocalPal.current
    Row(
        Modifier.fillMaxWidth().hairlines(pal.line).pressable({ vm.open(Sheet.BarangForm(b.id)) }, scaleTo = 0.985f).heightIn(min = 48.dp).padding(end = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.width(W_TICK + 8.dp).height(46.dp).clickable {
            // ada harga → terus masuk troli; tiada harga → buka borang (masuk troli bila disimpan)
            if (b.adaHarga) Kongsi.tickBarang(b.id, true) else vm.open(Sheet.BarangForm(b.id, troli = true))
        }, contentAlignment = Alignment.Center) {
            Box(Modifier.size(24.dp).border(1.5.dp, pal.lineStrong, RoundedCornerShape(7.dp)))
        }
        Column(Modifier.weight(1f)) {
            Txt(b.nama, size = 14f, weight = FontWeight.Medium, maxLines = 2)
            val sub = listOfNotNull(
                if (b.adaHarga) M(b.jumlah) else null,
                if (b.mykasih) "MyKasih" else null,
                b.nota.ifEmpty { null },
                if (b.oleh.isNotEmpty() && b.oleh != Kongsi.uid()) "oleh " + Kongsi.namaAhli(b.oleh) else null,
            )
            if (sub.isNotEmpty()) Txt(sub.joinToString(" · "), size = 11.5f, color = pal.muted, maxLines = 1)
        }
    }
}

/** Ambil barang baru ([id] null → terus masuk troli) atau ubah barang sedia ada. */
@Composable
fun BarangFormSheet(vm: MainViewModel, id: String?, troli0: Boolean? = null) {
    val pal = LocalPal.current
    val la = launch()
    val scope = rememberCoroutineScope()
    val list by Kongsi.barang.collectAsState()
    val b0 = remember(id) { if (id != null) Kongsi.barang.value.find { it.id == id } else null }
    val sej by Kongsi.sejarah.collectAsState()
    var nama by remember { mutableStateOf(b0?.nama ?: "") }
    var unit by remember { mutableStateOf(if (b0 != null && b0.unit != 1.0) Dapur.fmtUnit(b0.unit) else "") }
    var harga by remember { mutableStateOf(if (b0 != null && b0.adaHarga) PG.toFixed(b0.harga, 2) else "") }
    var mk by remember { mutableStateOf(b0?.mykasih ?: false) }
    var keTroli by remember { mutableStateOf(troli0 ?: b0?.dibeli ?: true) }
    var err by remember { mutableStateOf("") }
    var n by remember { mutableStateOf(0) }
    var baca by remember { mutableStateOf(false) }
    var aiNota by remember { mutableStateOf("") }
    val frNama = autoFocus(id == null)
    val frHarga = remember { FocusRequester() }
    val frUnit = remember { FocusRequester() }
    val u = Dapur.bacaUnit(unit)
    val h = Dapur.bacaHarga(harga)
    val (had, _) = rememberHad(vm)
    // harga kali lepas untuk barang yang sama (dari sejarah beli)
    val lepas = remember(nama, sej) {
        if (nama.isBlank()) null else { val k = Kongsi.kunciBarang(nama); sej.find { Kongsi.kunciBarang(it.nama) == k && it.harga > 0.004 } }
    }
    val item = if (u != null && h != null) PG.round2(u * h) else 0.0
    val selepas = Dapur.troliSelepas(list, id, item, keTroli, mk)
    fun simpan(): Boolean {
        err = vm.simpanBarang(id, nama, b0?.nota ?: "", unit, harga, mk, keTroli)
        if (err.isNotEmpty()) { if (nama.isBlank()) runCatching { frNama.requestFocus() }; return false }
        if (id == null) { n++; nama = ""; unit = ""; harga = ""; aiNota = "" } // MyKasih & status kekal untuk barang seterusnya
        return true
    }
    /** Enter pada medan terakhir: barang baru → simpan & sedia barang seterusnya; ubah → simpan & tutup. */
    fun enterAkhir() {
        if (id == null) { if (simpan()) runCatching { frNama.requestFocus() } } else if (simpan()) vm.close()
    }
    // snap tanda harga / barang → AI isi nama, harga, unit (lebih satu barang → Isi pantas)
    fun snap(uri: android.net.Uri) {
        if (baca) return
        baca = true; err = ""; aiNota = ""
        scope.launch {
            try {
                val prep = vm.prepFile(uri)
                val r = Ai.bacaBarang("", prep.block, Kongsi.sejarah.value, Kongsi::kunciBarang, vm.today())
                baca = false
                when {
                    r.items.isEmpty() -> err = r.nota.ifEmpty { "Tiada barang dapat dibaca. Cuba snap lebih dekat pada tanda harga." }
                    r.items.size == 1 -> {
                        val c = r.items[0]
                        nama = c.nama; harga = if (c.adaHarga) PG.toFixed(c.harga, 2) else ""
                        unit = if (c.unit == 1.0) "" else Dapur.fmtUnit(c.unit); if (c.mykasih) mk = true
                        aiNota = listOf(if (c.hargaLepas) "Harga ikut kali lepas — semak tanda harga." else "Dibaca AI — semak sebelum masuk troli.", r.nota).filter { it.isNotEmpty() }.joinToString(" ")
                        runCatching { (if (c.adaHarga) frUnit else frHarga).requestFocus() }
                    }
                    else -> vm.open(Sheet.DapurAi(r.items, r.nota))
                }
            } catch (e: Exception) {
                baca = false; err = e.message ?: "Tak dapat baca gambar."
            }
        }
    }
    SheetBody(actions = {
        if (id == null) SheetActions(if (keTroli) "Masuk troli" else "Simpan", { if (simpan()) vm.close() }, { vm.close() }, cancel = "Tutup", extra = "Tambah lagi", onExtra = { if (simpan()) runCatching { frNama.requestFocus() } })
        else SheetActions("Simpan", { if (simpan()) vm.close() }, { vm.close() })
    }) {
        SheetTitle(if (id != null) "Ubah barang" else "Ambil barang", if (id == null && n > 0) rich("**$n** barang ditambah.") else null)
        if (id == null) {
            // isi guna AI: snap tanda harga, atau tulis / sebut senarai
            Row(Modifier.fillMaxWidth().padding(horizontal = GL).padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Btn(if (baca) "Membaca…" else "Snap tanda harga", {
                    if (!Ai.ready()) err = "Snap guna AI perlukan kunci API. Tetapkan di " + Ai.TEMPAT + "." else if (!baca) la.takePhoto { snap(it) }
                }, Modifier.weight(1f), kind = BtnKind.SMALL)
                Btn("Isi pantas (AI)", { vm.open(Sheet.DapurAi()) }, Modifier.weight(1f), kind = BtnKind.SMALL)
            }
        }
        // jumlah troli selepas barang ini, berbanding had
        if (had != null && keTroli && !mk) {
            val baki = Dapur.bakiHad(selepas, had)
            val lebih = baki < -0.004
            Box(Modifier.fillMaxWidth().padding(horizontal = GL).padding(bottom = 8.dp)) {
                Txt(
                    rich("Selepas ini troli **" + M(selepas) + "** · " + (if (lebih) "melebihi had " + M(-baki) else "baki had " + M(baki))),
                    size = 13f, color = if (lebih) pal.bad else pal.muted,
                )
            }
        }
        Form {
            FieldText("Barang", nama, { nama = it; aiNota = "" }, placeholder = "cth: Beras 10kg", maxLen = 60, fr = frNama, capital = true,
                ime = ImeAction.Next, onEnter = { runCatching { frHarga.requestFocus() } }, small = aiNota.ifEmpty { null })
            FieldText(
                "Harga seunit (RM)", harga, { harga = it }, placeholder = "0.00", kb = KeyboardType.Decimal, maxLen = 10, fr = frHarga,
                ime = ImeAction.Next, onEnter = { runCatching { frUnit.requestFocus() } },
                small = if (lepas != null && harga.isBlank()) "Kali lepas " + M(lepas.harga) + (if (lepas.mykasih) " (MyKasih)" else "") else null,
                after = { if (lepas != null && harga.isBlank()) LinkBtn("Guna harga lepas", { harga = PG.toFixed(lepas.harga, 2); mk = lepas.mykasih }) },
            )
            FieldText("Unit", unit, { unit = it }, placeholder = "1", kb = KeyboardType.Decimal, maxLen = 7, fr = frUnit,
                ime = ImeAction.Done, onEnter = { enterAkhir() },
                small = if (u != null && h != null && h > 0.004 && u != 1.0) "Jumlah harga " + M(item) else null)
            FieldChips("Bayar guna", listOf("sendiri" to "Duit sendiri", "mykasih" to "MyKasih"), if (mk) "mykasih" else "sendiri", { mk = it == "mykasih" }, stack = false)
            FieldChips("Status", listOf("troli" to "Dah ambil (troli)", "senarai" to "Belum ambil"), if (keTroli) "troli" else "senarai", { keTroli = it == "troli" }, stack = false)
        }
        Box(Modifier.padding(horizontal = GL)) { FormError(err) }
        if (id == null) Note("Tekan Enter untuk ke medan seterusnya. Enter pada Unit terus simpan dan sedia untuk barang seterusnya.", Modifier.padding(top = 8.dp))
        if (mk) Note("MyKasih dibayar guna kredit MyKasih, jadi tidak ditolak dari poket dan tidak masuk had.", Modifier.padding(top = 8.dp))
        if (id == null && Kongsi.hid().isEmpty()) Note("Belum bersambung ke Firebase. Sambung ke internet sekali untuk aktifkan senarai kongsi.", Modifier.padding(top = 8.dp))
        if (id != null) {
            Spacer(Modifier.height(8.dp))
            DelZone("Buang barang", if (BuildConfig.ISTERI) "Buang barang ini dari senarai (untuk kau dan suami)?" else "Buang barang ini dari senarai (untuk kau dan isteri)?", { Kongsi.padamBarang(id); vm.close(); vm.toast("Barang dibuang") })
        }
    }
}

/**
 * Isi pantas: tulis / sebut (papan kekunci suara) senarai barang, atau snap tanda harga, resit atau senarai tulisan tangan.
 * AI senaraikan nama, unit, harga & MyKasih; tanpa kunci AI (atau tiada internet) teks dihurai ikut format "nama harga".
 * Pengguna semak & pilih barang sebelum ditambah — tiada apa disimpan tanpa tekan Tambah.
 */
@Composable
fun DapurAiSheet(vm: MainViewModel, awal: List<Dapur.Cadang>, nota0: String) {
    val pal = LocalPal.current
    val la = launch()
    val scope = rememberCoroutineScope()
    val list by Kongsi.barang.collectAsState()
    var teks by remember { mutableStateOf("") }
    var items by remember { mutableStateOf(awal) }
    var pilih by remember { mutableStateOf(awal.indices.toSet()) }
    var nota by remember { mutableStateOf(nota0) }
    var baca by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    var keTroli by remember { mutableStateOf(awal.isEmpty() || awal.any { it.adaHarga }) }
    val (had, _) = rememberHad(vm)
    val fr = autoFocus(awal.isEmpty())

    fun tunjuk(r: List<Dapur.Cadang>, n: String) {
        if (r.isEmpty()) { err = n.ifEmpty { "Tiada barang dapat dibaca. Tulis satu barang sebaris, cth: Beras 10kg 32.90" }; return }
        items = r; pilih = r.indices.toSet(); nota = n; err = ""; keTroli = r.any { it.adaHarga }
    }
    fun tanpaAi(n: String) = tunjuk(Dapur.lengkapkan(Dapur.huraiTeks(teks), Kongsi.sejarah.value, Kongsi::kunciBarang), n)
    fun hurai() {
        if (baca.isNotEmpty()) return
        if (teks.isBlank()) { err = "Tulis atau sebut barang dulu."; return }
        err = ""
        if (!Ai.ready()) { tanpaAi(""); return }
        baca = "AI sedang membaca senarai…"
        scope.launch {
            try {
                val r = Ai.bacaBarang(teks, null, Kongsi.sejarah.value, Kongsi::kunciBarang, vm.today())
                baca = ""; tunjuk(r.items, r.nota)
            } catch (e: Exception) {
                baca = ""; tanpaAi("AI tak dapat dihubungi, jadi senarai dihurai tanpa AI. Semak nama dan harga.")
            }
        }
    }
    fun gambar(uri: android.net.Uri) {
        if (baca.isNotEmpty()) return
        err = ""; baca = "AI sedang membaca gambar…"
        scope.launch {
            try {
                val prep = vm.prepFile(uri)
                val r = Ai.bacaBarang(teks, prep.block, Kongsi.sejarah.value, Kongsi::kunciBarang, vm.today())
                baca = ""; tunjuk(r.items, r.nota)
            } catch (e: Exception) {
                baca = ""; err = e.message ?: "Tak dapat baca gambar."
            }
        }
    }
    fun perluKunci() { err = "Baca gambar perlukan kunci API AI. Tetapkan di " + Ai.TEMPAT + "." }

    val dipilih = items.filterIndexed { i, _ -> i in pilih }
    SheetBody(actions = {
        if (items.isEmpty()) SheetActions(if (baca.isNotEmpty()) "Membaca…" else if (Ai.ready()) "Baca guna AI" else "Hurai senarai", { hurai() }, { vm.close() })
        else SheetActions(
            "Tambah barang dipilih (" + dipilih.size + ")", {
                when {
                    dipilih.isEmpty() -> err = "Pilih sekurang-kurangnya satu barang."
                    Kongsi.hid().isEmpty() -> err = "Belum bersambung ke Firebase. Semak internet, kemudian cuba lagi."
                    else -> { vm.tambahBarangBanyak(dipilih, keTroli); vm.close() }
                }
            }, { vm.close() }, extra = "Baca semula", onExtra = { items = emptyList(); pilih = emptySet(); nota = ""; err = "" },
        )
    }) {
        if (items.isEmpty()) {
            SheetTitle("Isi pantas", rich("Tulis atau **sebut** senarai barang, atau snap tanda harga, resit atau senarai tulisan tangan."))
            Form {
                FieldText("Senarai barang", teks, { teks = it }, placeholder = "cth: Beras 10kg 32.90, Minyak 2 x 7.50, Susu 12 mykasih",
                    lines = 4, maxLen = 3000, fr = fr, capital = true,
                    small = "Satu barang sebaris atau pisah dengan koma. Untuk sebut, tekan ikon mikrofon pada papan kekunci.")
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = GL).padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Btn("Kamera", { if (!Ai.ready()) perluKunci() else la.takePhoto { gambar(it) } }, Modifier.weight(1f), kind = BtnKind.SMALL)
                Btn("Galeri", { if (!Ai.ready()) perluKunci() else la.pickScan { gambar(it) } }, Modifier.weight(1f), kind = BtnKind.SMALL)
            }
            if (baca.isNotEmpty()) Txt(baca, Modifier.padding(horizontal = GL).padding(top = 10.dp), size = 13f, weight = FontWeight.SemiBold, color = pal.accent)
            Box(Modifier.padding(horizontal = GL)) { FormError(err) }
            if (!Ai.ready()) Note("Tanpa kunci AI, teks dihurai ikut format nama + harga dan snap gambar tidak tersedia. Tetapkan kunci di " + Ai.TEMPAT + " supaya AI faham ayat biasa dan gambar.", Modifier.padding(top = 8.dp))
        } else {
            SheetTitle("Barang dijumpai: " + items.size, rich("Tekan barang untuk pilih atau buang. Harga boleh diubah selepas ditambah."))
            if (had != null && keTroli) {
                val selepas = PG.round2(Dapur.jumlahRekod(list) + Dapur.jumlahCadang(dipilih))
                val baki = Dapur.bakiHad(selepas, had)
                val lebih = baki < -0.004
                Box(Modifier.fillMaxWidth().padding(horizontal = GL).padding(bottom = 8.dp)) {
                    Txt(rich("Selepas ini troli **" + M(selepas) + "** · " + (if (lebih) "melebihi had " + M(-baki) else "baki had " + M(baki))),
                        size = 13f, weight = if (lebih) FontWeight.SemiBold else FontWeight.Normal, color = if (lebih) pal.bad else pal.muted)
                }
            }
            Form {
                FieldChips("Status", listOf("troli" to "Masuk troli", "senarai" to "Belum ambil"), if (keTroli) "troli" else "senarai", { keTroli = it == "troli" }, stack = false)
            }
            Spacer(Modifier.height(8.dp))
            ListBlock {
                items.forEachIndexed { i, c ->
                    val on = i in pilih
                    Row(
                        Modifier.fillMaxWidth().hairlines(pal.line).clickable { pilih = if (on) pilih - i else pilih + i }.heightIn(min = 48.dp).padding(start = 12.dp, end = 12.dp, top = 6.dp, bottom = 6.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Box(
                            Modifier.size(24.dp).background(if (on) pal.accent else Color.Transparent, RoundedCornerShape(7.dp))
                                .border(1.5.dp, if (on) pal.accent else pal.lineStrong, RoundedCornerShape(7.dp)),
                            contentAlignment = Alignment.Center,
                        ) { if (on) Txt("✓", size = 14f, weight = FontWeight.Bold, color = Color.White) }
                        Column(Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Txt(c.nama, Modifier.weight(1f, fill = false), size = 14f, weight = FontWeight.Medium, maxLines = 2, color = if (on) pal.ink else pal.muted)
                                if (c.mykasih) { Spacer(Modifier.width(6.dp)); Pill("MyKasih", Tone.INFO) }
                            }
                            val sub = listOfNotNull(
                                if (c.adaHarga) (if (c.unit != 1.0) Dapur.fmtUnit(c.unit) + " × " else "") + M(c.harga) else "tiada harga",
                                if (c.hargaLepas) "harga lepas" else null,
                            )
                            Txt(sub.joinToString(" · "), size = 11.5f, color = if (c.hargaLepas || !c.adaHarga) pal.warn else pal.muted, maxLines = 1)
                        }
                        Txt(if (c.adaHarga) Dapur.fmtRm(c.jumlah) else "–", Modifier.width(W_JUM), size = 13.5f, weight = FontWeight.SemiBold,
                            align = TextAlign.End, num = true, maxLines = 1, color = if (on) pal.ink else pal.muted)
                    }
                }
            }
            if (nota.isNotEmpty()) Note(nota, Modifier.padding(top = 8.dp))
            Box(Modifier.padding(horizontal = GL)) { FormError(err) }
        }
    }
}

/** Had belanja dapur & baki MyKasih (disimpan dalam telefon ini). */
@Composable
fun DapurHadSheet(vm: MainViewModel) {
    val bajet = rememberBajetDapur(vm)
    var had by remember { mutableStateOf(hadSendiri()?.let { PG.toFixed(it, 2) } ?: "") }
    var mk by remember { mutableStateOf(bakiMyKasih()?.let { PG.toFixed(it, 2) } ?: "") }
    SheetBody(actions = {
        SheetActions("Simpan", {
            val h = vm.parseAmt(had); val m = vm.parseAmt(mk)
            com.asyraf.hadirku.data.Repo.putStr("dapur.had", if (h.isFinite() && h > 0) PG.toFixed(h, 2) else "")
            com.asyraf.hadirku.data.Repo.putStr("dapur.mykasih", if (m.isFinite() && m > 0) PG.toFixed(m, 2) else "")
            dapurVer.intValue++
            vm.close(); vm.toast("Had disimpan")
        }, { vm.close() })
    }) {
        SheetTitle("Had belanja dapur", rich("Troli bertukar merah bila jumlah melebihi had."))
        Form {
            FieldText("Had belanja (RM)", had, { had = it }, placeholder = if (bajet != null) "ikut bajet dapur" else "cth 250", kb = KeyboardType.Decimal, big = true,
                small = if (bajet != null) "Kosongkan untuk guna baki bajet dapur bulan ini (" + M(bajet) + ")" else "Kosongkan kalau tak mahu had.")
            FieldText("Baki MyKasih (RM, pilihan)", mk, { mk = it }, placeholder = "0.00", kb = KeyboardType.Decimal)
        }
    }
}

// ---------------- Nafkah ----------------

/* ---------------- Nafkah, duit dapur, minta duit & tabung bersama (live antara dua app) ---------------- */

private fun uidSaya(): String = Kongsi.uid() ?: ""
private fun hariLabel(h: Int): String = if (h >= 31) "hujung bulan" else "${h}hb"

/**
 * Tindakan yang menunggu di atas tab Utama — dipapar hanya bila ada sesuatu untuk ditekan.
 * Isteri: nafkah / duit dapur untuk diterima. Suami: permintaan isteri, baki duit dapur dipulangkan, nafkah bulanan belum dihantar.
 */
@Composable
fun NafkahNotice(vm: MainViewModel) {
    val list by Kongsi.nafkah.collectAsState()
    val jadual by Kongsi.jadual.collectAsState()
    val st by Kongsi.status.collectAsState()
    if (st != com.asyraf.hadirku.kongsi.Status.SEDIA) return
    val u = uidSaya()
    val today = vm.today()
    val items = ArrayList<Triple<AnnotatedString, String, () -> Unit>>()
    if (BuildConfig.ISTERI) {
        list.filter { it.dihantar && !it.diterima && it.dari != u }.take(3).forEach { n ->
            items += Triple(rich("**" + M(n.jumlah) + "** " + (if (n.dapur) "duit dapur" else "nafkah") + " dari " + Kongsi.namaAhli(n.dari) +
                (if (n.catatan.isNotEmpty()) " · " + n.catatan else "")), "Terima", { vm.terimaNafkah(n.id) })
        }
    } else {
        list.filter { it.tungguJawapan && it.peminta != u }.take(3).forEach { n ->
            items += Triple(rich(Kongsi.namaAhli(n.peminta) + " minta **" + M(n.jumlah) + "**" + (if (n.dapur) " untuk dapur" else "") +
                (if (n.catatan.isNotEmpty()) " · " + n.catatan else "")), "Lulus", { vm.lulusMinta(n.id) })
        }
        list.filter { it.dari == u && it.pulangBelumDirekod }.take(2).forEach { n ->
            items += Triple(rich("Baki duit dapur **" + M(n.pulang) + "** dipulangkan"), "Rekod", { vm.terimaPulangDapur(n.id) })
        }
        if (com.asyraf.hadirku.kongsi.Rumahtangga.perluHantarNafkah(jadual, list.filter { it.dari == u }, today)) {
            val j = jadual!!
            items += Triple(rich("Nafkah bulanan **" + M(j.jumlah) + "** belum dihantar bulan ini"), "Hantar", { vm.hantarNafkah(jumlah = j.jumlah) })
        }
    }
    if (items.isEmpty()) return
    Column(Modifier.padding(horizontal = GL), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEach { (t, b, f) -> Notice(t, Tone.GOOD, b, f) }
    }
}

/** Duit dapur yang sedang digunakan: jumlah, belanja, baki (live di kedua-dua telefon). */
@Composable
fun DuitDapurCard(vm: MainViewModel) {
    val pal = LocalPal.current
    val list by Kongsi.nafkah.collectAsState()
    val u = uidSaya()
    val aktif = list.filter { (if (BuildConfig.ISTERI) it.dari != u else it.dari == u) && it.dihantar && it.dapur && !it.selesai }
    if (aktif.isEmpty()) return
    ListBlock {
        aktif.forEachIndexed { i, n ->
            Column(Modifier.fillMaxWidth().hairlines(pal.line, bottom = i < aktif.lastIndex).padding(horizontal = GL, vertical = 11.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Txt("Duit dapur " + M(n.jumlah) + (if (n.tarikh.isNotEmpty()) " · " + PG.fmtShort(n.tarikh) else ""), size = 14f, weight = FontWeight.SemiBold)
                        Txt(if (!n.diterima) "Belum diterima" else "Guna " + M(n.guna) + " · baki " + M(n.baki), size = 12.5f, color = pal.muted, num = true)
                    }
                    if (BuildConfig.ISTERI && n.diterima) Btn(if (n.baki > 0.004) "Pulangkan baki" else "Selesai", { vm.pulangDapur(n.id) }, kind = BtnKind.SMALL)
                    else if (!n.diterima) Pill("Menunggu", Tone.NEUTRAL)
                }
                if (n.diterima) { Spacer(Modifier.height(8.dp)); Bar(if (n.jumlah > 0) (n.guna + n.pulang) / n.jumlah else 0.0, warn = n.baki < n.jumlah * 0.15) }
            }
        }
    }
}

/** Bayaran → Komitmen: nafkah & duit dapur (suami hantar / isteri terima & minta) serta nafkah bulanan. */
@Composable
fun NafkahBlock(vm: MainViewModel) {
    val pal = LocalPal.current
    val list by Kongsi.nafkah.collectAsState()
    val jadual by Kongsi.jadual.collectAsState()
    val u = uidSaya()
    val isteri = BuildConfig.ISTERI
    if (isteri) SecHead("Nafkah & duit dapur", "Minta duit") { vm.open(Sheet.MintaDuit) }
    else SecHead("Nafkah & duit dapur")
    if (!isteri) Row(Modifier.fillMaxWidth().padding(horizontal = GL), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Btn("Hantar nafkah", { vm.hantarNafkah() }, Modifier.weight(1f), kind = BtnKind.PRIMARY)
        Btn("Hantar duit dapur", { vm.hantarNafkah(dapur = true) }, Modifier.weight(1f))
    }
    // nafkah bulanan
    Block(if (isteri) Modifier else Modifier.pressable({ vm.open(Sheet.JadualNafkah) }, scaleTo = 0.99f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Txt("Nafkah bulanan", Modifier.weight(1f), size = 14f)
            Txt(jadual?.let { M(it.jumlah) + " · " + hariLabel(it.hari) } ?: (if (isteri) "Belum ditetapkan" else "Tetapkan"),
                size = 14f, weight = FontWeight.SemiBold, color = if (jadual == null && !isteri) pal.accent else pal.ink, num = true)
        }
        Txt(if (isteri) "Ditetapkan oleh suami. Ramalan baki jangka nafkah ini masuk setiap bulan."
            else "Isteri nampak jadual ini dan ramalan baki dia mengambil kiranya. Kau diingatkan di Utama bila sampai tarikh.",
            size = 12.5f, color = pal.muted)
    }
    DuitDapurCard(vm)
    // permintaan
    val minta = if (isteri) list.filter { it.peminta == u && (it.tungguJawapan || it.minta == "tolak") }.take(3)
        else list.filter { it.tungguJawapan && it.peminta != u }
    if (minta.isNotEmpty()) ListBlock {
        minta.forEachIndexed { i, n ->
            Row(Modifier.fillMaxWidth().hairlines(pal.line, bottom = i < minta.lastIndex).padding(horizontal = GL, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Txt((if (isteri) "Minta " else Kongsi.namaAhli(n.peminta) + " minta ") + M(n.jumlah), size = 14.5f, weight = FontWeight.SemiBold, num = true)
                    Txt((if (n.dapur) "Duit dapur" else "Nafkah") + (if (n.catatan.isNotEmpty()) " · " + n.catatan else "") + " · " + PG.fmtShort(n.tarikh), size = 12.5f, color = pal.muted)
                }
                when {
                    isteri && n.tungguJawapan -> Pill("Menunggu", Tone.NEUTRAL)
                    isteri -> Btn("Padam", { Kongsi.padamNafkah(n.id) }, kind = BtnKind.SMALL)
                    else -> Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Btn("Tolak", { vm.tolakMinta(n.id) }, kind = BtnKind.SMALL)
                        Btn("Lulus", { vm.lulusMinta(n.id) }, kind = BtnKind.SMALL)
                    }
                }
            }
        }
    }
    // sejarah ringkas
    val sej = list.filter { it.dihantar && (if (isteri) it.dari != u else it.dari == u) && !(it.dapur && !it.selesai && it.diterima) }.take(6)
    if (sej.isEmpty()) Note(if (isteri) "Nafkah dan duit dapur yang suami hantar dari app Duitku dia muncul di sini. Tekan Terima untuk rekod duit masuk."
        else "Rekod duit yang kau bagi kepada isteri. Ia dicatat sebagai Keluar dari poket kau, dan muncul dalam app isteri untuk dia tekan Terima. Baki duit dapur yang isteri pulangkan direkod semula di sini.")
    else ListBlock {
        sej.forEachIndexed { i, n ->
            Row(Modifier.fillMaxWidth().hairlines(pal.line, bottom = i < sej.lastIndex).padding(horizontal = GL, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Txt(M(n.jumlah) + (if (n.dapur) " · duit dapur" else ""), size = 15f, weight = FontWeight.SemiBold, num = true)
                    Txt((if (n.tarikh.isNotEmpty()) PG.fmtShort(n.tarikh) else "") + (if (isteri) " · " + Kongsi.namaAhli(n.dari) else "") +
                        (if (n.catatan.isNotEmpty()) " · " + n.catatan else ""), size = 12.5f, color = pal.muted)
                }
                when {
                    isteri && !n.diterima -> Btn("Terima", { vm.terimaNafkah(n.id) }, kind = BtnKind.SMALL)
                    !isteri && n.pulangBelumDirekod -> Btn("Rekod baki " + M(n.pulang), { vm.terimaPulangDapur(n.id) }, kind = BtnKind.SMALL)
                    n.dapur && n.selesai && n.pulang > 0.004 -> Pill("Baki " + M(n.pulang) + " dipulangkan", Tone.GOOD)
                    n.diterima -> Pill("✔ Diterima", Tone.GOOD)
                    else -> Pill("Belum diterima", Tone.NEUTRAL)
                }
            }
        }
    }
}

/** App isteri: minta duit daripada suami. */
@Composable
fun MintaDuitSheet(vm: MainViewModel) {
    var jumlah by remember { mutableStateOf("") }
    var jenis by remember { mutableStateOf("nafkah") }
    var sebab by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    val fr = autoFocus(true)
    SheetBody(actions = { SheetActions("Hantar", { err = vm.mintaDuit(jumlah, sebab, jenis) }, { vm.close() }) }) {
        SheetTitle("Minta duit", rich("Suami nampak permintaan ini dalam app dia. Bila dia **Lulus**, duit itu muncul di sini untuk diterima."))
        Form {
            FieldText("Jumlah (RM)", jumlah, { jumlah = it }, placeholder = "0.00", kb = KeyboardType.Decimal, big = true, fr = fr)
            FieldChips("Untuk", listOf("nafkah" to "Keperluan", "dapur" to "Duit dapur"), jenis, { jenis = it })
            FieldText("Sebab", sebab, { sebab = it }, placeholder = "cth: ubat anak, yuran sekolah", maxLen = 80)
        }
        Box(Modifier.padding(horizontal = GL)) { FormError(err) }
    }
}

/** App suami: nafkah bulanan (jumlah & tarikh). */
@Composable
fun JadualNafkahSheet(vm: MainViewModel) {
    val j = Kongsi.jadual.collectAsState().value
    var jumlah by remember { mutableStateOf(j?.let { PG.toFixed(it.jumlah, 2) } ?: "") }
    var hari by remember { mutableStateOf((j?.hari ?: 30).toString()) }
    var err by remember { mutableStateOf("") }
    val ops = listOf("1", "5", "10", "15", "25", "28", "30").map { it to it + "hb" } + listOf("31" to "Hujung bulan")
    SheetBody(actions = { SheetActions("Simpan", { err = vm.simpanJadualNafkah(jumlah, hari.toIntOrNull() ?: 30) }, { vm.close() }) }) {
        SheetTitle("Nafkah bulanan", rich("Isteri nampak jadual ini dan **ramalan baki** dia mengambil kira nafkah ini. Kau diingatkan di Utama bila sampai tarikh dan belum hantar."))
        Form {
            FieldText("Jumlah sebulan (RM)", jumlah, { jumlah = it }, placeholder = "0.00", kb = KeyboardType.Decimal, big = true,
                small = "Kosongkan untuk padam jadual.")
            FieldChips("Tarikh", if (ops.any { it.first == hari }) ops else ops + (hari to hari + "hb"), hari, { hari = it })
        }
        Box(Modifier.padding(horizontal = GL)) { FormError(err) }
    }
}

/** Tabung bersama di bahagian Matlamat (kedua-dua app). */
@Composable
fun TabungBersamaSection(vm: MainViewModel) {
    val pal = LocalPal.current
    val st by Kongsi.status.collectAsState()
    val list by Kongsi.tabung.collectAsState()
    val rumah by Kongsi.rumah.collectAsState()
    if (st != com.asyraf.hadirku.kongsi.Status.SEDIA) return
    SecHeadLinks("Tabung bersama", listOf("+ Tabung" to { vm.open(Sheet.TabungForm(null)) }))
    if (list.isEmpty()) { Note("Simpan bersama untuk tujuan keluarga (cth duit raya, percutian, rumah). Setiap telefon simpan dalam poket tabung sendiri; jumlah kedua-dua dipapar terus di kedua-dua app."); return }
    ListBlock {
        list.forEachIndexed { i, t ->
            Column(Modifier.fillMaxWidth().hairlines(pal.line, bottom = i < list.lastIndex).clickable { vm.open(Sheet.TabungGerak(t.id)) }.padding(horizontal = GL, vertical = 11.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Txt(t.nama, Modifier.weight(1f), size = 15f, weight = FontWeight.Medium, maxLines = 1)
                    Txt(M(t.jumlah) + (if (t.sasaran > 0.004) " / " + M(t.sasaran) else ""), size = 13.5f, num = true)
                }
                if (t.sasaran > 0.004) { Spacer(Modifier.height(6.dp)); Bar(t.peratus) }
                Spacer(Modifier.height(4.dp))
                val ahli = (rumah?.ahli ?: emptyList()).ifEmpty { t.ahli.keys.toList() }
                Txt(ahli.joinToString(" · ") { a -> Kongsi.namaAhli(a) + " " + M(t.ahli[a] ?: 0.0) } +
                    (if (t.tarikh.isNotEmpty()) " · sasaran " + PG.fmtDate(t.tarikh) else ""), size = 12.5f, color = pal.muted, maxLines = 2)
            }
        }
    }
}

@Composable
fun TabungFormSheet(vm: MainViewModel, id: String?) {
    val t = remember(id) { Kongsi.tabung.value.find { it.id == id } }
    var nama by remember { mutableStateOf(t?.nama ?: "") }
    var sasaran by remember { mutableStateOf(t?.sasaran?.takeIf { it > 0 }?.let { PG.toFixed(it, 2) } ?: "") }
    var tempoh by remember { mutableStateOf(if (t?.tarikh?.isNotEmpty() == true) "kekal" else "") }
    var err by remember { mutableStateOf("") }
    val today = vm.hariIni()
    val fr = autoFocus(t == null)
    fun tarikh(): String = when (tempoh) {
        "kekal" -> t?.tarikh ?: ""
        "" -> ""
        else -> YearMonth.from(today).plusMonths(tempoh.toLong()).atEndOfMonth().toString()
    }
    val ops = (t?.tarikh?.takeIf { it.isNotEmpty() }?.let { listOf("kekal" to PG.fmtDate(it)) } ?: emptyList()) +
        listOf("" to "Tiada", "3" to "3 bulan", "6" to "6 bulan", "12" to "12 bulan", "24" to "24 bulan")
    SheetBody(actions = { SheetActions("Simpan", { err = vm.simpanTabung(id, nama, sasaran, tarikh()) }, { vm.close() }) }) {
        SheetTitle(if (t != null) "Ubah tabung bersama" else "Tabung bersama baru", rich("Nampak di kedua-dua app. Setiap orang simpan dalam **poket tabung** sendiri."))
        Form {
            FieldText("Nama", nama, { nama = it }, placeholder = "cth: Duit raya 2027", maxLen = 40, fr = fr)
            FieldText("Sasaran (RM)", sasaran, { sasaran = it }, placeholder = "0.00", kb = KeyboardType.Decimal, big = true)
            FieldChips("Capai dalam", ops, tempoh, { tempoh = it })
        }
        Box(Modifier.padding(horizontal = GL)) { FormError(err) }
        if (t != null) { Spacer(Modifier.height(8.dp)); DelZone("Padam tabung", "Padam " + t.nama + " untuk kedua-dua telefon? Duit dalam poket tabung tidak berubah.", { vm.padamTabung(t.id) }) }
    }
}

@Composable
fun TabungGerakSheet(vm: MainViewModel, id: String) {
    val pal = LocalPal.current
    val list by Kongsi.tabung.collectAsState()
    val s by vm.pg.collectAsState()
    val t = list.find { it.id == id }
    if (t == null) { Empty(rich("Tabung tidak dijumpai.")); return }
    val pk = vm.poketTabung(id)
    var arah by remember { mutableStateOf("simpan") }
    var jumlah by remember { mutableStateOf("") }
    var dari by remember { mutableStateOf(PG.BELUM_AGIH) }
    var err by remember { mutableStateOf("") }
    val fr = autoFocus(true)
    val bal = remember(s) { PG.balances(s) }
    val poketOps = s.pockets.filter { it.id != pk }.map { it.id to it.nama + " · " + M(bal[it.id] ?: 0.0) }
    SheetBody(actions = { SheetActions("Simpan", { err = vm.gerakTabung(id, jumlah, arah == "simpan", dari) }, { vm.close() }, extra = "Ubah", onExtra = { vm.open(Sheet.TabungForm(id)) }) }) {
        SheetTitle(t.nama, rich("Terkumpul **" + M(t.jumlah) + "**" + (if (t.sasaran > 0.004) " / " + M(t.sasaran) else "")))
        if (t.sasaran > 0.004) Box(Modifier.padding(horizontal = GL)) { Bar(t.peratus) }
        Note("Simpanan kau dalam telefon ini: " + M(pk?.let { bal[it] } ?: 0.0) + (if (pk == null) " (poket tabung dibuat bila kau mula simpan)" else ""), Modifier.padding(top = 6.dp, bottom = 6.dp))
        Form {
            FieldChips("Tindakan", listOf("simpan" to "Simpan", "keluar" to "Keluarkan"), arah, { arah = it })
            FieldText("Jumlah (RM)", jumlah, { jumlah = it }, placeholder = "0.00", kb = KeyboardType.Decimal, big = true, fr = fr)
            FieldChips(if (arah == "simpan") "Ambil dari poket" else "Masuk ke poket", poketOps, dari, { dari = it }, stack = true)
        }
        Box(Modifier.padding(horizontal = GL)) { FormError(err) }
        Txt("Duit dipindah antara poket dalam telefon ini; bukan perbelanjaan.", Modifier.padding(horizontal = GL), size = 12.5f, color = pal.muted)
    }
}

// ---------------- Tetapan ----------------

@Composable
fun KongsiSection(vm: MainViewModel) {
    val pal = LocalPal.current
    val la = launch()
    val st by Kongsi.status.collectAsState()
    val ralat by Kongsi.ralat.collectAsState()
    val rumah by Kongsi.rumah.collectAsState()
    val scope = rememberCoroutineScope()
    var nama by remember { mutableStateOf(Kongsi.namaSaya()) }
    var kod by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val isteri = BuildConfig.ISTERI
    SecHead(if (isteri) "Kongsi dengan suami" else "Kongsi dengan isteri")
    CardGroup {
        StatusRow("Sambungan", when (st) {
            Status.SEDIA -> "✔ Bersambung · " + (rumah?.ahli?.size ?: 1) + " ahli dalam rumah ini" + (rumah?.let { r -> r.ahli.filter { it != Kongsi.uid() }.joinToString { Kongsi.namaAhli(it) }.ifEmpty { null }?.let { " ($it)" } } ?: "")
            Status.RALAT -> ralat
            else -> "Menyambung…"
        }) { if (st == Status.RALAT) Btn("Cuba lagi", { Kongsi.cubaLagi() }, kind = BtnKind.SMALL) }
        val k = rumah?.kod
        if (k != null && k.isNotEmpty()) {
            Column(Modifier.fillMaxWidth().background(pal.surface).hairlines(pal.line).padding(horizontal = GL, vertical = 12.dp)) {
                Txt("Kod rumah", size = 12f, color = pal.muted)
                Txt(k.chunked(3).joinToString(" "), size = 28f, weight = FontWeight.Bold, color = pal.accentStrong, num = true)
                Txt(if (isteri) "Beri kod ini kepada suami. Dia masukkan dalam app Duitku dia: Tetapan → Kongsi dengan isteri → Kod dari app isteri."
                    else "Kod rumah dalam app ini. Untuk kongsi dengan isteri, masukkan kod dari app Duitku Isteri di bawah.", size = 12.5f, color = pal.muted)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Btn("Salin kod", { la.copy(k, "Kod disalin") }, Modifier.weight(1f), kind = BtnKind.SMALL)
                    Btn("Kongsi kod", { la.share("kod-rumah.txt", "text/plain", "Kod rumah Duitku: $k", "Kod rumah Duitku") }, Modifier.weight(1f), kind = BtnKind.SMALL)
                }
            }
        }
    }
    CardGroup { Form {
        FieldText("Nama saya", nama, { nama = it }, placeholder = if (isteri) "cth: Sayang" else "cth: Abang", maxLen = 20, after = {
            if (nama.trim() != Kongsi.namaSaya()) LinkBtn("Simpan nama", { Kongsi.tukarNama(nama); vm.toast("Nama disimpan") })
        }, small = if (isteri) "Nama ini dipaparkan pada telefon suami, contohnya \"✔ Sayang\" pada barang yang dah dibeli."
            else "Nama ini dipaparkan pada telefon isteri, contohnya \"✔ Abang\" pada barang yang dah dibeli.")
        FieldText(if (isteri) "Kod dari app suami (pilihan)" else "Kod dari app isteri", kod, { kod = it.uppercase().filter { c -> c.isLetterOrDigit() }.take(6) }, placeholder = "Kod 6 aksara",
            small = if (isteri) "Biasanya tak perlu: suami masukkan kod rumah kau. Isi ini hanya kalau suami beri kod rumah dia. Senarai dalam rumah app ini (kalau ada) tidak dibawa bersama."
                else "Buka app isteri → Tetapan → Kongsi dengan suami untuk lihat kod 6 aksara. Senarai dalam rumah app ini (kalau ada) tidak dibawa bersama.", after = {
                if (kod.length == 6) LinkBtn(if (busy) "Menyambung…" else "Masuk rumah ini", {
                    if (!busy) { busy = true; err = ""; scope.launch { err = Kongsi.masukRumah(kod) ?: ""; busy = false; if (err.isEmpty()) { kod = ""; vm.toast(if (isteri) "Bersambung dengan app suami" else "Bersambung dengan app isteri") } } }
                })
            })
    } }
    Box(Modifier.padding(horizontal = GL)) { FormError(err) }
}

