@file:OptIn(ExperimentalLayoutApi::class)

package com.asyraf.hadirku.ui

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.asyraf.hadirku.MainViewModel
import com.asyraf.hadirku.Sheet
import com.asyraf.hadirku.kongsi.Barang
import com.asyraf.hadirku.kongsi.Kongsi
import com.asyraf.hadirku.kongsi.Status
import com.asyraf.hadirku.rumah.Belanja
import com.asyraf.hadirku.rumah.Dapur
import com.asyraf.hadirku.rumah.Peringatan
import com.asyraf.hadirku.pg.PG
import kotlinx.coroutines.launch

/* ======================================================================
 *  Rumah tangga: senarai barang dapur (unit, harga, MyKasih), nafkah
 *  dan sambungan kongsi dengan isteri.
 * ====================================================================== */

/** Notis status sambungan Firebase (hanya bila belum sedia). */
@Composable
fun KongsiStatusNotice() {
    val st by Kongsi.status.collectAsState()
    val ralat by Kongsi.ralat.collectAsState()
    when (st) {
        Status.SEDIA -> {}
        Status.SAMBUNG, Status.MATI -> Notice(rich("Menyambung ke Firebase untuk kongsi dengan suami…"), Tone.INFO)
        Status.RALAT -> Notice(rich(ralat.ifEmpty { "Tak dapat bersambung." }), Tone.WARN, "Cuba lagi") { Kongsi.cubaLagi() }
    }
}

// ---------------- Barang dapur (senarai beli, dikongsi dengan isteri) ----------------

// lebar lajur jadual barang (kepala & baris mesti sama)
private val W_TICK = 40.dp
private val W_NO = 22.dp
private val W_UNIT = 34.dp
private val W_HARGA = 60.dp
private val W_JUM = 68.dp
private val COL_GAP = 4.dp

@Composable
fun SenaraiScreen(vm: MainViewModel) {
    val pal = LocalPal.current
    val list by Kongsi.barang.collectAsState()
    val sej by Kongsi.sejarah.collectAsState()
    val today = vm.today()
    KongsiStatusNotice()
    val ada = list.map { Kongsi.kunciBarang(it.nama) }.toSet()
    val cad = remember(sej, ada, today) { Belanja.cadangan(sej, ada, today) { Kongsi.kunciBarang(it) } }
    val r = remember(list) { Dapur.ringkasan(list) }

    if (list.isEmpty()) {
        Empty(rich("Senarai dapur kosong. Tekan **Tambah barang** dan isi unit serta harga. Pilih **MyKasih** untuk barang yang dibayar guna kredit MyKasih. Isteri boleh nampak dan tambah barang yang sama dari telefon dia."))
    } else {
        // ---------- ringkasan jumlah ----------
        Block {
            Txt("Perlu bayar sendiri", size = 12f, color = pal.muted)
            Spacer(Modifier.height(4.dp))
            MoneyAnim(r.sendiri.jumlah, 24f)
            Spacer(Modifier.height(10.dp))
            KvLine("MyKasih") { Txt(M(r.mykasih.jumlah), size = 13.5f, num = true) }
            Spacer(Modifier.height(2.dp))
            KvLine("Jumlah keseluruhan") { Txt(M(r.jumlahSemua), size = 13.5f, weight = FontWeight.SemiBold, num = true) }
            val tanpa = r.sendiri.tanpaHarga + r.mykasih.tanpaHarga
            if (tanpa > 0) {
                Spacer(Modifier.height(6.dp))
                Txt("$tanpa barang belum ada harga. Tekan barang untuk isi harga.", size = 12.5f, color = pal.muted)
            }
        }
        JadualBarang(vm, "Bayar sendiri", "Jumlah bayar sendiri", r.sendiri)
        JadualBarang(vm, "MyKasih", "Jumlah MyKasih", r.mykasih)
    }

    // ---------- troli ----------
    val troli = r.troli
    if (troli.isNotEmpty()) {
        val ts = r.sendiri.troli
        val tm = r.mykasih.troli
        SecHeadLinks("Dah masuk troli (" + troli.size + ")", listOf("Batal semua" to { troli.forEach { Kongsi.tickBarang(it.id, false) } }))
        Block {
            if (ts.isNotEmpty()) KvLine("Bayar sendiri (" + ts.size + ")") { Txt(M(r.sendiri.jumlahTroli), size = 13.5f, weight = FontWeight.SemiBold, num = true) }
            if (ts.isNotEmpty() && tm.isNotEmpty()) Spacer(Modifier.height(4.dp))
            if (tm.isNotEmpty()) KvLine("MyKasih (" + tm.size + ")") { Txt(M(r.mykasih.jumlahTroli), size = 13.5f, num = true) }
        }
        if (ts.isNotEmpty()) {
            Btn("Rekod belanja " + M(r.sendiri.jumlahTroli), { vm.rekodBelanjaBarang() }, Modifier.fillMaxWidth().padding(horizontal = GL), kind = BtnKind.PRIMARY)
            Btn("Dah beli, tak perlu rekod", { vm.buangBarangDitick() }, Modifier.fillMaxWidth().padding(horizontal = GL))
        } else {
            Btn("Selesai beli MyKasih (" + tm.size + ")", { vm.buangBarangDitick() }, Modifier.fillMaxWidth().padding(horizontal = GL), kind = BtnKind.PRIMARY)
        }
        Note("Rekod belanja hanya untuk barang bayar sendiri. Barang MyKasih dibayar guna kredit MyKasih, jadi tidak ditolak dari poket. Lepas selesai, barang dibuang dari senarai, dan tarikh serta harga diingat untuk cadangan beli semula.")
    }

    // ---------- beli semula ----------
    if (cad.isNotEmpty()) {
        SecHead("Mungkin dah nak habis")
        ListBlock {
            cad.forEach { c ->
                Row(Modifier.fillMaxWidth().hairlines(pal.line).padding(horizontal = GL, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Txt(c.nama, size = 15f, weight = FontWeight.SemiBold)
                        Txt("Biasa dibeli setiap " + c.selang + " hari · kali terakhir " + PG.fmtShort(c.terakhir) +
                            (if (c.harga > 0.004) " · " + M(c.harga) else "") + (if (c.mykasih) " · MyKasih" else ""), size = 12.5f, color = pal.muted)
                    }
                    Btn("+ Tambah", { Kongsi.tambahBarang(c.nama, harga = c.harga, mykasih = c.mykasih); vm.toast(c.nama + " ditambah") }, kind = BtnKind.SMALL, color = pal.accentStrong)
                }
            }
        }
    }
}

/** Jadual satu bahagian: No | Jenis barang | Unit | Harga | Jumlah, dengan jumlah di bawah. */
@Composable
private fun JadualBarang(vm: MainViewModel, tajuk: String, labelJumlah: String, b: Dapur.Bahagian) {
    val pal = LocalPal.current
    if (b.bil == 0) return
    SecHead(tajuk, right = b.bil.toString() + " barang")
    ListBlock {
        Row(
            Modifier.fillMaxWidth().background(pal.surface2).hairlines(pal.line).padding(start = 8.dp, end = 12.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(COL_GAP),
        ) {
            Spacer(Modifier.width(W_TICK - COL_GAP))
            Kepala("No", Modifier.width(W_NO))
            Kepala("Jenis barang", Modifier.weight(1f))
            Kepala("Unit", Modifier.width(W_UNIT), TextAlign.End)
            Kepala("Harga", Modifier.width(W_HARGA), TextAlign.End)
            Kepala("Jumlah", Modifier.width(W_JUM), TextAlign.End)
        }
        b.barang.forEachIndexed { i, x -> BarangRow(vm, i + 1, x) }
        Row(
            Modifier.fillMaxWidth().background(pal.surface2).padding(start = 8.dp + W_TICK, end = 12.dp, top = 10.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Txt(labelJumlah, Modifier.weight(1f), size = 14f, weight = FontWeight.SemiBold)
            Txt(M(b.jumlah), size = 15f, weight = FontWeight.Bold, num = true)
        }
    }
    if (b.tanpaHarga > 0) Note(b.tanpaHarga.toString() + " barang tanpa harga tidak masuk jumlah.")
}

@Composable
private fun Kepala(t: String, m: Modifier, align: TextAlign = TextAlign.Start) {
    Txt(t, m, size = 11.5f, weight = FontWeight.SemiBold, color = LocalPal.current.muted, align = align, maxLines = 1)
}

@Composable
private fun BarangRow(vm: MainViewModel, no: Int, b: Barang) {
    val pal = LocalPal.current
    val ink = if (b.dibeli) pal.muted else pal.ink
    Row(
        Modifier.fillMaxWidth().hairlines(pal.line).pressable({ vm.open(Sheet.BarangForm(b.id)) }, scaleTo = 0.985f).heightIn(min = 52.dp).padding(start = 8.dp, end = 12.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(COL_GAP),
    ) {
        // kotak tick: tekan untuk masuk / keluar troli (baris lain → edit)
        Box(Modifier.width(W_TICK - COL_GAP).height(44.dp).clickable { Kongsi.tickBarang(b.id, !b.dibeli) }, contentAlignment = Alignment.Center) {
            val shape = RoundedCornerShape(7.dp)
            Box(
                Modifier.size(24.dp).background(if (b.dibeli) pal.accent else Color.Transparent, shape).border(1.5.dp, if (b.dibeli) pal.accent else pal.lineStrong, shape),
                contentAlignment = Alignment.Center,
            ) { if (b.dibeli) Txt("✓", size = 13f, weight = FontWeight.Bold, color = pal.accentInk) }
        }
        Txt(no.toString(), Modifier.width(W_NO), size = 13f, color = pal.muted, num = true, maxLines = 1)
        Column(Modifier.weight(1f)) {
            Txt(b.nama, size = 14f, weight = FontWeight.Medium, color = ink, maxLines = 2)
            val sub = listOfNotNull(b.nota.ifEmpty { null }, if (b.oleh.isNotEmpty() && b.oleh != Kongsi.uid()) "oleh " + Kongsi.namaAhli(b.oleh) else null)
            if (sub.isNotEmpty()) Txt(sub.joinToString(" · "), size = 11.5f, color = pal.muted, maxLines = 1)
        }
        Txt(Dapur.fmtUnit(b.unit), Modifier.width(W_UNIT), size = 13f, color = ink, align = TextAlign.End, num = true, maxLines = 1)
        Txt(if (b.adaHarga) Dapur.fmtRm(b.harga) else "–", Modifier.width(W_HARGA), size = 13f, color = if (b.adaHarga) ink else pal.muted, align = TextAlign.End, num = true, maxLines = 1)
        Txt(if (b.adaHarga) Dapur.fmtRm(b.jumlah) else "–", Modifier.width(W_JUM), size = 13f, weight = FontWeight.SemiBold, color = if (b.adaHarga) ink else pal.muted, align = TextAlign.End, num = true, maxLines = 1)
    }
}

/** Tambah barang baru ([id] null) atau edit barang sedia ada. */
@Composable
fun BarangFormSheet(vm: MainViewModel, id: String?) {
    val b0 = remember(id) { if (id != null) Kongsi.barang.value.find { it.id == id } else null }
    val sej by Kongsi.sejarah.collectAsState()
    var nama by remember { mutableStateOf(b0?.nama ?: "") }
    var unit by remember { mutableStateOf(if (b0 != null) Dapur.fmtUnit(b0.unit) else "1") }
    var harga by remember { mutableStateOf(if (b0 != null && b0.adaHarga) PG.toFixed(b0.harga, 2) else "") }
    var mk by remember { mutableStateOf(b0?.mykasih ?: false) }
    var nota by remember { mutableStateOf(b0?.nota ?: "") }
    var err by remember { mutableStateOf("") }
    var n by remember { mutableStateOf(0) }
    val fr = autoFocus(id == null)
    val u = Dapur.bacaUnit(unit)
    val h = Dapur.bacaHarga(harga)
    // harga kali lepas untuk barang yang sama (dari sejarah beli)
    val lepas = remember(nama, sej) {
        if (nama.isBlank()) null else { val k = Kongsi.kunciBarang(nama); sej.find { Kongsi.kunciBarang(it.nama) == k && it.harga > 0.004 } }
    }
    fun simpan(): Boolean {
        err = vm.simpanBarang(id, nama, nota, unit, harga, mk)
        if (err.isNotEmpty()) return false
        if (id == null) { n++; nama = ""; nota = ""; unit = "1"; harga = "" } // MyKasih kekal untuk barang seterusnya
        return true
    }
    SheetBody(actions = {
        if (id == null) SheetActions("Tambah & tutup", { if (simpan()) vm.close() }, { vm.close() }, cancel = "Tutup", extra = "Tambah lagi", onExtra = { if (simpan()) runCatching { fr.requestFocus() } })
        else SheetActions("Simpan", { if (simpan()) vm.close() }, { vm.close() })
    }) {
        SheetTitle(
            if (id != null) "Edit barang" else "Tambah barang",
            if (id == null) (if (n > 0) rich("**$n** barang ditambah.") else rich("Contoh: beras 10kg, minyak masak, susu anak.")) else null,
        )
        Form {
            FieldText("Jenis barang", nama, { nama = it }, placeholder = "cth: Beras 10kg", maxLen = 60, fr = fr)
            FieldText("Unit", unit, { unit = it }, placeholder = "1", kb = KeyboardType.Decimal, maxLen = 7)
            FieldText(
                "Harga seunit (RM)", harga, { harga = it }, placeholder = "0.00", kb = KeyboardType.Decimal, maxLen = 10,
                small = if (lepas != null && harga.isBlank()) "Harga kali lepas " + M(lepas.harga) + (if (lepas.mykasih) " (MyKasih)" else "") else "Kosongkan kalau belum tahu harga.",
                after = { if (lepas != null && harga.isBlank()) LinkBtn("Guna harga lepas", { harga = PG.toFixed(lepas.harga, 2) }) },
            )
            FieldText("Jumlah harga", if (u != null && h != null && h > 0.004) M(PG.round2(u * h)) else "–", {}, readOnly = true)
            FieldChips("Bayar guna", listOf("sendiri" to "Duit sendiri", "mykasih" to "MyKasih"), if (mk) "mykasih" else "sendiri", { mk = it == "mykasih" }, stack = false)
            FieldText("Nota (pilihan)", nota, { nota = it }, placeholder = "cth: jenama biasa", maxLen = 60)
        }
        Box(Modifier.padding(horizontal = GL)) { FormError(err) }
        if (mk) Note("Barang MyKasih dibayar guna kredit MyKasih. Ia diasingkan dalam senarai dan tidak direkod sebagai belanja dari poket.", Modifier.padding(top = 8.dp))
        if (id == null) {
            if (Kongsi.hid().isEmpty()) Note("Belum bersambung ke Firebase. Sambung ke internet sekali untuk aktifkan senarai kongsi.", Modifier.padding(top = 8.dp))
            else Note("Tiada internet pun tak apa: barang disimpan dan dihantar ke telefon isteri bila ada internet.", Modifier.padding(top = 8.dp))
        } else {
            Spacer(Modifier.height(8.dp))
            DelZone("Buang barang", "Buang barang ini dari senarai (untuk kau dan isteri)?", { Kongsi.padamBarang(id); vm.close(); vm.toast("Barang dibuang") })
        }
    }
}

// ---------------- Nafkah ----------------

/** Hantar nafkah ke app isteri dan lihat status terima. */
@Composable
fun NafkahBlock(vm: MainViewModel) {
    val pal = LocalPal.current
    val list by Kongsi.nafkah.collectAsState()
    val saya = list.filter { it.dari == Kongsi.uid() }.take(4)
    SecHead("Nafkah", "Hantar nafkah") { vm.hantarNafkah() }
    if (saya.isEmpty()) Note("Rekod duit yang kau bagi kepada isteri. Ia dicatat sebagai Keluar dari poket kau, dan muncul dalam app isteri untuk dia tekan Terima.")
    else ListBlock {
        saya.forEach { n ->
            Row(Modifier.fillMaxWidth().hairlines(pal.line).padding(horizontal = GL, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Txt(M(n.jumlah), size = 15f, weight = FontWeight.SemiBold, num = true)
                    Txt((if (n.tarikh.isNotEmpty()) PG.fmtShort(n.tarikh) else "") + (if (n.catatan.isNotEmpty()) " · " + n.catatan else ""), size = 12.5f, color = pal.muted)
                }
                Pill(if (n.diterima) "✔ Diterima" else "Belum diterima", if (n.diterima) Tone.GOOD else Tone.NEUTRAL)
            }
        }
    }
}

// ---------------- Tetapan ----------------

@Composable
fun KongsiSection(vm: MainViewModel) {
    val pal = LocalPal.current
    val la = launch()
    val st by Kongsi.status.collectAsState()
    val ralat by Kongsi.ralat.collectAsState()
    val rumah by Kongsi.rumah.collectAsState()
    val scope = rememberCoroutineScope()
    var nama by remember { mutableStateOf(Kongsi.namaSaya()) }
    var kod by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    SecHead("Kongsi dengan isteri")
    CardGroup {
        StatusRow("Sambungan", when (st) {
            Status.SEDIA -> "✔ Bersambung · " + (rumah?.ahli?.size ?: 1) + " ahli dalam rumah ini" + (rumah?.let { r -> r.ahli.filter { it != Kongsi.uid() }.joinToString { Kongsi.namaAhli(it) }.ifEmpty { null }?.let { " ($it)" } } ?: "")
            Status.RALAT -> ralat
            else -> "Menyambung…"
        }) { if (st == Status.RALAT) Btn("Cuba lagi", { Kongsi.cubaLagi() }, kind = BtnKind.SMALL) }
        val k = rumah?.kod
        if (k != null && k.isNotEmpty()) {
            Column(Modifier.fillMaxWidth().background(pal.surface).hairlines(pal.line).padding(horizontal = GL, vertical = 12.dp)) {
                Txt("Kod rumah", size = 12f, color = pal.muted)
                Txt(k.chunked(3).joinToString(" "), size = 28f, weight = FontWeight.Bold, color = pal.accentStrong, num = true)
                Txt("Kod rumah dalam app ini. Untuk kongsi dengan isteri, masukkan kod dari app Duitku Isteri di bawah.", size = 12.5f, color = pal.muted)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Btn("Salin kod", { la.copy(k, "Kod disalin") }, Modifier.weight(1f), kind = BtnKind.SMALL)
                    Btn("Kongsi kod", { la.share("kod-rumah.txt", "text/plain", "Kod rumah Duitku: $k", "Kod rumah Duitku") }, Modifier.weight(1f), kind = BtnKind.SMALL)
                }
            }
        }
    }
    CardGroup { Form {
        FieldText("Nama saya", nama, { nama = it }, placeholder = "cth: Abang", maxLen = 20, after = {
            if (nama.trim() != Kongsi.namaSaya()) LinkBtn("Simpan nama", { Kongsi.tukarNama(nama); vm.toast("Nama disimpan") })
        }, small = "Nama ini dipaparkan pada telefon isteri, contohnya \"✔ Abang\" pada barang yang dah dibeli.")
        FieldText("Kod dari app isteri", kod, { kod = it.uppercase().filter { c -> c.isLetterOrDigit() }.take(6) }, placeholder = "Kod 6 aksara",
            small = "Buka app isteri → Tetapan → Kongsi dengan suami untuk lihat kod 6 aksara. Senarai dalam rumah app ini (kalau ada) tidak dibawa bersama.", after = {
                if (kod.length == 6) LinkBtn(if (busy) "Menyambung…" else "Masuk rumah ini", {
                    if (!busy) { busy = true; err = ""; scope.launch { err = Kongsi.masukRumah(kod) ?: ""; busy = false; if (err.isEmpty()) { kod = ""; vm.toast("Bersambung dengan app isteri") } } }
                })
            })
    } }
    Box(Modifier.padding(horizontal = GL)) { FormError(err) }
}

