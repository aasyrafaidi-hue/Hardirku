package com.asyraf.hadirku.kongsi

import com.asyraf.hadirku.BuildConfig
import com.asyraf.hadirku.data.Repo
import com.asyraf.hadirku.pg.PG
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import org.json.JSONArray
import org.json.JSONObject
import java.security.SecureRandom

/* Data yang dikongsi antara telefon isteri dan suami (Firestore). Poket & transaksi kekal dalam telefon. */

// Barang & SejarahBeli dalam KongsiData.kt (boleh diuji tanpa Firebase)
// Nafkah, JadualNafkah, Tabung & kiraan Rumahtangga dalam KongsiData.kt (boleh diuji tanpa Firebase)
data class Rumah(val id: String, val kod: String, val ahli: List<String>, val nama: Map<String, String>)

enum class Status { MATI, SAMBUNG, SEDIA, RALAT }

/**
 * Sambungan Firebase: log masuk tanpa nama (anonymous), satu "rumah" untuk setiap keluarga.
 * Telefon pertama buat rumah dan dapat kod 6 aksara; telefon kedua masuk guna kod itu.
 * Firestore simpan salinan luar talian, jadi perubahan semasa tiada internet dihantar kemudian.
 *
 * Struktur:
 *   rumah/{id}            kod, ahli[uid], nama{uid: nama}
 *   rumah/{id}/barang     senarai barang dapur: nama, nota, unit, harga (seunit), mykasih, dibeli
 *   rumah/{id}/sejarah    tarikh setiap barang dibeli + harga & mykasih terakhir (cadangan beli semula)
 *   rumah/{id}/bil        bil & tarikh jatuh tempo, bayar{yyyy-mm: {...}}
 *   rumah/{id}/nafkah     duit yang suami hantar (nafkah / duit dapur) & permintaan duit isteri — lihat [Nafkah]
 *   rumah/{id}/tetapan/nafkah  jadual nafkah bulanan: jumlah, hari
 *   rumah/{id}/tabung     tabung bersama: nama, sasaran, tarikh, ahli{uid: RM}
 *   rumah/{id}/projek     (tidak digunakan lagi; data lama dibiarkan, tidak dipadam)
 *   jemputan/{kod}        rumah, uid  (untuk masuk guna kod)
 */
object Kongsi {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var regs: List<ListenerRegistration> = emptyList()

    private val _status = MutableStateFlow(Status.MATI)
    val status: StateFlow<Status> = _status.asStateFlow()
    private val _ralat = MutableStateFlow("")
    val ralat: StateFlow<String> = _ralat.asStateFlow()

    private val _rumah = MutableStateFlow<Rumah?>(null)
    val rumah: StateFlow<Rumah?> = _rumah.asStateFlow()
    private val _barang = MutableStateFlow<List<Barang>>(emptyList())
    val barang: StateFlow<List<Barang>> = _barang.asStateFlow()
    private val _sejarah = MutableStateFlow<List<SejarahBeli>>(emptyList())
    val sejarah: StateFlow<List<SejarahBeli>> = _sejarah.asStateFlow()
    private val _nafkah = MutableStateFlow<List<Nafkah>>(emptyList())
    val nafkah: StateFlow<List<Nafkah>> = _nafkah.asStateFlow()
    private val _jadual = MutableStateFlow<JadualNafkah?>(null)
    /** Jadual nafkah bulanan (null = belum ditetapkan). */
    val jadual: StateFlow<JadualNafkah?> = _jadual.asStateFlow()
    private val _jadualDimuat = MutableStateFlow(false)
    /** true selepas dokumen jadual dibaca sekurang-kurangnya sekali (supaya null bermaksud "tiada", bukan "belum tahu"). */
    val jadualDimuat: StateFlow<Boolean> = _jadualDimuat.asStateFlow()
    private val _tabung = MutableStateFlow<List<Tabung>>(emptyList())
    val tabung: StateFlow<List<Tabung>> = _tabung.asStateFlow()

    private val db: FirebaseFirestore get() = FirebaseFirestore.getInstance()
    private val auth: FirebaseAuth get() = FirebaseAuth.getInstance()

    fun hid(): String = Repo.getStr("kongsi.hid")
    /** Nama lalai ikut app: "Isteri" dalam Duitku Isteri, "Abang" dalam Duitku. */
    private val NAMA_LALAI = if (BuildConfig.ISTERI) "Isteri" else "Abang"
    fun namaSaya(): String = Repo.getStr("kongsi.nama", NAMA_LALAI).ifBlank { NAMA_LALAI }
    fun uid(): String? = try { auth.currentUser?.uid } catch (e: Exception) { null }
    fun sedia(): Boolean = _status.value == Status.SEDIA

    /** Nama ahli rumah untuk paparan ("Abang", "Isteri"…). */
    fun namaAhli(uid: String): String = _rumah.value?.nama?.get(uid)?.ifBlank { null } ?: if (uid == uid()) namaSaya() else "Pasangan"

    // ---------------- sambung ----------------

    /** Mula sambungan (selamat dipanggil berkali-kali). */
    fun mula() {
        if (_status.value == Status.SAMBUNG || _status.value == Status.SEDIA) return
        _status.value = Status.SAMBUNG
        _ralat.value = ""
        scope.launch {
            try {
                if (auth.currentUser == null) auth.signInAnonymously().await()
                var h = hid()
                if (h.isEmpty()) h = buatRumah()
                dengar(h)
                _status.value = Status.SEDIA
            } catch (e: Exception) {
                gagal(e)
            }
        }
    }

    fun cubaLagi() {
        if (_status.value == Status.SAMBUNG) return
        _status.value = Status.MATI
        mula()
    }

    private fun gagal(e: Exception) {
        _ralat.value = pesan(e)
        _status.value = Status.RALAT
    }

    fun pesan(e: Exception): String = when {
        e is FirebaseNetworkException -> "Tiada internet. Sambung ke internet sekali untuk aktifkan perkongsian."
        e is FirebaseFirestoreException && e.code == FirebaseFirestoreException.Code.PERMISSION_DENIED ->
            "Firebase menolak akses. Semak peraturan Firestore (security rules) dalam Firebase Console."
        e is FirebaseFirestoreException && e.code == FirebaseFirestoreException.Code.UNAVAILABLE -> "Server Firebase tak dapat dihubungi. Cuba lagi sebentar."
        (e.message ?: "").contains("CONFIGURATION_NOT_FOUND") || (e.message ?: "").contains("ADMIN_ONLY_OPERATION") ->
            "Log masuk Anonymous belum dihidupkan dalam Firebase Console (Authentication → Sign-in method)."
        else -> e.message?.take(160) ?: "Ralat Firebase."
    }

    private fun kodRawak(): String {
        val abc = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789" // tanpa 0/O/1/I supaya senang dibaca
        val r = SecureRandom()
        return (1..6).map { abc[r.nextInt(abc.length)] }.joinToString("")
    }

    private suspend fun buatRumah(): String {
        val u = uid() ?: throw Exception("Belum log masuk.")
        var last: Exception? = null
        repeat(6) {
            val ref = db.collection("rumah").document()
            val kod = kodRawak()
            val b = db.batch()
            b.set(ref, mapOf("kod" to kod, "ahli" to listOf(u), "nama" to mapOf(u to namaSaya()), "dibuat" to System.currentTimeMillis()))
            b.set(db.collection("jemputan").document(kod), mapOf("rumah" to ref.id, "uid" to u))
            try {
                b.commit().await()
                Repo.putStr("kongsi.hid", ref.id)
                return ref.id
            } catch (e: FirebaseFirestoreException) {
                // kod sudah digunakan rumah lain → cuba kod lain
                if (e.code != FirebaseFirestoreException.Code.PERMISSION_DENIED) throw e
                last = e
            }
        }
        throw last ?: Exception("Tak dapat buat kod rumah.")
    }

    /** Masuk rumah pasangan guna kod. Pulang mesej ralat, atau null jika berjaya. */
    suspend fun masukRumah(kod0: String): String? {
        val kod = kod0.trim().uppercase()
        if (kod.length != 6) return "Kod rumah ada 6 aksara."
        val u = uid() ?: return "Belum bersambung ke Firebase."
        return try {
            val inv = db.collection("jemputan").document(kod).get().await()
            if (!inv.exists()) return "Kod $kod tidak dijumpai."
            val h = inv.getString("rumah") ?: return "Kod ini rosak."
            if (h == hid()) return "Ini kod rumah awak sendiri."
            db.collection("rumah").document(h).update(mapOf("ahli" to FieldValue.arrayUnion(u), "nama.$u" to namaSaya())).await()
            Repo.putStr("kongsi.hid", h)
            dengar(h)
            _status.value = Status.SEDIA
            null
        } catch (e: Exception) {
            pesan(e)
        }
    }

    fun tukarNama(n: String) {
        val nama = n.trim().take(20).ifEmpty { NAMA_LALAI }
        Repo.putStr("kongsi.nama", nama)
        val u = uid() ?: return
        val h = hid().ifEmpty { return }
        db.collection("rumah").document(h).update("nama.$u", nama)
    }

    // ---------------- dengar perubahan ----------------

    private fun col(h: String, c: String) = db.collection("rumah").document(h).collection(c)
    private fun ref(c: String) = col(hid(), c)

    private fun dengar(h: String) {
        regs.forEach { it.remove() }
        val r = ArrayList<ListenerRegistration>()
        r += db.collection("rumah").document(h).addSnapshotListener { d, e ->
            if (e != null) { gagal(e); return@addSnapshotListener }
            if (d != null && d.exists()) _rumah.value = Rumah(
                d.id, d.getString("kod") ?: "", (d.get("ahli") as? List<*>)?.map { it.toString() } ?: emptyList(),
                (d.get("nama") as? Map<*, *>)?.entries?.associate { it.key.toString() to it.value.toString() } ?: emptyMap(),
            )
        }
        r += col(h, "barang").addSnapshotListener { q, e ->
            if (e != null || q == null) return@addSnapshotListener
            _barang.value = q.documents.map { d ->
                Barang(
                    d.id, d.str("nama"), d.str("nota"), d.getBoolean("dibeli") == true, d.str("oleh"), d.lng("dibuat"),
                    unit = d.dbl("unit").takeIf { it > 0 } ?: 1.0, harga = d.dbl("harga").coerceAtLeast(0.0), mykasih = d.getBoolean("mykasih") == true,
                )
            }.sortedWith(compareBy<Barang> { it.dibuat }.thenBy { it.id })
        }
        r += col(h, "sejarah").addSnapshotListener { q, e ->
            if (e != null || q == null) return@addSnapshotListener
            _sejarah.value = q.documents.map { d ->
                SejarahBeli(d.id, d.str("nama"), (d.get("tarikh") as? List<*>)?.map { it.toString() }?.sorted() ?: emptyList(), d.dbl("harga"), d.getBoolean("mykasih") == true)
            }
        }
        r += col(h, "nafkah").addSnapshotListener { q, e ->
            if (e != null || q == null) return@addSnapshotListener
            _nafkah.value = q.documents.map { d ->
                Nafkah(
                    d.id, d.dbl("jumlah"), d.str("catatan"), d.str("dari"), d.str("tarikh"), d.getBoolean("diterima") == true, d.lng("dibuat"),
                    jenis = d.str("jenis").ifEmpty { "nafkah" }, minta = d.str("minta"), peminta = d.str("peminta"),
                    diterimaTarikh = d.str("diterimaTarikh"), guna = d.dbl("guna"), pulang = d.dbl("pulang"), pulangTx = d.str("pulangTx"),
                    pulangDiterima = d.getBoolean("pulangDiterima") == true, selesai = d.getBoolean("selesai") == true,
                )
            }.sortedByDescending { it.dibuat }
        }
        r += col(h, "tetapan").document("nafkah").addSnapshotListener { d, e ->
            if (e != null) return@addSnapshotListener
            val j = d?.takeIf { it.exists() }?.let { JadualNafkah(it.dbl("jumlah"), it.lng("hari").toInt().coerceIn(1, 31)) }
            _jadual.value = j?.takeIf { it.jumlah > 0.004 }
            _jadualDimuat.value = true
        }
        r += col(h, "tabung").addSnapshotListener { q, e ->
            if (e != null || q == null) return@addSnapshotListener
            _tabung.value = q.documents.map { d ->
                Tabung(
                    d.id, d.str("nama"), d.dbl("sasaran"), d.str("tarikh"),
                    (d.get("ahli") as? Map<*, *>)?.entries?.associate { it.key.toString() to ((it.value as? Number)?.toDouble() ?: 0.0) } ?: emptyMap(),
                    d.lng("dibuat"),
                )
            }.sortedBy { it.dibuat }
        }
        regs = r
    }

    private fun DocumentSnapshot.str(k: String): String = getString(k) ?: ""
    private fun DocumentSnapshot.dbl(k: String): Double = (get(k) as? Number)?.toDouble() ?: 0.0
    private fun DocumentSnapshot.lng(k: String): Long = (get(k) as? Number)?.toLong() ?: 0L

    // ---------------- senarai barang ----------------

    fun tambahBarang(nama: String, nota: String = "", unit: Double = 1.0, harga: Double = 0.0, mykasih: Boolean = false, dibeli: Boolean = false) {
        val n = nama.trim().take(60)
        if (n.isEmpty() || hid().isEmpty()) return
        ref("barang").add(mapOf(
            "nama" to n, "nota" to nota.trim().take(60), "dibeli" to dibeli, "oleh" to (uid() ?: ""), "dibuat" to System.currentTimeMillis(),
            "unit" to unit, "harga" to harga, "mykasih" to mykasih,
        ))
    }

    /** Ubah barang sedia ada (status troli & pembuat tidak disentuh). */
    fun kemaskiniBarang(id: String, nama: String, nota: String, unit: Double, harga: Double, mykasih: Boolean) {
        val n = nama.trim().take(60)
        if (n.isEmpty() || hid().isEmpty()) return
        ref("barang").document(id).update(mapOf("nama" to n, "nota" to nota.trim().take(60), "unit" to unit, "harga" to harga, "mykasih" to mykasih))
    }

    fun tickBarang(id: String, on: Boolean) { if (hid().isNotEmpty()) ref("barang").document(id).update("dibeli", on) }
    fun padamBarang(id: String) { if (hid().isNotEmpty()) ref("barang").document(id).delete() }

    fun kunciBarang(nama: String): String = PG.normNama(nama).replace(" ", "").ifEmpty { "x" }.take(80)

    /** Barang dah dibeli: buang dari senarai dan catat tarikh untuk cadangan beli semula. */
    fun selesaiBeli(ids: Collection<String>, tarikh: String) {
        if (hid().isEmpty()) return
        val b = db.batch()
        ids.forEach { id ->
            val it = _barang.value.find { x -> x.id == id } ?: return@forEach
            b.delete(ref("barang").document(id))
            val sej = HashMap<String, Any>()
            sej["nama"] = it.nama
            sej["tarikh"] = FieldValue.arrayUnion(tarikh)
            sej["mykasih"] = it.mykasih
            if (it.adaHarga) sej["harga"] = it.harga // harga 0 tidak padam harga lama
            b.set(ref("sejarah").document(kunciBarang(it.nama)), sej, SetOptions.merge())
        }
        b.commit()
    }

    // ---------------- nafkah ----------------

    /** Suami hantar nafkah ([jenis] "nafkah") atau duit dapur ([jenis] "dapur"). */
    fun hantarNafkah(jumlah: Double, catatan: String, tarikh: String, jenis: String = "nafkah") {
        if (hid().isEmpty()) return
        ref("nafkah").add(mapOf("jumlah" to jumlah, "catatan" to catatan.trim().take(80), "dari" to (uid() ?: ""), "tarikh" to tarikh,
            "diterima" to false, "dibuat" to System.currentTimeMillis(), "jenis" to jenis))
    }

    /** Isteri minta duit: menunggu suami Lulus (jadi nafkah/duit dapur) atau Tolak. */
    fun mintaDuit(jumlah: Double, sebab: String, jenis: String, tarikh: String) {
        if (hid().isEmpty()) return
        ref("nafkah").add(mapOf("jumlah" to jumlah, "catatan" to sebab.trim().take(80), "dari" to "", "peminta" to (uid() ?: ""), "minta" to "tunggu",
            "jenis" to jenis, "tarikh" to tarikh, "diterima" to false, "dibuat" to System.currentTimeMillis()))
    }

    /** Suami luluskan permintaan: kini duit dihantar (isteri nampak "Terima"). */
    fun lulusMinta(id: String, jumlah: Double, tarikh: String) {
        if (hid().isEmpty()) return
        ref("nafkah").document(id).update(mapOf("minta" to "lulus", "dari" to (uid() ?: ""), "jumlah" to jumlah, "tarikh" to tarikh))
    }

    fun tolakMinta(id: String) { if (hid().isNotEmpty()) ref("nafkah").document(id).update("minta", "tolak") }
    fun padamNafkah(id: String) { if (hid().isNotEmpty()) ref("nafkah").document(id).delete() }

    /** App isteri: belanja dapur terkini bagi duit dapur [id]. */
    fun kemaskiniGuna(id: String, guna: Double) { if (hid().isNotEmpty()) ref("nafkah").document(id).update("guna", guna) }

    /** App isteri: pulangkan baki duit dapur (atau 0 = tutup sahaja). */
    fun pulangDapur(id: String, jumlah: Double, txId: String, tarikh: String) {
        if (hid().isEmpty()) return
        ref("nafkah").document(id).update(mapOf("pulang" to jumlah, "pulangTx" to txId, "pulangTarikh" to tarikh, "selesai" to true,
            "pulangDiterima" to (jumlah <= 0.004)))
    }

    /** App suami: pulangan duit dapur sudah direkod. */
    fun terimaPulang(id: String) { if (hid().isNotEmpty()) ref("nafkah").document(id).update("pulangDiterima", true) }

    // ---------------- jadual nafkah & tabung bersama ----------------

    fun setJadual(jumlah: Double, hari: Int) {
        if (hid().isEmpty()) return
        ref("tetapan").document("nafkah").set(mapOf("jumlah" to jumlah, "hari" to hari.coerceIn(1, 31), "oleh" to (uid() ?: ""), "dikemas" to System.currentTimeMillis()))
    }

    fun padamJadual() { if (hid().isNotEmpty()) ref("tetapan").document("nafkah").delete() }

    /** Tabung baru (pulang id) atau ubah tabung sedia ada. */
    fun simpanTabung(id: String?, nama: String, sasaran: Double, tarikh: String): String {
        if (hid().isEmpty()) return ""
        val d = mapOf("nama" to nama.trim().take(40), "sasaran" to sasaran, "tarikh" to tarikh)
        return if (id != null) { ref("tabung").document(id).update(d); id }
        else { val r = ref("tabung").document(); r.set(d + mapOf("ahli" to emptyMap<String, Double>(), "dibuat" to System.currentTimeMillis(), "oleh" to (uid() ?: ""))); r.id }
    }

    fun padamTabung(id: String) { if (hid().isNotEmpty()) ref("tabung").document(id).delete() }

    /** Sumbangan telefon ini = baki poket tabung dalam telefon ini. */
    fun kemaskiniSumbangan(id: String, jumlah: Double) {
        val u = uid() ?: return
        if (hid().isNotEmpty()) ref("tabung").document(id).update("ahli.$u", jumlah)
    }

    /**
     * Bil lama dari app Duitku Isteri versi dahulu (rumah/{id}/bil). Dibaca sekali sahaja untuk dipindah ke Komitmen
     * dalam app isteri versi baharu. Data dalam Firebase tidak diubah atau dipadam.
     */
    data class BilLama(val nama: String, val jumlah: Double, val hari: Int, val poket: String)

    suspend fun bilLama(): List<BilLama> {
        val h = hid()
        if (h.isEmpty()) return emptyList()
        return col(h, "bil").get().await().documents.map { d ->
            BilLama(d.str("nama").trim(), d.dbl("jumlah"), d.lng("hari").toInt().coerceIn(1, 31), d.str("poket"))
        }.filter { it.nama.isNotEmpty() }
    }

    fun terimaNafkah(id: String, tarikh: String) {
        if (hid().isNotEmpty()) ref("nafkah").document(id).update(mapOf("diterima" to true, "diterimaPada" to System.currentTimeMillis(), "diterimaTarikh" to tarikh))
    }
}
