package com.asyraf.hadirku.system

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import com.asyraf.hadirku.BuildConfig
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Penjaga app: rekod bila app tergantung (tidak bergerak > 5 saat) atau tertutup sebab ralat.
 * Laporan disimpan dalam fail kecil; kali seterusnya app dibuka, jalur di atas tunjuk "Salin laporan"
 * supaya boleh dihantar kepada Claude untuk dibaiki dengan tepat.
 *
 * Kos: satu thread latar yang tidur hampir sepanjang masa (semak setiap ~2.5 saat).
 * Masa telefon tidur tidak dikira (guna uptimeMillis), jadi tiada amaran palsu.
 */
object Jaga {
    private const val FAIL = "jaga-laporan.txt"
    @Volatile private var hidup = false
    private var dir: File? = null

    fun mula(ctx: Context) {
        if (hidup) return
        hidup = true
        dir = ctx.applicationContext.filesDir

        // 1) app tertutup sebab ralat
        val asal = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                var c: Throwable? = e
                val b = StringBuilder()
                while (c != null && b.length < 7000) {
                    b.append(c.toString()).append('\n').append(ringkas(c.stackTrace)).append("\n\n")
                    val sebab = c.cause
                    c = if (sebab === c) null else sebab
                }
                simpan("App tertutup sebab ralat (thread " + t.name + ")", b.toString())
            } catch (_: Throwable) { }
            asal?.uncaughtException(t, e)
        }

        // 2) app tergantung: thread utama tak jawab dalam 5 saat
        val main = Handler(Looper.getMainLooper())
        val th = Thread({
            var dahLapor = false
            while (true) {
                try {
                    val jawab = AtomicBoolean(false)
                    val t0 = SystemClock.uptimeMillis()
                    main.post { jawab.set(true) }
                    while (!jawab.get() && SystemClock.uptimeMillis() - t0 < 5000) Thread.sleep(250)
                    if (!jawab.get()) {
                        if (!dahLapor) {
                            val st = Looper.getMainLooper().thread.stackTrace
                            simpan("App tergantung lebih 5 saat", ringkas(st))
                            dahLapor = true
                        }
                        while (!jawab.get()) Thread.sleep(500)
                    } else {
                        dahLapor = false
                    }
                    Thread.sleep(2500)
                } catch (_: InterruptedException) {
                    return@Thread
                } catch (_: Throwable) {
                    try { Thread.sleep(5000) } catch (_: InterruptedException) { return@Thread }
                }
            }
        }, "duitku-jaga")
        th.isDaemon = true
        th.priority = Thread.MIN_PRIORITY
        th.start()
    }

    /**
     * Tindanan panjang (cth fungsi berulang beratus kali) dipadatkan: 12 baris atas + bilangan ulangan +
     * 50 baris bawah — bahagian bawah ialah PUNCA (kod app yang mula panggil), paling penting untuk dibaiki.
     */
    private fun ringkas(st: Array<StackTraceElement>): String {
        val lines = st.map { "    at $it" }
        if (lines.size <= 70) return lines.joinToString("\n")
        val atas = lines.take(12)
        val bawah = lines.takeLast(50)
        return (atas + listOf("    … " + (lines.size - 62) + " baris berulang dibuang …") + bawah).joinToString("\n")
    }

    private fun simpan(tajuk: String, isi: String) {
        val d = dir ?: return
        val masa = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        val teks = "Duitku v" + BuildConfig.VERSION_NAME + " · " + masa + "\n" + tajuk + "\n\n" + isi.take(9000)
        File(d, FAIL).writeText(teks, Charsets.UTF_8)
    }

    /** Laporan terakhir (jika ada). */
    fun baca(ctx: Context): String? = try {
        val f = File(ctx.applicationContext.filesDir, FAIL)
        if (f.exists()) f.readText(Charsets.UTF_8).takeIf { it.isNotBlank() } else null
    } catch (_: Exception) { null }

    fun buang(ctx: Context) {
        try { File(ctx.applicationContext.filesDir, FAIL).delete() } catch (_: Exception) { }
    }
}
