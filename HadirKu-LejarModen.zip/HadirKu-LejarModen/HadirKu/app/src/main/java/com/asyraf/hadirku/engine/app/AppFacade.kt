package com.asyraf.hadirku.engine.app

import com.asyraf.hadirku.engine.assistant.Answer
import com.asyraf.hadirku.engine.assistant.AnswerSource
import com.asyraf.hadirku.engine.assistant.Intent
import com.asyraf.hadirku.engine.budget.Budget
import com.asyraf.hadirku.engine.budget.BudgetEngine
import com.asyraf.hadirku.engine.budget.BudgetLine
import com.asyraf.hadirku.engine.budget.BudgetSuggestion
import com.asyraf.hadirku.engine.budget.CarryOver
import com.asyraf.hadirku.engine.budget.SuggestionKind
import com.asyraf.hadirku.engine.cashflow.CashFlowEngine
import com.asyraf.hadirku.engine.cashflow.CashFlowReport
import com.asyraf.hadirku.engine.cashflow.ScheduledItem
import com.asyraf.hadirku.engine.cashflow.ScheduledKind
import com.asyraf.hadirku.engine.core.Dates
import com.asyraf.hadirku.engine.core.Money
import com.asyraf.hadirku.engine.forecast.ForecastEngine
import com.asyraf.hadirku.engine.forecast.Scenario
import com.asyraf.hadirku.engine.ledger.LedgerBook
import com.asyraf.hadirku.engine.ledger.PgLedgerAdapter
import com.asyraf.hadirku.engine.risk.RiskAlert
import com.asyraf.hadirku.engine.risk.RiskCode
import com.asyraf.hadirku.engine.risk.RiskEngine
import com.asyraf.hadirku.engine.risk.Severity
import com.asyraf.hadirku.engine.savings.Feasibility
import com.asyraf.hadirku.engine.savings.GoalMove
import com.asyraf.hadirku.engine.savings.GoalMoveIssue
import com.asyraf.hadirku.engine.savings.GoalProgress
import com.asyraf.hadirku.engine.savings.SavingsEngine
import com.asyraf.hadirku.engine.savings.SavingsGoal
import com.asyraf.hadirku.engine.store.EngineData
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.PgState
import java.math.BigDecimal
import java.time.LocalDate
import java.time.YearMonth

/* =====================================================================
 * Lapisan antara skrin dan enjin (tulen, tiada Android) — supaya logik paparan boleh diuji.
 * Skrin hanya memanggil fungsi di sini dan melukis hasilnya. Semua wang kekal Money (sen Long);
 * ditukar ke Double HANYA untuk dipaparkan melalui PG.money (rm()).
 * ===================================================================== */

/** Wang untuk paparan sahaja (PG.money menerima Double). */
fun Money.rm(): Double = toDecimal().toDouble()

data class EngineSummary(
    val today: LocalDate,
    val book: LedgerBook,
    val cash: CashFlowReport,
    val nextPay: LocalDate,
    /** hari sehingga gaji seterusnya (sekurang-kurangnya 1) */
    val daysToPay: Long,
    /** availableToSpend ÷ hari (sifar jika tiada baki boleh belanja) */
    val perDay: Money,
    val goals: List<GoalProgress>,
    val earmarked: Money,
    val budgets: List<BudgetLine>,
    val risks: List<RiskAlert>,
)

/** Teks paparan amaran (Bahasa Melayu; diterjemah oleh tr() di skrin). */
data class RiskText(val title: String, val body: String, val severity: Severity)

data class ScheduledText(val date: LocalDate?, val name: String, val amount: Money, val inflow: Boolean, val estimate: Boolean)

object AppFacade {

    fun summary(s: PgState, d: EngineData, today: LocalDate): EngineSummary {
        val book = PgLedgerAdapter.build(s, today).book
        val goals = SavingsEngine.progress(allGoals(s, d, today), d.goalMoves, book, today, null)
        val earmarked = SavingsEngine.totalEarmarked(goals)
        val cash = CashFlowEngine.report(s, book, today, earmarked = earmarked)
        val nextPay = cash.window.lastDay
        val days = maxOf(1L, Dates.daysBetween(today, nextPay))
        val perDay = if (cash.availableToSpend.isPositive) cash.availableToSpend.div(days) else Money.ZERO
        val f = ForecastEngine.project(s, book, today, 45, Scenario.CONSERVATIVE)
        val risks = RiskEngine.evaluate(RiskEngine.inputFrom(s, book, today, f, earmarked, earmarked))
        val budgets = BudgetEngine.lines(book, d.budgets, YearMonth.from(today))
        return EngineSummary(today, book, cash, nextPay, days, perDay, goals, earmarked, budgets, risks)
    }

    fun allGoals(s: PgState, d: EngineData, today: LocalDate): List<SavingsGoal> = d.goals + SavingsEngine.goalsFromPockets(s, today)

    // ---------------- aliran tunai ----------------

    fun scheduledText(s: PgState, items: List<ScheduledItem>): List<ScheduledText> = items.map { i ->
        val name = when (i.kind) {
            ScheduledKind.BILL -> s.commitments.find { it.id == i.refId }?.nama ?: "Komitmen"
            ScheduledKind.DEBT -> s.debts.find { it.id == i.refId }?.nama?.let { "Bayaran minimum $it" } ?: "Bayaran hutang"
            ScheduledKind.SALARY -> "Gaji"
            ScheduledKind.ADVANCE -> "Gaji pendahuluan"
        }
        ScheduledText(i.date, name, i.amount, i.inflow, i.confidence == com.asyraf.hadirku.engine.cashflow.Confidence.ESTIMATE)
    }

    /** Jumlah keluar yang dijadualkan sebelum gaji (bil + hutang) — dipaparkan sebagai baris tolak. */
    fun scheduledOut(r: CashFlowReport): Money =
        Money.sum(r.scheduled.filter { !it.inflow && (it.date == null || it.date.isBefore(r.window.endExclusive)) }.map { it.amount })

    // ---------------- amaran ----------------

    private fun dec(v: String?): Double = v?.toBigDecimalOrNull()?.toDouble() ?: 0.0
    private fun bpPct(v: String?): String = ((v?.toLongOrNull() ?: 0L) / 100).toString() + "%"

    /** Satu amaran setiap kod+subjek (DUE_DATE_SHORTFALL boleh berulang untuk setiap bil selepas duit tak cukup). */
    fun distinctRisks(alerts: List<RiskAlert>): List<RiskAlert> {
        val shortfalls = alerts.filter { it.code == RiskCode.DUE_DATE_SHORTFALL }
        val others = alerts.filter { it.code != RiskCode.DUE_DATE_SHORTFALL }
        val firstShort = shortfalls.minByOrNull { it.date ?: LocalDate.MAX }?.let { first ->
            // jumlah kekurangan = kekurangan pada bil TERAKHIR (kumulatif)
            val last = shortfalls.maxByOrNull { it.date ?: LocalDate.MIN }
            first.copy(amount = last?.amount ?: first.amount, params = first.params + ("count" to shortfalls.size.toString()))
        }
        return (listOfNotNull(firstShort) + others).sortedByDescending { it.severity.ordinal }
    }

    fun riskText(a: RiskAlert, s: PgState): RiskText {
        val amt = a.amount?.rm() ?: 0.0
        val tarikh = a.date?.let { PG.fmtShort(it.toString()) } ?: ""
        return when (a.code) {
            RiskCode.NEGATIVE_PROJECTED_BALANCE -> RiskText(
                "Baki dijangka negatif",
                "Ramalan berhati-hati: baki boleh jatuh ke " + PG.money(amt) + " sekitar " +
                    (a.params["lowest_date"]?.let { PG.fmtShort(it) } ?: tarikh) + ". Kurangkan belanja atau tangguh pembelian besar.",
                a.severity,
            )
            RiskCode.DUE_DATE_SHORTFALL -> {
                val n = a.params["count"]?.toIntOrNull() ?: 1
                val bil = s.commitments.find { it.id == a.subjectId }?.nama ?: "Komitmen"
                RiskText(
                    "Duit tak cukup untuk bil",
                    "Mula " + tarikh + " (" + bil + ")" + (if (n > 1) " dan $n bil" else "") + ": kurang " + PG.money(amt) + " sebelum gaji masuk.",
                    a.severity,
                )
            }
            RiskCode.HIGH_FIXED_COMMITMENTS -> RiskText(
                "Komitmen tetap tinggi",
                "Komitmen tetap " + PG.money(amt) + " sebulan = " + bpPct(a.params["ratio_bp"]) + " daripada gaji pasti (tanpa OT).",
                a.severity,
            )
            RiskCode.UNUSUAL_SPENDING -> RiskText(
                "Belanja luar biasa: " + PG.katLabel(a.subjectId),
                "Bulan ini " + PG.money(amt) + ", purata bulan lepas " + PG.money(dec(a.params["average"])) + ".",
                a.severity,
            )
            RiskCode.LOW_EMERGENCY_RESERVE -> RiskText(
                "Simpanan kecemasan rendah",
                "Simpanan sekarang " + PG.money(dec(a.params["reserve"])) + ". Sasaran " + (a.params["target_months"] ?: "3") +
                    " bulan belanja asas: perlu " + PG.money(amt) + " lagi.",
                a.severity,
            )
            RiskCode.HIGH_CREDIT_UTILISATION -> RiskText(
                "Penggunaan kad tinggi",
                (s.debts.find { it.id == a.subjectId }?.nama ?: "Kad kredit") + " sudah guna " + bpPct(a.params["utilisation_bp"]) + " daripada had.",
                a.severity,
            )
        }
    }

    // ---------------- bajet ----------------

    sealed interface Edit {
        data class Ok(val data: EngineData) : Edit
        data class Err(val message: String) : Edit
    }

    fun upsertBudget(
        d: EngineData, id: String?, category: String, amount: Money?, carry: CarryOver, essential: Boolean, month: YearMonth, newId: () -> String,
    ): Edit {
        if (!PG.katValid(category) || category == "belum") return Edit.Err("Pilih kategori.")
        if (amount == null || !amount.isPositive) return Edit.Err("Masukkan jumlah bajet lebih daripada RM0.")
        if (d.budgets.any { it.category == category && it.id != id }) return Edit.Err("Kategori ini sudah ada bajet. Ubah bajet yang sedia ada.")
        val old = id?.let { i -> d.budgets.find { it.id == i } }
        val b = Budget(old?.id ?: newId(), category, amount, old?.startMonth ?: month, carry, essential)
        val list = if (old != null) d.budgets.map { if (it.id == old.id) b else it } else d.budgets + b
        return Edit.Ok(d.copy(budgets = list))
    }

    fun deleteBudget(d: EngineData, id: String): EngineData = d.copy(budgets = d.budgets.filter { it.id != id })

    /** Cadangan hanya digunakan bila pengguna tekan "Guna" — tidak pernah automatik. */
    fun applySuggestion(d: EngineData, sug: BudgetSuggestion, month: YearMonth, newId: () -> String): EngineData {
        val old = d.budgets.find { it.category == sug.category }
        return if (old != null) d.copy(budgets = d.budgets.map { if (it.id == old.id) it.copy(amount = sug.suggested) else it })
        else d.copy(budgets = d.budgets + Budget(newId(), sug.category, sug.suggested, month, CarryOver.NONE, sug.category in BudgetEngine.DEFAULT_ESSENTIALS))
    }

    fun suggestionText(g: BudgetSuggestion): String = when (g.kind) {
        SuggestionKind.RAISE -> "Naikkan ke " + PG.money(g.suggested.rm()) + " (purata sebulan " + PG.money(g.trailingAverage.rm()) + ")"
        SuggestionKind.LOWER -> "Turunkan ke " + PG.money(g.suggested.rm()) + " (purata sebulan " + PG.money(g.trailingAverage.rm()) + ")"
        SuggestionKind.KEEP -> "Kekalkan bajet " + PG.money(g.suggested.rm())
        SuggestionKind.NEW_BUDGET -> "Bajet baru " + PG.money(g.suggested.rm()) + " (purata sebulan " + PG.money(g.trailingAverage.rm()) + ")"
    }

    // ---------------- matlamat simpanan ----------------

    fun upsertGoal(
        d: EngineData, id: String?, name: String, target: Money?, targetDate: LocalDate?, accountId: String?, today: LocalDate, newId: () -> String,
    ): Edit {
        val n = name.trim()
        if (n.isEmpty()) return Edit.Err("Masukkan nama matlamat.")
        if (target == null || !target.isPositive) return Edit.Err("Masukkan sasaran lebih daripada RM0.")
        if (targetDate != null && !targetDate.isAfter(today)) return Edit.Err("Tarikh sasaran mesti selepas hari ini.")
        val old = id?.let { i -> d.goals.find { it.id == i } }
        val g = SavingsGoal(old?.id ?: newId(), n.take(40), target, targetDate, accountId, old?.createdOn ?: today)
        val list = if (old != null) d.goals.map { if (it.id == old.id) g else it } else d.goals + g
        return Edit.Ok(d.copy(goals = list))
    }

    /** Padam matlamat dan pergerakan asingannya. Duit sebenar dalam poket TIDAK disentuh. */
    fun deleteGoal(d: EngineData, id: String): EngineData =
        d.copy(goals = d.goals.filter { it.id != id }, goalMoves = d.goalMoves.filter { it.goalId != id })

    fun moveGoal(s: PgState, d: EngineData, book: LedgerBook, today: LocalDate, goalId: String, amount: Money?, withdraw: Boolean, newId: () -> String): Edit {
        if (amount == null || !amount.isPositive) return Edit.Err("Masukkan jumlah lebih daripada RM0.")
        val m = GoalMove(newId(), goalId, today, if (withdraw) -amount else amount)
        val issues = SavingsEngine.validateMove(allGoals(s, d, today), d.goalMoves, book, m)
        if (issues.isNotEmpty()) return Edit.Err(issues.joinToString(" ") { moveIssueText(it) })
        return Edit.Ok(d.copy(goalMoves = d.goalMoves + m))
    }

    fun moveIssueText(i: GoalMoveIssue): String = when (i) {
        GoalMoveIssue.UNKNOWN_GOAL -> "Matlamat tidak dijumpai."
        GoalMoveIssue.ZERO_AMOUNT -> "Masukkan jumlah lebih daripada RM0."
        GoalMoveIssue.WITHDRAW_MORE_THAN_ALLOCATED -> "Jumlah keluar lebih daripada yang diasingkan."
        GoalMoveIssue.NOT_ENOUGH_FREE_BALANCE -> "Baki sebenar tidak cukup untuk diasingkan."
    }

    fun feasibilityText(p: GoalProgress): String = when (p.feasibility) {
        Feasibility.DONE -> "✔ Sasaran tercapai"
        Feasibility.FEASIBLE -> p.requiredMonthly?.let { "Perlu simpan " + PG.money(it.rm()) + " sebulan" } ?: "Mengikut jadual"
        Feasibility.TIGHT -> p.requiredMonthly?.let { "Ketat: perlu simpan " + PG.money(it.rm()) + " sebulan" } ?: "Ketat"
        Feasibility.NOT_FEASIBLE -> p.requiredMonthly?.let { "Sukar dicapai: perlu simpan " + PG.money(it.rm()) + " sebulan" } ?: "Sukar dicapai"
        Feasibility.NO_TARGET_DATE -> "Tiada tarikh sasaran"
        Feasibility.PAST_DUE -> "Tarikh sasaran sudah lepas"
    }

    // ---------------- pembantu ----------------

    private fun f(v: String?): String = PG.money(dec(v))

    /** Jawapan pembantu dalam ayat biasa. Nilai diambil terus daripada fakta snapshot (tiada nombor rekaan). */
    fun answerText(a: Answer): String = when (a.source) {
        AnswerSource.AI -> a.aiText ?: ""
        AnswerSource.UNAVAILABLE -> "Soalan ini perlukan AI. Tetapkan kunci AI dalam Tetapan, atau tanya tentang belanja kategori, baki, bil, hutang atau gaji."
        AnswerSource.DETERMINISTIC -> when (a.intent) {
            Intent.SPEND_IN_CATEGORY -> {
                val (k, v) = a.values.entries.firstOrNull()?.toPair() ?: ("" to "0")
                "Belanja " + PG.katLabel(k.removePrefix("spend.mtd.")) + " bulan ini: " + f(v) +
                    (if (a.citations.isNotEmpty()) " (" + a.citations.size + " transaksi)" else "") + "."
            }
            Intent.BALANCE -> {
                val lbl = mapOf("balance.bank" to "Bank", "balance.ewallet" to "E-wallet", "balance.cash" to "Tunai")
                val lines = a.values.entries.map { (k, v) -> (lbl[k] ?: k.removePrefix("balance.")) + ": " + f(v) }
                if (lines.isEmpty()) "Tiada baki direkod." else "Baki hari ini — " + lines.joinToString(" · ")
            }
            Intent.DEBT_TOTAL -> "Jumlah hutang (termasuk baki EPP belum dibil): " + f(a.values["debt.total_owed"]) + "."
            Intent.UPCOMING_BILLS -> {
                val n = a.values["bills.next14.count"]?.toIntOrNull() ?: 0
                if (n == 0) "Tiada bil belum bayar dalam 14 hari ini."
                else "$n bil belum bayar dalam 14 hari, jumlah " + f(a.values["bills.next14.total"]) +
                    (a.values["bills.next_due_date"]?.let { ". Paling awal " + PG.fmtShort(it) } ?: "") + "."
            }
            Intent.INCOME_MONTH -> "Bulan ini: gaji " + f(a.values["income.mtd.salary"]) + " · OT " + f(a.values["income.mtd.overtime"]) +
                " · lain-lain " + f(a.values["income.mtd.other"]) + "."
            Intent.OPEN_QUESTION -> a.aiText ?: ""
        }
    }

    /** Keyakinan "boleh belanja": peratus baki boleh belanja daripada baki tunai (untuk bar). */
    fun spendFrac(r: CashFlowReport): Double =
        if (!r.liquid.isPositive || !r.availableToSpend.isPositive) 0.0
        else (BigDecimal(r.availableToSpend.sen).divide(BigDecimal(r.liquid.sen), 4, java.math.RoundingMode.HALF_UP)).toDouble().coerceIn(0.0, 1.0)
}
