package com.asyraf.hadirku.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.asyraf.hadirku.MainViewModel
import com.asyraf.hadirku.Sheet
import com.asyraf.hadirku.pg.DebtStat
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.Tx

/*
 * SPayLater (Shopee): beli dulu bayar bulan depan. Disimpan sebagai hutang jenis "kad" dengan penyedia "spaylater"
 * supaya belian, bayaran, ramalan, peringatan & lejar guna enjin kad yang sama — tetapi tiada bayaran minimum:
 * bil mesti dibayar penuh, caj lewat RM10 (atau pokok bil jika kurang), ansuran rata 1.5% sebulan atas harga asal.
 */

private fun hb(h: Int): String = h.toString() + "hb"

/** Menu SPayLater: jadual bil semasa, bil seterusnya, had dan ansuran. */
@Composable
fun SplMenuSheet(vm: MainViewModel, d: DebtStat) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val today = vm.today()
    val i = remember(s, today, d.id) { PG.splInfo(s, d.d, today) } ?: return
    val plans = remember(s, today, d.id) { d.d.epp.map { it to PG.eppInfo(it, today) }.filter { it.second.aktif } }
    SheetBody {
        SheetTitle(d.nama, rich("Bil **" + hb(d.d.penyataHari) + "** · bayar sebelum **" + hb(d.d.bayarHari) + "** · bayar penuh, 1 bulan 0%"))
        KadVisual(d.nama, M(i.digunakan), "Bil " + hb(d.d.penyataHari) + " · bayar " + hb(d.d.bayarHari), i.bakiHad?.let { "Boleh guna " + M(Math.max(0.0, it)) })
        if (i.lewat) {
            Box(Modifier.padding(bottom = 8.dp)) {
                Notice(
                    rich("**Lewat bayar.** Shopee kenakan caj lewat " + M(i.cajLewat) + " dan bekukan akaun sehingga bil dibayar." +
                        if (i.cajDicatat) " Caj dah dicatat dalam bil ini." else ""),
                    Tone.BAD, btn = if (!i.cajDicatat) "Catat caj " + M(i.cajLewat) else null, onBtn = { vm.splCatatCajLewat(d.id) },
                )
            }
        }
        Column(Modifier.fillMaxWidth().padding(horizontal = GL).padding(bottom = 12.dp)) {
            // ---- bil semasa
            TGroup("Bil semasa · " + PG.fmtShort(i.tarikhBil))
            TRow("Jumlah bil", M(i.bil), garis = false)
            i.tarikhAkhir?.let { ta ->
                TRow("Tarikh akhir bayar", PG.fmtShort(ta) + " " + PG.parse(ta).y, sub = if (i.bil > 0.004) tempohLagi(d, today) else null, color = if (i.lewat) pal.bad else null)
            }
            TRow("Dah bayar", M(i.dibayar))
            TRow("Tinggal", if (i.tinggal > 0.004) M(i.tinggal) else "✔ Selesai", color = if (i.tinggal > 0.004) pal.bad else pal.good, bold = true)
            // ---- bil seterusnya (sedang terkumpul)
            TGroup("Bil seterusnya · " + PG.fmtShort(i.tarikhBilSeterusnya))
            TRow("Belanja sejak " + PG.fmtShort(i.tarikhBil), M(i.belanjaKini), garis = false)
            val ansuranNext = PG.round2(i.bilSeterusnya - i.belanjaKini)
            if (ansuranNext > 0.004) TRow("Ansuran", M(ansuranNext))
            TRow("Anggaran bil", M(i.bilSeterusnya), bold = true)
            // ---- had
            TGroup("Had SPayLater")
            if (i.had > 0.004) {
                TRow("Had", M(i.had), garis = false)
                TRow("Dah guna", M(i.digunakan), sub = "termasuk pokok ansuran belum dibil", color = if (i.digunakan >= i.had * 0.9) pal.bad else null)
                TRow("Baki boleh guna", M(Math.max(0.0, i.bakiHad ?: 0.0)), bold = true)
            } else TRow("Dah guna", M(i.digunakan), sub = "isi had dalam Tetapan SPayLater", garis = false)
            // ---- ansuran
            if (plans.isNotEmpty()) {
                TGroup("Ansuran")
                EppJadual(vm, d.id, plans)
            }
        }
        if (i.tinggal > 0.004) MenuBtn("Bayar bil " + M(i.tinggal), { vm.payDebt(d.id) }, primary = true)
        else if (d.baki > 0.004) MenuBtn("Bayar awal " + M(d.baki), {
            vm.newTx(Tx(jenis = "keluar", poket = d.poket, jumlah = d.baki, perkara = "Bayar " + d.nama, hutangId = d.id), "Bayar awal " + d.nama)
        }, primary = true)
        MenuBtn("Belanja guna " + d.nama, { vm.newTx(Tx(jenis = "kad", kadId = d.id), "Belanja guna " + d.nama) })
        MenuBtn("+ Ansuran 3 / 6 / 12 bulan", { vm.open(Sheet.SplAnsuran(d.id)) })
        MenuBtn("Betulkan bil ikut app Shopee", { vm.open(Sheet.SplBetul(d.id)) })
        MenuBtn("Sejarah", { vm.open(Sheet.HHist(d.id)) })
        MenuBtn("Tetapan SPayLater", { vm.open(Sheet.SplForm(d.id)) })
        Spacer(Modifier.height(6.dp))
        Note("Belanja 1 bulan: 0%, masuk bil berikutnya. Ansuran: 1.5% sebulan atas harga asal (3 bulan 0% untuk kebanyakan belian di Shopee, tetapi ShopeeFood, bil & prabayar tetap dikenakan). Lewat bayar: caj RM10 atau pokok bil jika kurang.")
    }
}

/** Tetapan / tambah akaun SPayLater. */
@Composable
fun SplFormSheet(vm: MainViewModel, id: String?) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val d = if (id != null) s.debts.find { it.id == id } else null
    var nama by remember { mutableStateOf(d?.nama ?: "SPayLater") }
    var kit by remember { mutableStateOf(PG.SPL_KITARAN.indexOfFirst { it.first == d?.penyataHari }.takeIf { it >= 0 } ?: 0) }
    var had by remember { mutableStateOf(d?.hadKredit?.takeIf { it > 0.004 }?.let { PG.toFixed(it, 2) } ?: "") }
    var asing by remember { mutableStateOf(d?.asingkan ?: true) }
    var poket by remember { mutableStateOf(d?.poket ?: (if (s.pockets.any { it.id == "p-komitmen" }) "p-komitmen" else "")) }
    var bil by remember { mutableStateOf("") }
    var belum by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    val fr = autoFocus(false)
    val today = vm.today()
    val (bh, ah) = PG.SPL_KITARAN[kit]
    val per = PG.kitaranPenyata(today, bh)
    val akhir = PG.tarikhAkhirBayar(per.start, ah)
    // asingkan duit = pindahan maya dari poket bank, jadi poket e-wallet / tunai tak boleh dipilih
    val opts = s.pockets.filter { it.id != PG.BELUM_AGIH && (!asing || !it.dompet) }
    val poketEff = if (opts.any { it.id == poket }) poket else ""
    SheetBody(actions = {
        SheetActions("Simpan", { err = vm.saveSpl(id, nama, kit, had, poketEff, asing, bil, belum) }, { vm.close() })
    }) {
        SheetTitle(if (id != null) "Tetapan SPayLater" else "Tambah SPayLater", rich("Beli dulu, bayar bulan depan. Bil mesti dibayar **penuh** sebelum tarikh akhir."))
        Form {
            FieldText("Nama", nama, { nama = it }, placeholder = "SPayLater", maxLen = 40, fr = fr)
            FieldChips(
                "Kitaran bil", PG.SPL_KITARAN.mapIndexed { k, (b, a) -> k.toString() to ("Bil " + hb(b) + " → bayar " + hb(a)) }, kit.toString(), { kit = it.toInt() },
                stack = true,
                note = {
                    Txt("Lihat dalam app Shopee → SPayLater → bil. Bil semasa " + PG.fmtShort(per.start) + (if (akhir != null) ", bayar sebelum " + PG.fmtShort(akhir) else "") + ".",
                        size = 12.5f, color = pal.muted)
                },
            )
            FieldText("Had SPayLater (RM)", had, { had = it }, placeholder = "cth 1500", kb = KeyboardType.Decimal, maxLen = 10,
                small = "Di halaman SPayLater: Total Limit. Kosongkan kalau tak pasti.")
            if (id == null) {
                FieldText("Bil " + PG.fmtShort(per.start) + " belum dibayar (RM)", bil, { bil = it }, placeholder = "0.00", kb = KeyboardType.Decimal, maxLen = 10,
                    small = "Jumlah bil semasa yang masih perlu dibayar. Kosongkan kalau tiada.")
                FieldText("Belanja sejak " + PG.fmtShort(per.start) + " (belum dibil, RM)", belum, { belum = it }, placeholder = "0.00", kb = KeyboardType.Decimal, maxLen = 10,
                    small = "Masuk bil " + PG.fmtShort(per.endExcl) + ". Kosongkan kalau tiada.")
            }
            FieldChips(
                "Bila belanja guna SPayLater", listOf("asing" to "Asingkan duit sekarang", "nanti" to "Bayar bila bil sampai"), if (asing) "asing" else "nanti", { asing = it == "asing" },
                stack = true,
                note = {
                    Txt(
                        if (asing) "Setiap belanja, jumlahnya terus dipindah dari poket belanja ke poket di bawah. Bajet poket terus berkurang dan duit bil dah sedia."
                        else "Duit tak dipindah. Bil dibayar dari poket di bawah bila sampai. Sesuai kalau guna SPayLater sementara tunggu gaji.",
                        size = 12.5f, color = pal.muted,
                    )
                },
            )
            FieldGrid(if (asing) "Poket untuk bayar bil" else "Bayar bil dari poket", pocketOpts(opts), poketEff, { poket = it })
        }
        Box(Modifier.padding(horizontal = GL)) { FormError(err) }
        if (id != null) {
            Spacer(Modifier.height(8.dp))
            DelZone("Padam SPayLater", "Padam akaun SPayLater ini dan semua rekod bilnya? Transaksi belanja & bayaran kekal, cuma tak lagi dikaitkan.", { vm.delH(id) })
        }
    }
}

/** Ansuran SPayLater baru: kira caj, ansuran & EPR sebelum simpan. */
@Composable
fun SplAnsuranSheet(vm: MainViewModel, debtId: String) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val d = s.debts.find { it.id == debtId } ?: return
    var nama by remember { mutableStateOf("") }
    var harga by remember { mutableStateOf("") }
    var tempoh by remember { mutableStateOf("3") }
    var kadar by remember { mutableStateOf("caj") }
    var tarikh by remember { mutableStateOf(vm.today()) }
    var err by remember { mutableStateOf("") }
    val fr = autoFocus(true)
    val h = vm.parseAmt(harga).let { if (it.isFinite() && it > 0) it else 0.0 }
    val n = tempoh.toIntOrNull() ?: 3
    val kb = if (kadar == "kosong") 0.0 else PG.SPL_KADAR_BULAN
    val p = PG.splPelan(h, n, kb)
    val bil1 = PG.splTarikhBil(d, tarikh.ifEmpty { vm.today() })
    SheetBody(actions = {
        SheetActions("Simpan", { err = vm.saveSplAnsuran(debtId, nama, harga, n, kb, tarikh) }, { vm.open(Sheet.HMenu(debtId)) })
    }) {
        SheetTitle("Ansuran " + d.nama, rich("Caj rata **1.5% sebulan atas harga asal**, kecuali promosi 0%."))
        Form {
            FieldText("Barang", nama, { nama = it }, placeholder = "cth: Kasut sukan", maxLen = 40, fr = fr, capital = true)
            FieldText("Harga (RM)", harga, { harga = it }, placeholder = "0.00", kb = KeyboardType.Decimal, big = true, maxLen = 10)
            FieldChips("Tempoh", listOf("3", "6", "12", "18", "24").map { it to "$it bln" }, tempoh, { tempoh = it }, stack = false)
            FieldChips("Caj", listOf("caj" to "1.5% sebulan", "kosong" to "0% (promosi)"), kadar, { kadar = it }, stack = false, note = {
                Txt("3 bulan biasanya 0% untuk belian di Shopee. ShopeeFood, insurans, bil & prabayar, dan bayaran di luar Shopee tetap 1.5% sebulan. Semak di skrin checkout.",
                    size = 12.5f, color = pal.muted)
            })
            FieldDate("Tarikh beli", tarikh, { tarikh = it }, small = "Ansuran pertama masuk bil " + PG.fmtShort(bil1) + ".")
        }
        if (h > 0.004) {
            Column(Modifier.fillMaxWidth().padding(horizontal = GL).padding(top = 10.dp).background(pal.surface).padding(vertical = 4.dp)) {
                JRow(listOf("Harga", "Caj", "Jumlah bayar"), header = true)
                JRow(listOf(rmTanpa(h), rmTanpa(p.caj), rmTanpa(p.jumlah)), total = true)
                Spacer(Modifier.height(6.dp))
                TRow("Ansuran sebulan", M(p.ansuran) + (if (Math.abs(p.akhir - p.ansuran) > 0.004) " (akhir " + M(p.akhir) + ")" else ""), garis = false, bold = true)
                if (p.epr > 0.004) TRow("Kos sebenar setahun (EPR)", PG.toFixed(p.epr, 2) + "%", sub = "caj atas harga asal walaupun baki berkurang", color = pal.warn)
            }
        }
        Box(Modifier.padding(horizontal = GL)) { FormError(err) }
        Note("Ansuran direkod sebagai hutang SPayLater dan masuk bil setiap bulan. Ia tidak dikira sebagai belanja kategori (sama macam EPP kad).", Modifier.padding(top = 8.dp))
    }
}

/** Betulkan bil kitaran semasa supaya sama dengan app Shopee. */
@Composable
fun SplBetulSheet(vm: MainViewModel, debtId: String) {
    val s by vm.pg.collectAsState()
    val d = s.debts.find { it.id == debtId } ?: return
    val today = vm.today()
    val i = remember(s, today, debtId) { PG.splInfo(s, d, today) } ?: return
    var bil by remember { mutableStateOf(if (i.bil > 0.004) PG.toFixed(i.bil, 2) else "") }
    var err by remember { mutableStateOf("") }
    val fr = autoFocus(true)
    SheetBody(actions = {
        SheetActions("Simpan", { err = vm.splBetulBil(debtId, bil) }, { vm.open(Sheet.HMenu(debtId)) })
    }) {
        SheetTitle("Betulkan bil " + PG.fmtShort(i.tarikhBil), rich("App kira **" + M(i.bil) + "**. Isi jumlah bil penuh seperti dalam app Shopee (sebelum bayaran)."))
        Form {
            FieldText("Jumlah bil (RM)", bil, { bil = it }, placeholder = "0.00", kb = KeyboardType.Decimal, big = true, maxLen = 10, fr = fr,
                small = "Shopee → SPayLater → bil " + PG.fmtShort(i.tarikhBil) + ". Bayaran yang dah dibuat (" + M(i.dibayar) + ") kekal dan ditolak.")
        }
        Box(Modifier.padding(horizontal = GL)) { FormError(err) }
        Note("Belanja sejak " + PG.fmtShort(i.tarikhBil) + " tidak berubah — ia masuk bil seterusnya.", Modifier.padding(top = 8.dp))
    }
}
