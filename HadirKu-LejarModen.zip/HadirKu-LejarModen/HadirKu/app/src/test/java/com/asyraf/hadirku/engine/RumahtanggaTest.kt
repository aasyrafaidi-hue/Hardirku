package com.asyraf.hadirku.engine

import com.asyraf.hadirku.engine.core.Money
import com.asyraf.hadirku.engine.forecast.EventKind
import com.asyraf.hadirku.engine.forecast.ForecastEngine
import com.asyraf.hadirku.engine.ledger.PgLedgerAdapter
import com.asyraf.hadirku.kongsi.JadualNafkah
import com.asyraf.hadirku.kongsi.Nafkah
import com.asyraf.hadirku.kongsi.Rumahtangga
import com.asyraf.hadirku.kongsi.Tabung
import com.asyraf.hadirku.pg.NafkahTetap
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.PgSettings
import com.asyraf.hadirku.pg.PgState
import com.asyraf.hadirku.pg.Pocket
import com.asyraf.hadirku.pg.Tx
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

/** Ciri live antara app suami & isteri: duit dapur, minta duit, nafkah bulanan, tabung bersama. */
class RumahtanggaTest {
    private val POKET = listOf(Pocket(PG.BELUM_AGIH, "Belum Agih"), Pocket("p-dapur", "Dapur"), Pocket("p-tabung", "Tabung Raya"))

    private fun dapur(id: String, jumlah: Double, terima: String, dibuat: Long = 1, pulang: Double = 0.0, pulangTx: String = "", selesai: Boolean = false) =
        Nafkah(id, jumlah, "", "suami", terima, diterima = true, dibuat = dibuat, jenis = "dapur", diterimaTarikh = terima,
            pulang = pulang, pulangTx = pulangTx, selesai = selesai)

    private fun keluar(id: String, t: String, j: Double, kat: String = "dapur") = Tx(id, t, "keluar", "p-dapur", jumlah = j, kategori = kat)

    @Test fun duitDapurGunaDanBaki() {
        val s = PgState(pockets = POKET, transactions = listOf(
            Tx("in", "2026-11-01", "masuk", PG.BELUM_AGIH, jumlah = 250.0, perkara = "Duit dapur dari Abang"),
            keluar("a", "2026-10-30", 40.0),                 // sebelum terima — tidak dikira
            keluar("b", "2026-11-02", 120.50),
            keluar("c", "2026-11-05", 30.0, kat = "makan"),  // bukan dapur
            Tx("k", "2026-11-06", "kad", "p-dapur", kadId = "x", jumlah = 45.0, kategori = "dapur"),
            Tx("r", "2026-11-07", "masuk", "p-dapur", jumlah = 10.0, kategori = "dapur", pulangan = true), // refund kedai
        ))
        val n = dapur("d1", 250.0, "2026-11-01")
        val g = Rumahtangga.gunaDapur(s, listOf(n))
        assertEquals(155.50, g.getValue("d1"), 1e-9)          // 120.50 + 45 − 10
        assertEquals(94.50, n.copy(guna = 155.50).baki, 1e-9)
        assertEquals(94.50, Rumahtangga.bakiDapur(listOf(n.copy(guna = 155.50)))!!, 1e-9)
    }

    @Test fun duaDuitDapurIkutGiliranDanTidakMelebihi() {
        val s = PgState(pockets = POKET, transactions = listOf(
            keluar("b1", "2026-11-03", 180.0), keluar("b2", "2026-11-10", 90.0), keluar("b3", "2026-11-12", 200.0),
        ))
        val a = dapur("d1", 200.0, "2026-11-01", dibuat = 1)
        val b = dapur("d2", 150.0, "2026-11-08", dibuat = 2)
        val g = Rumahtangga.gunaDapur(s, listOf(b, a))
        assertEquals(200.0, g.getValue("d1"), 1e-9)   // 180 + 20 daripada b2
        assertEquals(150.0, g.getValue("d2"), 1e-9)   // baki 70 b2 + 80 b3 (penuh); lebihan 120 bukan duit dapur
    }

    @Test fun pulangBakiTidakDikiraBelanjaDanDitutup() {
        val s = PgState(pockets = POKET, transactions = listOf(
            keluar("b", "2026-11-03", 200.0), keluar("ret", "2026-11-20", 50.0),
        ))
        val buka = dapur("d1", 250.0, "2026-11-01", pulangTx = "ret")
        assertEquals(200.0, Rumahtangga.gunaDapur(s, listOf(buka)).getValue("d1"), 1e-9)
        val tutup = buka.copy(guna = 200.0, pulang = 50.0, selesai = true)
        assertFalse(tutup.dapurAktif)
        assertEquals(0.0, tutup.baki, 1e-9)
        assertTrue(tutup.pulangBelumDirekod)
        assertNull(Rumahtangga.bakiDapur(listOf(tutup)))
        assertTrue(Rumahtangga.gunaDapur(s, listOf(tutup)).isEmpty())
    }

    @Test fun permintaanBukanDuitDihantar() {
        val minta = Nafkah("m", 50.0, "ubat anak", "", "2026-11-20", false, 5, minta = "tunggu", peminta = "isteri")
        assertTrue(minta.tungguJawapan); assertFalse(minta.dihantar)
        assertFalse(minta.copy(minta = "tolak").dihantar)
        val lulus = minta.copy(minta = "lulus", dari = "suami")
        assertTrue(lulus.dihantar); assertFalse(lulus.tungguJawapan)
        // dokumen nafkah lama (tiada medan baharu) tetap dikira dihantar
        assertTrue(Nafkah("lama", 500.0, "", "suami", "2026-10-30", true, 1).dihantar)
    }

    @Test fun ingatanNafkahBulananSuami() {
        val j = JadualNafkah(800.0, 30)
        assertFalse(Rumahtangga.perluHantarNafkah(j, emptyList(), "2026-11-29"))   // belum sampai 30hb
        assertTrue(Rumahtangga.perluHantarNafkah(j, emptyList(), "2026-11-30"))
        val dah = listOf(Nafkah("n", 800.0, "", "suami", "2026-11-30", false, 1))
        assertFalse(Rumahtangga.perluHantarNafkah(j, dah, "2026-11-30"))
        // duit dapur bukan nafkah
        assertTrue(Rumahtangga.perluHantarNafkah(j, listOf(dah[0].copy(jenis = "dapur")), "2026-11-30"))
        // 31 = hujung bulan: Februari 28hb
        assertEquals("2027-02-28", Rumahtangga.tarikhNafkah(JadualNafkah(800.0, 31), "2027-02"))
        assertFalse(Rumahtangga.perluHantarNafkah(null, emptyList(), "2026-11-30"))
    }

    @Test fun ramalanIsteriJangkaNafkahBulanan() {
        val base = PgState(pockets = POKET, settings = PgSettings(gaji = com.asyraf.hadirku.pg.Gaji(basic = 0.0, night = 0.0, transport = 0.0),
            nafkahTetap = NafkahTetap(800.0, 30, masuk = true)), transactions = listOf(
            Tx("o", "2026-11-01", "baki-awal", PG.BELUM_AGIH, jumlah = 300.0),
        ))
        val d = LocalDate.of(2026, 11, 20)
        val f = ForecastEngine.project(base, PgLedgerAdapter.build(base, d).book, d, 75)
        val n = f.events.filter { it.refId.startsWith("nafkah:") }
        assertEquals(listOf("2026-11-30", "2026-12-30", "2027-01-30"), n.map { it.date.toString() })
        assertTrue(n.all { it.kind == EventKind.SALARY && it.amount == Money.parse("800.00") })
        // nafkah November sudah diterima → hanya Dis & Jan
        val dah = base.copy(transactions = base.transactions + Tx("n", "2026-11-18", "masuk", PG.BELUM_AGIH, jumlah = 800.0, perkara = "Nafkah dari Abang"))
        val f2 = ForecastEngine.project(dah, PgLedgerAdapter.build(dah, d).book, d, 75)
        assertEquals(listOf("2026-12-30", "2027-01-30"), f2.events.filter { it.refId.startsWith("nafkah:") }.map { it.date.toString() })
        // app suami (masuk = false): tiada jangkaan (elak kira dua kali dengan komitmen nafkah sendiri)
        val suami = base.copy(settings = base.settings.copy(nafkahTetap = NafkahTetap(800.0, 30, masuk = false)))
        assertTrue(ForecastEngine.project(suami, PgLedgerAdapter.build(suami, d).book, d, 75).events.none { it.refId.startsWith("nafkah:") })
        assertEquals(800.0, PG.nafkahBulan(dah, "2026-11", true), 1e-9)
    }

    @Test fun tabungBersamaJumlahDanPeratus() {
        val t = Tabung("t", "Duit raya", 1000.0, "", mapOf("suami" to 300.0, "isteri" to 150.25), 1)
        assertEquals(450.25, t.jumlah, 1e-9)
        assertEquals(0.45025, t.peratus, 1e-9)
        assertEquals(0.0, t.copy(sasaran = 0.0).peratus, 0.0)
        assertEquals(1.0, t.copy(ahli = mapOf("a" to 2000.0)).peratus, 0.0)
        // sumbangan telefon = baki poket tabung (pindah masuk − keluar), bukan perbelanjaan
        val s = PgState(pockets = POKET, transactions = listOf(
            Tx("o", "2026-11-01", "baki-awal", PG.BELUM_AGIH, jumlah = 1000.0),
            Tx("a", "2026-11-02", "pindah", PG.BELUM_AGIH, ke = "p-tabung", jumlah = 300.0),
            Tx("b", "2026-11-10", "pindah", "p-tabung", ke = PG.BELUM_AGIH, jumlah = 49.75),
        ))
        assertEquals(250.25, PG.balances(s).getValue("p-tabung"), 1e-9)
        assertEquals(0.0, PG.periodReport(s, PG.finPeriod("2026-11-15", 1)).belanja, 1e-9)
    }
}
