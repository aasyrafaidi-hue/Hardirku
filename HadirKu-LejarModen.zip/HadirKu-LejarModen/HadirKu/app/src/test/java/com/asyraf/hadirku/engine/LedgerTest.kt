package com.asyraf.hadirku.engine

import com.asyraf.hadirku.engine.TestKit.D
import com.asyraf.hadirku.engine.TestKit.T0
import com.asyraf.hadirku.engine.TestKit.bank
import com.asyraf.hadirku.engine.TestKit.book
import com.asyraf.hadirku.engine.TestKit.card
import com.asyraf.hadirku.engine.TestKit.cash
import com.asyraf.hadirku.engine.TestKit.expense
import com.asyraf.hadirku.engine.TestKit.must
import com.asyraf.hadirku.engine.TestKit.opening
import com.asyraf.hadirku.engine.TestKit.rm
import com.asyraf.hadirku.engine.core.DateRange
import com.asyraf.hadirku.engine.core.Money
import com.asyraf.hadirku.engine.ledger.ChargeKind
import com.asyraf.hadirku.engine.ledger.Entry
import com.asyraf.hadirku.engine.ledger.EntryType
import com.asyraf.hadirku.engine.ledger.LedgerIntegrity
import com.asyraf.hadirku.engine.ledger.LedgerIssue
import com.asyraf.hadirku.engine.ledger.LedgerOps
import com.asyraf.hadirku.engine.ledger.LedgerReports
import com.asyraf.hadirku.engine.ledger.PostResult
import org.junit.Assert.assertEquals
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test
import java.math.BigDecimal

class MoneyTest {
    @Test fun parsesAndAddsExactly() {
        assertEquals(1230L, Money.parse("12.30").sen)
        assertEquals(123450L, Money.parse("1,234.50").sen)
        assertEquals(Money.parse("0.30"), Money.parse("0.10") + Money.parse("0.20")) // no 0.30000000000000004
        assertEquals(1230L, Money.fromDouble(12.3).sen)
        assertEquals(495310L, Money.fromDouble(4953.1000000001).sen)
    }

    @Test(expected = ArithmeticException::class)
    fun overflowIsDetected() { Money(Long.MAX_VALUE) + Money(1) }

    @Test(expected = IllegalArgumentException::class)
    fun nanIsRejected() { Money.fromDouble(Double.NaN) }

    @Test fun splitEvenSumsExactlyAndLastAbsorbsRemainder() {
        val parts = Money.parse("100.00").splitEven(3)
        assertEquals(listOf(3333L, 3333L, 3334L), parts.map { it.sen })
        assertEquals(Money.parse("100.00"), Money.sum(parts))
    }

    @Test fun ratioRounding() {
        assertEquals(Money.parse("4.95"), Money.parse("98.90").times(BigDecimal("0.05")))
    }
}

class LedgerTest {
    /** Spec scenario 1 */
    @Test fun expenseLeavesCorrectBalance() {
        val b = book(bank("a")).must(opening("o", "a", "100.00")).must(expense("e", "a", "12.30"))
        assertEquals(rm("87.70"), b.balance("a"))
    }

    /** Spec scenario 2 */
    @Test fun transferChangesNeitherNetWorthNorExpense() {
        var b = book(bank("a"), cash("c")).must(opening("o", "a", "200.00"))
        val nw = b.netWorth()
        b = b.must(Entry("tr", D, EntryType.TRANSFER, rm("50.00"), from = "a", to = "c"))
        assertEquals(nw, b.netWorth())
        assertEquals(rm("150.00"), b.balance("a"))
        assertEquals(rm("50.00"), b.balance("c"))
        val t = LedgerReports.totals(b)
        assertEquals(Money.ZERO, t.expense)
        assertEquals(rm("50.00"), t.transfers)
    }

    @Test fun multipleAccountsAndCardPurchaseAndPartialRepayment() {
        var b = book(bank("a"), card("k")).must(opening("o", "a", "1000.00"))
        b = b.must(expense("p1", "k", "300.00", "dapur"))                     // charged to card
        b = b.must(Entry("int", D, EntryType.CHARGE, rm("4.50"), from = "k", chargeKind = ChargeKind.INTEREST))
        b = b.must(Entry("rp", D, EntryType.DEBT_REPAYMENT, rm("100.00"), from = "a", to = "k")) // partial
        assertEquals(rm("900.00"), b.balance("a"))
        assertEquals(rm("-204.50"), b.balance("k"))                           // still owe 204.50
        val t = LedgerReports.totals(b)
        assertEquals(rm("300.00"), t.expense)                                 // purchase counted once
        assertEquals(rm("4.50"), t.interest)                                  // interest identifiable
        assertEquals(rm("100.00"), t.debtRepayment)                           // repayment is not spending
    }

    /** Spec scenario 6 */
    @Test fun duplicateImportDoesNotPostTwice() {
        var b = book(bank("a")).must(opening("o", "a", "50.00"))
        b = b.must(expense("imp1", "a", "10.00"), key = "csv:hash-1")
        val r = LedgerOps.post(b, expense("imp2", "a", "10.00"), T0, "csv:hash-1")
        assertTrue(r.result is PostResult.Duplicate)
        assertEquals("imp1", (r.result as PostResult.Duplicate).existingId)
        assertEquals(2, r.book.entries.size)
        assertEquals(rm("40.00"), r.book.balance("a"))
    }

    /** Spec scenario 9 */
    @Test fun refundAndReversalUpdateBalancesAndCategories() {
        var b = book(bank("a")).must(opening("o", "a", "100.00"))
        b = b.must(expense("e1", "a", "40.00", "diri"))
        b = b.must(expense("e2", "a", "15.00", "makan"))
        b = LedgerOps.refund(b, "e1", rm("10.00"), "rf1", D, T0).book            // partial refund
        assertEquals(rm("55.00"), b.balance("a"))
        b = LedgerOps.reverse(b, "e2", "rv2", D, T0).book                        // undo wrong entry
        assertEquals(rm("70.00"), b.balance("a"))
        val cats = LedgerReports.expenseByCategory(b)
        assertEquals(rm("30.00"), cats["diri"])
        assertEquals(null, cats["makan"])                                         // reversed pair removed
        assertEquals(rm("30.00"), LedgerReports.totals(b).expense)
        // over-refund rejected, double reversal rejected
        val over = LedgerOps.refund(b, "e1", rm("30.01"), "rf2", D, T0)
        assertEquals(listOf(LedgerIssue.REFUND_EXCEEDS_ORIGINAL), (over.result as PostResult.Rejected).issues)
        val again = LedgerOps.reverse(b, "e2", "rv3", D, T0)
        assertTrue(LedgerIssue.ALREADY_REVERSED in (again.result as PostResult.Rejected).issues)
        assertTrue(LedgerIntegrity.check(b).isEmpty())
        assertTrue(b.audit.size >= 5)
    }

    @Test fun batchIsAtomic() {
        val b0 = book(bank("a")).must(opening("o", "a", "10.00"))
        val r = LedgerOps.postBatch(b0, listOf(
            expense("x1", "a", "1.00") to null,
            expense("x2", "nope", "1.00") to null,   // unknown account → whole batch rejected
        ), T0)
        assertSame(b0, r.book)
        assertTrue(r.result.last() is PostResult.Rejected)
    }

    @Test fun rulesRejectBadEntries() {
        val b = book(bank("a"), card("k"))
        fun issues(e: Entry) = LedgerOps.validate(b, e)
        assertTrue(LedgerIssue.NON_POSITIVE_AMOUNT in issues(Entry("z", D, EntryType.EXPENSE, Money.ZERO, from = "a")))
        assertTrue(LedgerIssue.SAME_FROM_TO in issues(Entry("z", D, EntryType.TRANSFER, rm("1"), from = "a", to = "a")))
        assertTrue(LedgerIssue.REPAYMENT_TARGET_NOT_LIABILITY in issues(Entry("z", D, EntryType.DEBT_REPAYMENT, rm("1"), from = "a", to = "a")))
        assertTrue(LedgerIssue.CHARGE_NEEDS_KIND in issues(Entry("z", D, EntryType.CHARGE, rm("1"), from = "k")))
        assertTrue(LedgerIssue.CURRENCY_MISMATCH in issues(Entry("z", D, EntryType.EXPENSE, rm("1"), from = "a", currency = "USD")))
    }

    @Test fun balancesAsOfDateAndRunningBalanceAreDeterministic() {
        var b = book(bank("a")).must(opening("o", "a", "10.00", D.minusDays(5)))
        b = b.must(expense("late", "a", "3.00", date = D.plusDays(2)))
        b = b.must(expense("now", "a", "1.00", date = D))
        assertEquals(rm("9.00"), b.balance("a", D))
        assertEquals(listOf("o", "now", "late"), b.runningBalance("a").map { it.first.id })
        assertEquals(rm("6.00"), b.runningBalance("a").last().second)
        assertEquals(rm("4.00"), LedgerReports.totals(b, DateRange.inclusive(D.minusDays(1), D.plusDays(5))).expense)
    }
}

/** Semakan integriti versi linear mesti beri keputusan sama dengan versi lama (salin buku setiap entri). */
class IntegrityEquivalenceTest {
    private fun lama(book: com.asyraf.hadirku.engine.ledger.LedgerBook): List<com.asyraf.hadirku.engine.ledger.LedgerIntegrity.Problem> {
        val out = ArrayList<com.asyraf.hadirku.engine.ledger.LedgerIntegrity.Problem>()
        val seen = HashSet<String>()
        var replay = com.asyraf.hadirku.engine.ledger.LedgerBook(accounts = book.accounts)
        for (e in book.entries) {
            if (!seen.add(e.id)) { out += com.asyraf.hadirku.engine.ledger.LedgerIntegrity.Problem(e.id, com.asyraf.hadirku.engine.ledger.LedgerIssue.DUPLICATE_ID); continue }
            com.asyraf.hadirku.engine.ledger.LedgerOps.validate(replay, e).filter { it != com.asyraf.hadirku.engine.ledger.LedgerIssue.DUPLICATE_ID }
                .forEach { out += com.asyraf.hadirku.engine.ledger.LedgerIntegrity.Problem(e.id, it) }
            replay = replay.copy(entries = replay.entries + e)
        }
        return out
    }

    @org.junit.Test fun sameProblemsAsOldAlgorithm() {
        for (d in listOf("2026-02-28", "2026-11-26", "2026-12-31")) {
            val s = com.asyraf.hadirku.pg.PgSample.sampleState(d)
            val book = com.asyraf.hadirku.engine.ledger.PgLedgerAdapter.build(s, java.time.LocalDate.parse(d)).book
            org.junit.Assert.assertEquals(lama(book), com.asyraf.hadirku.engine.ledger.LedgerIntegrity.check(book))
        }
        // kes sukar: refund berlebihan, refund terbalik lalu refund semula, terbalik dua kali, sasaran hilang, id berganda
        val acc = mapOf(
            "p:a" to com.asyraf.hadirku.engine.ledger.Account("p:a", "A", com.asyraf.hadirku.engine.ledger.AccountKind.ASSET, com.asyraf.hadirku.engine.ledger.Storage.BANK),
        )
        val d0 = java.time.LocalDate.of(2026, 11, 1)
        fun m(v: String) = com.asyraf.hadirku.engine.core.Money.parse(v)
        val es = listOf(
            com.asyraf.hadirku.engine.ledger.Entry("e1", d0, com.asyraf.hadirku.engine.ledger.EntryType.EXPENSE, m("50"), from = "p:a", category = "makan"),
            com.asyraf.hadirku.engine.ledger.Entry("r1", d0, com.asyraf.hadirku.engine.ledger.EntryType.REFUND, m("30"), to = "p:a", refundOf = "e1"),
            com.asyraf.hadirku.engine.ledger.Entry("r2", d0, com.asyraf.hadirku.engine.ledger.EntryType.REFUND, m("30"), to = "p:a", refundOf = "e1"),       // melebihi
            com.asyraf.hadirku.engine.ledger.Entry("v1", d0, com.asyraf.hadirku.engine.ledger.EntryType.REVERSAL, m("30"), from = "p:a", reverses = "r1"),
            com.asyraf.hadirku.engine.ledger.Entry("r3", d0, com.asyraf.hadirku.engine.ledger.EntryType.REFUND, m("30"), to = "p:a", refundOf = "e1"),       // sah selepas r1 terbalik
            com.asyraf.hadirku.engine.ledger.Entry("v2", d0, com.asyraf.hadirku.engine.ledger.EntryType.REVERSAL, m("30"), from = "p:a", reverses = "r1"),   // dah terbalik
            com.asyraf.hadirku.engine.ledger.Entry("r4", d0, com.asyraf.hadirku.engine.ledger.EntryType.REFUND, m("5"), to = "p:a", refundOf = "tiada"),
            com.asyraf.hadirku.engine.ledger.Entry("e1", d0, com.asyraf.hadirku.engine.ledger.EntryType.EXPENSE, m("1"), from = "p:a"),
        )
        val book = com.asyraf.hadirku.engine.ledger.LedgerBook(accounts = acc, entries = es)
        org.junit.Assert.assertEquals(lama(book), com.asyraf.hadirku.engine.ledger.LedgerIntegrity.check(book))
    }
}
