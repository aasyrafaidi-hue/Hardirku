package com.asyraf.hadirku.engine

import com.asyraf.hadirku.kongsi.Barang
import com.asyraf.hadirku.kongsi.SejarahBeli
import com.asyraf.hadirku.rumah.Belanja
import com.asyraf.hadirku.rumah.Dapur
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Senarai barang dapur: jumlah ikut unit × harga, MyKasih diasingkan dan tidak direkod sebagai belanja. */
class DapurTest {
    private fun b(id: String, nama: String, unit: Double, harga: Double, mk: Boolean = false, dibeli: Boolean = false, dibuat: Long = id.hashCode().toLong()) =
        Barang(id, nama, "", dibeli, "u1", dibuat, unit, harga, mk)

    private val senarai = listOf(
        b("a", "Beras 10kg", 1.0, 26.90, dibuat = 1),
        b("b", "Minyak masak 5kg", 2.0, 29.50, mk = true, dibuat = 2),
        b("c", "Telur gred A", 3.0, 13.20, dibuat = 3),
        b("d", "Gula 1kg", 2.0, 2.85, mk = true, dibuat = 4),
        b("e", "Sabun", 1.0, 0.0, dibuat = 5), // belum ada harga
    )

    private fun c(nama: String, unit: Double, harga: Double, mk: Boolean = false) = Dapur.Cadang(nama, unit, harga, mk)

    @Test fun huraiTeksTanpaAi() {
        val r = Dapur.huraiTeks(
            "Beras 10kg 32.90\nMinyak 2 x 7.50, 2x Gula 3.10; Susu rm12 mykasih\n" +
                "- Telur 30biji\n1. Milo 7.50 x2\nRoti 2,80\n\n  ,  \nAyam 1.5 x 12.90",
        )
        assertEquals(
            listOf(
                c("Beras 10kg", 1.0, 32.9), c("Minyak", 2.0, 7.5), c("Gula", 2.0, 3.1), c("Susu", 1.0, 12.0, mk = true),
                c("Telur 30biji", 1.0, 0.0), c("Milo", 2.0, 7.5), c("Roti", 1.0, 2.8), c("Ayam", 1.5, 12.9),
            ),
            r,
        )
        assertEquals(15.0, r[1].jumlah, 1e-9)
        // MyKasih tidak dikira dalam jumlah bayar sendiri
        assertEquals(PG_round(32.9 + 15.0 + 6.2 + 15.0 + 2.8 + 19.35), Dapur.jumlahCadang(r), 1e-9)
    }

    private fun PG_round(x: Double) = Math.round(x * 100) / 100.0

    @Test fun cadangDibersihkan() {
        assertNull(Dapur.cadang("  ", 1.0, 5.0, false))
        assertNull(Dapur.cadang("12.50", 1.0, 0.0, false))
        assertEquals(c("Sabun", 1.0, 0.0), Dapur.cadang(" sabun - ", -3.0, -1.0, false))
        assertEquals(c("Kicap", 1.0, 0.0), Dapur.cadang("kicap", Double.NaN, Double.POSITIVE_INFINITY, false))
        assertEquals(c("Bawang", 0.75, 8.99), Dapur.cadang("bawang", 0.75, 8.989, false))
    }

    @Test fun lengkapkanHargaLepas() {
        val sej = listOf(SejarahBeli("1", "Beras 10kg", listOf("2026-11-01"), 33.5, false), SejarahBeli("2", "Susu", listOf("2026-11-01"), 12.0, true))
        val kunci = { n: String -> n.lowercase().replace(" ", "") }
        val r = Dapur.lengkapkan(listOf(c("Beras  10KG", 1.0, 0.0), c("Susu", 2.0, 0.0), c("Gula", 1.0, 0.0), c("Beras 10kg", 1.0, 31.0)), sej, kunci)
        assertEquals(Dapur.Cadang("Beras  10KG", 1.0, 33.5, false, hargaLepas = true), r[0])
        assertEquals(Dapur.Cadang("Susu", 2.0, 12.0, true, hargaLepas = true), r[1]) // MyKasih ikut kali lepas
        assertEquals(c("Gula", 1.0, 0.0), r[2])            // tiada sejarah → kekal tanpa harga
        assertEquals(c("Beras 10kg", 1.0, 31.0), r[3])     // harga baru tidak diganti
    }

    @Test fun troliSelepasDanBakiHad() {
        val list = listOf(
            b("a", "Beras", 1.0, 30.0, dibeli = true),
            b("b", "Minyak", 2.0, 7.5, dibeli = true),          // 15.00
            b("c", "Susu", 1.0, 20.0, mk = true, dibeli = true), // MyKasih: tak masuk had
            b("d", "Gula", 1.0, 3.0),                            // belum ambil: tak masuk
        )
        // barang baru masuk troli
        assertEquals(57.0, Dapur.troliSelepas(list, null, 12.0, keTroli = true, mykasih = false), 1e-9)
        // barang baru MyKasih / belum ambil → troli tak berubah
        assertEquals(45.0, Dapur.troliSelepas(list, null, 12.0, keTroli = true, mykasih = true), 1e-9)
        assertEquals(45.0, Dapur.troliSelepas(list, null, 12.0, keTroli = false, mykasih = false), 1e-9)
        // ubah barang sedia ada: nilai lama diganti, tidak dikira dua kali
        assertEquals(40.0, Dapur.troliSelepas(list, "b", 10.0, keTroli = true, mykasih = false), 1e-9)
        // keluarkan dari troli
        assertEquals(15.0, Dapur.troliSelepas(list, "a", 30.0, keTroli = false, mykasih = false), 1e-9)
        // barang belum ambil dimasukkan ke troli
        assertEquals(48.0, Dapur.troliSelepas(list, "d", 3.0, keTroli = true, mykasih = false), 1e-9)
        assertEquals(5.0, Dapur.bakiHad(45.0, 50.0), 1e-9)
        assertEquals(-7.0, Dapur.bakiHad(57.0, 50.0), 1e-9)
        assertEquals(0.1, Dapur.bakiHad(0.2, 0.3), 1e-9) // bundar 2 titik perpuluhan
    }

    @Test fun jumlahIkutUnitDanHarga() {
        assertEquals(59.0, senarai[1].jumlah, 0.001)
        assertEquals(39.6, senarai[2].jumlah, 0.001)
        assertEquals(0.0, senarai[4].jumlah, 0.001)
    }

    @Test fun asingkanMyKasihDaripadaBayarSendiri() {
        val r = Dapur.ringkasan(senarai)
        assertEquals(listOf("a", "c", "e"), r.sendiri.barang.map { it.id })
        assertEquals(listOf("b", "d"), r.mykasih.barang.map { it.id })
        assertEquals(66.50, r.sendiri.jumlah, 0.001) // 26.90 + 39.60
        assertEquals(64.70, r.mykasih.jumlah, 0.001) // 59.00 + 5.70
        assertEquals(131.20, r.jumlahSemua, 0.001)
        assertEquals(1, r.sendiri.tanpaHarga)
        assertEquals(0, r.mykasih.tanpaHarga)
        assertEquals(5, r.bil)
    }

    @Test fun nomborItemKekalBilaDitick() {
        val ditick = senarai.map { if (it.id == "a") it.copy(dibeli = true) else it }.shuffled(java.util.Random(7))
        val r = Dapur.ringkasan(ditick)
        assertEquals(listOf("a", "c", "e"), r.sendiri.barang.map { it.id })
    }

    @Test fun rekodHanyaBarangBayarSendiriYangDitick() {
        val ditick = senarai.map { if (it.id in setOf("a", "b", "c")) it.copy(dibeli = true) else it }
        assertEquals(66.50, Dapur.jumlahRekod(ditick), 0.001) // MyKasih (b) tidak dikira
        val r = Dapur.ringkasan(ditick)
        assertEquals(66.50, r.sendiri.jumlahTroli, 0.001)
        assertEquals(59.0, r.mykasih.jumlahTroli, 0.001)
        assertEquals(3, r.troli.size)
        assertEquals("Beras 10kg, Telur gred A ×3", Dapur.perkara(r.sendiri.troli))
    }

    @Test fun bacaUnitDanHarga() {
        assertEquals(1.0, Dapur.bacaUnit("")!!, 0.0)
        assertEquals(1.5, Dapur.bacaUnit("1,5")!!, 0.0)
        assertNull(Dapur.bacaUnit("0"))
        assertNull(Dapur.bacaUnit("-2"))
        assertNull(Dapur.bacaUnit("abc"))
        assertEquals(0.0, Dapur.bacaHarga("")!!, 0.0)
        assertEquals(12.9, Dapur.bacaHarga("RM12.90")!!, 0.0)
        assertEquals(3.5, Dapur.bacaHarga("3,50")!!, 0.0)
        assertNull(Dapur.bacaHarga("abc"))
    }

    @Test fun formatUnitDanWang() {
        assertEquals("2", Dapur.fmtUnit(2.0))
        assertEquals("1.5", Dapur.fmtUnit(1.5))
        assertEquals("0.25", Dapur.fmtUnit(0.25))
        assertEquals("1,234.50", Dapur.fmtRm(1234.5))
    }

    @Test fun perkaraDipotong60Aksara() {
        val banyak = (1..20).map { b("x$it", "Barang nombor $it", 1.0, 1.0, dibuat = it.toLong()) }
        val p = Dapur.perkara(banyak)
        assertTrue(p.length <= 60)
        assertTrue(p.endsWith("…"))
    }

    @Test fun cadanganBawaHargaDanMyKasihTerakhir() {
        val sej = listOf(SejarahBeli("minyak", "Minyak masak", listOf("2026-10-01", "2026-10-15", "2026-10-29"), 29.5, true))
        val c = Belanja.cadangan(sej, emptySet(), "2026-11-12") { it.lowercase().replace(" ", "") }
        assertEquals(1, c.size)
        assertEquals(29.5, c[0].harga, 0.0)
        assertTrue(c[0].mykasih)
    }
}
