package com.asyraf.hadirku.engine

import com.asyraf.hadirku.pg.Commitment
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.PgState
import com.asyraf.hadirku.pg.Pocket
import com.asyraf.hadirku.pg.Tx
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Komitmen: bila semua tempoh ini selesai, paparan beralih ke bulan depan; bayaran awal dibawa ke bulan depan. */
class KomitmenAlihTest {
    private val c1 = Commitment("k1", "TNB", 120.0, tempo = 10, poket = "p1")
    private val c2 = Commitment("k2", "Astro", 80.0, tempo = 20, poket = "p1")
    private fun st(vararg t: Tx) = PgState(pockets = listOf(Pocket("p1", "Bank")), commitments = listOf(c1, c2), transactions = t.toList())
    private fun bayar(id: String, k: Commitment, tarikh: String, rm: Double = k.jumlah) = Tx(id, tarikh, "keluar", "p1", jumlah = rm, perkara = k.nama, komitmenId = k.id)

    @Test fun staysOnCurrentMonthUntilAllPaid() {
        val s = st(bayar("a", c1, "2026-11-09"))
        assertEquals("2026-11-26", PG.commitmentViewDate(s, "2026-11-26"))
        assertFalse(PG.commitmentDiAlih(s, "2026-11-26"))
    }

    @Test fun movesToNextMonthWhenAllPaid() {
        val s = st(bayar("a", c1, "2026-11-09"), bayar("b", c2, "2026-11-19"))
        val vd = PG.commitmentViewDate(s, "2026-11-26")
        assertEquals("2026-12-01", vd)
        val dis = PG.commitmentStatus(s, vd)
        assertTrue(dis.all { it.status == "belum" })
        val sm = PG.commitmentSummary(dis)
        assertEquals(200.0, sm.baki, 0.001); assertEquals(2, sm.belum)
        assertEquals("2026-12-10", PG.tempoDate(dis.first { it.id == "k1" }.c, vd))
    }

    @Test fun earlyPaymentCountsForNextMonthWithoutDoubleCounting() {
        // Nov selesai, kemudian TNB Dis dibayar awal pada 28 Nov
        val s = st(bayar("a", c1, "2026-11-09"), bayar("b", c2, "2026-11-19"), bayar("c", c1, "2026-11-28"))
        val nov = PG.commitmentStatus(s, "2026-11-28")
        assertTrue(nov.all { it.status == "sudah" })                                      // Nov tetap selesai
        val dis = PG.commitmentStatus(s, PG.commitmentViewDate(s, "2026-11-28"))
        assertEquals("sudah", dis.first { it.id == "k1" }.status)                         // TNB Dis dah dibayar
        assertEquals("belum", dis.first { it.id == "k2" }.status)
        assertEquals(80.0, PG.commitmentSummary(dis).baki, 0.001)
        // Pada Dis sebenar, bayaran awal kekal dikira untuk Dis
        assertEquals("sudah", PG.commitmentStatus(s, "2026-12-05").first { it.id == "k1" }.status)
    }

    @Test fun manualMarkUsesViewedPeriodKey() {
        val s = st(bayar("a", c1, "2026-11-09"), bayar("b", c2, "2026-11-19"))
        val vd = PG.commitmentViewDate(s, "2026-11-26")
        assertEquals("2026-12-01", PG.commitmentStatus(s, vd).first().periodKey)
    }
}
