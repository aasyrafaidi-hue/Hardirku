package com.asyraf.hadirku.engine

import com.asyraf.hadirku.engine.app.AppFacade
import com.asyraf.hadirku.engine.budget.Budget
import com.asyraf.hadirku.engine.budget.BudgetEngine
import com.asyraf.hadirku.engine.core.DateRange
import com.asyraf.hadirku.engine.core.Money
import com.asyraf.hadirku.engine.ledger.EntryType
import com.asyraf.hadirku.engine.ledger.LedgerIntegrity
import com.asyraf.hadirku.engine.ledger.LedgerReports
import com.asyraf.hadirku.engine.ledger.PgLedgerAdapter
import com.asyraf.hadirku.engine.reconcile.CsvBankParser
import com.asyraf.hadirku.engine.reconcile.MatchStatus
import com.asyraf.hadirku.engine.reconcile.ReconciliationEngine
import com.asyraf.hadirku.engine.store.EngineData
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.PgState
import com.asyraf.hadirku.pg.Pocket
import com.asyraf.hadirku.pg.Tx
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.YearMonth

/**
 * Kes pemilik: beri isteri RM250 duit dapur → isteri pulangkan RM100 untuk suami beli barang → suami beli RM100.
 * Belanja dapur sebenar = RM250, pendapatan = RM0, baki bank = −RM250.
 */
class PulanganTest {
    private val today = LocalDate.of(2026, 11, 18)

    private fun state(pulang: Boolean = true) = PgState(
        pockets = listOf(Pocket("p1", "Bank")),
        transactions = listOf(
            Tx("t0", "2026-11-01", "baki-awal", "p1", jumlah = 2000.0),
            Tx("t1", "2026-11-05", "keluar", "p1", jumlah = 250.0, perkara = "Duit dapur isteri", kategori = "dapur"),
            Tx("t2", "2026-11-10", "masuk", "p1", jumlah = 100.0, perkara = "Isteri pulangkan duit dapur", kategori = if (pulang) "dapur" else null, pulangan = pulang),
            Tx("t3", "2026-11-10", "keluar", "p1", jumlah = 100.0, perkara = "Mydin", kategori = "dapur"),
        ),
    )

    @Test fun refundReducesCategorySpendingNotIncome() {
        val s = state()
        val r = PgLedgerAdapter.build(s, today)
        assertEquals(emptyList<Any>(), r.issues)
        assertEquals(emptyList<Any>(), PgLedgerAdapter.parity(s, r.book, today))
        assertEquals(emptyList<Any>(), LedgerIntegrity.check(r.book))
        val e = r.book.entries.single { it.id == "t:t2" }
        assertEquals(EntryType.REFUND, e.type)
        assertEquals("dapur", e.category)
        assertEquals(Money.parse("1750.00"), r.book.balance("p:p1"))             // 2000 − 250 + 100 − 100
        val t = LedgerReports.totals(r.book)
        assertEquals(Money.ZERO, t.incomeOther)
        assertEquals(Money.parse("250.00"), t.expense)
        assertEquals(Money.parse("250.00"), LedgerReports.expenseByCategory(r.book, DateRange.month(YearMonth.of(2026, 11)))["dapur"])
    }

    @Test fun withoutRefundFlagTheMoneyIsCountedTwice() {
        val r = PgLedgerAdapter.build(state(pulang = false), today)
        val t = LedgerReports.totals(r.book)
        assertEquals(Money.parse("100.00"), t.incomeOther)
        assertEquals(Money.parse("350.00"), t.expense)
        assertEquals(Money.parse("1750.00"), r.book.balance("p:p1"))             // baki sama — hanya laporan yang salah
    }

    @Test fun budgetAndCashFlowUseNetSpending() {
        val s = state()
        val book = PgLedgerAdapter.build(s, today).book
        val b = Budget("b1", "dapur", Money.parse("300.00"), YearMonth.of(2026, 11))
        val line = BudgetEngine.line(book, b, YearMonth.of(2026, 11))
        assertEquals(Money.parse("250.00"), line.actual)
        assertFalse(line.over.isPositive)
        val sum = AppFacade.summary(s, EngineData(budgets = listOf(b)), today)
        assertEquals(Money.parse("250.00"), sum.budgets.single().actual)
    }

    @Test fun oldPeriodReportTreatsRefundAsNegativeSpending() {
        val s = state()
        val per = com.asyraf.hadirku.pg.Period("2026-11-01", "2026-12-01", "2026-11-30", "2026-11")
        val r = PG.periodReport(s, per)
        assertEquals(0.0, r.masuk, 0.001)                                         // baki-awal bukan Masuk; pulangan bukan pendapatan
        assertEquals(250.0, r.keluar, 0.001)
        assertEquals(250.0, r.katHarian["dapur"] ?: 0.0, 0.001)
        val r0 = PG.periodReport(state(pulang = false), per)
        assertEquals(100.0, r0.masuk, 0.001)
        assertEquals(350.0, r0.keluar, 0.001)
        assertEquals(r0.bersih, r.bersih, 0.001)                                  // bersih (masuk − keluar) tidak berubah
    }

    @Test fun validationRequiresCategoryAndNoOt() {
        val base = Tx("x", "2026-11-10", "masuk", "p1", jumlah = 50.0, pulangan = true)
        assertTrue(PG.validateTx(base, listOf("p1")).any { it.contains("kategori") })
        assertTrue(PG.validateTx(base.copy(kategori = "dapur"), listOf("p1")).isEmpty())
        assertTrue(PG.validateTx(base.copy(kategori = "dapur", otBayar = 10.0), listOf("p1")).isNotEmpty())
        assertTrue(PG.validateTx(base.copy(jenis = "keluar", kategori = "dapur"), listOf("p1")).isNotEmpty())
        assertFalse(PG.isPulangan(base))                                         // tanpa kategori → bukan pulangan
        // pulangan tidak dikira gaji walaupun perkara sebut gaji
        assertFalse(PG.isPulangan(base.copy(kategori = "dapur", jenis = "keluar")))
    }

    @Test fun bankStatementMatchesAllThreeLines() {
        val s = state()
        val book = PgLedgerAdapter.build(s, today).book
        val csv = "Tarikh,Keterangan,Jumlah\n05/11/2026,DUITNOW KE ISTERI,-250.00\n10/11/2026,DUITNOW DARI ISTERI,100.00\n10/11/2026,MYDIN,-100.00\n"
        val p = CsvBankParser.parse(csv)
        assertEquals(3, p.lines.size)
        val rep = ReconciliationEngine.reconcile(p.lines, book)
        assertEquals(3, rep.count(MatchStatus.EXACT))
    }
}
