package com.asyraf.hadirku.engine

import com.asyraf.hadirku.engine.TestKit.D
import com.asyraf.hadirku.engine.TestKit.bank
import com.asyraf.hadirku.engine.TestKit.book
import com.asyraf.hadirku.engine.TestKit.expense
import com.asyraf.hadirku.engine.TestKit.must
import com.asyraf.hadirku.engine.TestKit.opening
import com.asyraf.hadirku.engine.TestKit.rm
import com.asyraf.hadirku.engine.bills.BillEngine
import com.asyraf.hadirku.engine.category.CategoryEngine
import com.asyraf.hadirku.engine.category.CategoryRule
import com.asyraf.hadirku.engine.category.ItemLine
import com.asyraf.hadirku.engine.category.MatchType
import com.asyraf.hadirku.engine.category.Provenance
import com.asyraf.hadirku.engine.core.FixedClock
import com.asyraf.hadirku.engine.core.Money
import com.asyraf.hadirku.engine.forecast.Certainty
import com.asyraf.hadirku.engine.forecast.EventKind
import com.asyraf.hadirku.engine.forecast.ForecastEngine
import com.asyraf.hadirku.engine.forecast.PointKind
import com.asyraf.hadirku.engine.forecast.Scenario
import com.asyraf.hadirku.engine.ledger.LedgerOps
import com.asyraf.hadirku.engine.ledger.PgLedgerAdapter
import com.asyraf.hadirku.engine.notify.NotifEvent
import com.asyraf.hadirku.engine.notify.NotifKind
import com.asyraf.hadirku.engine.notify.NotifPrefs
import com.asyraf.hadirku.engine.notify.NotificationEngine
import com.asyraf.hadirku.engine.notify.NotificationSink
import com.asyraf.hadirku.engine.reconcile.CsvBankParser
import com.asyraf.hadirku.engine.reconcile.MatchStatus
import com.asyraf.hadirku.engine.reconcile.ReconciliationEngine
import com.asyraf.hadirku.engine.risk.RiskCode
import com.asyraf.hadirku.engine.risk.RiskEngine
import com.asyraf.hadirku.engine.risk.RiskInput
import com.asyraf.hadirku.pg.Commitment
import com.asyraf.hadirku.pg.Gaji
import com.asyraf.hadirku.pg.OtEntry
import com.asyraf.hadirku.pg.PgSample
import com.asyraf.hadirku.pg.PgSettings
import com.asyraf.hadirku.pg.PgState
import com.asyraf.hadirku.pg.Pocket
import com.asyraf.hadirku.pg.Tx
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.LocalTime

class ForecastTest {
    /** State with guaranteed pay + overtime history in the last 3 complete OT cycles. */
    private fun state(): PgState {
        val ot = LinkedHashMap<String, OtEntry>()
        var d = LocalDate.of(2026, 7, 22)
        while (d.isBefore(LocalDate.of(2026, 11, 17))) { if (d.dayOfWeek.value == 6) ot[d.toString()] = OtEntry("off", 8.0); d = d.plusDays(1) }
        return PgState(
            settings = PgSettings(gaji = Gaji(basic = 2600.0, transport = 100.0, potongan = 300.0, advance = 500.0), otMulaHari = 22),
            pockets = listOf(Pocket("p1", "Bank")),
            commitments = listOf(Commitment("c1", "Sewa", 700.0, tempo = 5, poket = "p1")),
            transactions = listOf(
                Tx("o", "2026-09-01", "baki-awal", "p1", jumlah = 1500.0),
                Tx("e1", "2026-10-20", "keluar", "p1", jumlah = 600.0, kategori = "makan"),
                Tx("e2", "2026-11-10", "keluar", "p1", jumlah = 300.0, kategori = "dapur"),
            ),
            ot = ot,
        )
    }

    /** Spec scenario 10 */
    @Test fun distinguishesIrregularOvertimeFromGuaranteedSalary() {
        val s = state()
        val book = PgLedgerAdapter.build(s, D).book
        val cons = ForecastEngine.project(s, book, D, 60, Scenario.CONSERVATIVE)
        val base = ForecastEngine.project(s, book, D, 60, Scenario.BASE)
        val opt = ForecastEngine.project(s, book, D, 60, Scenario.OPTIMISTIC)
        // guaranteed pay identical across scenarios, 60 days from 17 Nov:
        // 30 Nov base 1900 + 15 Dec advance 500 + 30 Dec base 1900 + 15 Jan advance 500
        assertEquals(cons.guaranteedIncome, base.guaranteedIncome)
        assertEquals(rm("4800.00"), base.guaranteedIncome)
        assertTrue(base.events.filter { it.kind == EventKind.SALARY || it.kind == EventKind.ADVANCE }.all { it.certainty == Certainty.GUARANTEED })
        // overtime is scenario dependent and labelled
        assertTrue(cons.overtimeIncome < base.overtimeIncome)
        assertTrue(base.overtimeIncome <= opt.overtimeIncome)
        assertTrue(base.events.any { it.kind == EventKind.OVERTIME && it.certainty == Certainty.ESTIMATE })
        assertTrue(base.assumptions.any { it.code == "income_not_guaranteed" })
        // points labelled actual vs forecast
        assertEquals(PointKind.ACTUAL, base.points.first().kind)
        assertEquals(PointKind.FORECAST, base.points.last().kind)
        assertTrue(cons.lowest.balance <= opt.lowest.balance)
    }

    @Test fun billsAndPaydaysAppearOnceAndAlreadyPaidPaydayIsSkipped() {
        val s = state().let { it.copy(transactions = it.transactions + Tx("g", "2026-11-14", "masuk", "p1", jumlah = 500.0, perkara = "Advance")) }
        val book = PgLedgerAdapter.build(s, D).book
        val f = ForecastEngine.project(s, book, LocalDate.of(2026, 11, 14), 40)
        assertFalse(f.events.any { it.date == LocalDate.of(2026, 11, 15) && it.kind == EventKind.ADVANCE }) // credited early
        assertEquals(1, f.events.count { it.kind == EventKind.BILL && it.date == LocalDate.of(2026, 12, 5) })
    }
}

class RiskTest {
    @Test fun rulesProduceNeutralCodes() {
        val s = PgState(
            settings = PgSettings(gaji = Gaji(basic = 2000.0, advance = 0.0)),
            pockets = listOf(Pocket("p1", "Bank")),
            commitments = listOf(Commitment("c1", "Sewa", 900.0, tempo = 20, poket = "p1"), Commitment("c2", "Kereta", 450.0, tempo = 25, poket = "p1")),
            transactions = listOf(Tx("o", "2026-08-01", "baki-awal", "p1", jumlah = 1000.0)) +
                (8..10).map { Tx("m$it", "2026-%02d-10".format(it), "keluar", "p1", jumlah = 100.0, kategori = "hiburan") } +
                Tx("big", "2026-11-12", "keluar", "p1", jumlah = 400.0, kategori = "hiburan"),
        )
        val book = PgLedgerAdapter.build(s, D).book
        val f = ForecastEngine.project(s, book, D, 45, Scenario.CONSERVATIVE)
        val input = RiskEngine.inputFrom(s, book, D, f, emergencyReserve = Money.ZERO)
        val codes = RiskEngine.evaluate(input).map { it.code }.toSet()
        assertTrue(RiskCode.DUE_DATE_SHORTFALL in codes)       // RM300 left vs 900 + 450 due before payday (30th)
        assertTrue(RiskCode.HIGH_FIXED_COMMITMENTS in codes)   // 1350 / 2000 = 67.5%
        assertTrue(RiskCode.UNUSUAL_SPENDING in codes)         // 400 vs avg 100
        assertTrue(RiskCode.NEGATIVE_PROJECTED_BALANCE in codes)
        assertTrue(RiskCode.LOW_EMERGENCY_RESERVE in codes)
    }

    @Test fun healthyStateHasNoAlerts() {
        val book = book(bank("a")).must(opening("o", "a", "20000.00"))
        val i = RiskInput(D, null, rm("20000.00"), D.plusDays(10), emptyList(), rm("5000.00"), rm("1000.00"), book, rm("9000.00"), rm("2000.00"))
        assertEquals(emptyList<Any>(), RiskEngine.evaluate(i))
    }
}

class CategoryTest {
    @Test fun precedenceAndProvenance() {
        val e = CategoryEngine(
            overrides = mapOf("petronaslunas" to "kenderaan"),
            rules = listOf(CategoryRule("r1", "kopi", MatchType.CONTAINS, "makan", 5)),
            history = mapOf("kedaipakabu" to "dapur"),
        )
        assertEquals(Provenance.USER_OVERRIDE, e.suggest("Petronas Lunas").provenance)
        assertEquals("kenderaan", e.suggest("PETRONAS LUNAS").category)
        assertEquals(Provenance.USER_RULE, e.suggest("Kopi O Ais").provenance)
        assertEquals("dapur", e.suggest("Kedai Pak Abu").category)
        assertEquals(Provenance.HISTORY, e.suggest("Kedai Pak Abu").provenance)
        assertEquals("minyak", e.suggest("Shell Kulim").category)
        assertEquals("makan", e.suggest("GrabFood order").category)
        assertEquals(Provenance.BUILTIN, e.suggest("99 Speedmart Lunas").provenance)
        assertNull(e.suggest("Zzyx Unknown").category)
    }

    @Test fun aiFailureOrGarbageNeverBreaksAndHistoryIsNotRewritten() {
        val failing = CategoryEngine(ai = { _, _ -> throw RuntimeException("offline") })
        assertEquals(Provenance.NONE, failing.suggest("Zzyx").provenance)            // spec scenario 11 (category side)
        val garbage = CategoryEngine(ai = { _, _ -> "not-a-category" })
        assertEquals(Provenance.NONE, garbage.suggest("Zzyx").provenance)
        var b = book(bank("a")).must(opening("o", "a", "100.00"))
        b = b.must(expense("e1", "a", "10.00", cat = "hiburan").copy(memo = "Shell Kulim"))   // user put it in hiburan
        b = b.must(expense("e2", "a", "12.00", cat = null).copy(memo = "Shell Kulim"))
        val props = CategoryEngine().proposeForUncategorised(b)
        assertEquals(listOf("e2"), props.map { it.entryId })                         // categorised e1 untouched
        assertEquals("hiburan", b.entry("e1")!!.category)
    }

    @Test fun itemLevelConflictDetection() {
        val r = CategoryEngine().categoriseItems(listOf(ItemLine("Beras 10kg", rm("32.00")), ItemLine("Panadol", rm("9.00")), ItemLine("Netflix gift card", rm("35.00"))), "Mydin")
        assertTrue(r.conflict)                                   // hiburan 35 of 76 ≥ 20%
        assertEquals("dapur", r.dominant)                        // unknown items fall back to the merchant's category
        assertEquals(rm("41.00"), r.byCategory["dapur"])
        assertNotNull(r.byCategory["hiburan"])
    }
}

class ReconciliationTest {
    private val csv = """
        Tarikh,Keterangan,Debit,Kredit,Baki
        01/11/2026,"GAJI OKT, PLEXUS",,"2,500.00",2600.00
        03/11/2026,99 SPEEDMART LUNAS,45.20,,2554.80
        05/11/2026,TNB BILL,120.00,,2434.80
        06/11/2026,KOPI,5.00,,2429.80
        06/11/2026,KOPI,5.00,,2424.80
        12-Nov-26,UNKNOWN MERCHANT,(17.30),,2407.50
        bad,row,1,,
    """.trimIndent()

    @Test fun parsesMalaysianFormats() {
        val r = CsvBankParser.parse(csv)
        assertEquals(6, r.lines.size)
        assertEquals(1, r.errors.size)
        assertEquals(rm("2500.00"), r.lines[0].amount)
        assertEquals(rm("-45.20"), r.lines[1].amount)
        assertEquals(LocalDate.of(2026, 11, 12), r.lines[5].date)
        assertEquals(rm("-17.30"), r.lines[5].amount)
        assertTrue(r.lines[3].possibleDuplicate && r.lines[4].possibleDuplicate)
        assertTrue(r.lines[3].key != r.lines[4].key)                                   // two real coffees keep distinct keys
        assertEquals(CsvBankParser.parse(csv).lines.map { it.key }, r.lines.map { it.key }) // stable across imports
        assertEquals(rm("-12.30"), CsvBankParser.parseAmount("12.30 DR"))
        assertEquals(rm("-12.30"), CsvBankParser.parseAmount("12.30-"))
        assertEquals(LocalDate.of(2026, 3, 4), CsvBankParser.parseDate("04 Mac 2026"))
    }

    @Test fun matchesExactAndFuzzyWithoutMerging() {
        val s = PgState(
            pockets = listOf(Pocket("p1", "Bank"), Pocket("p2", "Simpanan")),
            commitments = listOf(Commitment("c1", "TNB", 120.0, poket = "p1")),
            transactions = listOf(
                Tx("g", "2026-11-01", "masuk", "p1", jumlah = 2500.0, perkara = "Gaji"),
                Tx("s", "2026-11-04", "keluar", "p1", jumlah = 45.2, perkara = "99 Speedmart"), // bank says 3 Nov → fuzzy
                Tx("t", "2026-11-05", "keluar", "p1", jumlah = 120.0, perkara = "TNB", komitmenId = "c1"),
                Tx("x", "2026-11-05", "pindah", "p1", ke = "p2", jumlah = 300.0),                // internal: invisible to bank
                Tx("m", "2026-11-09", "keluar", "p1", jumlah = 60.0, perkara = "Kedai"),         // not on statement
            ),
        )
        val book = PgLedgerAdapter.build(s, D).book
        val before = book.entries.size
        val lines = CsvBankParser.parse(csv).lines
        val rep = ReconciliationEngine.reconcile(lines, book, importedKeys = setOf(lines[5].key))
        assertEquals(2, rep.count(MatchStatus.EXACT))                 // gaji, TNB
        assertEquals(1, rep.count(MatchStatus.FUZZY_REVIEW))          // speedmart, 1 day apart
        assertEquals(2, rep.count(MatchStatus.UNMATCHED_BANK))        // two coffees
        assertEquals(1, rep.count(MatchStatus.ALREADY_IMPORTED))
        assertEquals(listOf("t:m"), rep.rows.filter { it.status == MatchStatus.UNMATCHED_LEDGER }.map { it.entryId })
        assertEquals(before, book.entries.size)                       // nothing merged or posted
    }
}

class NotificationTest {
    private class Sink(var allowed: Boolean = true) : NotificationSink {
        val posted = ArrayList<String>()
        override fun canPost() = allowed
        override fun post(event: NotifEvent): Boolean { posted += event.key; return true }
    }

    /** Spec scenario 13 */
    @Test fun repeatedWorkerRunsDoNotDuplicate() {
        val s = PgState(pockets = listOf(Pocket("p1", "Bank")), commitments = listOf(Commitment("c1", "Sewa", 800.0, tempo = 20, poket = "p1")))
        val book = PgLedgerAdapter.build(s, D).book
        val day = LocalDate.of(2026, 11, 17)
        val events = NotificationEngine.fromBillReminders(BillEngine.remindersFor(s, book, day))
        assertEquals(1, events.size)
        val eng = NotificationEngine(NotifPrefs(), FixedClock.at(day))
        val sink = Sink()
        var sent = emptyMap<String, String>()
        repeat(3) { sent = eng.dispatch(events, sent, sink).sent }
        assertEquals(1, sink.posted.size)
        assertEquals(setOf("BILL_DUE:c1:2026-11-20:3"), sent.keys)
    }

    @Test fun permissionQuietHoursAndPreferences() {
        val ev = listOf(NotifEvent(NotifKind.RISK, "x", "2026-11", D), NotifEvent(NotifKind.ANOMALY, "y", "1", D))
        val noPerm = Sink(allowed = false)
        val r1 = NotificationEngine(NotifPrefs(), FixedClock.at(D)).dispatch(ev, emptyMap(), noPerm)
        assertEquals(2, r1.plan.blockedNoPermission.size)
        assertTrue(r1.sent.isEmpty())                                  // not recorded → can fire once allowed
        val quiet = NotificationEngine(NotifPrefs(quietStart = LocalTime.of(8, 0), quietEnd = LocalTime.of(10, 0)), FixedClock.at(D)) // clock 09:00
        assertEquals(2, quiet.plan(ev, emptySet(), true).deferredQuietHours.size)
        val overnight = NotificationEngine(NotifPrefs(quietStart = LocalTime.of(22, 0), quietEnd = LocalTime.of(7, 0)), FixedClock.at(D))
        assertTrue(overnight.inQuietHours(LocalTime.of(23, 30)) && overnight.inQuietHours(LocalTime.of(6, 0)) && !overnight.inQuietHours(LocalTime.of(9, 0)))
        val onlyRisk = NotificationEngine(NotifPrefs(enabled = setOf(NotifKind.RISK)), FixedClock.at(D)).plan(ev, emptySet(), true)
        assertEquals(listOf("RISK:x:2026-11"), onlyRisk.send.map { it.key })
    }
}

class SampleDataSmokeTest {
    /** Every engine runs on the bundled sample data without throwing. */
    @Test fun allEnginesRunOnSampleData() {
        val s = PgSample.sampleState(D.toString())
        val book = PgLedgerAdapter.build(s, D).book
        BillEngine.upcoming(s, book, D)
        val f = ForecastEngine.project(s, book, D)
        RiskEngine.evaluate(RiskEngine.inputFrom(s, book, D, f, Money.ZERO))
        com.asyraf.hadirku.engine.cashflow.CashFlowEngine.report(s, book, D)
        com.asyraf.hadirku.engine.debt.DebtEngine.profiles(s, book, D)
        CategoryEngine().proposeForUncategorised(book)
        assertTrue(LedgerOps.validate(book, book.entries.first()).isNotEmpty()) // already present → DUPLICATE_ID
    }
}
