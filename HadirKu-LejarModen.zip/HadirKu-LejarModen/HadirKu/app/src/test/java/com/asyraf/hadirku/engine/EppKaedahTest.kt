package com.asyraf.hadirku.engine

import com.asyraf.hadirku.engine.debt.DebtEngine
import com.asyraf.hadirku.engine.debt.EarlySettlementPolicy
import com.asyraf.hadirku.engine.ledger.EntryType
import com.asyraf.hadirku.engine.ledger.LedgerIntegrity
import com.asyraf.hadirku.engine.ledger.PgLedgerAdapter
import com.asyraf.hadirku.pg.Debt
import com.asyraf.hadirku.pg.DebtLog
import com.asyraf.hadirku.pg.Epp
import com.asyraf.hadirku.pg.EppSemak
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.PgState
import com.asyraf.hadirku.pg.Pocket
import com.asyraf.hadirku.pg.Tx
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

/**
 * Data penyata RHB sebenar (Nov 2026). Angka dijangka disahkan berasingan dengan Python Decimal
 * (lihat dokumen kajian). Tarikh penyata diandaikan 20hb.
 */
class EppKaedahTest {
    private val today = "2026-11-26"
    private val tPenyata = "2026-11-20"

    private val smartMove = Epp("sm", "Smart Move BT", tempoh = 36, ansuran = 105.42, mula = PG.eppMulaDariKe(tPenyata, 8),
        kaedah = "baki", semak = listOf(EppSemak(8, 88.45, 16.97)))
    private val cashXcess = Epp("cx", "CashXcess", tempoh = 24, ansuran = 89.98, mula = PG.eppMulaDariKe(tPenyata, 7),
        kaedah = "baki", semak = listOf(EppSemak(7, 80.46, 9.52)))
    private val senheng = Epp("sh", "EPP Senheng", pokok = 1464.0, tempoh = 24, mula = PG.eppMulaDariKe(tPenyata, 15))

    private fun near(exp: Double, act: Double, tol: Double, msg: String = "") = assertEquals(msg, exp, act, tol)

    @Test fun t1SmartMoveFromStatement() {
        assertEquals("2026-04-20", smartMove.mula)
        val e = PG.eppInfo(smartMove, today)
        assertEquals(8, e.dibil); assertEquals(28, e.bakiBulan)
        near(7.285, e.kadarNominal!!, 0.005, "nominal")
        near(3399.87, e.pokok, 0.10, "pokok asal tersirat")
        near(2707.02, e.pokokBaki, 0.05, "baki pokok")
        assertEquals(2951.76, e.baki, 0.001)
        near(244.74, e.faedahBaki, 0.05, "faedah akan datang")
        assertEquals("2029-03-20", e.tamat)
        assertEquals(88.45, e.pokokAt(7), 0.001); assertEquals(16.97, e.faedahAt(7), 0.001)  // ansuran ke-8 = penyata tepat
        near(7.53, e.kadarEfektif!!, 0.01, "EAR")
        near(3.875, e.kadarRataSetara, 0.01, "rata setara")
        assertTrue(e.pokokTahu)
        // setiap ansuran tetap RM105.42, faedah menurun, pokok menaik
        for (k in 0 until 36) assertEquals(105.42, e.amountAt(k), 0.001)
        for (k in 1 until 35) assertTrue("faedah menurun @$k", e.faedahAt(k) <= e.faedahAt(k - 1) + 0.001)
        assertEquals(e.pokok, (0 until 36).sumOf { e.pokokAt(it) }, 0.02)
    }

    @Test fun t2OctoberReconstructedAndReconciled() {
        val e = PG.eppInfo(smartMove, today)
        near(87.92, e.pokokAt(6), 0.011, "pokok Okt"); near(17.50, e.faedahAt(6), 0.011, "faedah Okt")
        val withOct = smartMove.copy(semak = listOf(EppSemak(7, 87.92, 17.50), EppSemak(8, 88.45, 16.97)))
        val b = PG.eppInfo(withOct, today).banding
        assertEquals(listOf(7, 8), b.map { it.ke })
        assertTrue("beza Okt ≤ 2 sen", b[0].beza <= 0.02)
        assertEquals(0.0, b[1].beza, 0.001)
    }

    @Test fun t3CashXcess() {
        val e = PG.eppInfo(cashXcess, today)
        assertEquals(17, e.bakiBulan)
        near(7.478, e.kadarNominal!!, 0.005, "nominal")
        near(2000.08, e.pokok, 0.10, "pokok asal")
        near(1447.18, e.pokokBaki, 0.05, "baki pokok")
        assertEquals(1529.66, e.baki, 0.001)
        near(82.48, e.faedahBaki, 0.05, "faedah akan datang")
        assertEquals("2028-04-20", e.tamat)
        near(79.97, e.pokokAt(5), 0.011, "pokok Okt"); near(10.01, e.faedahAt(5), 0.011, "faedah Okt")
    }

    @Test fun t4SenhengZeroPercent() {
        val e = PG.eppInfo(senheng, today)
        assertEquals(61.0, e.ans, 0.001); assertEquals(9, e.bakiBulan)
        assertEquals(549.0, e.baki, 0.001); assertEquals(549.0, e.pokokBaki, 0.001); assertEquals(0.0, e.faedahBaki, 0.001)
        assertEquals("2027-08-20", e.tamat)
        assertTrue(e.pokokList.isEmpty())                                     // kaedah rata asal, tidak berubah
    }

    private fun card(vararg plans: Epp, penyata: Double = 500.0) = Debt("rhb", "RHB", jenis = "kad", kadar = 18.0, minPeratus = 5.0, minLantai = 50.0,
        hadKredit = 10000.0, poket = "p1", epp = plans.toList(), log = listOf(DebtLog("l1", tPenyata, "penyata", penyata)))

    @Test fun t5PortfolioTotalsAndJumlahHutangIsPrincipal() {
        val plans = listOf(smartMove, cashXcess, senheng).map { PG.eppInfo(it, today) }
        assertEquals(256.40, plans.sumOf { it.ans }, 0.001)
        assertEquals(5030.42, plans.sumOf { it.baki }, 0.001)
        assertEquals(28, plans.maxOf { it.bakiBulan })
        near(4703.20, plans.sumOf { it.pokokBaki }, 0.10, "baki pokok")
        near(327.22, plans.sumOf { it.faedahBaki }, 0.10, "faedah akan datang")
        val s = PgState(pockets = listOf(Pocket("p1", "Bank")), debts = listOf(card(smartMove, cashXcess, senheng)))
        val st = PG.debtStatus(s, today).single()
        assertEquals(5030.42, st.eppBaki, 0.001)
        near(500 + 4703.20, st.jumlah, 0.10, "jumlah hutang = baki kad + pokok")
        near((500 + 4703.20) / 10000.0, st.guna!!, 0.0001, "penggunaan had ikut pokok")
    }

    @Test fun t6FixedInstalmentUnknownSplit() {
        val d = PG.eppSediaSimpan(Epp("t", "Smart Move", tempoh = 36, ansuran = 105.42, mula = PG.eppMulaDariKe(tPenyata, 8), kaedah = "tetap"), today)
        assertEquals(3795.12, d.pokok, 0.001)
        val e = PG.eppInfo(d, today)
        assertFalse(e.pokokTahu)
        assertEquals(28, e.bakiBulan); assertEquals(2951.76, e.baki, 0.001); assertEquals("2029-03-20", e.tamat)
        assertNull(e.kadarNominal)
        val s = PgState(pockets = listOf(Pocket("p1", "Bank")), debts = listOf(card(d)))
        val r = PgLedgerAdapter.build(s, LocalDate.parse(today))
        assertEquals(emptyList<Any>(), PgLedgerAdapter.parity(s, r.book, LocalDate.parse(today)))
        assertTrue("tiada faedah diteka", r.book.entries.none { it.type == EntryType.CHARGE && it.id.contains(":t-") })
        val prof = DebtEngine.eppProfile("rhb", d, LocalDate.parse(today), null)
        assertTrue(prof.schedule.all { it.interest == null })
    }

    @Test fun t7OldFlatRecordUnchanged() {
        val old = Epp("o", "Peti sejuk", pokok = 1200.0, tempoh = 12, kadar = 6.0, mula = "2026-06-20")
        val e = PG.eppInfo(old, today)
        assertEquals("rata", old.kaedah)
        assertEquals(106.0, e.ans, 0.001); assertEquals(100.0, e.pokokAns, 0.001); assertEquals(6.0, e.faedahAns, 0.001)
        assertEquals(6, e.dibil); assertEquals(600.0, e.pokokBaki, 0.001); assertEquals(36.0, e.faedahBaki, 0.001)
        assertTrue(e.pokokList.isEmpty() && e.pokokTahu)
        assertEquals(old, PG.eppSediaSimpan(old, today))                      // simpan semula tidak ubah rekod lama
    }

    @Test fun t8NoDoubleCountingOnCardBalance() {
        val s0 = PgState(pockets = listOf(Pocket("p1", "Bank")), debts = listOf(card(smartMove, cashXcess, senheng, penyata = 2000.0)),
            transactions = listOf(Tx("b0", "2026-11-01", "baki-awal", "p1", jumlah = 5000.0)))
        val d = s0.debts.single()
        assertEquals(2000.0, PG.debtBalance(s0, d, null, today), 0.001)                  // penyata termasuk ansuran Nov
        assertEquals(2256.40, PG.debtBalance(s0, d, "2026-12-21", "2026-12-21"), 0.001)  // ansuran Dis sekali sahaja
        val s1 = s0.copy(transactions = s0.transactions + Tx("p", "2026-12-01", "keluar", "p1", jumlah = 2000.0, hutangId = "rhb", perkara = "Bayar RHB"))
        assertEquals(256.40, PG.debtBalance(s1, d, "2026-12-21", "2026-12-21"), 0.001)
    }

    @Test fun t9LedgerParityAllModes() {
        val tetap = PG.eppSediaSimpan(Epp("t", "Tetap", tempoh = 12, ansuran = 50.0, mula = PG.eppMulaDariKe(tPenyata, 3), kaedah = "tetap"), today)
        val flat = Epp("f", "Rata", pokok = 600.0, tempoh = 12, kadar = 5.0, mula = "2026-09-20")
        val s = PgState(pockets = listOf(Pocket("p1", "Bank")), debts = listOf(card(PG.eppSediaSimpan(smartMove, today), PG.eppSediaSimpan(cashXcess, today), senheng, tetap, flat)))
        val r = PgLedgerAdapter.build(s, LocalDate.parse(today))
        assertEquals(emptyList<Any>(), r.issues)
        assertEquals(emptyList<Any>(), PgLedgerAdapter.parity(s, r.book, LocalDate.parse(today)))
        assertEquals(emptyList<Any>(), LedgerIntegrity.check(r.book))
    }

    @Test fun t10Validation() {
        assertEquals("", PG.eppValidate(smartMove, 8))
        assertTrue(PG.eppValidate(smartMove.copy(semak = listOf(EppSemak(8, 88.45, 17.97))), 8).contains("Pokok + faedah"))
        assertTrue(PG.eppValidate(smartMove, 37).contains("Ansuran ke-"))
        assertTrue(PG.eppValidate(smartMove.copy(semak = listOf(EppSemak(8, 0.0, 105.42))), 8).isNotEmpty())
        assertTrue(PG.eppValidate(smartMove.copy(semak = emptyList()), 8).isNotEmpty())
        assertTrue(PG.eppValidate(senheng.copy(pokok = 0.0), 15).isNotEmpty())
        assertEquals("", PG.eppValidate(Epp("x", "Tetap", tempoh = 12, ansuran = 50.0, mula = "2026-01-20", kaedah = "tetap"), 11))
    }

    @Test fun t11EarlySettlementIsPrincipalNeverScheduled() {
        val td = LocalDate.parse(today)
        val e = PG.eppInfo(smartMove, today)
        val prof = DebtEngine.eppProfile("rhb", smartMove, td, null)
        val lang = DebtEngine.earlySettlement(prof.schedule, td, EarlySettlementPolicy.REMAINING_PRINCIPAL)
        near(e.pokokBaki, lang.toDecimal().toDouble(), 0.02, "langsai = baki pokok")
        assertTrue(lang.toDecimal().toDouble() < e.baki - 200)
    }

    @Test fun t12MinimumUsesPrincipalNotScheduled() {
        val s = PgState(pockets = listOf(Pocket("p1", "Bank")), debts = listOf(card(smartMove)))
        val st = PG.debtStatus(s, today).single()
        near(500 + 2707.02, st.minInfo!!.asas, 0.05, "asas minimum")
    }
}
