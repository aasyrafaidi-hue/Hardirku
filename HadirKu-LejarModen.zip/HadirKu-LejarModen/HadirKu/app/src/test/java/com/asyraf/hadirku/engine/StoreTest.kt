package com.asyraf.hadirku.engine

import com.asyraf.hadirku.engine.TestKit.D
import com.asyraf.hadirku.engine.TestKit.rm
import com.asyraf.hadirku.engine.budget.Budget
import com.asyraf.hadirku.engine.budget.CarryOver
import com.asyraf.hadirku.engine.category.CategoryRule
import com.asyraf.hadirku.engine.category.MatchType
import com.asyraf.hadirku.engine.core.FixedClock
import com.asyraf.hadirku.engine.core.MiniJson
import com.asyraf.hadirku.engine.ledger.PgLedgerAdapter
import com.asyraf.hadirku.engine.notify.NotifKind
import com.asyraf.hadirku.engine.notify.NotifPrefs
import com.asyraf.hadirku.engine.receipt.KnownReceipt
import com.asyraf.hadirku.engine.savings.GoalMove
import com.asyraf.hadirku.engine.savings.SavingsGoal
import com.asyraf.hadirku.engine.store.EngineData
import com.asyraf.hadirku.engine.store.EngineStore
import com.asyraf.hadirku.engine.store.MemoryTextIo
import com.asyraf.hadirku.pg.PgSample
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalTime
import java.time.YearMonth

class StoreTest {
    private val clock = FixedClock.at(D)

    private fun full() = EngineData(
        categoryOverrides = mapOf("petronaslunas" to "minyak"),
        categoryRules = listOf(CategoryRule("r1", "kopi", MatchType.CONTAINS, "makan", 3)),
        budgets = listOf(Budget("b1", "makan", rm("450.00"), YearMonth.of(2026, 8), CarryOver.BOTH, essential = false)),
        goals = listOf(SavingsGoal("g1", "Kecemasan", rm("3000.00"), D.plusMonths(6), "p:x", D)),
        goalMoves = listOf(GoalMove("m1", "g1", D, rm("-12.34"))),
        notificationsSent = mapOf("BILL_DUE:c1:2026-11-20:3" to "2026-11-17"),
        importKeys = mapOf("csv:abc" to "t:1"),
        knownReceipts = listOf(KnownReceipt("r1", "Mydin", D, rm("16.00"), "INV1", listOf("Gula"))),
        notifPrefs = NotifPrefs(setOf(NotifKind.RISK), LocalTime.of(22, 0), LocalTime.of(7, 0), 3),
    )

    @Test fun roundTripPreservesEverything() {
        val io = MemoryTextIo()
        val st = EngineStore(io, clock)
        assertTrue(st.save(full()))
        assertEquals(full(), st.load().data)
    }

    /** Spec scenario 12: migration keeps every pre-existing record and backs the old file up first. */
    @Test fun migrationFromV0KeepsRecordsAndBacksUp() {
        val v0 = """{"overrides":{"shellkulim":"minyak"},"sent":{"x:y:z":"2026-10-01"},"future_feature":{"a":1}}"""
        val io = MemoryTextIo(v0)
        val st = EngineStore(io, clock)
        val r = st.load()
        assertEquals(0, r.migratedFrom)
        assertEquals(mapOf("shellkulim" to "minyak"), r.data.categoryOverrides)
        assertEquals(mapOf("x:y:z" to "2026-10-01"), r.data.notificationsSent)
        assertEquals(v0, io.backups["v0-2026-11-17"])
        assertTrue(st.save(r.data))
        val saved = MiniJson.parseObject(io.text!!)
        assertEquals(1, (saved["version"] as java.math.BigDecimal).toInt())
        assertTrue(saved.containsKey("future_feature"))          // unknown keys preserved, not dropped
    }

    @Test fun newerVersionIsReadOnlyAndCorruptFileIsBackedUp() {
        val newer = """{"version":99,"categoryOverrides":{"a":"makan"}}"""
        val io = MemoryTextIo(newer)
        val st = EngineStore(io, clock)
        assertTrue(st.load().readOnly)
        assertFalse(st.save(EngineData()))
        assertEquals(newer, io.text)                              // never overwritten
        val bad = MemoryTextIo("{not json")
        val st2 = EngineStore(bad, clock)
        val r = st2.load()
        assertEquals("corrupt-2026-11-17", r.backupTag)
        assertEquals("{not json", bad.backups["corrupt-2026-11-17"])
    }

    @Test fun engineStoreNeverTouchesExistingAppData() {
        val s = PgSample.sampleState(D.toString())
        val before = s.toString()
        val io = MemoryTextIo()
        EngineStore(io, clock).update { it.copy(importKeys = it.importKeys + ("k" to "v")) }
        PgLedgerAdapter.build(s, D)
        assertEquals(before, s.toString())
        assertNull(io.backups["anything"])
    }
}
