package com.asyraf.hadirku.engine

import com.asyraf.hadirku.engine.app.AppFacade
import com.asyraf.hadirku.engine.assistant.AssistantEngine
import com.asyraf.hadirku.engine.assistant.SnapshotBuilder
import com.asyraf.hadirku.engine.budget.BudgetEngine
import com.asyraf.hadirku.engine.budget.CarryOver
import com.asyraf.hadirku.engine.core.Money
import com.asyraf.hadirku.engine.ledger.PgLedgerAdapter
import com.asyraf.hadirku.engine.risk.RiskAlert
import com.asyraf.hadirku.engine.risk.RiskCode
import com.asyraf.hadirku.engine.risk.Severity
import com.asyraf.hadirku.engine.store.EngineData
import com.asyraf.hadirku.pg.PgSample
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.YearMonth

class AppFacadeTest {
    private val today = LocalDate.of(2026, 11, 17)
    private var n = 0
    private val id: () -> String = { "id" + (++n) }

    @Test fun summaryOnSampleDataIsConsistent() {
        for (d in listOf(today, LocalDate.of(2026, 2, 28), LocalDate.of(2026, 12, 31))) {
            val s = PgSample.sampleState(d.toString())
            val sum = AppFacade.summary(s, EngineData(), d)
            assertTrue(sum.daysToPay >= 1)
            assertFalse(sum.nextPay.isBefore(d))
            // boleh belanja = tunai + tertunda − keluar dijadualkan − diasingkan (gaji dijangka TIDAK ditambah)
            val r = sum.cash
            assertEquals(r.liquid + r.pending.netLiquid - AppFacade.scheduledOut(r) - r.earmarked, r.availableToSpend)
            if (r.availableToSpend.isPositive) assertTrue(sum.perDay * sum.daysToPay <= r.availableToSpend + Money.ofSen(sum.daysToPay))
            else assertEquals(Money.ZERO, sum.perDay)
            AppFacade.distinctRisks(sum.risks).forEach { a ->
                val t = AppFacade.riskText(a, s)
                assertTrue(t.title.isNotBlank() && t.body.isNotBlank())
            }
            AppFacade.scheduledText(s, r.scheduled).forEach { assertTrue(it.name.isNotBlank()) }
        }
    }

    @Test fun everyRiskCodeHasText() {
        val s = PgSample.sampleState(today.toString())
        RiskCode.entries.forEach { c ->
            val t = AppFacade.riskText(RiskAlert(c, Severity.CAUTION, today, Money.parse("12.50"), null, mapOf("ratio_bp" to "6500", "utilisation_bp" to "8500")), s)
            assertTrue(c.name, t.title.isNotBlank() && t.body.isNotBlank())
        }
    }

    @Test fun shortfallAlertsCollapseToOne() {
        val a = listOf(
            RiskAlert(RiskCode.DUE_DATE_SHORTFALL, Severity.CAUTION, today.plusDays(2), Money.parse("10"), "b1"),
            RiskAlert(RiskCode.DUE_DATE_SHORTFALL, Severity.CAUTION, today.plusDays(5), Money.parse("90"), "b2"),
            RiskAlert(RiskCode.HIGH_FIXED_COMMITMENTS, Severity.WARNING, amount = Money.parse("2000"), params = mapOf("ratio_bp" to "7200")),
        )
        val d = AppFacade.distinctRisks(a)
        assertEquals(2, d.size)
        assertEquals(RiskCode.HIGH_FIXED_COMMITMENTS, d[0].code) // WARNING dulu
        val sf = d.first { it.code == RiskCode.DUE_DATE_SHORTFALL }
        assertEquals(today.plusDays(2), sf.date)
        assertEquals(Money.parse("90"), sf.amount)
        assertEquals("2", sf.params["count"])
    }

    @Test fun budgetEditsValidateAndNeverDuplicateCategory() {
        val m = YearMonth.from(today)
        var d = EngineData()
        assertTrue(AppFacade.upsertBudget(d, null, "tiada", Money.parse("100"), CarryOver.NONE, false, m, id) is AppFacade.Edit.Err)
        assertTrue(AppFacade.upsertBudget(d, null, "makan", Money.ZERO, CarryOver.NONE, false, m, id) is AppFacade.Edit.Err)
        d = (AppFacade.upsertBudget(d, null, "makan", Money.parse("300"), CarryOver.UNDERSPEND_ONLY, false, m, id) as AppFacade.Edit.Ok).data
        assertEquals(1, d.budgets.size)
        assertTrue(AppFacade.upsertBudget(d, null, "makan", Money.parse("200"), CarryOver.NONE, false, m, id) is AppFacade.Edit.Err)
        val bid = d.budgets[0].id
        d = (AppFacade.upsertBudget(d, bid, "makan", Money.parse("350"), CarryOver.NONE, true, m.plusMonths(1), id) as AppFacade.Edit.Ok).data
        assertEquals(Money.parse("350"), d.budgets[0].amount)
        assertEquals(m, d.budgets[0].startMonth) // bulan mula kekal
        assertTrue(d.budgets[0].essential)
        assertTrue(AppFacade.deleteBudget(d, bid).budgets.isEmpty())
    }

    @Test fun suggestionAppliesOnlyWhenCalled() {
        val s = PgSample.sampleState(today.toString())
        val book = PgLedgerAdapter.build(s, today).book
        val d = EngineData()
        val sug = BudgetEngine.suggestions(book, d.budgets, YearMonth.from(today))
        assertTrue(d.budgets.isEmpty())
        sug.firstOrNull()?.let { g ->
            val d2 = AppFacade.applySuggestion(d, g, YearMonth.from(today), id)
            assertEquals(1, d2.budgets.size)
            assertEquals(g.suggested, d2.budgets[0].amount)
            assertTrue(AppFacade.suggestionText(g).isNotBlank())
        }
    }

    @Test fun goalsValidateAndMovesAreBackedByRealMoney() {
        val s = PgSample.sampleState(today.toString())
        val book = PgLedgerAdapter.build(s, today).book
        var d = EngineData()
        assertTrue(AppFacade.upsertGoal(d, null, " ", Money.parse("100"), null, null, today, id) is AppFacade.Edit.Err)
        assertTrue(AppFacade.upsertGoal(d, null, "Cuti", Money.parse("100"), today, null, today, id) is AppFacade.Edit.Err)
        d = (AppFacade.upsertGoal(d, null, "Cuti", Money.parse("1000"), today.plusMonths(5), null, today, id) as AppFacade.Edit.Ok).data
        val gid = d.goals.single().id
        // keluarkan lebih daripada yang diasingkan → ditolak
        assertTrue(AppFacade.moveGoal(s, d, book, today, gid, Money.parse("5"), true, id) is AppFacade.Edit.Err)
        // asing lebih daripada semua baki sebenar → ditolak
        assertTrue(AppFacade.moveGoal(s, d, book, today, gid, Money.parse("99999999"), false, id) is AppFacade.Edit.Err)
        d = (AppFacade.moveGoal(s, d, book, today, gid, Money.parse("50"), false, id) as AppFacade.Edit.Ok).data
        val sum = AppFacade.summary(s, d, today)
        val p = sum.goals.first { it.goal.id == gid }
        assertEquals(Money.parse("50"), p.allocated)
        assertTrue(AppFacade.feasibilityText(p).isNotBlank())
        // diasingkan ditolak daripada boleh belanja
        val sum0 = AppFacade.summary(s, EngineData(), today)
        assertEquals(sum0.cash.availableToSpend - Money.parse("50"), sum.cash.availableToSpend)
        val d2 = AppFacade.deleteGoal(d, gid)
        assertTrue(d2.goals.isEmpty() && d2.goalMoves.isEmpty())
    }

    @Test fun assistantAnswersReadFromSnapshotFacts() {
        val s = PgSample.sampleState(today.toString())
        val book = PgLedgerAdapter.build(s, today).book
        val snap = SnapshotBuilder.build(s, book, today)
        val eng = AssistantEngine(null)
        listOf("berapa hutang saya", "bil minggu ni", "baki saya", "gaji bulan ini", "belanja makan bulan ini").forEach { q ->
            val t = AppFacade.answerText(eng.ask(q, snap))
            assertTrue(q, t.isNotBlank())
            assertFalse(q, t.contains("null"))
        }
        assertTrue(AppFacade.answerText(eng.ask("patut saya beli rumah?", snap)).contains("AI"))
    }
}
