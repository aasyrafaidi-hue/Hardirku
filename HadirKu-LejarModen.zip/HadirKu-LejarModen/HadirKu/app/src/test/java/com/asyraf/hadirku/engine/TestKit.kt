package com.asyraf.hadirku.engine

import com.asyraf.hadirku.engine.core.Money
import com.asyraf.hadirku.engine.ledger.Account
import com.asyraf.hadirku.engine.ledger.AccountKind
import com.asyraf.hadirku.engine.ledger.Entry
import com.asyraf.hadirku.engine.ledger.EntryType
import com.asyraf.hadirku.engine.ledger.LedgerBook
import com.asyraf.hadirku.engine.ledger.LedgerOps
import com.asyraf.hadirku.engine.ledger.PostResult
import com.asyraf.hadirku.engine.ledger.Storage
import org.junit.Assert.assertTrue
import java.time.Instant
import java.time.LocalDate

/** Shared helpers for engine tests. */
object TestKit {
    val T0: Instant = Instant.parse("2026-11-17T01:00:00Z")
    val D: LocalDate = LocalDate.of(2026, 11, 17)

    fun rm(s: String) = Money.parse(s)

    fun bank(id: String) = Account(id, id, AccountKind.ASSET, Storage.BANK)
    fun cash(id: String) = Account(id, id, AccountKind.ASSET, Storage.CASH)
    fun card(id: String) = Account(id, id, AccountKind.LIABILITY, Storage.CREDIT_CARD)

    fun book(vararg acc: Account): LedgerBook = acc.fold(LedgerBook()) { b, a -> LedgerOps.addAccount(b, a, T0) }

    /** Post and assert it was accepted. */
    fun LedgerBook.must(e: Entry, key: String? = null): LedgerBook {
        val r = LedgerOps.post(this, e, T0, key)
        assertTrue("expected Posted but was ${r.result}", r.result is PostResult.Posted)
        return r.book
    }

    fun opening(id: String, acc: String, amt: String, date: LocalDate = D.minusDays(30)) =
        Entry(id, date, EntryType.OPENING_BALANCE, rm(amt), to = acc)

    fun expense(id: String, from: String, amt: String, cat: String? = "makan", date: LocalDate = D) =
        Entry(id, date, EntryType.EXPENSE, rm(amt), from = from, category = cat)
}
