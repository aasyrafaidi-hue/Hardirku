package com.asyraf.hadirku.engine

import com.asyraf.hadirku.engine.TestKit.D
import com.asyraf.hadirku.engine.TestKit.T0
import com.asyraf.hadirku.engine.TestKit.bank
import com.asyraf.hadirku.engine.TestKit.book
import com.asyraf.hadirku.engine.TestKit.expense
import com.asyraf.hadirku.engine.TestKit.must
import com.asyraf.hadirku.engine.TestKit.opening
import com.asyraf.hadirku.engine.TestKit.rm
import com.asyraf.hadirku.engine.assistant.AnswerSource
import com.asyraf.hadirku.engine.assistant.AssistantEngine
import com.asyraf.hadirku.engine.assistant.Intent
import com.asyraf.hadirku.engine.assistant.SnapshotBuilder
import com.asyraf.hadirku.engine.ledger.LedgerOps
import com.asyraf.hadirku.engine.ledger.PgLedgerAdapter
import com.asyraf.hadirku.engine.ledger.PostResult
import com.asyraf.hadirku.engine.receipt.BackendConfig
import com.asyraf.hadirku.engine.receipt.ClaudeBackendProvider
import com.asyraf.hadirku.engine.receipt.CheckCode
import com.asyraf.hadirku.engine.receipt.DraftStatus
import com.asyraf.hadirku.engine.receipt.DuplicateKind
import com.asyraf.hadirku.engine.receipt.FieldConfidence
import com.asyraf.hadirku.engine.receipt.HttpResponse
import com.asyraf.hadirku.engine.receipt.KnownReceipt
import com.asyraf.hadirku.engine.receipt.OpenAiBackendProvider
import com.asyraf.hadirku.engine.receipt.ProviderResult
import com.asyraf.hadirku.engine.receipt.ReceiptConfirmation
import com.asyraf.hadirku.engine.receipt.ReceiptEngine
import com.asyraf.hadirku.engine.receipt.ReceiptExtractor
import com.asyraf.hadirku.engine.receipt.ReceiptJson
import com.asyraf.hadirku.engine.receipt.ReceiptParse
import com.asyraf.hadirku.engine.receipt.ReceiptRequest
import com.asyraf.hadirku.engine.receipt.UploadIssue
import com.asyraf.hadirku.pg.PgState
import com.asyraf.hadirku.pg.Pocket
import com.asyraf.hadirku.pg.Tx
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.IOException
import java.time.LocalDate

class ReceiptTest {
    private fun receipt(total: String, extra: String = "") = """
        {"schema_version":1,
         "merchant":{"value":"Kedai Runcit Ali","confidence":"high","source":"printed"},
         "date":{"value":"2026-11-15","confidence":"high","source":"printed"},
         "currency":{"value":"MYR"},
         "items":[{"name":{"value":"Gula 1kg"},"quantity":{"value":2},"unit_price":{"value":4.50},"line_total":{"value":9.00}},
                  {"name":{"value":"Teh"},"quantity":{"value":1},"unit_price":{"value":9.00},"line_total":{"value":9.00}}],
         "subtotal":{"value":18.00,"confidence":"high"},
         "discount":{"value":2.00,"confidence":"high"},
         "total":{"value":$total,"confidence":"high","source":"printed"} $extra}
    """.trimIndent()

    private fun ok(json: String) = (ReceiptJson.parse(json) as ReceiptParse.Ok).data

    /** Spec scenario 5 */
    @Test fun recomputedTotalsPassOrAreFlaggedNeverCorrected() {
        val good = ok(receipt("16.00"))
        assertTrue(ReceiptEngine.verify(good, D).consistent)
        val bad = ok(receipt("17.00"))
        val v = ReceiptEngine.verify(bad, D)
        val flag = v.flags.single { it.code == CheckCode.TOTAL_MISMATCH }
        assertEquals(rm("16.00"), flag.expected)
        assertEquals(rm("17.00"), flag.claimed)
        assertEquals(rm("17.00"), bad.total.value)                      // not silently corrected
        assertEquals(DraftStatus.NEEDS_REVIEW, ReceiptEngine.draft("r", bad, emptyList(), null, D).status)
    }

    /** Spec scenario 7 */
    @Test fun missingOrBlurryFieldsStayNullOrUncertain() {
        val json = """{"schema_version":1,"merchant":{"value":null,"confidence":"low"},"date":{"value":"15/11/2026"},
            "total":{"value":"12.30","confidence":"low"},"subtotal":{"value":12.3,"confidence":"low","source":"inferred"}}"""
        val p = ReceiptJson.parse(json) as ReceiptParse.Ok
        assertNull(p.data.merchant.value)
        assertNull(p.data.date.value)                                    // wrong format → null, not guessed
        assertNull(p.data.total.value)                                   // string instead of number → null, not coerced
        assertTrue("date:format" in p.warnings && "total:type" in p.warnings)
        assertEquals(FieldConfidence.LOW, p.data.total.confidence)
        val v = ReceiptEngine.verify(p.data, D)
        assertTrue(v.flags.any { it.code == CheckCode.TOTAL_MISSING } && v.flags.any { it.code == CheckCode.DATE_MISSING })
        assertTrue("subtotal" in v.uncertainFields)
        assertNull(ReceiptEngine.confirm(ReceiptEngine.draft("r", p.data, emptyList(), null, D), ReceiptConfirmation("a"), "e")) // needs user input
        assertTrue(ReceiptJson.parse("""{"schema_version":2}""") is ReceiptParse.Invalid)
    }

    @Test fun itemLineMismatchIsFlagged() {
        val d = ok(receipt("16.00").replace(""""line_total":{"value":9.00}},""", """"line_total":{"value":9.50}},"""))
        val codes = ReceiptEngine.verify(d, D).flags.map { it.code }
        assertTrue(CheckCode.ITEM_LINE_MISMATCH in codes && CheckCode.ITEMS_SUBTOTAL_MISMATCH in codes)
    }

    /** Spec scenario 6 */
    @Test fun duplicateReceiptImportDoesNotPostTwice() {
        val d = ok(receipt("16.00", ""","receipt_id":{"value":"INV-00123"}"""))
        var b = book(bank("a")).must(opening("o", "a", "100.00"))
        val draft = ReceiptEngine.draft("r1", d, emptyList(), b, D)
        val e1 = ReceiptEngine.confirm(draft, ReceiptConfirmation("a", category = "dapur"), "rc1")!!
        b = LedgerOps.post(b, e1, T0, draft.idempotencyKey).book
        val again = ReceiptEngine.draft("r2", d, listOf(KnownReceipt("r1", "Kedai Runcit Ali", d.date.value, d.total.value, "INV 00123")), b, D)
        assertEquals(DraftStatus.DUPLICATE_SUSPECTED, again.status)
        assertTrue(again.duplicates.any { it.kind == DuplicateKind.SAME_RECEIPT_ID })
        assertTrue(again.duplicates.any { it.kind == DuplicateKind.LEDGER_ENTRY && it.refId == "rc1" })
        val e2 = ReceiptEngine.confirm(again, ReceiptConfirmation("a"), "rc2")!!
        val r = LedgerOps.post(b, e2, T0, again.idempotencyKey)
        assertTrue(r.result is PostResult.Duplicate)
        assertEquals(rm("84.00"), r.book.balance("a"))
    }

    @Test fun fuzzyDuplicateWithoutReceiptId() {
        val d = ok(receipt("16.00"))
        val dup = ReceiptEngine.duplicates(d, listOf(KnownReceipt("k", "KEDAI RUNCIT ALI SDN BHD", LocalDate.of(2026, 11, 16), rm("16.00"), null, listOf("Gula 1kg"))), null)
        assertEquals(DuplicateKind.FUZZY_RECEIPT, dup.single().kind)
    }

    @Test fun legacyScanResultMapsWithoutInventingFields() {
        val legacy = """{"boleh_baca":true,"kedai":"Petronas Lunas","tarikh":"2026-11-10","jumlah":50.0,"cara_bayar":"tak_pasti",
            "ringkasan":"RON95","poket":"Minyak","kategori":"minyak","item":[{"nama":"RON95","jumlah":50.0}],"keyakinan":"sederhana"}"""
        val d = (ReceiptJson.fromLegacy(legacy) as ReceiptParse.Ok).data
        assertEquals("Petronas Lunas", d.merchant.value)
        assertEquals(rm("50.00"), d.total.value)
        assertNull(d.subtotal.value); assertNull(d.paymentMethod.value); assertNull(d.receiptId.value)
        assertEquals(FieldConfidence.MEDIUM, d.total.confidence)
        val roundTrip = ReceiptJson.parse(ReceiptJson.toJson(d)) as ReceiptParse.Ok
        assertEquals(d.total.value, roundTrip.data.total.value)
    }
}

class ReceiptProviderTest {
    private val req = ReceiptRequest(ByteArray(1000) { 1 }, "image/jpeg", "req-1")

    /** Spec scenario 11 */
    @Test fun aiUnavailableOrFailingNeverAffectsManualEntry() {
        val none = ReceiptExtractor(listOf(ClaudeBackendProvider(null), OpenAiBackendProvider(BackendConfig("http://insecure", "t"))))
        assertFalse(none.isAvailable())
        assertTrue(none.extract(req).first is ProviderResult.Unavailable)
        val broken = ReceiptExtractor(listOf(ClaudeBackendProvider(BackendConfig("https://api.example", "tok"), { _, _, _, _ -> throw IOException("down") })))
        val r = broken.extract(req)
        assertTrue(r.first is ProviderResult.Failed && r.second == null)
        // manual entry still works exactly the same
        val b = book(bank("a")).must(opening("o", "a", "100.00")).must(expense("manual", "a", "12.30"))
        assertEquals(rm("87.70"), b.balance("a"))
    }

    @Test fun retriesOnRateLimitThenSucceedsAndNeverSendsProviderKey() {
        var calls = 0
        val seenHeaders = ArrayList<Map<String, String>>()
        val p = ClaudeBackendProvider(BackendConfig("https://api.example/", "device-token"), { url, h, body, _ ->
            calls++; seenHeaders += h
            assertEquals("https://api.example/v1/receipts/extract", url)
            assertTrue(body.contains("\"vendor\":\"claude\"") && body.contains("\"schema_version\":1"))
            if (calls < 2) HttpResponse(429, "") else HttpResponse(200, """{"schema_version":1,"total":{"value":5.5}}""")
        })
        val sleeps = ArrayList<Long>()
        val withSleep = object : com.asyraf.hadirku.engine.receipt.BackendReceiptProvider("claude", BackendConfig("https://api.example/", "device-token"),
            { _, h, _, _ -> calls++; seenHeaders += h; if (calls < 4) HttpResponse(503, "") else HttpResponse(200, """{"schema_version":1}""") }, { sleeps += it }) {}
        assertTrue(p.extract(req) is ProviderResult.Success)
        calls = 2
        assertTrue(withSleep.extract(req) is ProviderResult.Success)
        assertEquals(listOf(1000L), sleeps)
        assertTrue(seenHeaders.all { it["Authorization"] == "Bearer device-token" })
        val auth = ClaudeBackendProvider(BackendConfig("https://api.example", "x"), { _, _, _, _ -> HttpResponse(401, "") })
        assertEquals(ProviderResult.Failed("auth", false), auth.extract(req))
    }

    @Test fun uploadLimits() {
        assertEquals(listOf(UploadIssue.TOO_LARGE), ReceiptEngine.validateUpload("image/jpeg", 5_000_000))
        assertEquals(listOf(UploadIssue.UNSUPPORTED_TYPE), ReceiptEngine.validateUpload("image/gif", 10))
        val p = ClaudeBackendProvider(BackendConfig("https://api.example", "x"), { _, _, _, _ -> error("must not be called") })
        assertEquals(ProviderResult.Failed("upload:too_large", false), p.extract(ReceiptRequest(ByteArray(5_000_000), "image/jpeg", "r")))
    }
}

class AssistantTest {
    private val s = PgState(
        pockets = listOf(Pocket("p1", "Akaun Rahsia Saya")),
        transactions = listOf(
            Tx("o", "2026-11-01", "baki-awal", "p1", jumlah = 1000.0),
            Tx("a", "2026-11-03", "keluar", "p1", jumlah = 25.5, perkara = "Nasi kandar Line Clear", kategori = "makan", catatan = "dengan bos"),
            Tx("b", "2026-11-09", "keluar", "p1", jumlah = 14.5, perkara = "Mamak", kategori = "makan"),
        ),
    )

    @Test fun deterministicAnswersCiteEntriesAndSnapshotIsSanitised() {
        val book = PgLedgerAdapter.build(s, D).book
        val snap = SnapshotBuilder.build(s, book, D)
        val a = AssistantEngine().ask("Berapa belanja makan bulan ni?", snap)
        assertEquals(Intent.SPEND_IN_CATEGORY, a.intent)
        assertEquals(AnswerSource.DETERMINISTIC, a.source)
        assertEquals("40.00", a.values["spend.mtd.makan"])
        assertEquals(setOf("t:a", "t:b"), a.citations.toSet())
        assertNotNull(a.range)
        val json = snap.toProviderJson()
        listOf("Nasi kandar", "dengan bos", "Akaun Rahsia", "t:a").forEach { assertFalse("leaked: $it", json.contains(it)) }
    }

    @Test fun openQuestionsUseProviderOnlyWithSnapshotAndDegradeGracefully() {
        val book = PgLedgerAdapter.build(s, D).book
        val snap = SnapshotBuilder.build(s, book, D)
        var seen = ""
        val ai = AssistantEngine { _, json -> seen = json; "Ringkasan" }
        val a = ai.ask("Macam mana nak simpan lebih?", snap)
        assertEquals(AnswerSource.AI, a.source)
        assertEquals(snap.toProviderJson(), seen)
        val down = AssistantEngine { _, _ -> throw RuntimeException("offline") }.ask("Macam mana nak simpan lebih?", snap)
        assertEquals(AnswerSource.UNAVAILABLE, down.source)
        assertEquals(AnswerSource.UNAVAILABLE, AssistantEngine().ask("Apa pendapat kamu?", snap).source)
    }
}
