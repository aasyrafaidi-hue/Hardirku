package com.asyraf.hadirku.engine

import com.asyraf.hadirku.engine.budget.Budget
import com.asyraf.hadirku.engine.budget.BudgetEngine
import com.asyraf.hadirku.engine.budget.SuggestionKind
import com.asyraf.hadirku.engine.core.Money
import com.asyraf.hadirku.engine.forecast.ForecastEngine
import com.asyraf.hadirku.engine.ledger.LedgerIntegrity
import com.asyraf.hadirku.engine.ledger.LedgerReports
import com.asyraf.hadirku.engine.ledger.PgLedgerAdapter
import com.asyraf.hadirku.pg.Commitment
import com.asyraf.hadirku.pg.Debt
import com.asyraf.hadirku.pg.DebtLog
import com.asyraf.hadirku.pg.Epp
import com.asyraf.hadirku.pg.Gaji
import com.asyraf.hadirku.pg.OtEntry
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.PgCfo
import com.asyraf.hadirku.pg.PgSettings
import com.asyraf.hadirku.pg.PgState
import com.asyraf.hadirku.pg.Pocket
import com.asyraf.hadirku.pg.SimItem
import com.asyraf.hadirku.pg.Tx
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.math.BigDecimal
import java.math.RoundingMode
import java.time.LocalDate
import java.time.YearMonth
import kotlin.random.Random

/**
 * Simulasi pengiraan: setiap jangkaan dikira SEMULA secara bebas (BigDecimal, sen tepat) — bukan dengan memanggil
 * fungsi enjin yang sama — kemudian dibanding dengan output enjin hingga ke sen.
 */
class SimulasiKiraanTest {

    /* ---------------- alat bantu ---------------- */

    private fun bd(x: Double): BigDecimal = BigDecimal.valueOf(x)
    private fun r2(x: BigDecimal): BigDecimal = x.setScale(2, RoundingMode.HALF_UP)
    private fun sen(x: Double): Long = Money.fromDouble(x).sen
    private fun sen(x: BigDecimal): Long = r2(x).unscaledValue().toLong()
    private fun eqSen(msg: String, expected: BigDecimal, actual: Double) = assertEquals(msg, sen(expected), sen(actual))
    private fun eqSen(msg: String, expected: String, actual: Double) = eqSen(msg, BigDecimal(expected), actual)

    /** Pembina senario: rekod transaksi sambil mengira baki setiap poket sendiri (model bebas). */
    private class Bulan(val pockets: List<Pocket>) {
        val tx = ArrayList<Tx>()
        val baki = LinkedHashMap<String, BigDecimal>().apply { pockets.forEach { put(it.id, BigDecimal.ZERO) } }
        private var n = 0
        private fun add(p: String, v: BigDecimal) { baki[p] = baki.getValue(p) + v }
        fun rekod(t: Tx): Tx {
            val x = t.copy(id = "t${n++}", dibuat = n.toLong())
            tx += x
            val a = BigDecimal.valueOf(x.jumlah)
            when (x.jenis) {
                "masuk", "baki-awal", "pelarasan+", "tunai-kad" -> add(x.poket, a)
                "keluar", "pelarasan-" -> add(x.poket, a.negate())
                "pindah" -> { add(x.poket, a.negate()); add(x.ke, a) }
                "kad" -> if (x.ke.isNotEmpty() && x.ke != x.poket) { add(x.poket, a.negate()); add(x.ke, a) }
            }
            return x
        }
    }

    private val POKET = listOf(
        Pocket(PG.BELUM_AGIH, "Belum Agih"), Pocket("p-belanja", "Belanja"), Pocket("p-komit", "Komitmen"),
        Pocket("p-kad", "Bayar Kad"), Pocket("p-simpan", "Simpanan"),
        Pocket("p-tunai", "Dompet Tunai", dompet = true, tunai = true), Pocket("p-tng", "TNG", dompet = true),
    )
    private val TODAY = "2026-11-27"
    private val TV = Epp("e-tv", "TV", pokok = 2400.0, tempoh = 12, kadar = 5.0, mula = "2026-06-15")
    private val KAD = Debt("k1", "Maybank Visa", jenis = "kad", kadar = 18.0, minPeratus = 5.0, minLantai = 50.0, poket = "p-kad",
        hadKredit = 5000.0, epp = listOf(TV), log = listOf(DebtLog("l-pn", "2026-10-24", "penyata", 1000.0)))
    private val LOAN = Debt("L1", "Pinjaman peribadi", jenis = "pinjaman", kadar = 8.0, ansuran = 350.0, poket = "p-komit",
        log = listOf(DebtLog("l-ln", "2026-10-31", "penyata", 8000.0)))
    private val KOMIT = listOf(
        Commitment("c1", "Sewa rumah", 650.0, poket = "p-komit", tempo = 5),
        Commitment("c2", "Internet", 129.0, poket = "p-komit", tempo = 15),
        Commitment("c3", "Astro", 60.0, poket = "p-komit", tempo = 20),
    )

    /** Senario sebulan (Nov 2026) yang menyerupai penggunaan sebenar. */
    private fun bulanSebenar(): Pair<PgState, Bulan> {
        val b = Bulan(POKET)
        b.rekod(Tx(tarikh = "2026-10-31", jenis = "baki-awal", poket = PG.BELUM_AGIH, jumlah = 1000.0, perkara = "Baki awal"))
        b.rekod(Tx(tarikh = "2026-10-31", jenis = "baki-awal", poket = "p-tunai", jumlah = 50.0, perkara = "Baki awal"))
        b.rekod(Tx(tarikh = "2026-10-31", jenis = "baki-awal", poket = "p-tng", jumlah = 20.0, perkara = "Baki awal"))
        b.rekod(Tx(tarikh = "2026-11-07", jenis = "masuk", poket = PG.BELUM_AGIH, jumlah = 3456.78, perkara = "Gaji Oktober"))
        for ((ke, j) in listOf("p-belanja" to 1200.0, "p-komit" to 1300.0, "p-kad" to 600.0, "p-simpan" to 300.0, "p-tunai" to 200.0))
            b.rekod(Tx(tarikh = "2026-11-07", jenis = "pindah", poket = PG.BELUM_AGIH, ke = ke, jumlah = j, perkara = "Agih"))
        // belanja makan harian: bank & tunai
        for (d in 1..26) {
            val t = PG.iso(2026, 11, d)
            b.rekod(Tx(tarikh = t, jenis = "keluar", poket = "p-belanja", jumlah = 8.50 + (d % 5) * 2.35, perkara = "Makan", kategori = "makan"))
            if (d % 2 == 0) b.rekod(Tx(tarikh = t, jenis = "keluar", poket = "p-tunai", jumlah = 6.0, perkara = "Kopi", kategori = "makan"))
        }
        b.rekod(Tx(tarikh = "2026-11-09", jenis = "keluar", poket = "p-belanja", jumlah = 187.45, perkara = "Lotus's", kategori = "dapur"))
        b.rekod(Tx(tarikh = "2026-11-16", jenis = "masuk", poket = "p-belanja", jumlah = 35.0, perkara = "Isteri pulang baki duit dapur", kategori = "dapur", pulangan = true))
        // komitmen
        b.rekod(Tx(tarikh = "2026-11-05", jenis = "keluar", poket = "p-komit", jumlah = 650.0, perkara = "Sewa", komitmenId = "c1", kategori = "rumah"))
        b.rekod(Tx(tarikh = "2026-11-15", jenis = "keluar", poket = "p-komit", jumlah = 100.0, perkara = "Internet", komitmenId = "c2", kategori = "bil"))
        b.rekod(Tx(tarikh = "2026-11-18", jenis = "keluar", poket = "p-komit", jumlah = 29.0, perkara = "Internet baki", komitmenId = "c2", kategori = "bil"))
        // kad kredit: belian (diasingkan ke poket Bayar Kad), bayaran, tunai dari kad ke TNG (+ fee)
        b.rekod(Tx(tarikh = "2026-11-03", jenis = "kad", poket = "p-belanja", ke = "p-kad", kadId = "k1", jumlah = 150.40, perkara = "Makan keluarga", kategori = "makan"))
        b.rekod(Tx(tarikh = "2026-11-12", jenis = "kad", poket = "p-belanja", ke = "p-kad", kadId = "k1", jumlah = 89.90, perkara = "Petrol", kategori = "minyak"))
        b.rekod(Tx(tarikh = "2026-11-20", jenis = "kad", poket = "p-belanja", ke = "p-kad", kadId = "k1", jumlah = 320.0, perkara = "Kasut", kategori = "diri"))
        b.rekod(Tx(tarikh = "2026-11-10", jenis = "keluar", poket = "p-kad", jumlah = 400.0, perkara = "Bayar kad", hutangId = "k1"))
        b.rekod(Tx(tarikh = "2026-11-22", jenis = "tunai-kad", poket = "p-tng", kadId = "k1", jumlah = 100.0, fee = 5.0, perkara = "Reload TNG guna kad"))
        b.rekod(Tx(tarikh = "2026-11-23", jenis = "keluar", poket = "p-tng", jumlah = 12.30, perkara = "Tol", kategori = "minyak"))
        // pinjaman
        b.rekod(Tx(tarikh = "2026-11-25", jenis = "keluar", poket = "p-komit", jumlah = 350.0, perkara = "Ansuran pinjaman", hutangId = "L1"))
        val s = PgState(pockets = POKET, transactions = b.tx, commitments = KOMIT, debts = listOf(KAD, LOAN))
        return s to b
    }

    /* ---------------- S1: baki poket ---------------- */

    @Test fun s1_bakiPoketBankTunaiEwalletTepatHinggaSen() {
        val (s, b) = bulanSebenar()
        val bal = PG.balances(s)
        b.baki.forEach { (id, v) -> eqSen("baki $id", v, bal.getValue(id)) }
        val bank = b.baki.filterKeys { it !in setOf("p-tunai", "p-tng") }.values.fold(BigDecimal.ZERO, BigDecimal::add)
        eqSen("baki bank", bank, PG.total(s))
        eqSen("tunai", b.baki.getValue("p-tunai"), PG.totalTunai(s))
        eqSen("e-wallet", b.baki.getValue("p-tng"), PG.totalEwallet(s))
        eqSen("luar bank", b.baki.getValue("p-tunai") + b.baki.getValue("p-tng"), PG.totalDompet(s))
        // contoh angka sebenar: Bayar Kad = 600 agih + 560.30 diasingkan − 400 bayar
        eqSen("poket bayar kad", "760.30", bal.getValue("p-kad"))
        eqSen("TNG", "107.70", bal.getValue("p-tng"))
    }

    /* ---------------- S2: laporan bulanan ---------------- */

    @Test fun s2_laporanBulananNov() {
        val (s, b) = bulanSebenar()
        val r = PG.periodReport(s, PG.finPeriod(TODAY, 1))
        val nov = b.tx.filter { it.tarikh.startsWith("2026-11") }
        fun sum(f: (Tx) -> Boolean) = nov.filter(f).fold(BigDecimal.ZERO) { a, t -> a + bd(t.jumlah) }
        val keluarSemua = sum { it.jenis == "keluar" }
        val pulangan = sum { it.pulangan }
        val hutang = sum { it.jenis == "keluar" && it.hutangId.isNotEmpty() }
        val komit = sum { it.jenis == "keluar" && it.komitmenId.isNotEmpty() }
        val kad = sum { it.jenis == "kad" }
        eqSen("masuk (pulangan bukan pendapatan)", "3456.78", r.masuk)
        eqSen("keluar", keluarSemua - pulangan, r.keluar)
        eqSen("hutang", "750.00", r.hutang)
        eqSen("komitmen", "779.00", r.komitmen)
        eqSen("guna kad", "560.30", r.kad)
        eqSen("bayar kad", "400.00", r.bayarKad)
        eqSen("bayar pinjaman", "350.00", r.bayarPinjaman)
        eqSen("fee tunai kad", "5.00", r.kadLog)
        val harian = keluarSemua - pulangan - hutang - komit + kad
        eqSen("belanja harian", harian, r.harian)
        eqSen("jumlah belanja", harian + komit + bd(350.0) + bd(5.0), r.belanja)
        eqSen("lebihan", bd(3456.78) - (harian + komit + bd(350.0) + bd(5.0)), r.lebihan)
        eqSen("dapur bersih selepas pulangan", "152.45", r.katHarian.getValue("dapur"))
        val makan = sum { it.kategori == "makan" }
        eqSen("makan (tunai + bank + kad)", makan, r.katHarian.getValue("makan"))
    }

    /* ---------------- S3: kad kredit & pinjaman ---------------- */

    @Test fun s3_hutangKadMinimumSasaranDanPinjaman() {
        val (s, _) = bulanSebenar()
        val st = PG.debtStatus(s, TODAY).associateBy { it.id }
        val k = st.getValue("k1")
        // penyata 24 Okt 1,000 + EPP 15 Nov 210 + belian 560.30 + tunai 100 + fee 5 − bayar 400
        eqSen("baki kad", "1475.30", k.baki)
        eqSen("EPP bulan ini", "210.00", k.eppDue)
        eqSen("pokok EPP belum dibil (6 × 200)", "1200.00", k.eppPokok)
        eqSen("EPP belum dibil (6 × 210)", "1260.00", k.eppBaki)
        eqSen("faedah EPP belum dibil", "60.00", k.eppFaedah)
        eqSen("jumlah hutang kad", "2675.30", k.jumlah)
        // minimum cara "jumlah": 5% × (1,875.30 + 1,200) = 153.77 < ansuran EPP 210 → minimum = 210
        eqSen("minimum", "210.00", k.min)
        assertEquals("ansuran", k.minInfo!!.sebab)
        eqSen("sasaran = pelan 210 + belanja & tunai kad 665.30", "875.30", k.sasaran)
        eqSen("baki perlu bayar", "475.30", k.bakiBayar)
        assertEquals("pelan", k.status)
        val l = st.getValue("L1")
        eqSen("baki pinjaman", "7650.00", l.baki)
        assertEquals("sudah", l.status)
        val c = PG.commitmentSummary(PG.commitmentStatus(s, TODAY))
        eqSen("komitmen", "839.00", c.jumlah); eqSen("dibayar", "779.00", c.dibayar); eqSen("baki", "60.00", c.baki)
        assertEquals(1, c.belum)
    }

    /* ---------------- S4: lejar enjin (sen Long) sama dengan kiraan app ---------------- */

    @Test fun s4_lejarEnjinSamaHinggaSenDanSeimbang() {
        val (s, b) = bulanSebenar()
        val d = LocalDate.parse(TODAY)
        val r = PgLedgerAdapter.build(s, d)
        assertEquals("isu adapter", emptyList<Any>(), r.issues)
        assertEquals("parity", emptyList<Any>(), PgLedgerAdapter.parity(s, r.book, d))
        assertTrue(LedgerIntegrity.check(r.book).isEmpty())
        val aset = b.baki.values.fold(BigDecimal.ZERO, BigDecimal::add)
        val nilaiBersih = aset - BigDecimal("1475.30") - BigDecimal("7650.00") - BigDecimal("1200.00")
        assertEquals(sen(nilaiBersih), r.book.netWorth().sen)
        val t = LedgerReports.totals(r.book, com.asyraf.hadirku.engine.core.DateRange.month(YearMonth.of(2026, 11)))
        val rep = PG.periodReport(s, PG.finPeriod(TODAY, 1))
        assertEquals("belanja lejar = harian + komitmen", sen(bd(rep.harian) + bd(rep.komitmen)), t.expense.sen)
        assertEquals(Money.parse("750.00"), t.debtRepayment)
        assertEquals(Money.parse("5.00"), t.fees)
        assertEquals(Money.parse("3456.78"), t.income)
    }

    /* ---------------- S5: OT ---------------- */

    @Test fun s5_otJamDanNilai() {
        val ot = LinkedHashMap<String, OtEntry>()
        var d = "2026-10-22"
        repeat(10) { ot[d] = OtEntry("biasa", 12.0); d = PG.addDays(d, 1) }       // 10 × 3 j @1.5
        ot["2026-11-01"] = OtEntry("rest", 11.0); ot["2026-11-08"] = OtEntry("rest", 11.0) // 9 j @2.0 + 2 j @3.0
        ot["2026-11-03"] = OtEntry("umum", 8.0)                                       // 8 j @2.0
        ot["2026-11-15"] = OtEntry("off", 8.0)                                        // 8 j @1.5
        ot["2026-11-22"] = OtEntry("biasa", 12.0)                                     // kitaran seterusnya — tidak dikira
        val s = PgState(settings = PgSettings(gaji = Gaji(basic = 2500.0, night = 300.0, transport = 200.0, jamNormal = 9.0, hadOT = 104.0, potongan = 250.0)), ot = ot)
        val c = PG.otCycleOf("2026-11-10", 22)
        assertEquals("2026-10-22", c.start); assertEquals("2026-11-21", c.end); assertEquals("2026-11", c.bayarYm)   // dibayar dalam gaji 30 Nov
        val sm = PG.otSummary(s, c)
        assertEquals(14, sm.hari)
        assertEquals(38.0, sm.h15, 1e-9); assertEquals(26.0, sm.h20, 1e-9); assertEquals(4.0, sm.h30, 1e-9)
        val hrp = BigDecimal(3000).divide(BigDecimal(208), 20, RoundingMode.HALF_UP)
        val nilai = (BigDecimal("57") + BigDecimal("52") + BigDecimal("12")) * hrp       // 38×1.5 + 26×2 + 4×3 = 121 jam setara
        eqSen("nilai OT", nilai, sm.nilai)
        eqSen("gaji kasar", BigDecimal(3000) + nilai, sm.kasar)
        eqSen("gaji bersih", BigDecimal(2750) + nilai, sm.bersih)
        assertEquals(42.0, sm.kiraHad, 1e-9)                                         // had OT 104 kira 1.5x + 3.0x
        assertEquals(62.0, sm.bakiHad, 1e-9)
    }

    /* ---------------- S6: EPP kadar rata (300 pelan rawak) ---------------- */

    @Test fun s6_eppRataJadualTepat() {
        val rnd = Random(20261127)
        repeat(300) { i ->
            val pokok = BigDecimal.valueOf(rnd.nextLong(10_000, 2_000_000), 2)
            val tempoh = listOf(3, 6, 9, 12, 18, 24, 36)[rnd.nextInt(7)]
            val kadar = BigDecimal.valueOf(rnd.nextInt(0, 1300).toLong(), 2)               // 0.00–12.99% setahun
            val mula = LocalDate.of(2026, 1, 1).plusDays(rnd.nextLong(0, 330))
            val asOf = LocalDate.of(2026, 11, 27)
            val p = Epp("e$i", pokok = pokok.toDouble(), tempoh = tempoh, kadar = kadar.toDouble(), mula = mula.toString())
            val e = PG.eppInfo(p, asOf.toString())
            // model bebas
            val jumlah = r2(pokok + (pokok * kadar * BigDecimal(tempoh)).divide(BigDecimal(1200), 12, RoundingMode.HALF_UP))
            val ans = jumlah.divide(BigDecimal(tempoh), 2, RoundingMode.HALF_UP)
            val akhir = jumlah - ans * BigDecimal(tempoh - 1)
            val dibil = (0 until tempoh).count { !mula.plusMonths(it.toLong()).isAfter(asOf) }
            val dibilRm = if (dibil >= tempoh) jumlah else ans * BigDecimal(dibil)
            val pp = pokok.divide(BigDecimal(tempoh), 2, RoundingMode.HALF_UP)
            val pokokDibil = if (dibil >= tempoh) pokok else pp * BigDecimal(dibil)
            val msg = "EPP $pokok × $tempoh @ $kadar% mula $mula"
            eqSen("$msg jumlah", jumlah, e.jumlahBayar)
            eqSen("$msg ansuran", ans, e.ans)
            eqSen("$msg ansuran akhir", akhir, e.last)
            assertEquals("$msg dibil", dibil, e.dibil)
            eqSen("$msg baki", jumlah - dibilRm, e.baki)
            eqSen("$msg pokok baki", (pokok - pokokDibil).max(BigDecimal.ZERO).min(jumlah - dibilRm), e.pokokBaki)
            eqSen("$msg pokok + faedah = baki", bd(e.baki), e.pokokBaki + e.faedahBaki)
            val sumPokok = (0 until tempoh).fold(BigDecimal.ZERO) { a, k -> a + bd(e.pokokAt(k)) }
            eqSen("$msg jumlah pokok semua ansuran", pokok, sumPokok.toDouble())
        }
    }

    /* ---------------- S7: SPayLater ---------------- */

    @Test fun s7_spaylaterPelanEprDanBil() {
        val p3 = PG.splPelan(1000.0, 3, 1.5)
        eqSen("caj 3 bulan", "45.00", p3.caj); eqSen("jumlah", "1045.00", p3.jumlah)
        eqSen("ansuran", "348.33", p3.ansuran); eqSen("akhir", "348.34", p3.akhir)
        val p6 = PG.splPelan(1000.0, 6, 1.5)
        eqSen("caj 6 bulan", "90.00", p6.caj); eqSen("ansuran", "181.67", p6.ansuran); eqSen("akhir", "181.65", p6.akhir)
        // EPR dikira semula dengan kaedah Newton (bebas daripada bahagi dua dalam enjin)
        for (n in listOf(3, 6, 12, 24)) {
            val a = (1 + 0.015 * n) / n
            var r = 0.01
            repeat(60) {
                val f = a * (1 - Math.pow(1 + r, -n.toDouble())) / r - 1
                val h = 1e-9
                val f2 = a * (1 - Math.pow(1 + r + h, -n.toDouble())) / (r + h) - 1
                r -= f / ((f2 - f) / h)
            }
            assertEquals("EPR $n bulan", Math.round(r * 1200 * 100) / 100.0, PG.splEpr(1.5, n), 0.011)
        }
        assertEquals(5.0, PG.splCajLewat(5.0), 0.0); assertEquals(10.0, PG.splCajLewat(30.0), 0.0)
        // sebulan: beli RM200 pada 5 Nov (bil 1hb, akhir 10hb) → bil 1 Dis RM200, lewat selepas 10 Dis
        val spl = Debt("s1", "SPayLater", jenis = "kad", penyedia = PG.SPL, penyataHari = 1, bayarHari = 10, poket = "p-kad", hadKredit = 1500.0)
        val base = PgState(pockets = POKET, debts = listOf(spl), transactions = listOf(
            Tx("a", "2026-11-01", "baki-awal", "p-belanja", jumlah = 500.0),
            Tx("b", "2026-11-05", "kad", "p-belanja", ke = "p-kad", kadId = "s1", jumlah = 200.0, perkara = "ShopeeFood"),
        ))
        val i1 = PG.splInfo(base, spl, "2026-12-03")!!
        eqSen("bil Dis", "200.00", i1.bil); assertEquals("2026-12-10", i1.tarikhAkhir); assertFalse(i1.lewat)
        val i2 = PG.splInfo(base, spl, "2026-12-11")!!
        assertTrue(i2.lewat); eqSen("caj lewat", "10.00", i2.cajLewat)
        val paid = base.copy(transactions = base.transactions + Tx("c", "2026-12-08", "keluar", "p-kad", jumlah = 200.0, hutangId = "s1"))
        assertEquals("langsai", PG.debtStatus(paid, "2026-12-11").single().status)   // bil dibayar penuh, tiada baki
        eqSen("poket belanja selepas asingkan", "300.00", PG.balances(base).getValue("p-belanja"))
    }

    /* ---------------- S8: komitmen bayar awal dibawa ---------------- */

    @Test fun s8_komitmenBayarLebihDibawaKeBulanDepan() {
        val s = PgState(pockets = POKET, commitments = KOMIT, transactions = listOf(
            Tx("a", "2026-10-05", "keluar", "p-komit", jumlah = 1300.0, komitmenId = "c1"),  // bayar Okt + Nov sekali
        ))
        val nov = PG.commitmentStatus(s, "2026-11-10").associateBy { it.id }
        eqSen("sewa Nov dibawa dari Okt", "650.00", nov.getValue("c1").dibayar)
        assertEquals("sudah", nov.getValue("c1").status)
        assertEquals("belum", nov.getValue("c2").status)
        // semua selesai → paparan beralih ke bulan seterusnya
        val full = s.copy(transactions = s.transactions + listOf(
            Tx("b", "2026-11-12", "keluar", "p-komit", jumlah = 129.0, komitmenId = "c2"),
            Tx("c", "2026-11-12", "keluar", "p-komit", jumlah = 60.0, komitmenId = "c3"),
        ))
        assertEquals("2026-12-01", PG.commitmentViewDate(full, "2026-11-20"))
    }

    /* ---------------- S9: pelan langsai hutang ---------------- */

    @Test fun s9_pelanHutangSamaDenganJadualBebas() {
        val loan = Debt("L", "Pinjaman", jenis = "pinjaman", kadar = 12.0, ansuran = 100.0)
        val sim = PG.simulateDebts(listOf(SimItem(loan, 1000.0, emptyList())), 100.0, "avalanche")
        var b = BigDecimal("1000.00"); var faedah = BigDecimal.ZERO; var bulan = 0
        while (b.signum() > 0) {
            bulan++
            val i = r2(b * BigDecimal("0.01")); b += i; faedah += i
            b -= b.min(BigDecimal("100.00"))
        }
        assertEquals("bulan langsai", bulan, sim.bulan)
        eqSen("jumlah faedah", faedah, sim.faedah)
        eqSen("jumlah bayar = pokok + faedah", BigDecimal("1000.00") + faedah, sim.bayar)
        // dua hutang: avalanche tidak pernah lebih mahal daripada snowball; bayaran = pokok + faedah
        val kad = Debt("K", "Kad", jenis = "kad", kadar = 18.0, minPeratus = 5.0, minLantai = 50.0)
        val items = listOf(SimItem(kad, 3000.0, emptyList()), SimItem(loan.copy(kadar = 6.0), 2000.0, emptyList()))
        val av = PG.simulateDebts(items, 600.0, "avalanche")
        val sb = PG.simulateDebts(items, 600.0, "snowball")
        assertFalse(av.never); assertFalse(sb.never)
        assertTrue("avalanche ${av.faedah} ≤ snowball ${sb.faedah}", av.faedah <= sb.faedah + 0.005)
        eqSen("avalanche bayar", BigDecimal("5000.00") + bd(av.faedah), av.bayar)
        eqSen("snowball bayar", BigDecimal("5000.00") + bd(sb.faedah), sb.bayar)
    }

    /* ---------------- S10: invarian rawak (400 keadaan) ---------------- */

    @Test fun s10_invarianRawak() {
        val rnd = Random(90)
        val ids = POKET.map { it.id }
        repeat(400) { round ->
            val b = Bulan(POKET)
            val plans = (0 until rnd.nextInt(0, 3)).map { j ->
                Epp("e$j", pokok = rnd.nextLong(10_000, 500_000) / 100.0, tempoh = listOf(3, 6, 12, 24)[rnd.nextInt(4)],
                    kadar = rnd.nextInt(0, 1000) / 100.0, mula = LocalDate.of(2026, 1, 1).plusDays(rnd.nextLong(0, 320)).toString())
            }
            val kad = Debt("k", "Kad", jenis = "kad", kadar = 18.0, poket = "p-kad", epp = plans, hadKredit = 8000.0,
                penyataHari = if (rnd.nextBoolean()) 0 else rnd.nextInt(1, 29), bayarHari = rnd.nextInt(1, 29))
            val spl = Debt("s", "SPayLater", jenis = "kad", penyedia = PG.SPL, penyataHari = 1, bayarHari = 10, poket = "p-kad")
            val loan = Debt("L", "Pinjaman", jenis = "pinjaman", kadar = 7.0, ansuran = 300.0, poket = "p-komit")
            b.rekod(Tx(tarikh = "2026-06-01", jenis = "baki-awal", poket = PG.BELUM_AGIH, jumlah = rnd.nextLong(0, 1_000_000) / 100.0))
            var kadOwed = BigDecimal.ZERO
            repeat(rnd.nextInt(40, 160)) {
                val t = LocalDate.of(2026, 6, 1).plusDays(rnd.nextLong(0, 180)).toString()
                val a = rnd.nextLong(1, 300_000) / 100.0
                val p = ids[rnd.nextInt(ids.size)]
                when (rnd.nextInt(10)) {
                    0, 1 -> b.rekod(Tx(tarikh = t, jenis = "masuk", poket = p, jumlah = a, perkara = "Gaji"))
                    2, 3 -> b.rekod(Tx(tarikh = t, jenis = "keluar", poket = p, jumlah = a, kategori = "makan",
                        komitmenId = if (rnd.nextInt(5) == 0) "c1" else ""))
                    4 -> b.rekod(Tx(tarikh = t, jenis = "pindah", poket = p, ke = ids.filter { it != p }[rnd.nextInt(ids.size - 1)], jumlah = a))
                    5 -> { b.rekod(Tx(tarikh = t, jenis = "kad", poket = p, ke = if (rnd.nextBoolean()) "p-kad" else "", kadId = "k", jumlah = a, kategori = "diri")); kadOwed += bd(a) }
                    6 -> { b.rekod(Tx(tarikh = t, jenis = "keluar", poket = p, jumlah = a, hutangId = "k")); kadOwed -= bd(a) }
                    7 -> { val f = rnd.nextLong(0, 1000) / 100.0
                           b.rekod(Tx(tarikh = t, jenis = "tunai-kad", poket = p, kadId = "k", jumlah = a, fee = f)); kadOwed += bd(a) + bd(f) }
                    8 -> b.rekod(Tx(tarikh = t, jenis = "masuk", poket = p, jumlah = a, kategori = "dapur", pulangan = true))
                    else -> b.rekod(Tx(tarikh = t, jenis = if (rnd.nextBoolean()) "pelarasan+" else "pelarasan-", poket = p, jumlah = a))
                }
            }
            val today = "2026-11-27"
            val s = PgState(pockets = POKET, transactions = b.tx, commitments = KOMIT, debts = listOf(kad, spl, loan))
            val msg = "keadaan #$round"
            // 1) baki setiap poket = model bebas
            val bal = PG.balances(s)
            b.baki.forEach { (id, v) -> eqSen("$msg baki $id", v, bal.getValue(id)) }
            // 2) bank + luar bank = semua poket; tunai + e-wallet = luar bank
            eqSen("$msg jumlah", b.baki.values.fold(BigDecimal.ZERO, BigDecimal::add), PG.total(s) + PG.totalDompet(s))
            eqSen("$msg luar bank", bd(PG.totalTunai(s)) + bd(PG.totalEwallet(s)), PG.totalDompet(s))
            // 3) hutang kad = belian + tunai + fee + EPP dibil − bayaran (model bebas)
            val eppDibil = plans.fold(BigDecimal.ZERO) { acc, p ->
                val jumlah = r2(bd(p.pokok) + (bd(p.pokok) * bd(p.kadar) * BigDecimal(p.tempoh)).divide(BigDecimal(1200), 12, RoundingMode.HALF_UP))
                val ans = jumlah.divide(BigDecimal(p.tempoh), 2, RoundingMode.HALF_UP)
                val m = LocalDate.parse(p.mula)
                val n = (0 until p.tempoh).count { !m.plusMonths(it.toLong()).isAfter(LocalDate.parse(today)) }
                acc + if (n >= p.tempoh) jumlah else ans * BigDecimal(n)
            }
            eqSen("$msg hutang kad", kadOwed + eppDibil, PG.debtBalance(s, kad, null, today))
            // 4) lejar enjin sama hingga sen & seimbang
            val r = PgLedgerAdapter.build(s, LocalDate.parse(today))
            assertTrue("$msg integriti ${r.issues}", r.issues.none { it.code.startsWith("integrity") })
            assertEquals("$msg parity", emptyList<Any>(), PgLedgerAdapter.parity(s, r.book, LocalDate.parse(today)))
            // 5) status hutang konsisten
            PG.debtStatus(s, today).forEach { d ->
                eqSen("$msg ${d.id} jumlah = baki + pokok EPP", bd(d.baki) + bd(d.eppPokok), d.jumlah)
                eqSen("$msg ${d.id} pokok + faedah EPP", bd(d.eppPokok) + bd(d.eppFaedah), d.eppBaki)
                assertTrue("$msg ${d.id} sasaran ≥ 0", d.sasaran >= 0)
            }
            // 6) laporan bulanan boleh dijumlah: Jun–Nov = jumlah semua masuk (bukan pulangan)
            var masuk = BigDecimal.ZERO; var kadSum = BigDecimal.ZERO
            for (m in 6..11) {
                val rep = PG.periodReport(s, PG.finPeriod(PG.iso(2026, m, 15), 1))
                masuk += bd(rep.masuk); kadSum += bd(rep.kad)
                eqSen("$msg harian bulan $m", bd(rep.keluar) - bd(rep.hutang) - bd(rep.komitmen) + bd(rep.kad), rep.harian)
            }
            eqSen("$msg masuk 6 bulan", b.tx.filter { it.jenis == "masuk" && !it.pulangan }.fold(BigDecimal.ZERO) { a, t -> a + bd(t.jumlah) }, masuk.toDouble())
            eqSen("$msg kad 6 bulan", b.tx.filter { it.jenis == "kad" }.fold(BigDecimal.ZERO) { a, t -> a + bd(t.jumlah) }, kadSum.toDouble())
            // 7) komitmen: baki = max(0, jumlah − dibayar)
            PG.commitmentStatus(s, today).forEach { c ->
                eqSen("$msg komitmen ${c.id}", (bd(c.jumlah) - bd(c.dibayar)).max(BigDecimal.ZERO), c.baki)
            }
        }
    }

    /* ---------------- S11: pembundaran separuh sen ---------------- */

    @Test fun s11_pembundaranSeparuhSenNaikSepertiBank() {
        assertEquals(1.01, PG.round2(1.005), 0.0)
        assertEquals(2.68, PG.round2(2.675), 0.0)
        assertEquals(153.77, PG.round2(3075.30 * 5 / 100), 0.0)
        assertEquals(1234567.9, PG.round2(1234567.895), 0.0)
        val rnd = Random(7)
        repeat(20_000) {
            val s = rnd.nextLong(0, 100_000_000)                                   // hingga RM1 juta
            val tie = (s * 10 + 5) / 1000.0                                         // x.xx5
            assertEquals("separuh sen $tie", (s + 1) / 100.0, PG.round2(tie), 1e-9)
            val below = (s * 10 + 4) / 1000.0
            assertEquals("bawah separuh $below", s / 100.0, PG.round2(below), 1e-9)
        }
    }

    /* ---------------- S12–S14: kematangan data (90 hari) ---------------- */

    private fun pengguna(mula: String, belanja: List<Pair<String, Double>>, kat: String = "makan"): PgState {
        val tx = ArrayList<Tx>()
        tx += Tx("o", mula, "baki-awal", "p-belanja", jumlah = 5000.0)
        belanja.forEachIndexed { i, (t, a) -> tx += Tx("x$i", t, "keluar", "p-belanja", jumlah = a, kategori = kat) }
        return PgState(pockets = POKET, transactions = tx)
    }

    @Test fun s12_cadanganBajetHanyaGunaBulanYangAdaRekod() {
        // mula merekod 3 Okt: Okt 600 + Nov 650 makan; bajet makan 1,000
        val s = pengguna("2026-10-03", listOf("2026-10-10" to 600.0, "2026-11-10" to 650.0))
        val book = PgLedgerAdapter.build(s, LocalDate.of(2026, 12, 2)).book
        val bajet = listOf(Budget("b", "makan", Money.parse("1000.00"), YearMonth.of(2026, 1)))
        val g = BudgetEngine.suggestions(book, bajet, YearMonth.of(2026, 12)).single()
        assertEquals(2, g.months)                                                    // Sep tiada rekod — tidak dikira RM0
        assertEquals(Money.parse("625.00"), g.trailingAverage)                       // bukan 1,250 ÷ 3 = 416.67
        assertEquals(SuggestionKind.KEEP, g.kind)                                     // belum cukup 3 bulan untuk cadang turun
        // tiga bulan penuh → baru boleh cadang turun
        val s3 = pengguna("2026-09-01", listOf("2026-09-10" to 500.0, "2026-10-10" to 600.0, "2026-11-10" to 650.0))
        val g3 = BudgetEngine.suggestions(PgLedgerAdapter.build(s3, LocalDate.of(2026, 12, 2)).book, bajet, YearMonth.of(2026, 12)).single()
        assertEquals(3, g3.months); assertEquals(SuggestionKind.LOWER, g3.kind); assertEquals(Money.parse("590.00"), g3.suggested)
        // baru mula 20 Nov → tiada bulan penuh → tiada cadangan
        val s0 = pengguna("2026-11-20", listOf("2026-11-21" to 80.0))
        assertTrue(BudgetEngine.suggestions(PgLedgerAdapter.build(s0, LocalDate.of(2026, 12, 2)).book, bajet, YearMonth.of(2026, 12)).isEmpty())
    }

    @Test fun s13_purataHarianRamalanIkutHariSebenarDirekod() {
        // mula 18 Nov; 20/hari 18–26 Nov (9 hari) + guna kad 45 − pulangan 10 = 215 → 23.89 sehari
        val belanja = (18..26).map { PG.iso(2026, 11, it) to 20.0 }
        val base = pengguna("2026-11-18", belanja)
        val epp = Epp("e", "Telefon", pokok = 1200.0, tempoh = 12, mula = "2026-01-10")     // EPP lama: tarikh jauh lebih awal
        val kad = Debt("k", "Kad", jenis = "kad", epp = listOf(epp), poket = "p-kad")
        val s = base.copy(debts = listOf(kad), transactions = base.transactions + listOf(
            Tx("k1", "2026-11-20", "kad", "p-belanja", ke = "p-kad", kadId = "k", jumlah = 45.0, kategori = "makan"),
            Tx("r1", "2026-11-21", "masuk", "p-belanja", jumlah = 10.0, kategori = "makan", pulangan = true),
            Tx("c1", "2026-11-22", "keluar", "p-komit", jumlah = 650.0, komitmenId = "c1"),       // komitmen: bukan belanja harian
        ), commitments = KOMIT)
        val today = LocalDate.of(2026, 11, 27)
        val book = PgLedgerAdapter.build(s, today).book
        val (sehari, hari) = ForecastEngine.dailyDiscretionary(book, today)
        assertEquals(9L, hari)
        assertEquals(Money.parse("23.89"), sehari)
    }

    @Test fun s14_purata90HariFailCfo() {
        // 20 hari data (8–27 Nov): 25/hari + kad 100 − pulangan 40 = 560 ÷ 20 = 28.00
        val belanja = (8..27).map { PG.iso(2026, 11, it) to 25.0 }
        val base = pengguna("2026-11-08", belanja)
        val kad = Debt("k", "Kad", jenis = "kad", poket = "p-kad")
        val s = base.copy(debts = listOf(kad), commitments = KOMIT, transactions = base.transactions + listOf(
            Tx("k1", "2026-11-12", "kad", "p-belanja", ke = "p-kad", kadId = "k", jumlah = 100.0, kategori = "diri"),
            Tx("r1", "2026-11-14", "masuk", "p-belanja", jumlah = 40.0, kategori = "makan", pulangan = true),
            Tx("c1", "2026-11-10", "keluar", "p-komit", jumlah = 300.0, komitmenId = "c1"),
        ))
        val md = PgCfo.cfoMarkdown(s, "2026-11-27", PgCfo.Opts(transaksi = false))
        assertTrue(md, md.contains("Purata belanja harian (20 hari) | RM28.00 sehari"))
        // data 3 hari sahaja → dibahagi minimum 7 hari (purata belum matang, nampak rendah)
        val baru = pengguna("2026-11-25", (25..27).map { PG.iso(2026, 11, it) to 30.0 })
        val md2 = PgCfo.cfoMarkdown(baru, "2026-11-27", PgCfo.Opts(transaksi = false))
        assertTrue(md2, md2.contains("Purata belanja harian (7 hari) | RM12.86 sehari"))
    }
}
