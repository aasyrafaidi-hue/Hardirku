package com.asyraf.hadirku.engine

import com.asyraf.hadirku.engine.core.Money
import com.asyraf.hadirku.engine.ledger.EntryType
import com.asyraf.hadirku.engine.ledger.LedgerReports
import com.asyraf.hadirku.engine.ledger.PgLedgerAdapter
import com.asyraf.hadirku.pg.Debt
import com.asyraf.hadirku.pg.DebtLog
import com.asyraf.hadirku.pg.Epp
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.PgSample
import com.asyraf.hadirku.pg.PgState
import com.asyraf.hadirku.pg.Pocket
import com.asyraf.hadirku.pg.Tx
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class AdapterTest {
    private val today = LocalDate.of(2026, 11, 17)

    /** The projected ledger must match the existing app's own numbers to the sen. */
    @Test fun sampleDataParityWithExistingCalculations() {
        for (d in listOf(today, LocalDate.of(2026, 12, 31), LocalDate.of(2027, 3, 1))) {
            val s = PgSample.sampleState(d.toString())
            val r = PgLedgerAdapter.build(s, d)
            assertTrue("adapter issues: ${r.issues}", r.issues.none { it.code.startsWith("integrity") })
            assertEquals("parity @ $d", emptyList<Any>(), PgLedgerAdapter.parity(s, r.book, d))
        }
    }

    @Test fun existingDataIsNotModifiedByProjection() {
        val s = PgSample.sampleState(today.toString())
        val before = s.toString()
        PgLedgerAdapter.build(s, today)
        assertEquals(before, s.toString())
    }

    /** Spec scenario 3 + 4: EPP imported half-way; principal never counted as spending twice. */
    @Test fun preExistingEppHalfwayKeepsOutstandingAndNoDoubleSpending() {
        val plan = Epp("e1", "Peti sejuk", pokok = 1200.0, tempoh = 12, kadar = 0.0, mula = "2026-05-05") // 7 billed by 17 Nov
        val card = Debt("k1", "Kad", jenis = "kad", kadar = 18.0, poket = "p1", epp = listOf(plan),
            log = listOf(DebtLog("l0", "2026-05-01", "penyata", 0.0)))
        val s = PgState(
            pockets = listOf(Pocket("p1", "Bank")),
            transactions = listOf(
                Tx("t0", "2026-05-01", "baki-awal", "p1", jumlah = 3000.0),
                Tx("t1", "2026-06-20", "keluar", "p1", jumlah = 100.0, hutangId = "k1", perkara = "Bayar kad"),
                Tx("t2", "2026-07-20", "keluar", "p1", jumlah = 100.0, hutangId = "k1", perkara = "Bayar kad"),
            ),
            debts = listOf(card),
        )
        val r = PgLedgerAdapter.build(s, today)
        assertEquals(emptyList<Any>(), PgLedgerAdapter.parity(s, r.book, today))
        val bal = r.book.balances()
        assertEquals(Money.parse("-500.00"), bal["e:k1:e1"])                 // 5 × 100 principal still unbilled
        assertEquals(Money.parse("-500.00"), bal["d:k1"])                    // 7 × 100 billed − 200 paid
        val t = LedgerReports.totals(r.book)
        assertEquals(Money.ZERO, t.expense)                                   // EPP principal is not re-created as spending
        assertEquals(Money.parse("200.00"), t.debtRepayment)
        assertEquals(Money.ZERO, t.interest)
    }

    @Test fun eppInterestIsIdentifiableAsCharge() {
        val plan = Epp("e1", "TV", pokok = 1000.0, tempoh = 10, kadar = 6.0, mula = "2026-09-01") // flat 6%/yr → 50 interest
        val s = PgState(pockets = listOf(Pocket("p1", "Bank")), debts = listOf(Debt("k1", "Kad", jenis = "kad", epp = listOf(plan))))
        val r = PgLedgerAdapter.build(s, today)
        assertEquals(emptyList<Any>(), PgLedgerAdapter.parity(s, r.book, today))
        val charges = r.book.entries.filter { it.type == EntryType.CHARGE }
        assertEquals(3, charges.size)                                         // Sep, Oct, Nov billed
        assertEquals(Money.parse("15.00"), Money.sum(charges.map { it.amount }))
        assertEquals(Money.ZERO, LedgerReports.totals(r.book).expense)
    }

    @Test fun cardPurchaseCashAdvanceAndSalaryWithOvertimeAreClassified() {
        val s = PgState(
            pockets = listOf(Pocket("p1", "Belanja"), Pocket("p2", "Bayar kad")),
            debts = listOf(Debt("k1", "Kad", jenis = "kad", poket = "p2")),
            transactions = listOf(
                Tx("g", "2026-11-15", "masuk", "p1", jumlah = 3000.0, perkara = "Gaji Nov", otBayar = 800.0),
                Tx("c", "2026-11-16", "kad", "p1", ke = "p2", jumlah = 120.0, perkara = "Lotus", kadId = "k1", kategori = "dapur"),
                Tx("w", "2026-11-16", "tunai-kad", "p1", jumlah = 200.0, kadId = "k1", fee = 6.0),
            ),
        )
        val r = PgLedgerAdapter.build(s, today)
        assertEquals(emptyList<Any>(), PgLedgerAdapter.parity(s, r.book, today))
        val t = LedgerReports.totals(r.book)
        assertEquals(Money.parse("800.00"), t.incomeOvertime)
        assertEquals(Money.parse("2200.00"), t.incomeSalary)
        assertEquals(Money.parse("120.00"), t.expense)
        assertEquals(Money.parse("6.00"), t.fees)
        assertEquals(Money.parse("200.00"), t.debtDisbursement)
        assertEquals(Money.parse("-326.00"), r.book.balance("d:k1"))
        assertEquals(Money.parse("120.00"), LedgerReports.expenseByCategory(r.book)["dapur"])
        assertTrue(PG.isGajiTx(s.transactions[0]))
    }
}
