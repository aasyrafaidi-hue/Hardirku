package com.asyraf.hadirku.engine

import com.asyraf.hadirku.engine.TestKit.D
import com.asyraf.hadirku.engine.TestKit.T0
import com.asyraf.hadirku.engine.TestKit.bank
import com.asyraf.hadirku.engine.TestKit.book
import com.asyraf.hadirku.engine.TestKit.cash
import com.asyraf.hadirku.engine.TestKit.expense
import com.asyraf.hadirku.engine.TestKit.must
import com.asyraf.hadirku.engine.TestKit.opening
import com.asyraf.hadirku.engine.TestKit.rm
import com.asyraf.hadirku.engine.bills.BillEngine
import com.asyraf.hadirku.engine.bills.BillStatus
import com.asyraf.hadirku.engine.budget.Budget
import com.asyraf.hadirku.engine.budget.BudgetEngine
import com.asyraf.hadirku.engine.budget.CarryOver
import com.asyraf.hadirku.engine.budget.SuggestionKind
import com.asyraf.hadirku.engine.cashflow.CashFlowEngine
import com.asyraf.hadirku.engine.cashflow.ScheduledKind
import com.asyraf.hadirku.engine.core.Dates
import com.asyraf.hadirku.engine.core.DueDayPolicy
import com.asyraf.hadirku.engine.core.Money
import com.asyraf.hadirku.engine.debt.DebtEngine
import com.asyraf.hadirku.engine.debt.EarlySettlementPolicy
import com.asyraf.hadirku.engine.debt.RateMethod
import com.asyraf.hadirku.engine.ledger.LedgerOps
import com.asyraf.hadirku.engine.ledger.PgLedgerAdapter
import com.asyraf.hadirku.engine.savings.Feasibility
import com.asyraf.hadirku.engine.savings.GoalMove
import com.asyraf.hadirku.engine.savings.GoalMoveIssue
import com.asyraf.hadirku.engine.savings.SavingsEngine
import com.asyraf.hadirku.engine.savings.SavingsGoal
import com.asyraf.hadirku.pg.Commitment
import com.asyraf.hadirku.pg.Debt
import com.asyraf.hadirku.pg.Epp
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.PgSample
import com.asyraf.hadirku.pg.PgState
import com.asyraf.hadirku.pg.Pocket
import com.asyraf.hadirku.pg.Tx
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.math.BigDecimal
import java.time.LocalDate
import java.time.YearMonth

class BillEngineTest {
    /** Spec scenario 8: bill due on the 31st in shorter months follows an explicit policy. */
    @Test fun dueOn31stHandlesShortMonths() {
        assertEquals(LocalDate.of(2027, 2, 28), Dates.dueDate(YearMonth.of(2027, 2), 31, DueDayPolicy.CLAMP_TO_MONTH_END))
        assertEquals(LocalDate.of(2028, 2, 29), Dates.dueDate(YearMonth.of(2028, 2), 31, DueDayPolicy.CLAMP_TO_MONTH_END))
        assertEquals(LocalDate.of(2027, 3, 1), Dates.dueDate(YearMonth.of(2027, 2), 31, DueDayPolicy.ROLL_TO_NEXT_MONTH))
        assertEquals(LocalDate.of(2026, 4, 30), Dates.dueDate(YearMonth.of(2026, 4), 31, DueDayPolicy.CLAMP_TO_MONTH_END))
        // matches the existing app's own clamping for commitment tempo
        assertEquals("2027-02-28", PG.tempoDate(Commitment("c", "Sewa", 500.0, tempo = 31), "2027-02-10"))
    }

    private fun state(vararg tx: Tx) = PgState(
        pockets = listOf(Pocket("p1", "Bank")),
        commitments = listOf(Commitment("c1", "Sewa rumah", 800.0, tempo = 31, poket = "p1"), Commitment("c2", "Internet", 129.0, tempo = 10, poket = "p1")),
        transactions = listOf(Tx("t0", "2026-11-01", "baki-awal", "p1", jumlah = 3000.0)) + tx,
    )

    @Test fun statusFromLedgerMatchesExistingAppAndIgnoresReversedPayments() {
        val s = state(
            Tx("a", "2026-11-03", "keluar", "p1", jumlah = 300.0, komitmenId = "c1"),
            Tx("b", "2026-11-05", "keluar", "p1", jumlah = 129.0, komitmenId = "c2"),
        )
        var book = PgLedgerAdapter.build(s, D).book
        val occ = BillEngine.occurrences(s, book, D).associateBy { it.bill.id }
        assertEquals(BillStatus.PARTIAL, occ.getValue("c1").status)
        assertEquals(rm("500.00"), occ.getValue("c1").remaining)
        assertEquals(LocalDate.of(2026, 11, 30), occ.getValue("c1").dueDate)
        assertEquals(BillStatus.PAID, occ.getValue("c2").status)
        // parity with PG.commitmentStatus
        PG.commitmentStatus(s, D.toString()).forEach { assertEquals(Money.fromDouble(it.baki), occ.getValue(it.id).remaining) }
        // reversing the internet payment makes it unpaid again
        book = LedgerOps.reverse(book, "t:b", "rv", D, T0).book
        assertEquals(BillStatus.UNPAID, BillEngine.occurrences(s, book, D).first { it.bill.id == "c2" }.status)
    }

    @Test fun remindersFireThreeAndOneDayBeforeWithStableKeys() {
        val s = state()
        val book = PgLedgerAdapter.build(s, D).book
        val r = BillEngine.remindersFor(s, book, LocalDate.of(2026, 11, 27))
        assertEquals(listOf("bill:c1:2026-11-30:3"), r.map { it.dedupKey })
        assertTrue(BillEngine.remindersFor(s, book, LocalDate.of(2026, 11, 28)).isEmpty())
        assertEquals(1, BillEngine.remindersFor(s, book, LocalDate.of(2026, 11, 29)).size)
    }

    @Test fun duplicateDetection() {
        val s = state(
            Tx("x1", "2026-11-04", "keluar", "p1", jumlah = 129.0, komitmenId = "c2"),
            Tx("x2", "2026-11-05", "keluar", "p1", jumlah = 129.0, komitmenId = "c2"),
        ).let { it.copy(commitments = it.commitments + Commitment("c3", "SEWA RUMAH", 800.0, tempo = 1, poket = "p1")) }
        val book = PgLedgerAdapter.build(s, D).book
        assertEquals(listOf("same_name"), BillEngine.duplicateBills(s).map { it.reason })
        assertEquals(listOf("t:x1", "t:x2"), BillEngine.duplicatePayments(s, book, D).single().entryIds)
    }
}

class DebtEngineTest {
    @Test fun flatScheduleMatchesExistingEppArithmetic() {
        for (plan in listOf(
            Epp("a", pokok = 1999.0, tempoh = 12, kadar = 0.0, mula = "2026-01-31"),
            Epp("b", pokok = 3500.0, tempoh = 24, kadar = 5.5, mula = "2026-03-15"),
            Epp("c", pokok = 1000.0, tempoh = 7, kadar = 0.0, ansuran = 150.0, mula = "2026-06-01"),
        )) {
            val p = DebtEngine.eppProfile("k", plan, LocalDate.of(2026, 11, 17), null)
            val info = PG.eppInfo(plan, "2026-11-17")
            assertEquals(Money.fromDouble(info.jumlahBayar), Money.sum(p.schedule.map { it.total }))
            p.schedule.forEachIndexed { k, i ->
                assertEquals(Money.fromDouble(info.amountAt(k)), i.total)
                assertEquals(Money.fromDouble(info.pokokAt(k)), i.principal)
                assertEquals(info.dates[k], i.dueDate.toString())
            }
            assertEquals(Money.fromDouble(info.pokokBaki), p.outstandingPrincipal)
            assertEquals(info.dibil, p.billed)
        }
    }

    @Test fun reducingScheduleClearsPrincipalExactly() {
        val sch = DebtEngine.reducingSchedule(rm("10000.00"), BigDecimal("6.5"), 36, LocalDate.of(2026, 12, 1))
        assertEquals(rm("10000.00"), Money.sum(sch.map { it.principal }))
        assertEquals(306L * 100 + 49, sch.first().total.sen)   // standard annuity ≈ RM306.49
        assertTrue(sch.all { it.interest != null && !it.interest!!.isNegative })
    }

    /** Spec scenario 4 (engine side): mid-term import keeps outstanding, does not invent history. */
    @Test fun midTermImportUsesOnlyRemainingSchedule() {
        val sch = DebtEngine.importMidTerm(rm("1750.00"), 7, LocalDate.of(2026, 12, 5), RateMethod.FLAT, installment = rm("250.00"))
        assertEquals(7, sch.size)
        assertEquals(rm("1750.00"), Money.sum(sch.map { it.total }))
        assertNull(sch.first().interest)                     // split unknown → not fabricated
        val red = DebtEngine.importMidTerm(rm("6000.00"), 10, LocalDate.of(2026, 12, 5), RateMethod.REDUCING, BigDecimal("8"))
        assertEquals(rm("6000.00"), Money.sum(red.map { it.principal }))
    }

    @Test fun partialPaymentAllocationAndEarlySettlement() {
        val a = DebtEngine.allocate(rm("60.00"), dueFees = rm("10.00"), dueInterest = rm("30.00"), duePrincipal = rm("100.00"))
        assertEquals(listOf(rm("10.00"), rm("30.00"), rm("20.00"), Money.ZERO), listOf(a.toFees, a.toInterest, a.toPrincipal, a.unapplied))
        val sch = DebtEngine.flatSchedule(rm("1200.00"), BigDecimal("10"), 12, LocalDate.of(2026, 1, 1)) // interest 120
        val asOf = LocalDate.of(2026, 6, 15)                                                               // 6 billed, 6 left
        assertEquals(rm("600.00"), DebtEngine.earlySettlement(sch, asOf, EarlySettlementPolicy.REMAINING_PRINCIPAL))
        // Rule of 78: unearned = 120 × (6·7)/(12·13) = 32.31 → 660 − 32.31
        assertEquals(rm("627.69"), DebtEngine.earlySettlement(sch, asOf, EarlySettlementPolicy.RULE_OF_78))
    }

    @Test fun profilesFromSampleDataAgreeWithLedger() {
        val s = PgSample.sampleState(D.toString())
        val book = PgLedgerAdapter.build(s, D).book
        val prof = DebtEngine.profiles(s, book, D)
        assertEquals(s.debts.size, prof.size)
        prof.forEach { p ->
            val d = s.debts.first { it.id == p.debtId }
            assertEquals(Money.fromDouble(PG.debtBalance(s, d, null, D.toString())), p.outstanding)
        }
        assertTrue(DebtEngine.totalOwed(book).isPositive)
    }
}

class CashFlowTest {
    @Test fun pendingPaymentIsNotDoubleCountedAndTransfersAreNeutral() {
        val s = PgState(
            pockets = listOf(Pocket("p1", "Bank"), Pocket("p2", "Tunai", dompet = true, tunai = true)),
            commitments = listOf(Commitment("c1", "Sewa", 800.0, tempo = 25, poket = "p1")),
            debts = listOf(Debt("k1", "Kad", jenis = "kad", poket = "p1", minPeratus = 5.0, minLantai = 50.0)),
            transactions = listOf(
                Tx("o", "2026-11-01", "baki-awal", "p1", jumlah = 2000.0),
                Tx("tr", "2026-11-10", "pindah", "p1", ke = "p2", jumlah = 100.0),
                Tx("f", "2026-11-12", "keluar", "p1", jumlah = 40.0, kategori = "makan"),
                Tx("rent", "2026-11-24", "keluar", "p1", jumlah = 800.0, komitmenId = "c1"), // future-dated (pending)
            ),
        )
        val book = PgLedgerAdapter.build(s, D).book
        val r = CashFlowEngine.report(s, book, D, windowEnd = LocalDate.of(2026, 11, 30))
        assertEquals(rm("1960.00"), r.liquid)
        assertEquals(rm("40.00"), r.actual.spending)
        assertEquals(Money.ZERO, r.actual.income)                // transfer is not income
        assertEquals(rm("800.00"), r.pending.spending)
        assertTrue(r.scheduled.none { it.kind == ScheduledKind.BILL })   // rent already covered by the pending entry
        assertEquals(rm("1160.00"), r.availableToSpend)
    }

    @Test fun earmarkReducesAvailableAndCardPurchaseIsNotCashOut() {
        val s = PgState(
            pockets = listOf(Pocket("p1", "Bank")),
            debts = listOf(Debt("k1", "Kad", jenis = "kad", poket = "p1", minPeratus = 5.0, minLantai = 50.0)),
            transactions = listOf(
                Tx("o", "2026-11-01", "baki-awal", "p1", jumlah = 1000.0),
                Tx("c", "2026-11-05", "kad", "p1", jumlah = 300.0, kadId = "k1", kategori = "diri"),
            ),
        )
        val book = PgLedgerAdapter.build(s, D).book
        val r = CashFlowEngine.report(s, book, D, windowEnd = LocalDate.of(2026, 11, 30), earmarked = rm("200.00"))
        assertEquals(Money.ZERO, r.actual.spending)              // charged to the card, cash not spent yet
        val debt = r.scheduled.single { it.kind == ScheduledKind.DEBT }
        assertTrue(debt.amount.isPositive)
        assertEquals(rm("1000.00") - debt.amount - rm("200.00"), r.availableToSpend)
    }
}

class SavingsTest {
    private val g = SavingsGoal("g1", "Kecemasan", rm("3000.00"), LocalDate.of(2027, 5, 1), "a", LocalDate.of(2026, 1, 1))

    @Test fun earmarksNeverExceedRealBalance() {
        val book = book(bank("a"), cash("c")).must(opening("o", "a", "500.00"))
        val moves = listOf(GoalMove("m1", "g1", D.minusDays(3), rm("800.00")))   // more than the account holds
        val p = SavingsEngine.progress(listOf(g), moves, book, D, rm("1000.00")).single()
        assertEquals(rm("500.00"), p.allocated)
        assertTrue(p.cappedByBalance)
        assertEquals(rm("2500.00"), p.remaining)
        assertEquals(1666, p.progressBp)
        assertEquals(6L, p.monthsLeft)
        assertEquals(rm("416.67"), p.requiredMonthly)
        assertEquals(Feasibility.FEASIBLE, p.feasibility)
    }

    @Test fun movesAreValidated() {
        val book = book(bank("a")).must(opening("o", "a", "500.00"))
        val moves = listOf(GoalMove("m1", "g1", D.minusDays(3), rm("400.00")))
        assertEquals(listOf(GoalMoveIssue.NOT_ENOUGH_FREE_BALANCE), SavingsEngine.validateMove(listOf(g), moves, book, GoalMove("m2", "g1", D, rm("150.00"))))
        assertEquals(emptyList<GoalMoveIssue>(), SavingsEngine.validateMove(listOf(g), moves, book, GoalMove("m2", "g1", D, rm("100.00"))))
        assertEquals(listOf(GoalMoveIssue.WITHDRAW_MORE_THAN_ALLOCATED), SavingsEngine.validateMove(listOf(g), moves, book, GoalMove("m3", "g1", D, rm("-401.00"))))
    }

    @Test fun savingsPocketsBecomeReadOnlyGoals() {
        val s = PgState(pockets = listOf(Pocket("s1", "Tabung kecemasan", sasaran = 5000.0), Pocket("p", "Belanja", sasaran = 300.0)),
            transactions = listOf(Tx("o", "2026-10-01", "baki-awal", "s1", jumlah = 1200.0)))
        val book = PgLedgerAdapter.build(s, D).book
        val goals = SavingsEngine.goalsFromPockets(s, D)
        assertEquals(listOf("pocket:s1"), goals.map { it.id })
        assertEquals(rm("1200.00"), SavingsEngine.progress(goals, emptyList(), book, D, null).single().allocated)
    }
}

class BudgetTest {
    private fun spendBook(): com.asyraf.hadirku.engine.ledger.LedgerBook {
        var b = book(bank("a")).must(opening("o", "a", "10000.00", LocalDate.of(2026, 1, 1)))
        var n = 0
        // makan: Aug 400, Sep 450, Oct 500; dapur: 300 each; hiburan: 20 each
        listOf(8 to "400.00", 9 to "450.00", 10 to "500.00").forEach { (m, a) ->
            b = b.must(expense("m${n++}", "a", a, "makan", LocalDate.of(2026, m, 10)))
            b = b.must(expense("d${n++}", "a", "300.00", "dapur", LocalDate.of(2026, m, 12)))
            b = b.must(expense("h${n++}", "a", "20.00", "hiburan", LocalDate.of(2026, m, 15)))
        }
        b = b.must(expense("nov", "a", "120.00", "makan", LocalDate.of(2026, 11, 3)))
        return b
    }

    @Test fun plannedVersusActualWithCarryOver() {
        val book = spendBook()
        val b = Budget("b1", "makan", rm("450.00"), YearMonth.of(2026, 8), CarryOver.BOTH)
        // carry: Aug +50, Sep 0, Oct −50 → Nov planned 450 + 0 = 450
        val l = BudgetEngine.line(book, b, YearMonth.of(2026, 11))
        assertEquals(rm("0.00"), l.carryIn)
        assertEquals(rm("120.00"), l.actual)
        val under = BudgetEngine.line(book, b.copy(carryOver = CarryOver.UNDERSPEND_ONLY), YearMonth.of(2026, 11))
        assertEquals(rm("0.00"), under.carryIn)              // Aug +50 → Sep(500 plan) +50 → Oct(500 plan) +0
        val oct = BudgetEngine.line(book, b.copy(carryOver = CarryOver.UNDERSPEND_ONLY), YearMonth.of(2026, 10))
        assertEquals(rm("50.00"), oct.carryIn)
        assertEquals(rm("500.00"), oct.planned)
    }

    @Test fun suggestionsDoNotMutateAndProtectEssentials() {
        val book = spendBook()
        val budgets = listOf(
            Budget("b1", "makan", rm("400.00"), YearMonth.of(2026, 1)),
            Budget("b2", "dapur", rm("600.00"), YearMonth.of(2026, 1), essential = true),
            Budget("b3", "hiburan", rm("200.00"), YearMonth.of(2026, 1)),
        )
        val copy = budgets.toList()
        val sug = BudgetEngine.suggestions(book, budgets, YearMonth.of(2026, 11)).associateBy { it.category }
        assertEquals(copy, budgets)
        assertEquals(SuggestionKind.RAISE, sug.getValue("makan").kind)
        assertEquals(rm("450.00"), sug.getValue("makan").suggested)
        assertEquals(SuggestionKind.KEEP, sug.getValue("dapur").kind)       // essential: never suggested to lower
        assertTrue(sug.getValue("dapur").protectedEssential)
        assertEquals(SuggestionKind.LOWER, sug.getValue("hiburan").kind)
        assertEquals(rm("20.00"), sug.getValue("hiburan").suggested)
        assertFalse(sug.containsKey("lain"))
    }
}
