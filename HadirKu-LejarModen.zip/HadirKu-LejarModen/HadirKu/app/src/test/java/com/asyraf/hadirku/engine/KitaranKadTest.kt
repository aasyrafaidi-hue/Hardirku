package com.asyraf.hadirku.engine

import com.asyraf.hadirku.pg.Debt
import com.asyraf.hadirku.pg.DebtLog
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.PgState
import com.asyraf.hadirku.pg.Pocket
import com.asyraf.hadirku.pg.Tx
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Kad kredit ikut kitaran penyata bank (cth RHB: penyata 24hb, akhir bayar 14hb),
 * bukan 1hb hingga hujung bulan.
 */
class KitaranKadTest {

    @Test fun kitaranPenyataDariTarikhPenyataHinggaSebelumPenyataBerikutnya() {
        val k = PG.kitaranPenyata("2026-11-26", 24)
        assertEquals("2026-11-24", k.start)
        assertEquals("2026-12-24", k.endExcl)
        assertEquals("2026-12-23", k.end)
        assertEquals("2026-11-24", k.key)
        // sebelum tarikh penyata bulan ini → kitaran penyata bulan lepas
        val a = PG.kitaranPenyata("2026-11-20", 24)
        assertEquals("2026-10-24", a.start)
        assertEquals("2026-11-23", a.end)
        // hari penyata sendiri = mula kitaran baru
        assertEquals("2026-12-24", PG.kitaranPenyata("2026-12-24", 24).start)
        // lintas tahun
        val y = PG.kitaranPenyata("2027-01-05", 24)
        assertEquals("2026-12-24", y.start)
        assertEquals("2027-01-23", y.end)
    }

    @Test fun hariPenyataLewatDalamBulanPendek() {
        val k = PG.kitaranPenyata("2026-03-15", 31)
        assertEquals("2026-02-28", k.start)
        assertEquals("2026-03-31", k.endExcl)
        assertEquals("2026-03-31", PG.kitaranPenyata("2026-03-31", 31).start)
    }

    @Test fun tarikhAkhirBayarSelepasTarikhPenyata() {
        assertEquals("2026-12-14", PG.tarikhAkhirBayar("2026-11-24", 14))   // bulan berikutnya
        assertEquals("2026-11-25", PG.tarikhAkhirBayar("2026-11-05", 25))   // bulan sama
        assertEquals("2026-02-28", PG.tarikhAkhirBayar("2026-01-31", 30))   // Feb pendek
        assertNull(PG.tarikhAkhirBayar("2026-11-24", 0))
    }

    private fun kad(penyataHari: Int = 24, bayarHari: Int = 14) = Debt(
        "rhb", "Kad Kredit RHB", jenis = "kad", kadar = 18.0, poket = "p1", minPeratus = 5.0, minLantai = 50.0,
        log = listOf(DebtLog("l1", "2026-11-24", "penyata", 5346.25, "Penyata Nov")),
        minRm = 510.89, minBaki = 5346.25, minTarikh = "2026-11-26",
        penyataHari = penyataHari, bayarHari = bayarHari,
    )

    private fun state(d: Debt) = PgState(
        pockets = listOf(Pocket("p1", "Bank")),
        debts = listOf(d),
        transactions = listOf(
            Tx("t0", "2026-11-01", "baki-awal", "p1", jumlah = 5000.0),
            Tx("lama", "2026-11-10", "keluar", "p1", jumlah = 300.0, hutangId = "rhb"),   // untuk penyata Okt
            Tx("b1", "2026-11-26", "keluar", "p1", jumlah = 169.0, hutangId = "rhb"),     // untuk penyata 24 Nov
            Tx("k1", "2026-11-28", "kad", "p1", jumlah = 107.37, kadId = "rhb"),           // belanja selepas penyata
        ),
    )

    @Test fun bayaranSebelumTarikhAkhirKekalSelepas1hb() {
        val st = PG.debtStatus(state(kad()), "2026-12-05").single()
        assertTrue(st.kitaranBank)
        assertEquals("2026-11-24", st.perMula)
        assertEquals("2026-12-23", st.perAkhir)
        assertEquals("2026-12-14", st.tarikhAkhir)
        assertEquals(169.0, st.dibayar, 0.001)          // bayaran 26 Nov masih dikira pada 5 Dis
        assertEquals(510.89, st.min, 0.001)             // minimum ikut penyata kekal sepanjang kitaran
        assertEquals(341.89, st.minTinggal, 0.001)
        assertEquals(107.37, st.belanjaKad, 0.001)      // belanja kad sejak penyata
    }

    @Test fun caraLamaIkutBulanReset1hb() {
        val st = PG.debtStatus(state(kad(penyataHari = 0, bayarHari = 0)), "2026-12-05").single()
        assertFalse(st.kitaranBank)
        assertNull(st.tarikhAkhir)
        assertEquals(0.0, st.dibayar, 0.001)            // November dah tamat → reset
        assertEquals("2026-12-01", st.perMula)
    }

    @Test fun penyataBaruMulaKitaranBaru() {
        val st = PG.debtStatus(state(kad()), "2026-12-24").single()
        assertEquals("2026-12-24", st.perMula)
        assertEquals("2027-01-14", st.tarikhAkhir)
        assertEquals(0.0, st.dibayar, 0.001)
        assertEquals("jumlah", st.minInfo?.cara)        // minimum penyata Nov tak lagi dipakai tepat → anggaran peratus
        // dalam kitaran Nov, minimum ikut penyata dipakai tepat
        assertEquals("penyata", PG.debtStatus(state(kad()), "2026-12-23").single().minInfo?.cara)
    }
}
