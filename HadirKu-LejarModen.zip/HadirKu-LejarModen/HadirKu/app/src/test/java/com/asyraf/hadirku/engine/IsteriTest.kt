package com.asyraf.hadirku.engine

import com.asyraf.hadirku.engine.forecast.ForecastEngine
import com.asyraf.hadirku.engine.forecast.EventKind
import com.asyraf.hadirku.engine.ledger.PgLedgerAdapter
import com.asyraf.hadirku.pg.Isteri
import com.asyraf.hadirku.pg.OtEntry
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.PgCfo
import com.asyraf.hadirku.pg.PgSample
import com.asyraf.hadirku.pg.Tx
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

/** Versi isteri (Duitku Isteri): tiada gaji / OT; data kewangan lain tidak berubah. */
class IsteriTest {
    private val today = "2026-11-28"

    @Test fun dataContohTanpaGajiDanOt() {
        val s = PgSample.sampleState(today)
        assertTrue(s.ot.isNotEmpty())
        val i = Isteri.sesuaikan(s)
        assertEquals(0.0, i.settings.gaji.basic, 0.0)
        assertEquals(0.0, i.settings.gaji.advance, 0.0)
        assertFalse(i.settings.otPendapatan)
        assertTrue(i.ot.isEmpty())
        assertTrue(i.transactions.none { it.jenis == "masuk" && it.perkara.startsWith("Gaji") })
        assertTrue(i.transactions.any { it.perkara == Isteri.NAFKAH })
        // baki semua poket, komitmen & hutang tidak berubah
        assertEquals(PG.balances(s), PG.balances(i))
        assertEquals(s.commitments, i.commitments)
        assertEquals(s.debts, i.debts)
        // tiada gaji dijangka dalam ramalan
        val d = LocalDate.parse(today)
        val f = ForecastEngine.project(i, PgLedgerAdapter.build(i, d).book, d)
        assertTrue(f.events.none { it.kind == EventKind.SALARY || it.kind == EventKind.ADVANCE })
    }

    @Test fun dataSebenarIsteriTidakDiubahNamanya() {
        val s = PgSample.sampleState(today).copy(contoh = false)
        val i = Isteri.sesuaikan(s)
        assertEquals(s.transactions, i.transactions)
        // kali kedua: tiada perubahan, objek sama (tiada tulis semula fail)
        assertSame(i, Isteri.sesuaikan(i))
    }

    @Test fun failCfoRumahTanggaTanpaOtDanGaji() {
        val base = Isteri.sesuaikan(PgSample.sampleState(today))
        val s = base.copy(ot = mapOf("2026-11-20" to OtEntry("biasa", 12.0)),
            transactions = base.transactions + Tx("n1", "2026-11-25", "masuk", PG.BELUM_AGIH, jumlah = 800.0, perkara = Isteri.NAFKAH))
        val md = PgCfo.cfoMarkdown(s, today, PgCfo.Opts(transaksi = false, rumahTangga = true))
        assertTrue(md.contains("suri rumah"))
        assertTrue(md.contains("## 5. Duit masuk"))
        assertTrue(md.contains("Purata duit masuk sebulan"))
        assertFalse("tiada OT: " + Regex("\\bOT\\b").find(md)?.let { md.substring(maxOf(0, it.range.first - 60), minOf(md.length, it.range.last + 60)) },
            Regex("\\bOT\\b").containsMatchIn(md))
        assertFalse(md.contains("pekerja kilang"))
        assertFalse(md.contains("Gaji asas"))
        // versi suami tidak berubah
        val suami = PgCfo.cfoMarkdown(PgSample.sampleState(today), today, PgCfo.Opts(transaksi = false))
        assertTrue(suami.contains("## 5. Gaji & OT"))
        assertTrue(suami.contains("pekerja kilang"))
    }
}
