package com.asyraf.hadirku.engine

import com.asyraf.hadirku.pg.Debt
import com.asyraf.hadirku.pg.DebtLog
import com.asyraf.hadirku.pg.Epp
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.PgState
import com.asyraf.hadirku.pg.Pocket
import com.asyraf.hadirku.pg.Tx
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * SPayLater (Shopee): belian 1 bulan masuk bil pada tarikh bil berikutnya (cth bil 1hb, akhir bayar 10hb),
 * bil mesti dibayar penuh, ansuran rata 1.5% sebulan atas harga asal, caj lewat RM10 atau pokok bil jika kurang.
 */
class SPayLaterTest {
    private fun spl(bilHari: Int = 1, bayarHari: Int = 10, log: List<DebtLog> = emptyList(), epp: List<Epp> = emptyList()) = Debt(
        "spl", "SPayLater", jenis = "kad", kadar = 0.0, hadKredit = 1500.0, poket = "p2",
        penyataHari = bilHari, bayarHari = bayarHari, penyedia = PG.SPL, log = log, epp = epp,
    )
    private fun beli(id: String, tarikh: String, rm: Double) = Tx(id, tarikh, "kad", poket = "p1", ke = "p2", jumlah = rm, perkara = "ShopeeFood", kadId = "spl", kategori = "makan", dibuat = id.hashCode().toLong())
    private fun bayar(id: String, tarikh: String, rm: Double) = Tx(id, tarikh, "keluar", poket = "p2", jumlah = rm, perkara = "Bayar SPayLater", hutangId = "spl", dibuat = id.hashCode().toLong())
    private fun state(d: Debt, vararg t: Tx) = PgState(pockets = listOf(Pocket("p1", "Makan"), Pocket("p2", "Bayar bil")), debts = listOf(d), transactions = t.toList())
    private fun stat(s: PgState, today: String) = PG.debtStatus(s, today).single()

    @Test fun belianBulanIniMasukBilBulanDepan() {
        val s = state(spl(), beli("a", "2026-11-15", 20.0), beli("b", "2026-11-30", 12.5), beli("c", "2026-12-03", 15.0))
        val st = stat(s, "2026-12-05")
        assertEquals("2026-12-01", st.perMula)
        assertEquals("2026-12-10", st.tarikhAkhir)
        assertEquals(32.5, st.sasaran, 1e-9)         // bil 1 Dis = belian November sahaja
        assertEquals(32.5, st.min, 1e-9)             // tiada bayaran minimum: bil penuh
        assertEquals(15.0, st.belanjaKad, 1e-9)      // belian Disember → bil 1 Jan
        assertEquals(0.0, st.tambahan, 1e-9)         // tidak ditambah ke apa yang perlu dibayar sekarang
        assertEquals(47.5, st.baki, 1e-9)
        assertEquals("belum", st.status)
        val i = PG.splInfo(s, s.debts[0], "2026-12-05")!!
        assertEquals(15.0, i.bilSeterusnya, 1e-9)
        assertEquals("2027-01-01", i.tarikhBilSeterusnya)
        assertEquals(1452.5, i.bakiHad!!, 1e-9)
        assertFalse(i.lewat)
    }

    @Test fun bayarPenuhSudahDanBelianHariBilMasukBilSeterusnya() {
        val s = state(spl(), beli("a", "2026-11-15", 20.0), beli("b", "2026-12-01", 8.0), bayar("p", "2026-12-06", 20.0))
        val st = stat(s, "2026-12-06")
        assertEquals(20.0, st.sasaran, 1e-9)
        assertEquals("sudah", st.status)
        assertEquals(0.0, st.minTinggal, 1e-9)
        assertEquals(8.0, st.baki, 1e-9)
        // bayar separuh → separuh
        val s2 = state(spl(), beli("a", "2026-11-15", 20.0), bayar("p", "2026-12-06", 5.0))
        assertEquals("separuh", stat(s2, "2026-12-06").status)
        assertEquals(15.0, stat(s2, "2026-12-06").minTinggal, 1e-9)
    }

    @Test fun bayarAwalSebelumTarikhBilKurangkanBil() {
        val s = state(spl(), beli("a", "2026-11-15", 20.0), bayar("p", "2026-11-20", 20.0))
        val st = stat(s, "2026-12-03")
        assertEquals(0.0, st.sasaran, 1e-9)
        assertEquals("langsai", st.status)
    }

    @Test fun lewatBayarDanCajLewat() {
        val s = state(spl(), beli("a", "2026-11-15", 20.0))
        val i = PG.splInfo(s, s.debts[0], "2026-12-11")!!
        assertTrue(i.lewat)
        assertEquals(10.0, i.cajLewat, 1e-9)
        assertFalse(i.cajDicatat)
        assertEquals(9.0, PG.splCajLewat(9.0), 1e-9)   // pokok bil kurang RM10 → caj = pokok bil
        assertEquals(10.0, PG.splCajLewat(250.0), 1e-9)
        // caj dicatat dalam kitaran ini → masuk bil semasa
        val s2 = state(spl(log = listOf(DebtLog("c", "2026-12-11", "caj", 10.0, "Caj lewat"))), beli("a", "2026-11-15", 20.0))
        val st = stat(s2, "2026-12-11")
        assertEquals(30.0, st.sasaran, 1e-9)
        assertTrue(PG.splInfo(s2, s2.debts[0], "2026-12-11")!!.cajDicatat)
        assertFalse(PG.splInfo(s2, s2.debts[0], "2026-12-09")!!.lewat)
    }

    @Test fun kitaran21hbBayar1hb() {
        val s = state(spl(21, 1), beli("a", "2026-11-25", 30.0), beli("b", "2026-12-22", 5.0))
        val st = stat(s, "2026-12-23")
        assertEquals("2026-12-21", st.perMula)
        assertEquals("2027-01-01", st.tarikhAkhir)
        assertEquals(30.0, st.sasaran, 1e-9)
        assertEquals("2026-12-21", PG.splTarikhBil(s.debts[0], "2026-11-25"))
        assertEquals("2027-01-21", PG.splTarikhBil(s.debts[0], "2026-12-21"))
        assertEquals("2026-12-01", PG.splTarikhBil(spl(), "2026-11-30"))
        assertEquals("2027-01-01", PG.splTarikhBil(spl(), "2026-12-01"))
    }

    @Test fun ansuranRataMasukBilSetiapBulan() {
        // RM90, 3 bulan, 1.5% sebulan: caj RM4.05, jumlah RM94.05, ansuran RM31.35 — bil pertama 1 Dis
        val p = PG.splPelan(90.0, 3, PG.SPL_KADAR_BULAN)
        assertEquals(4.05, p.caj, 1e-9)
        assertEquals(94.05, p.jumlah, 1e-9)
        assertEquals(31.35, p.ansuran, 1e-9)
        val e = Epp("e1", "ShopeeFood 3 bln", pokok = 90.0, tempoh = 3, kadar = PG.SPL_KADAR_BULAN * 12, mula = "2026-12-01")
        val s = state(spl(epp = listOf(e)), beli("a", "2026-11-15", 20.0))
        val st = stat(s, "2026-12-05")
        assertEquals(51.35, st.sasaran, 1e-9)        // belian Nov RM20 + ansuran 1/3
        assertEquals(31.35, st.eppDue, 1e-9)
        assertEquals(60.0, st.eppPokok, 1e-9)        // pokok belum dibil (2 ansuran)
        assertEquals(82.7, stat(s, "2027-01-05").sasaran, 1e-9) // bil Jan: tunggakan Dis (20 + 31.35) dibawa + ansuran 2
        assertEquals(31.35, PG.splInfo(s, s.debts[0], "2026-12-05")!!.bilSeterusnya, 1e-9)
    }

    @Test fun eprSamaDenganJadualShopee() {
        assertEquals(26.80, PG.splEpr(1.5, 3), 1e-9)
        assertEquals(30.23, PG.splEpr(1.5, 6), 1e-9)
        assertEquals(31.72, PG.splEpr(1.5, 12), 1e-9)
        assertEquals(31.76, PG.splEpr(1.5, 18), 1e-9)
        assertEquals(31.46, PG.splEpr(1.5, 24), 1e-9)
        assertEquals(0.0, PG.splEpr(0.0, 3), 1e-9)
        assertEquals(0.0, PG.splEpr(1.5, 1), 1e-9)
        assertEquals(PG.SplPelan(0.0, 100.0, 33.33, 33.34, 0.0), PG.splPelan(100.0, 3, 0.0))
    }

    @Test fun minimumSimulasiBakiPenuhDanKadBiasaTidakBerubah() {
        val d = spl()
        assertEquals(120.0, PG.debtMin(d, 120.0, 0.0), 1e-9)
        assertFalse(PG.isSpl(d.copy(penyedia = "")))
        assertFalse(PG.isSpl(d.copy(jenis = "bnpl")))
        assertNull(PG.splInfo(state(d.copy(penyedia = "")), d.copy(penyedia = ""), "2026-12-05"))
        // kad kredit biasa masih guna peratus minimum
        val kad = d.copy(penyedia = "", kadar = 18.0, minPeratus = 5.0, minLantai = 50.0)
        assertEquals(50.0, PG.debtMin(kad, 120.0, 0.0), 1e-9)
    }

    @Test fun pembetulanBilIkutPenyata() {
        // penyata sehari sebelum tarikh bil menetapkan bil; belian kitaran ini kekal untuk bil seterusnya
        val s = state(spl(log = listOf(DebtLog("pn", "2026-11-30", "penyata", 88.4, "Bil ikut app Shopee", dibuat = 9_999_999_999_999))),
            beli("a", "2026-11-15", 20.0), beli("c", "2026-12-03", 15.0))
        val st = stat(s, "2026-12-05")
        assertEquals(88.4, st.sasaran, 1e-9)
        assertEquals(103.4, st.baki, 1e-9)
    }
}
