# HadirKu tiada reflection sendiri. Peraturan untuk WorkManager, Play Services
# dan Compose sudah dibekalkan oleh perpustakaan masing-masing.
-keepattributes SourceFile,LineNumberTable

# Kekalkan nama kelas & fungsi asal (kecilkan & optimum masih jalan) supaya laporan
# "app tergantung / tertutup" dari Jaga.kt boleh dibaca terus, bukan nama kabur seperti w.e0.
-dontobfuscate
