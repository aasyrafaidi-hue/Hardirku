# Duitku Lejar Moden — nota perubahan & laporan ujian

Reka bentuk: `DUITKU_LEJAR_APPROVED_FULL.png` (hijau zamrud, kad putih, tekstur lejar halus, bayang lembut).
Semua UI 100% Kotlin + Jetpack Compose. Tiada WebView, tiada gambar skrin, tiada game engine.

## Ringkasan perubahan

**Navigasi (5 tab bawah):** Utama · Lejar · Bayaran · Laporan · Tetapan, dengan kapsul hijau pucat yang meluncur.
- App kini dibuka di **Utama** (dulu OT).
- **OT** dan **Senarai Barang** kekal sebagai skrin penuh: satu sentuhan dari Utama (kad OT, butang "Isi OT", "Senarai Barang") dan dari **Menu ☰**.
- Butang/gerak **kembali**: dari OT / Senarai Barang pulang ke tab asal; dari tab lain pulang ke Utama; carian Lejar ditutup dulu.
- Bar atas ikut skrin: Utama (☰ · Duitku · 🔔 peringatan), skrin lain (← tajuk). Lejar ada 🔍 carian dan butang +.
- **Menu ☰** (baharu): akses ke semua bahagian (OT, Senarai Barang, Komitmen, Hutang & EPP, Projek, Laporan, Ramalan, Kekayaan, Semak bank, Simpan salinan, Tetapan & kongsi isteri).
- **Loceng 🔔** (baharu): senarai bil/komitmen belum bayar paling hampir tempo + peringatan salinan. Titik merah hanya bila ada komitmen lewat / jatuh tempo dalam 3 hari.
- FAB tanpa animasi berulang (denyut tak berkesudahan dibuang). Di Projek, FAB "Transaksi" kini buka borang transaksi (dulu tersilap buka bayaran komitmen).

**Utama (dashboard)**
- Sapaan + "Ringkasan Kewangan Anda" (nama panggilan dari Tetapan jika ada).
- Kad hero hijau: **Baki Semasa** = `PG.total` (semua poket bank). Bila ada tunai / e-wallet, label kekal **"Baki dalam bank"** dan baris tunai, e-wallet dan "Semua duit" dipapar berasingan. Butang 👁 sorok/tunjuk nilai (disimpan dalam peranti; bila disorok, semua nilai RM di Utama turut disorok).
- Status semak bank (Sama / Beza / Belum semak) → buka Semak baki bank.
- Masuk / Keluar bulan ini (`PG.periodReport`); mod "OT dikira pendapatan" → Pendapatan / Perbelanjaan.
- **Aliran Tunai Bulanan**: carta bar 4 bulan daripada `PG.trendPeriods` (asas sama dengan Laporan). Pilih bulan melalui ⌄ atau sentuh bar.
- Pintasan: **OT** (kitaran 22hb–21hb, berasingan daripada bulan 1hb–akhir), **Hutang** (jumlah, "Termasuk EPP …"), **EPP**, **Bil Bulan Ini** (komitmen belum bayar).
- Akses pantas: Poket (skrol ke senarai poket), Isi OT, Senarai Barang, Projek, Ramalan.
- Semua fungsi Poket asal kekal: Belum Agih, Dompet tunai (ATM / Belanja / Kira duit), Ramalan ringkas, peringatan salinan, senarai poket + Susun + "+ Poket".

**Lejar Harian**
- Penapis yang dipetakan terus ke medan sebenar: Semua · Masuk (`jenis=masuk`) · Keluar (`keluar` + guna kad) · Hutang & kad (`hutangId` / `kad` / `tunai-kad`) · Komitmen (`komitmenId`) · Pindah. **Tiada penapis "EPP"** kerana transaksi tidak boleh dipetakan secara jujur kepada EPP (EPP ialah jadual pada kad).
- Pemilih bulan (dropdown), ringkasan Masuk/Keluar: tanpa penapis = definisi asal (`dailySummary` / `periodReport` mod akruan); dengan penapis/carian = jumlah transaksi yang ditapis (ditanda "Jumlah ikut penapis").
- Carian (perkara, catatan, poket, kategori, jumlah) dengan keadaan kosong & butang padam.
- Kumpulan ikut hari (kepala tarikh gaya halaman lejar → tekan untuk ringkasan hari). Baris: ikon kategori, tajuk, poket/memo, +/−RM berwarna. **Tiada lencana "Selesai" rekaan** — sebaliknya tag sebenar: Komitmen / Hutang / Kad / Pindah.
- Menu ⋮ setiap transaksi: Sunting/padam (borang asal), Butiran hari, Ulang transaksi.
- **Kalendar | Senarai** asal dikekalkan (suis ikon di kanan atas senarai).

**Komitmen & Bayaran**
- Segmen baharu **Ringkasan** (lalai untuk pengguna baharu) + Komitmen · Hutang · Projek asal (tidak dibuang).
- **Hutang**: baki hutang (tanpa EPP belum dibil, supaya tiada kiraan dua kali) + perlu bayar bulan ini. Kemajuan = **bayaran bulan ini** (dibayar ÷ perlu bayar). Tiada "% langsai" palsu kerana jumlah pokok asal tidak direkod.
- **EPP**: baki EPP belum dibil, ansuran bulan ini, kemajuan = ansuran **sudah dibil** ÷ jumlah bayaran pelan (`PG.eppInfo`). EPP kekal terikat pada kad kredit.
- **Bil Bulanan** = senarai **Komitmen** sedia ada (bukan modul baharu): tarikh akhir, "n hari lagi" / Esok / Hari ini / Lewat / ✔ Sudah ikut status sebenar.

**Konsistensi seluruh app:** token warna `Pal` diganti (hijau zamrud, light + dark), dan komponen kongsi (`Block`, `ListBlock`, `Seg`, `Btn`, `Pill`, `Bar`, `Notice`, `NavRow`, `Stats`, `SumStrip`, baris transaksi) kini kad bulat berbayang — jadi OT, Senarai Barang, Laporan, Ramalan, Kekayaan, Tetapan, helaian & borang semua ikut gaya yang sama. Ikon pelancar ditukar ke buku lejar hijau.

## Fail yang diubah
- `MainViewModel.kt` — 3 baris paparan sahaja: `Sheet.Menu`, `Sheet.Notis`; tab mula `poket`; segmen Bayaran lalai `ringkasan` (pilihan tersimpan pengguna lama kekal).
- `ui/PgTheme.kt` (token), `ui/Kit.kt` (komponen kad), `ui/Common.kt` (baris lejar), `ui/Ico.kt` (+35 ikon), `ui/App.kt` (navigasi, bar atas/bawah, FAB, logo)
- `ui/PoketScreen.kt` (Utama), `ui/TransaksiScreen.kt` (Lejar Harian), `ui/BayaranScreen.kt` (Ringkasan + gaya)
- `ui/PoketExtra.kt`, `ui/RamalanScreen.kt` (sokong sorok baki), `ui/TetapanScreen.kt`, `ui/Rumah.kt`, `ui/LaporanScreen.kt`, `ui/Charts.kt`, `ui/SheetTx.kt` (gaya / dispatch helaian baharu)
- **Baharu:** `ui/Lejar.kt` (keadaan paparan, ikon kategori, IconTile/IconBtn), `ui/MenuSheets.kt` (Menu & Peringatan)
- `assets/i18n/en.tsv` (+104 terjemahan; "+ Transaksi" tidak lagi memaksa "transaction" tunggal, jadi "4 transaksi" → "4 transactions")
- `res/values*/colors.xml`, `res/drawable/ic_launcher_*.xml`

**Tidak diubah:** `pg/`, `data/`, `logic/`, `kongsi/`, `system/`, `rumah/`, `ai/`, `net/`, `i18n/Bahasa.kt`, `build.gradle.kts`, `applicationId com.asyraf.hadirku`, format salinan JSON, Firebase.

## Ujian yang BENAR-BENAR dijalankan
Persekitaran pembangunan tiada Android SDK dan tiada akses rangkaian ke Google Maven, jadi **`assembleDebug` TIDAK dijalankan**.
1. **Semakan sintaks Kotlin (pengkompil Kotlin 2.0.21, versi sama dengan projek)** — 43 fail, 0 ralat sintaks.
2. **Semakan pengkompil tanpa pustaka Android** — dibanding dengan source asal: tiada nama projek baharu yang tidak dikenali; semua argumen bernama pada fungsi projek wujud.
3. **Ujian data sebenar** (logik `pg/` dikompil + data contoh `PgSample`, 4 tarikh: 16 Nov 2026, 31 Jan 2026, 22 Dis 2025, 1 Mac 2026) — semua LULUS:
   - carta aliran tunai = `periodReport` bulan semasa; baki bulan = masuk − keluar
   - baki hutang (tanpa EPP) + EPP = jumlah `debtSummary` (tiada kiraan dua kali)
   - kemajuan EPP & bayaran hutang dalam julat 0–100%
   - Bil Bulanan = senarai komitmen asal; dibayar + baki = jumlah
   - penapis Masuk/Keluar = `dailySummary.masuk/keluar`; carian berfungsi
   - 58 rentetan UI baharu diterjemah ke English tanpa sisa perkataan BM

## Senarai semak penerimaan (06_QA_Acceptance)
| Perkara | Status |
|---|---|
| Utama, Lejar, Bayaran ikut mockup (Compose sebenar) | DILAKSANA · paparan **NOT TESTED** (tiada emulator) |
| Tema cerah hijau-kertas, bayang lembut | DILAKSANA · paparan NOT TESTED |
| Semua skrin guna token yang sama | PASS (peringkat kod: komponen kongsi) |
| Tiada teks bertindih 320/360/393/430dp | NOT TESTED (ada susun atur sempit & teks wang mengecil sendiri) |
| Tulisan besar, mod gelap, inset | NOT TESTED (palet gelap & inset dilaksana) |
| Animasi ringan, sasaran sentuh | PASS kod (butang ikon 48dp, tiada animasi berulang) |
| Baki bank/tunai/e-wallet ikut definisi asal | PASS (ujian data) |
| Masuk/keluar & graf ikut tempoh & mod akruan | PASS (ujian data) |
| Lejar: senarai, kalendar, penapis, sunting, tambah, padam | Penapis PASS; lain guna borang asal — NOT TESTED pada peranti |
| OT kitaran 22–21hb, nilai gaji tak berubah | PASS (logik tak diubah) · runtime NOT TESTED |
| Hutang kad, EPP, minimum, status | PASS (formula tak diubah; tiada kiraan dua kali) |
| Bil/komitmen tidak dikira dua kali | PASS |
| Senarai barang & sync Firebase | Logik tak diubah · NOT TESTED |
| Projek & nafkah dikekalkan | PASS (kod) |
| Laporan, ramalan, kekayaan, carta | Logik tak diubah · NOT TESTED |
| BM & English | PASS (ujian terjemahan) |
| Backup eksport/import | Tak diubah · NOT TESTED |
| Kes tepi (kosong, negatif, tiada hutang) | Keadaan kosong dilaksana · NOT TESTED |
| Package ID tidak berubah | PASS |
| Tiada keystore / kata laluan | PASS |
| Signing release kekal serasi | PASS (`build.gradle.kts` tak diubah) |
| `assembleDebug` | **NOT TESTED** — tiada SDK di persekitaran ini |
| ZIP source lengkap + senarai fail | PASS |

## Cara uji (cadangan)
1. Buka folder `HadirKu` dalam Android Studio → Sync → **Run** pada emulator (bukan telefon utama dulu).
2. Tetapan → Data → **Muat data contoh** di emulator untuk lihat semua kad berisi.
3. Uji 320dp (cth Pixel kecil), mod gelap, saiz tulisan 20, English.
4. APK debug **tidak boleh** dipasang atas app sebenar (tandatangan lain, package sama). Jangan nyahpasang app sebenar untuk menguji — data akan hilang.
5. Untuk APK release melalui GitHub: letak semula `app/hadirku-release.jks` anda dalam zip (secara peribadi) dan guna secret `HADIRKU_STORE_PASSWORD` seperti biasa.
