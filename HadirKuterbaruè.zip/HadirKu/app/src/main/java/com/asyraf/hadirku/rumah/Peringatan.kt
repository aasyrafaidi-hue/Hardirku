package com.asyraf.hadirku.rumah

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.asyraf.hadirku.MainActivity
import com.asyraf.hadirku.R
import com.asyraf.hadirku.data.Repo
import com.asyraf.hadirku.kongsi.Kongsi
import com.asyraf.hadirku.pg.PG
import java.time.Duration
import java.time.LocalDateTime
import java.util.concurrent.TimeUnit

/** Peringatan bil rumah (dikongsi dengan isteri): 3 hari dan 1 hari sebelum jatuh tempo. */
object Peringatan {
    const val CH_BIL = "bil-rumah"
    const val EXTRA_BUKA = "buka"

    fun saluran(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(NotificationChannel(CH_BIL, "Bil rumah", NotificationManager.IMPORTANCE_DEFAULT).apply {
            description = "Bil yang dikongsi dengan isteri dan hampir jatuh tempo"
        })
    }

    private fun boleh(ctx: Context): Boolean =
        (Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) &&
            NotificationManagerCompat.from(ctx).areNotificationsEnabled()

    private fun tunjuk(ctx: Context, id: Int, tajuk: String, teks: String) {
        if (!boleh(ctx)) return
        val i = Intent(ctx, MainActivity::class.java).putExtra(EXTRA_BUKA, "bil")
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pi = PendingIntent.getActivity(ctx, id, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(ctx, CH_BIL)
            .setSmallIcon(R.drawable.ic_stat_hadir)
            .setContentTitle(tajuk)
            .setContentText(teks)
            .setStyle(NotificationCompat.BigTextStyle().bigText(teks))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        try { NotificationManagerCompat.from(ctx).notify(id, n) } catch (e: SecurityException) { }
    }

    /** Bil belum dibayar yang jatuh tempo 3 hari atau 1 hari lagi (sekali setiap bil, setiap tahap). */
    fun semakBil(ctx: Context, today: String) {
        if (!Repo.getBool("ingat.bil", true)) return
        val list = Kongsi.bilCermin()
        val ymNow = PG.ym(today)
        listOf(ymNow, PG.shiftYm(ymNow, 1)).forEach { ym ->
            list.forEach { b ->
                if (Belanja.dahBayar(b, ym)) return@forEach
                val due = Belanja.tarikhBil(b, ym)
                val n = PG.hariAntara(today, due)
                if (n != 3 && n != 1) return@forEach
                val key = "bil.notis.${b.id}.$due.$n"
                if (Repo.getBool(key, false)) return@forEach
                Repo.putBool(key, true)
                tunjuk(
                    ctx, 3000 + ((b.id + due).hashCode() and 0xfff),
                    "${b.nama} " + (if (n == 1) "esok" else "3 hari lagi"),
                    "Bil ${b.nama} " + PG.money(b.jumlah) + " jatuh tempo " + PG.fmtShort(due) + (if (n == 1) " (esok)." else " (3 hari lagi).") + " Tekan untuk tanda dah bayar.",
                )
            }
        }
    }

    /** Semakan setiap pagi ~8:00 (WorkManager kekalkan selepas telefon dihidupkan semula). */
    fun pasang(ctx: Context) {
        val now = LocalDateTime.now()
        var pagi = now.withHour(8).withMinute(0).withSecond(0).withNano(0)
        if (!pagi.isAfter(now)) pagi = pagi.plusDays(1)
        val delay = Duration.between(now, pagi).toMinutes().coerceAtLeast(1)
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(
            "bil-rumah", ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<BilWorker>(1, TimeUnit.DAYS).setInitialDelay(delay, TimeUnit.MINUTES).build(),
        )
    }
}

class BilWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        Repo.init(applicationContext)
        Peringatan.semakBil(applicationContext, PG.todayISO())
        return Result.success()
    }
}
