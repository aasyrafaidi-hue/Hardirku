package com.asyraf.hadirku.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.asyraf.hadirku.MainViewModel
import com.asyraf.hadirku.Sheet
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.PgState
import com.asyraf.hadirku.pg.Pocket
import com.asyraf.hadirku.pg.Tx

/* ================= jenis simpanan poket: bank / tunai / e-wallet ================= */

/** Tag kecil di sebelah nama poket. */
fun simpanTag(p: Pocket): String? = when {
    p.tetap -> "tetap"
    p.tunai -> "tunai"
    p.dompet -> "e-wallet"
    else -> null
}

/** Pilihan poket untuk grid: nama + tag kecil "tunai" / "e-wallet" (tak diulang kalau nama dah sebut). */
fun pocketOpts(list: List<Pocket>): List<GridOpt> = list.map { p ->
    val sub = when {
        p.tunai -> if (p.nama.contains("tunai", ignoreCase = true)) null else "tunai"
        p.dompet -> if (p.nama.contains("wallet", ignoreCase = true)) null else "e-wallet"
        else -> null
    }
    GridOpt(p.id, p.nama, sub)
}

/** Ayat ringkas kesan transaksi pada bank / tunai / e-wallet, supaya tak keliru. null = tiada yang perlu diterangkan. */
fun aliranNota(s: PgState, jenis: String, dari: String, ke: String): String? {
    fun cari(id: String) = s.pockets.find { it.id == id }
    fun tempat(p: Pocket?) = when { p == null -> null; p.tunai -> "tunai"; p.dompet -> "e-wallet"; else -> "bank" }
    val a = tempat(cari(dari))
    return when (jenis) {
        "keluar" -> when (a) {
            "tunai" -> "Bayar guna duit tunai dalam dompet. Baki bank tidak berubah."
            "e-wallet" -> "Bayar guna e-wallet. Baki bank tidak berubah."
            else -> null
        }
        "masuk" -> when (a) {
            "tunai" -> "Duit tunai masuk ke dompet. Baki bank tidak berubah."
            "e-wallet" -> "Duit masuk ke e-wallet. Baki bank tidak berubah."
            else -> null
        }
        "pindah" -> {
            val b = tempat(cari(ke))
            when {
                a == null || b == null || a == b -> null
                a == "bank" && b == "tunai" -> "Macam keluar duit di ATM: baki bank turun, duit tunai dalam dompet naik."
                a == "tunai" && b == "bank" -> "Masukkan duit tunai ke bank: tunai turun, baki bank naik."
                a == "bank" && b == "e-wallet" -> "Tambah nilai e-wallet dari bank: baki bank turun, e-wallet naik."
                a == "e-wallet" && b == "bank" -> "Transfer e-wallet ke bank: e-wallet turun, baki bank naik."
                else -> "Pindah antara $a dan $b. Baki bank tidak berubah."
            }
        }
        else -> null
    }
}

/** Nota kecil di bawah pilihan poket (null = tiada nota). Lambda ditaip terus supaya selamat untuk Compose. */
fun notaUi(t: String?): (@Composable () -> Unit)? {
    if (t == null) return null
    val f: @Composable () -> Unit = { Txt(t, size = 12.5f, color = LocalPal.current.muted) }
    return f
}

/* ================= susun poket (naik / turun) ================= */

/**
 * Senarai poket dalam mod Susun: setiap poket ada anak panah naik/turun.
 * Belum Agih kekal paling atas. Susunan ini dipakai di semua senarai & pilihan poket.
 */
@Composable
fun SusunPoketList(vm: MainViewModel, pockets: List<Pocket>, sub: (Pocket) -> String) {
    val pal = LocalPal.current
    val movable = pockets.filter { it.id != PG.BELUM_AGIH }
    Note("Tekan anak panah untuk ubah susunan. Belum Agih sentiasa di atas.", Modifier.padding(bottom = 6.dp))
    ListBlock {
        pockets.forEach { p -> key(p.id) {
            val fixed = p.id == PG.BELUM_AGIH
            val idx = movable.indexOfFirst { it.id == p.id }
            val baru = vm.lastMoved == p.id
            val bg by animateColorAsState(if (baru) pal.accentSoft else Color.Transparent, animationSpec = tween(350), label = "susun")
            Row(
                Modifier.fillMaxWidth().background(bg).hairlines(pal.line).heightIn(min = 56.dp).padding(start = GL, end = 10.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Txt(p.nama, Modifier.weight(1f, fill = false), size = 15f, weight = FontWeight.SemiBold, maxLines = 1)
                        val tg = simpanTag(p)
                        if (tg != null) { Spacer(Modifier.width(6.dp)); Txt(tg.uppercase(), size = 11f, weight = FontWeight.SemiBold, color = pal.muted) }
                    }
                    Txt(if (fixed) "Sentiasa di atas" else sub(p), size = 12f, color = pal.muted, maxLines = 1)
                }
                if (!fixed) {
                    ArrowBtn(Ic.UP, idx > 0, "Naik") { vm.movePocket(p.id, -1) }
                    Spacer(Modifier.width(8.dp))
                    ArrowBtn(Ic.DOWN, idx in 0 until movable.size - 1, "Turun") { vm.movePocket(p.id, +1) }
                }
            }
        } }
    }
}

@Composable
private fun ArrowBtn(ic: Ic, enabled: Boolean, @Suppress("UNUSED_PARAMETER") desc: String, onClick: () -> Unit) {
    val pal = LocalPal.current
    Box(
        Modifier.size(44.dp).border(1.dp, if (enabled) pal.lineStrong else pal.line, RoundedCornerShape(11.dp))
            .pressable(onClick, enabled = enabled, scaleTo = 0.86f),
        contentAlignment = Alignment.Center,
    ) {
        Ico(ic, if (enabled) pal.accentStrong else pal.line, 22.dp, stroke = 2.3f)
    }
}

/* ================= dompet tunai ================= */

/** Kad Dompet tunai di tab Poket: baki tunai (asing dari bank) dan butang pantas. */
@Composable
fun DompetTunaiCard(vm: MainViewModel, s: PgState, b: Map<String, Double>) {
    val pal = LocalPal.current
    val tp = s.pockets.filter { it.tunai }
    if (tp.isEmpty()) {
        Notice(rich("Guna duit tunai? Buat **dompet tunai** supaya duit dalam dompet diasingkan dari baki bank."), Tone.INFO, "Buat") { vm.createTunai() }
        return
    }
    val utama = tp[0]
    val jumlah = PG.round2(tp.sumOf { b[it.id] ?: 0.0 })
    val kira = vm.tunaiKira(utama.id)
    Block {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).background(pal.accentSoft, RoundedCornerShape(11.dp)), contentAlignment = Alignment.Center) {
                Ico(Ic.WALLET, pal.accentStrong, 24.dp, stroke = 1.9f)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Txt(if (tp.size == 1) utama.nama else "Dompet tunai", size = 15f, weight = FontWeight.Bold)
                Txt("Duit tunai dalam dompet · asing dari bank", size = 12.5f, color = pal.muted)
            }
            MoneyAnim(jumlah, 20f, color = if (jumlah < -0.004) pal.bad else pal.ink)
        }
        if (tp.size > 1) {
            Spacer(Modifier.height(6.dp))
            Txt(rich(tp.joinToString(" · ") { it.nama + " **" + M(b[it.id] ?: 0.0) + "**" }), size = 12.5f, color = pal.muted)
        }
        Spacer(Modifier.height(6.dp))
        Txt(
            if (kira == null) "Belum pernah dikira. Kira duit dalam dompet sekali-sekala supaya angka ini tepat."
            else "Kali terakhir dikira " + PG.fmtShort(kira.first) + " (" + M(kira.second) + ")",
            size = 12.5f, color = if (jumlah < -0.004) pal.bad else pal.muted,
        )
        if (jumlah < -0.004) Txt("Baki tunai negatif: ada belanja tunai lebih daripada duit yang dikeluarkan. Tekan Kira duit untuk betulkan.", size = 12.5f, color = pal.bad)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Btn("Ambil ATM", { vm.newTx(Tx(jenis = "pindah", poket = "", ke = utama.id, perkara = "Keluar duit ATM"), "Ambil duit dari ATM") }, Modifier.weight(1f))
            Btn("Belanja", { vm.newTx(Tx(jenis = "keluar", poket = utama.id), "Belanja tunai") }, Modifier.weight(1f))
            Btn("Kira duit", { vm.open(Sheet.KiraTunai(utama.id)) }, Modifier.weight(1f), kind = BtnKind.PRIMARY)
        }
    }
}

/** Kira duit sebenar dalam dompet dan betulkan baki tunai app. */
@Composable
fun KiraTunaiSheet(vm: MainViewModel, id: String) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val p = s.pockets.find { it.id == id } ?: return
    val bal = PG.balances(s)[id] ?: 0.0
    var raw by remember { mutableStateOf("") }
    var cara by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    val fr = autoFocus(true)
    val v = vm.parseAmt(raw)
    val d = if (v.isFinite()) PG.round2(v - bal) else Double.NaN
    val pilihan = when {
        !d.isFinite() || Math.abs(d) < 0.005 -> emptyList()
        d < 0 -> listOf("belanja" to "Belanja tak direkod", "pelarasan" to "Pelarasan sahaja")
        else -> listOf("pelarasan" to "Pelarasan sahaja", "masuk" to "Duit masuk tak direkod")
    }
    val caraEff = if (pilihan.any { it.first == cara }) cara else pilihan.firstOrNull()?.first ?: ""
    SheetBody(actions = { SheetActions("Simpan kiraan", { err = vm.saveKiraTunai(id, raw, caraEff) }, { vm.close() }) }) {
        SheetTitle("Kira duit dalam dompet", rich("Kira semua duit kertas dan syiling dalam **" + p.nama + "**, kemudian masukkan jumlahnya. App akan betulkan baki tunai supaya sama dengan dompet sebenar."))
        Form {
            FieldText("Duit dalam dompet sekarang (RM)", raw, { raw = it; err = "" }, placeholder = "0.00", kb = KeyboardType.Decimal, big = true, fr = fr)
            Compare {
                KvLine("Baki tunai dalam app") { Txt(M(bal), size = 14f, weight = FontWeight.SemiBold, num = true) }
                if (d.isFinite()) {
                    if (Math.abs(d) < 0.005) KvLine("Keputusan") { Pill("✔ Sama", Tone.GOOD) }
                    else {
                        KvLine(if (d < 0) "Kurang dalam dompet" else "Lebih dalam dompet") { Txt(M(Math.abs(d)), size = 14f, weight = FontWeight.SemiBold, color = if (d < 0) pal.bad else pal.good, num = true) }
                        Txt(
                            if (d < 0) "Biasanya sebab ada belanja tunai kecil yang lupa direkod (air, parking, kedai runcit)."
                            else "Mungkin ada duit tunai masuk yang lupa direkod, atau belanja yang direkod dua kali.",
                            size = 13f, color = pal.muted,
                        )
                    }
                }
            }
            if (pilihan.isNotEmpty()) FieldChips("Rekod beza ini sebagai", pilihan, caraEff, { cara = it }, stack = true, note = {
                Txt(
                    when (caraEff) {
                        "belanja" -> "Dikira belanja hari ini (belum dikategori), jadi laporan perbelanjaan lebih tepat."
                        "masuk" -> "Dikira duit masuk hari ini."
                        else -> "Betulkan baki sahaja, tidak dikira belanja atau pendapatan."
                    },
                    size = 12.5f, color = pal.muted,
                )
            })
        }
        Box(Modifier.padding(horizontal = GL)) { FormError(err) }
        Note("Duit tunai tidak dikira dalam Semak baki bank. Ambil duit dari ATM = pindah dari poket bank ke dompet tunai.", Modifier.padding(top = 8.dp, bottom = 8.dp))
    }
}
