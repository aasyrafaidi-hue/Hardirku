@file:OptIn(ExperimentalLayoutApi::class)

package com.asyraf.hadirku.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/* ================= pembantu ================= */

/** Nilai 0→1 sekali bila carta mula dipapar (animasi masuk ringkas). */
@Composable
fun appear(key: Any?, ms: Int): State<Float> {
    val a = remember(key) { Animatable(0f) }
    LaunchedEffect(key) { a.animateTo(1f, tween(ms, easing = FastOutSlowInEasing)) }
    return a.asState()
}

fun compact(v: Double): String {
    val a = abs(v)
    val sg = if (v < 0) "−" else ""
    if (a >= 1000) {
        val k = a / 1000
        val r = if (k >= 10) Math.round(k).toString() else (Math.round(k * 10) / 10.0).let { if (it == floor(it)) it.toLong().toString() else it.toString() }
        return sg + r + "K"
    }
    return sg + Math.round(a)
}

fun niceMax(v: Double): Double {
    if (!(v > 0)) return 100.0
    val p = 10.0.pow(floor(log10(v)))
    val n = v / p
    for (s in doubleArrayOf(1.0, 1.5, 2.0, 2.5, 3.0, 4.0, 5.0, 6.0, 8.0, 10.0)) if (n <= s + 1e-9) return s * p
    return 10 * p
}

/** Warna tulisan yang jelas di atas warna latar (putih atau gelap). */
fun inkOn(c: Color): Color {
    val l = c.luminance()
    return if (1.05 / (l + 0.05) >= (l + 0.05) / 0.066) Color.White else Color(0xFF1B2427)
}

class TipRow(val label: String, val value: String, val color: Color?)
class TipData(val title: String, val rows: List<TipRow>, val note: String? = null)

@Composable
fun TipBox(d: TipData, modifier: Modifier = Modifier) {
    val pal = LocalPal.current
    Column(
        modifier.widthIn(min = 150.dp, max = 250.dp).background(pal.surface, RoundedCornerShape(10.dp)).border(1.dp, pal.line, RoundedCornerShape(10.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Txt(d.title, size = 11.5f, weight = FontWeight.SemiBold, color = pal.muted)
        d.rows.forEach { r ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (r.color != null) { Box(Modifier.width(12.dp).height(2.dp).background(r.color, RoundedCornerShape(2.dp))); Spacer(Modifier.width(8.dp)) }
                Txt(r.value, size = 12.5f, weight = FontWeight.SemiBold, num = true)
                Spacer(Modifier.weight(1f))
                Txt(r.label, Modifier.padding(start = 8.dp), size = 12.5f, color = pal.muted)
            }
        }
        if (d.note != null) Txt(d.note, size = 11.5f, weight = FontWeight.SemiBold, color = pal.muted)
    }
}

private fun DrawScope.label(tm: TextMeasurer, s: String, x: Float, y: Float, color: Color, sizeSp: Float, anchor: Int, bold: Boolean = false): TextLayoutResult {
    val r = tm.measure(AnnotatedString(s), style = TextStyle(fontSize = sizeSp.sp, color = color, fontWeight = if (bold) FontWeight.SemiBold else FontWeight.Normal, fontFeatureSettings = "tnum"))
    val w = r.size.width.toFloat()
    val h = r.size.height.toFloat()
    val left = when (anchor) { 0 -> x; 1 -> x - w / 2; else -> x - w }
    drawText(r, topLeft = Offset(left, y - h * 0.78f))
    return r
}

class LegItem(val label: String, val color: Color, val line: Boolean = false)

@Composable
fun Legend(items: List<LegItem>) {
    val pal = LocalPal.current
    FlowRow(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        items.forEach { it2 ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.width(if (it2.line) 14.dp else 10.dp).height(if (it2.line) 2.dp else 10.dp).background(it2.color, RoundedCornerShape(2.dp)))
                Spacer(Modifier.width(6.dp))
                Txt(it2.label, size = 12.5f, color = pal.muted)
            }
        }
    }
}

/** Jadual kecil di bawah carta ("Lihat jadual"). */
@Composable
fun TableView(head: List<String>, rows: List<List<String>>) {
    val pal = LocalPal.current
    var open by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth()) {
        Txt((if (open) "▾ " else "▸ ") + "Lihat jadual", Modifier.clickable { open = !open }.padding(vertical = 4.dp), size = 13f, weight = FontWeight.SemiBold, color = pal.accentStrong)
        AnimatedVisibility(visible = open, enter = fadeIn(), exit = fadeOut()) {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(top = 6.dp)) {
                head.indices.forEach { ci ->
                    Column {
                        (listOf(head) + rows).forEachIndexed { ri, r ->
                            Box(
                                Modifier.height(30.dp).hairlines(pal.line).padding(horizontal = 8.dp),
                                contentAlignment = if (ci == 0) Alignment.CenterStart else Alignment.CenterEnd,
                            ) {
                                Txt(r.getOrElse(ci) { "" }, size = 12.5f, weight = if (ri == 0 || ci == 0) FontWeight.SemiBold else FontWeight.Normal,
                                    color = if (ri == 0) pal.muted else pal.ink, num = true, maxLines = 1)
                            }
                        }
                    }
                }
            }
        }
    }
}

/* ================= lajur menegak ================= */

class ColCat(val label: String, val title: String, val note: String? = null)

@Composable
fun ColumnChart(series: List<Pair<String, Color>>, cats: List<ColCat>, vals: List<List<Double>>, labelLast: Boolean = true) {
    val pal = LocalPal.current
    val tm = rememberTextMeasurer()
    val dens = LocalDensity.current
    var sel by remember(cats.size, vals) { mutableStateOf(-1) }
    val growS = appear(vals, 700)
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val wDp = maxWidth
        val H = 176.dp
        Canvas(
            Modifier.fillMaxWidth().height(H).pointerInput(cats.size) {
                detectTapGestures(onTap = { o ->
                    val L = 36.dp.toPx(); val R = 6.dp.toPx()
                    val band = (size.width - L - R) / cats.size
                    val i = ((o.x - L) / band).toInt()
                    sel = if (i in cats.indices && i != sel) i else -1
                })
            },
        ) {
            val L = 36.dp.toPx(); val R = 6.dp.toPx(); val T = 20.dp.toPx(); val B = 24.dp.toPx()
            val pw = size.width - L - R; val ph = size.height - T - B
            val mx = niceMax((vals.flatten() + 0.0).maxOrNull() ?: 0.0)
            fun y(v: Double) = (T + ph - (v / mx) * ph).toFloat()
            listOf(0.0, 0.5, 1.0).forEach { f ->
                val yy = y(mx * f)
                drawLine(if (f > 0) pal.grid else pal.lineStrong, Offset(L, yy), Offset(size.width - R, yy), strokeWidth = 1.dp.toPx())
                label(tm, compact(mx * f), L - 6.dp.toPx(), yy + 4.dp.toPx(), pal.muted, 11f, 2)
            }
            val n = cats.size
            val band = pw / n
            val ns = series.size
            val bw = max(6.dp.toPx(), min(24.dp.toPx(), (band * 0.7f - (ns - 1) * 2.dp.toPx()) / ns))
            val gw = bw * ns + (ns - 1) * 2.dp.toPx()
            cats.forEachIndexed { i, c ->
                val x0 = L + band * i + (band - gw) / 2
                series.forEachIndexed { k, s ->
                    val v = vals[k].getOrElse(i) { 0.0 }
                    if (v > 0) {
                        val h = max(1.5f, ((v / mx) * ph).toFloat()) * growS.value
                        val x = x0 + k * (bw + 2.dp.toPx())
                        val r = min(4.dp.toPx(), min(bw / 2, h))
                        val p = Path().apply {
                            addRoundRect(RoundRect(x, T + ph - h, x + bw, T + ph, CornerRadius(r, r), CornerRadius(r, r), CornerRadius.Zero, CornerRadius.Zero))
                        }
                        drawPath(p, s.second, alpha = if (sel == i) 0.8f else 1f)
                    }
                    if (labelLast && i == n - 1 && v > 0 && (ns == 1 || bw + 2.dp.toPx() >= compact(v).length * 6.4f * dens.fontScale * dens.density + 2)) {
                        label(tm, compact(v), x0 + k * (bw + 2.dp.toPx()) + bw / 2, y(v) - 5.dp.toPx(), pal.ink, 11f, 1, bold = true)
                    }
                }
                label(tm, c.label, L + band * i + band / 2, size.height - 7.dp.toPx(), pal.muted, 11f, 1)
            }
        }
        val i = sel
        if (i in cats.indices) {
            val c = cats[i]
            val lpx = with(dens) { 36.dp.toPx() }
            val wpx = with(dens) { wDp.toPx() }
            val band = (wpx - lpx - with(dens) { 6.dp.toPx() }) / cats.size
            val cx = lpx + band * i + band / 2
            val tipW = with(dens) { 200.dp.toPx() }
            val left = (cx - tipW / 2).coerceIn(0f, max(0f, wpx - tipW))
            TipBox(
                TipData(c.title, series.mapIndexed { k, s -> TipRow(s.first, M(vals[k].getOrElse(i) { 0.0 }), s.second) }, c.note),
                Modifier.offset { IntOffset(left.roundToInt(), 0) }.width(200.dp).clickable { sel = -1 },
            )
        }
    }
}

/* ================= garis dengan crosshair ================= */

class LSeries(val label: String, val color: Color, val vals: List<Double>, val end: String? = null)

@Composable
fun LineChart(series: List<LSeries>, titles: List<String>, ticks: List<Pair<Int, String>>) {
    val pal = LocalPal.current
    val tm = rememberTextMeasurer()
    val dens = LocalDensity.current
    var cur by remember(series.size, titles.size) { mutableStateOf(-1) }
    val n = max(1, series.maxOf { it.vals.size } - 1)
    val revealS = appear(series.map { it.vals.size }, 900)
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val wDp = maxWidth
        fun idxAt(x: Float, w: Float): Int {
            val L = with(dens) { 40.dp.toPx() }; val R = with(dens) { 12.dp.toPx() }
            return (((x - L) / (w - L - R)) * n).roundToInt().coerceIn(0, n)
        }
        Canvas(
            Modifier.fillMaxWidth().height(184.dp)
                .pointerInput(n) { detectTapGestures(onTap = { o -> cur = idxAt(o.x, size.width.toFloat()) }) }
                .pointerInput(n) {
                    detectHorizontalDragGestures(
                        onDragStart = { o -> cur = idxAt(o.x, size.width.toFloat()) },
                        onHorizontalDrag = { ch, _ -> cur = idxAt(ch.position.x, size.width.toFloat()) },
                    )
                },
        ) {
            val L = 40.dp.toPx(); val R = 12.dp.toPx(); val T = 30.dp.toPx(); val B = 24.dp.toPx()
            val pw = size.width - L - R; val ph = size.height - T - B
            val mx = niceMax((series.flatMap { it.vals } + 0.0).maxOrNull() ?: 0.0)
            val reveal = revealS.value
            fun x(i: Int) = L + (i.toFloat() / n) * pw
            fun y(v: Double) = (T + ph - (v / mx) * ph).toFloat()
            listOf(0.0, 0.5, 1.0).forEach { f ->
                val yy = y(mx * f)
                drawLine(if (f > 0) pal.grid else pal.lineStrong, Offset(L, yy), Offset(size.width - R, yy), strokeWidth = 1.dp.toPx())
                label(tm, compact(mx * f), L - 6.dp.toPx(), yy + 4.dp.toPx(), pal.muted, 11f, 2)
            }
            ticks.forEach { (i, t) -> label(tm, t, x(i), size.height - 7.dp.toPx(), pal.muted, 11f, if (i == 0) 0 else 1) }
            series.forEachIndexed { k, s ->
                if (s.vals.isEmpty()) return@forEachIndexed
                val last = ((s.vals.size - 1) * reveal).toInt()
                val p = Path()
                for (i in 0..last) { if (i == 0) p.moveTo(x(i), y(s.vals[i])) else p.lineTo(x(i), y(s.vals[i])) }
                if (k == 0) {
                    val a = Path()
                    a.moveTo(x(0), y(0.0))
                    for (i in 0..last) a.lineTo(x(i), y(s.vals[i]))
                    a.lineTo(x(last), y(0.0)); a.close()
                    drawPath(a, pal.c1Wash)
                }
                drawPath(p, s.color, style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
            if (reveal >= 0.999f) {
                val boxes = ArrayList<FloatArray>()
                series.forEach { s ->
                    if (s.vals.isEmpty()) return@forEach
                    val i = s.vals.size - 1
                    val ex = x(i); val ey = y(s.vals[i])
                    drawCircle(pal.surface, radius = 6.dp.toPx(), center = Offset(ex, ey))
                    drawCircle(s.color, radius = 4.dp.toPx(), center = Offset(ex, ey))
                    val end = s.end ?: return@forEach
                    val w = end.length * 6.4f * dens.fontScale * dens.density
                    fun hits(x1: Float, x2: Float, yy: Float): Boolean {
                        if (yy < 10.dp.toPx()) return false
                        for (ss in series) for ((j, v) in ss.vals.withIndex()) {
                            val px = x(j); val py = y(v)
                            if (px >= x1 - 2 && px <= x2 + 2 && py >= yy - 12.dp.toPx() && py <= yy + 4.dp.toPx()) return true
                        }
                        return boxes.any { b -> x1 < b[1] && x2 > b[0] && yy - 11.dp.toPx() < b[2] && yy > b[2] - 11.dp.toPx() }
                    }
                    var best: FloatArray? = null
                    var dy = 6
                    while (dy <= 60 && best == null) {
                        val cands = ArrayList<FloatArray>()
                        val d = dy.dp.toPx()
                        if (ex + 8.dp.toPx() + w <= size.width - 2) cands.add(floatArrayOf(0f, ex + 8.dp.toPx(), ex + 8.dp.toPx(), ex + 8.dp.toPx() + w, ey - d))
                        if (ex - 8.dp.toPx() - w >= L) cands.add(floatArrayOf(2f, ex - 8.dp.toPx(), ex - 8.dp.toPx() - w, ex - 8.dp.toPx(), ey - d))
                        if (ex - w / 2 >= L && ex + w / 2 <= size.width - 2) cands.add(floatArrayOf(1f, ex, ex - w / 2, ex + w / 2, ey - d - 4.dp.toPx()))
                        best = cands.firstOrNull { !hits(it[2], it[3], it[4]) }
                        dy += 4
                    }
                    val b = best ?: floatArrayOf(2f, ex, ex - w, ex, ey - 8.dp.toPx())
                    val ly = max(10.dp.toPx(), b[4])
                    boxes.add(floatArrayOf(b[2], b[3], ly))
                    label(tm, end, b[1], ly, pal.ink, 11f, b[0].toInt(), bold = true)
                }
            }
            val c = cur
            if (c >= 0) {
                val xx = x(c)
                drawLine(pal.lineStrong, Offset(xx, T), Offset(xx, T + ph), strokeWidth = 1.dp.toPx())
                series.forEach { s ->
                    val v = s.vals.getOrNull(c) ?: return@forEach
                    drawCircle(pal.surface, radius = 6.dp.toPx(), center = Offset(xx, y(v)))
                    drawCircle(s.color, radius = 4.dp.toPx(), center = Offset(xx, y(v)))
                }
            }
        }
        val c = cur
        if (c >= 0) {
            val wpx = with(dens) { wDp.toPx() }
            val L = with(dens) { 40.dp.toPx() }; val R = with(dens) { 12.dp.toPx() }
            val xx = L + (c.toFloat() / n) * (wpx - L - R)
            val tipW = with(dens) { 210.dp.toPx() }
            val left = (xx - tipW / 2).coerceIn(0f, max(0f, wpx - tipW))
            TipBox(
                TipData(titles.getOrElse(c) { "" }, series.map { s -> TipRow(s.label, s.vals.getOrNull(c)?.let { M(it) } ?: "✔ Langsai", s.color) }),
                Modifier.offset { IntOffset(left.roundToInt(), 0) }.width(210.dp).clickable { cur = -1 },
            )
        }
    }
}

/* ================= pie ================= */

class Slice(val id: String, val name: String, val v: Double, val color: Color)

/** Warna pie yang cerah (ikut susunan besar → kecil), seperti carta statistik. */
val PIE_COLORS = listOf(
    Color(0xFFF2675E), Color(0xFFFF9248), Color(0xFFFFC24D), Color(0xFFF0DC3A), Color(0xFFB5DD47), Color(0xFF5FCB6C),
    Color(0xFF4CD2C2), Color(0xFF4DB5EE), Color(0xFF5A8CEE), Color(0xFF8D7BE6), Color(0xFFBF6FDF), Color(0xFFEF6FA6),
)

fun pieColor(i: Int): Color = PIE_COLORS[((i % PIE_COLORS.size) + PIE_COLORS.size) % PIE_COLORS.size]

private class PieLbl(val i: Int, val right: Boolean, val ax: Float, val ay: Float, val ang: Float, var y: Float)

/** Jejari pie: beri ruang untuk label di kiri & kanan. */
private fun pieRadius(w: Float, h: Float, density: Float): Float {
    val labelSpace = 100f * density
    return min(h * 0.37f, (w - 2 * labelSpace) / 2).coerceIn(48f * density, 110f * density)
}

private fun DrawScope.labelFit(tm: TextMeasurer, s: String, x: Float, y: Float, color: Color, sizeSp: Float, right: Boolean, bold: Boolean, maxW: Float) {
    val r = tm.measure(
        AnnotatedString(s),
        style = TextStyle(fontSize = sizeSp.sp, color = color, fontWeight = if (bold) FontWeight.SemiBold else FontWeight.Normal, fontFeatureSettings = "tnum"),
        overflow = TextOverflow.Ellipsis, maxLines = 1,
        constraints = Constraints(maxWidth = max(1, maxW.toInt())),
    )
    val w = r.size.width.toFloat()
    drawText(r, topLeft = Offset(if (right) x else x - w, y - r.size.height * 0.78f))
}

/** Pie penuh dengan label nama + peratus di luar, bersambung dengan garis penunjuk. */
@Composable
fun PieChart(slices: List<Slice>, total: Double, label: String) {
    val pal = LocalPal.current
    val tm = rememberTextMeasurer()
    var sel by remember(slices.size, total) { mutableStateOf(-1) }
    // animasi masuk (lengkung dikira dalam Gerak.java): pie berpusing masuk, potongan "pop" satu-satu dengan lantunan, label pudar masuk
    val tA = remember(slices.map { it.id }, total) { Animatable(0f) }
    LaunchedEffect(tA) { tA.animateTo(1f, tween(1400, easing = LinearEasing)) }
    // potongan dipilih melantun keluar dengan spring
    var popIdx by remember(slices.size, total) { mutableStateOf(-1) }
    if (sel >= 0) popIdx = sel
    val popT by animateFloatAsState(if (sel >= 0) 1f else 0f, spring(dampingRatio = 0.38f, stiffness = 480f), label = "piePop")
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Txt(label, Modifier.weight(1f), size = 13f, color = pal.muted)
            Txt(M(total), size = 15f, weight = FontWeight.SemiBold, num = true)
        }
        Box(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
            Canvas(
                Modifier.fillMaxWidth().height(250.dp).pointerInput(slices, total) {
                    detectTapGestures(onTap = { o ->
                        val cx = size.width / 2f; val cy = size.height / 2f
                        val R = pieRadius(size.width.toFloat(), size.height.toFloat(), density)
                        val dx = o.x - cx; val dy = o.y - cy
                        if (sqrt(dx * dx + dy * dy) > R + 8.dp.toPx()) { sel = -1; return@detectTapGestures }
                        var ang = (atan2(dy, dx) * 180 / PI).toFloat() + 90f
                        if (ang < 0) ang += 360f
                        var acc = 0f
                        var hit = -1
                        slices.forEachIndexed { i, s ->
                            val sw = if (total > 0) (s.v / total * 360).toFloat() else 0f
                            if (hit < 0 && ang >= acc && ang < acc + sw) hit = i
                            acc += sw
                        }
                        sel = if (hit == sel) -1 else hit
                    })
                },
            ) {
                val W = size.width; val Hh = size.height
                val cx = W / 2; val cy = Hh / 2
                val R = pieRadius(W, Hh, density)
                val t = tA.value
                val ps = Gerak.iosOut(Gerak.clamp01(t / 0.7f))          // sapuan terkumpul
                val rot = (1f - ps) * -110f                               // pusingan masuk
                val n = slices.size
                var a = -90f + rot
                slices.forEachIndexed { i, s ->
                    val frac = if (total > 0) (s.v / total).toFloat() else 0f
                    val sw = frac * 360f * ps
                    val grow = Gerak.lerp(0.5f, 1f, Gerak.easeOutBack(Gerak.stagger(t, i, n, 0.5f)))
                    val pk = if (i == popIdx) popT else 0f
                    val r = R * grow * (1f + 0.05f * pk)
                    val pop = 9.dp.toPx() * pk
                    val m = ((a + sw / 2) * PI / 180).toFloat()
                    val tl = Offset(cx + pop * cos(m) - r, cy + pop * sin(m) - r)
                    drawArc(s.color, a, sw, useCenter = true, topLeft = tl, size = Size(r * 2, r * 2), alpha = if (sel >= 0 && sel != i) 0.6f else 1f)
                    if (n > 1 && sw > 0.3f) drawArc(pal.surface, a, sw, useCenter = true, topLeft = tl, size = Size(r * 2, r * 2), style = Stroke(width = 1.dp.toPx()))
                    a += sw
                }
                val la = Gerak.iosEase(Gerak.clamp01((t - 0.62f) / 0.38f))   // label pudar masuk
                if (la <= 0f) return@Canvas

                // ---------- label luar dengan garis penunjuk ----------
                val lbls = ArrayList<PieLbl>()
                a = -90f
                slices.forEachIndexed { i, s ->
                    val frac = if (total > 0) (s.v / total).toFloat() else 0f
                    if (frac >= 0.015f) {
                        val m = ((a + frac * 180f) * PI / 180).toFloat()
                        lbls.add(PieLbl(i, cos(m) >= 0f, cx + R * cos(m), cy + R * sin(m), m, cy + (R + 16.dp.toPx()) * sin(m)))
                    }
                    a += frac * 360f
                }
                val gap = 27.dp.toPx(); val top = 12.dp.toPx(); val bot = Hh - 18.dp.toPx()
                listOf(true, false).forEach { side ->
                    val g = lbls.filter { it.right == side }.sortedBy { it.y }
                    for (k in g.indices) { val lo = if (k == 0) top else g[k - 1].y + gap; if (g[k].y < lo) g[k].y = lo }
                    for (k in g.indices.reversed()) { val hi = if (k == g.size - 1) bot else g[k + 1].y - gap; if (g[k].y > hi) g[k].y = hi }
                    for (k in g.indices) { val lo = if (k == 0) top else g[k - 1].y + gap; if (g[k].y < lo) g[k].y = lo }
                }
                lbls.forEach { l ->
                    val s = slices[l.i]
                    val frac = if (total > 0) (s.v / total).toFloat() else 0f
                    val dir = if (l.right) 1f else -1f
                    val e1 = Offset(cx + (R + 10.dp.toPx()) * cos(l.ang), cy + (R + 10.dp.toPx()) * sin(l.ang))
                    val endX = cx + dir * (R + 24.dp.toPx())
                    val ex = if (l.right) max(endX, e1.x + 6.dp.toPx()) else min(endX, e1.x - 6.dp.toPx())
                    val p = Path().apply { moveTo(l.ax, l.ay); lineTo(e1.x, e1.y); lineTo(ex, l.y) }
                    drawPath(p, s.color.copy(alpha = la), style = Stroke(width = 1.2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
                    // label meluncur keluar sedikit sambil pudar masuk
                    val tx = ex + dir * (4.dp.toPx() + (1f - la) * 12.dp.toPx())
                    val maxW = if (l.right) W - tx - 2.dp.toPx() else tx - 2.dp.toPx()
                    val ink = pal.ink.copy(alpha = la)
                    labelFit(tm, s.name, tx, l.y - 1.dp.toPx(), ink, 11.5f, l.right, true, maxW)
                    labelFit(tm, pct(frac * 100.0) + " %", tx, l.y + 13.dp.toPx(), ink, 11f, l.right, false, maxW)
                }
            }
            val i = sel
            if (i in slices.indices) {
                val s = slices[i]
                TipBox(
                    TipData(s.name, listOf(TipRow(pct(if (total > 0) s.v / total * 100 else 0.0) + "% daripada jumlah", M(s.v), s.color))),
                    Modifier.align(Alignment.TopCenter).width(210.dp).clickable { sel = -1 },
                )
            }
        }
    }
}

/** Baris senarai di bawah donut: peratus berwarna, nama, jumlah. */
@Composable
fun PieRow(pctText: String, color: Color, name: String, value: String, onClick: (() -> Unit)?) {
    val pal = LocalPal.current
    Row(
        Modifier.fillMaxWidth().hairlines(pal.line).then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier).padding(horizontal = GL, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.widthIn(min = 52.dp).background(color, RoundedCornerShape(5.dp)).padding(horizontal = 6.dp, vertical = 3.dp), contentAlignment = Alignment.Center) {
            Txt(pctText, size = 13f, weight = FontWeight.SemiBold, color = inkOn(color), num = true, align = TextAlign.Center)
        }
        Spacer(Modifier.width(12.dp))
        Txt(name, Modifier.weight(1f), size = 15f, maxLines = 1)
        Spacer(Modifier.width(12.dp))
        Txt(value, size = 15f, num = true)
        if (onClick != null) { Spacer(Modifier.width(8.dp)); Txt("›", size = 18f, color = pal.muted) }
    }
}

/** Lebar teks anggaran untuk label (dp). */
fun estW(s: String, sp: Float): Dp = (s.length * sp * 0.55f).dp

@Suppress("unused")
private fun ceilDiv(a: Int, b: Int): Int = ceil(a.toDouble() / b).toInt()
