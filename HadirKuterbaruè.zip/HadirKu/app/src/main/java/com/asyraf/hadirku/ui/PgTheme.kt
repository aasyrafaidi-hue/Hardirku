package com.asyraf.hadirku.ui

import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.sp

/** Token warna Duitku (gaya lejar rata, aksen cyan lembut). Masuk biru, keluar merah lembut, tiada kuning terang. */
class Pal(
    val dark: Boolean,
    val bg: Color, val surface: Color, val surface2: Color, val track: Color,
    val ink: Color, val muted: Color, val line: Color, val lineStrong: Color,
    val accent: Color, val accentStrong: Color, val accentInk: Color, val accentSoft: Color,
    val good: Color, val goodSoft: Color, val warn: Color, val warnSoft: Color,
    val bad: Color, val badSoft: Color, val badInk: Color,
    val inn: Color, val inSoft: Color, val out: Color,
    val p: List<Color>, val pu: Color,
    val c1: Color, val c2: Color, val c1Wash: Color, val grid: Color, val scrim: Color,
) {
    /** Warna poket / kategori: slot 1..6. */
    fun slot(i: Int): Color = p[(i - 1).coerceIn(0, 5)]
}

private fun c(hex: Long): Color = Color(hex or 0xFF000000L)

val LightPal = Pal(
    dark = false,
    bg = c(0xF1F4F5), surface = c(0xFFFFFF), surface2 = c(0xF6F9FA), track = c(0xE5ECEE),
    ink = c(0x1B2427), muted = c(0x6A777B), line = c(0xE1E8EA), lineStrong = c(0xC3CFD3),
    accent = c(0x0C7C8C), accentStrong = c(0x075E6B), accentInk = c(0xFFFFFF), accentSoft = c(0xE0F3F5),
    good = c(0x2C7449), goodSoft = c(0xE3F2E8), warn = c(0x8A5520), warnSoft = c(0xF6ECE0),
    bad = c(0xA23A3A), badSoft = c(0xF8E6E6), badInk = c(0xFFFFFF),
    inn = c(0x2B6CB0), inSoft = c(0xEEF4FB), out = c(0xC2453D),
    p = listOf(c(0x0E93A3), c(0x7C66B6), c(0xB85207), c(0x4E9A5F), c(0xDA6EA8), c(0xA2AEB2)), pu = c(0xDCE4E6),
    c1 = c(0x0E93A3), c2 = c(0x7C66B6), c1Wash = Color(0x1A0E93A3), grid = c(0xEBF1F2), scrim = Color(0x730A1416),
)

val DarkPal = Pal(
    dark = true,
    bg = c(0x080C0D), surface = c(0x131819), surface2 = c(0x192022), track = c(0x232C2F),
    ink = c(0xE3ECEE), muted = c(0x91A1A5), line = c(0x242D30), lineStrong = c(0x364247),
    accent = c(0x5CC3CF), accentStrong = c(0x86D6DF), accentInk = c(0x05252A), accentSoft = c(0x12292D),
    good = c(0x7ECB98), goodSoft = c(0x1A2E22), warn = c(0xE0A66B), warnSoft = c(0x332619),
    bad = c(0xEA8D8D), badSoft = c(0x382020), badInk = c(0x1A0E0E),
    inn = c(0x7DB2EC), inSoft = c(0x152130), out = c(0xEE8E86),
    p = listOf(c(0x36AFBE), c(0x9A7DE3), c(0xD17746), c(0x4F9E68), c(0x9D4575), c(0x5D696C)), pu = c(0x313B3E),
    c1 = c(0x36AFBE), c2 = c(0x8F7ECE), c1Wash = Color(0x1F36AFBE), grid = c(0x1F2729), scrim = Color(0x99000000),
)

val LocalPal = staticCompositionLocalOf { LightPal }

/** Tema app: warna PoketGaji + saiz tulisan pengguna (10–20px, asal 15px). */
@Composable
fun PgTheme(dark: Boolean, saiz: Int, content: @Composable () -> Unit) {
    val pal = if (dark) DarkPal else LightPal
    val scheme = if (dark) darkColorScheme(
        primary = pal.accent, onPrimary = pal.accentInk, primaryContainer = pal.accentSoft, onPrimaryContainer = pal.accentStrong,
        secondary = pal.accentStrong, onSecondary = pal.accentInk, background = pal.bg, onBackground = pal.ink,
        surface = pal.surface, onSurface = pal.ink, surfaceVariant = pal.surface2, onSurfaceVariant = pal.muted,
        outline = pal.lineStrong, outlineVariant = pal.line, error = pal.bad, onError = pal.badInk,
        surfaceContainer = pal.surface, surfaceContainerHigh = pal.surface, surfaceContainerHighest = pal.surface2,
        surfaceContainerLow = pal.surface, surfaceContainerLowest = pal.surface,
    ) else lightColorScheme(
        primary = pal.accent, onPrimary = pal.accentInk, primaryContainer = pal.accentSoft, onPrimaryContainer = pal.accentStrong,
        secondary = pal.accentStrong, onSecondary = pal.accentInk, background = pal.bg, onBackground = pal.ink,
        surface = pal.surface, onSurface = pal.ink, surfaceVariant = pal.surface2, onSurfaceVariant = pal.muted,
        outline = pal.lineStrong, outlineVariant = pal.line, error = pal.bad, onError = pal.badInk,
        surfaceContainer = pal.surface, surfaceContainerHigh = pal.surface, surfaceContainerHighest = pal.surface2,
        surfaceContainerLow = pal.surface, surfaceContainerLowest = pal.surface,
    )
    val d = LocalDensity.current
    val fz = saiz.coerceIn(10, 20) / 15f
    MaterialTheme(colorScheme = scheme) {
        CompositionLocalProvider(
            LocalPal provides pal,
            LocalDensity provides Density(d.density, d.fontScale * fz),
            LocalContentColor provides pal.ink,
            LocalTextStyle provides TextStyle(fontSize = 15.sp, color = pal.ink, lineHeight = 21.sp),
        ) {
            content()
        }
    }
}
