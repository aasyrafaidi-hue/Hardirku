package com.asyraf.hadirku.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.asyraf.hadirku.MainViewModel
import com.asyraf.hadirku.Sheet
import com.asyraf.hadirku.pg.DailySummary
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.PgState
import com.asyraf.hadirku.pg.Tx

private val byNewest = Comparator<Tx> { a, b ->
    val c = b.tarikh.compareTo(a.tarikh)
    if (c != 0) c else b.dibuat.compareTo(a.dibuat)
}

/** Tab Transaksi: Kalendar | Senarai (lejar harian). */
@Composable
fun TransaksiScreen(vm: MainViewModel) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val ym = vm.txYm
    val pk = vm.txPocket
    val ds = remember(s, ym, pk) { PG.dailySummary(s, ym, pk.ifEmpty { null }) }
    val om = akruanOn(s) && pk.isEmpty()
    val sett = remember(s) { PG.otSettlements(s).byTx }

    Seg(listOf("kalendar" to "Kalendar", "senarai" to "Senarai"), vm.txView) { vm.setTxViewMode(it) }
    NavRow(PG.fmtMonth(ym), null, { vm.txYm = PG.shiftYm(ym, -1) }, { vm.txYm = PG.shiftYm(ym, 1) })
    if (om) {
        val rb = remember(s, ym) { PG.periodReport(s, PG.finPeriod("$ym-01", 1)) }
        val k = rb.otKitaran
        SumStrip(rb.pend, rb.belanja, "Pendapatan", "Perbelanjaan", if (k != null) "OT dalam pendapatan bulan ini: kitaran " + PG.fmtShort(k.start) + " – " + PG.fmtShort(k.end) else null)
    } else SumStrip(ds.masuk, ds.keluar)
    if (pk.isNotEmpty()) {
        Row(Modifier.padding(horizontal = GL), verticalAlignment = Alignment.CenterVertically) {
            Txt("Poket:", size = 13f, color = pal.muted)
            Spacer(Modifier.width(8.dp))
            Box(
                Modifier.border(1.dp, pal.line, RoundedCornerShape(999.dp)).background(pal.surface, RoundedCornerShape(999.dp))
                    .clickable { vm.txPocket = "" }.padding(horizontal = 12.dp, vertical = 6.dp),
            ) { Txt(pname(s, pk) + " ✕", size = 13f, weight = FontWeight.SemiBold) }
        }
    }
    if (vm.txView == "kalendar") Kalendar(vm, s, ds, om)
    else Senarai(vm, s, ds, om, sett)
}

@Composable
private fun Senarai(vm: MainViewModel, s: PgState, ds: DailySummary, om: Boolean, sett: Map<String, Double>) {
    val pal = LocalPal.current
    val ym = vm.txYm
    val pk = vm.txPocket
    val list = remember(s, ym, pk) {
        s.transactions.filter { PG.ym(it.tarikh) == ym && (pk.isEmpty() || it.poket == pk || it.ke == pk) }.sortedWith(byNewest)
    }
    val byDay = LinkedHashMap<String, MutableList<Tx>>()
    list.forEach { byDay.getOrPut(it.tarikh) { ArrayList() }.add(it) }
    val dates = ArrayList(byDay.keys)
    val logs = HashMap<String, MutableList<com.asyraf.hadirku.pg.KadLog>>()
    if (om) {
        ds.days.forEach { x -> if ((x.ot > 0 || x.kadLog > 0) && !byDay.containsKey(x.tarikh)) { byDay[x.tarikh] = ArrayList(); dates.add(x.tarikh) } }
        PG.kadLogs(s, ds.days[0].tarikh, PG.addDays(ds.days[ds.days.size - 1].tarikh, 1)).forEach { l -> logs.getOrPut(l.tarikh) { ArrayList() }.add(l) }
        dates.sortDescending()
    }
    if (dates.isEmpty()) {
        Empty(rich("Tiada transaksi " + (if (pk.isNotEmpty()) "untuk poket ini " else "") + "pada " + PG.fmtMonth(ym) + ". Tekan **Transaksi** di bawah untuk rekod yang pertama."))
        return
    }
    dates.forEach { d ->
        val p = PG.parse(d)
        val day = ds.days[p.d - 1]
        Column(Modifier.fillMaxWidth().background(pal.surface).hairlines(pal.line, top = true, bottom = true)) {
            Row(Modifier.fillMaxWidth().hairlines(pal.line).padding(horizontal = GL, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                Txt(p.d.toString(), size = 22f, weight = FontWeight.SemiBold, num = true, lh = 24f)
                Spacer(Modifier.width(8.dp))
                Box(Modifier.background(pal.muted, RoundedCornerShape(3.dp)).padding(horizontal = 5.dp, vertical = 2.dp)) {
                    Txt(PG.HARI[PG.weekday(d)], size = 11.5f, weight = FontWeight.SemiBold, color = pal.surface)
                }
                Spacer(Modifier.width(8.dp))
                Txt(PG.pad(p.m) + "." + p.y, Modifier.weight(1f), size = 12f, color = pal.muted, maxLines = 1)
                Txt(M(if (om) day.pend else day.masuk), Modifier.widthIn(min = 64.dp), size = 13.5f, color = pal.inn, num = true, align = TextAlign.End)
                Spacer(Modifier.width(8.dp))
                Txt(M(if (om) day.belanja else day.keluar), Modifier.widthIn(min = 64.dp), size = 13.5f, color = pal.out, num = true, align = TextAlign.End)
            }
            if (om && day.ot > 0) {
                val cy = PG.otCycleOf(d, vm.otSd())
                LRow("OT", "OT diperoleh", otParts(s, d).joinToString(" + ") + " · masuk gaji " + PG.fmtMonth(cy.bayarYm), "+" + M(day.ot), pal.inn, { vm.open(Sheet.OtDay(d)) })
            }
            byDay[d]?.forEach { t ->
                TxRow(vm, s, t, om, sett)
                val amt = sett[t.id]
                if (om && amt != null) {
                    val pc = PG.prevCycleOf(t.tarikh, vm.otSd())
                    LRow("OT", "Tolak OT dalam gaji", "OT " + PG.fmtShort(pc.start) + " – " + PG.fmtShort(pc.end) + " dah dikira berasingan sebagai OT", M(-amt), pal.muted, { vm.editTx(t.id) })
                }
            }
            if (om) logs[d]?.forEach { KadLogRow(vm, it) }
        }
    }
}

fun otParts(s: PgState, d: String): List<String> {
    val ov = PG.otValue(s, d)
    val parts = ArrayList<String>()
    if (ov.h15 > 0) parts.add(fmtH(ov.h15) + "j × 1.5")
    if (ov.h20 > 0) parts.add(fmtH(ov.h20) + "j × 2.0")
    if (ov.h30 > 0) parts.add(fmtH(ov.h30) + "j × 3.0")
    return parts
}

private fun calNum(v: Double): String {
    val a = Math.abs(v)
    return if (a >= 1000) (if (a >= 10000) Math.round(a / 1000).toString() else (Math.round(a / 100) / 10.0).toString()) + "K" else Math.round(a).toString()
}

@Composable
private fun Kalendar(vm: MainViewModel, s: PgState, ds: DailySummary, om: Boolean) {
    val pal = LocalPal.current
    val today = vm.today()
    val first = ds.days[0].tarikh
    val lead = (PG.weekday(first) + 6) % 7
    val past = ds.days.filter { it.tarikh <= today }
    if (om) {
        val lebih = past.count { it.harian > it.ot + 0.004 }
        CalSum(
            M(ds.bakiOt), "OT harian − belanja harian, 1–" + ds.days.size + " " + PG.BULAN[PG.parse(first).m - 1], ds.bakiOt < -0.004,
            "$lebih hari", "Belanja melebihi OT", lebih > 0,
        )
    } else {
        val hb = ds.days.count { it.keluar > 0 && it.tarikh <= today }
        CalSum(if (past.isNotEmpty()) M(ds.keluar / Math.max(1, past.size)) else "–", "Purata belanja sehari", false, "$hb/${past.size}", "Hari ada belanja", false)
    }
    Column(Modifier.fillMaxWidth().background(pal.surface).hairlines(pal.line, top = true, bottom = true)) {
        Row(Modifier.fillMaxWidth().hairlines(pal.line)) {
            listOf("Isn", "Sel", "Rab", "Kha", "Jum", "Sab", "Ahd").forEachIndexed { k, h ->
                Txt(h, Modifier.weight(1f).padding(vertical = 7.dp), size = 11.5f, weight = FontWeight.SemiBold, color = if (k >= 5) pal.accentStrong else pal.muted, align = TextAlign.Center)
            }
        }
        val cells: List<com.asyraf.hadirku.pg.DayRow?> = List(lead) { null } + ds.days
        Column(Modifier.fillMaxWidth().background(pal.line), verticalArrangement = Arrangement.spacedBy(1.dp)) {
            cells.chunked(7).forEach { week ->
                Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(1.dp)) {
                    (0 until 7).forEach { i ->
                        val x = week.getOrNull(i)
                        if (x == null) Box(Modifier.weight(1f).fillMaxHeight().heightIn(min = 66.dp).background(pal.surface2))
                        else {
                            val p = PG.parse(x.tarikh)
                            val fut = x.tarikh > today
                            val inc = if (om) x.pend else x.masuk
                            val out = if (om) x.belanja else x.keluar
                            val bz = if (om) x.bersihL else x.bersih
                            val aktif = inc > 0 || out > 0
                            val lebihOt = om && !fut && x.harian > x.ot + 0.004
                            val gaji = vm.txPocket.isEmpty() && x.masuk > 0
                            Column(
                                Modifier.weight(1f).fillMaxHeight().heightIn(min = 66.dp)
                                    .background(if (gaji) pal.inSoft else pal.surface)
                                    .then(if (x.tarikh == today) Modifier.border(2.dp, pal.accent) else Modifier)
                                    .clickable { vm.open(Sheet.Day(x.tarikh)) }
                                    .padding(start = 4.dp, end = 4.dp, top = 4.dp, bottom = 5.dp),
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Txt(p.d.toString(), size = 12f, weight = FontWeight.SemiBold, color = if (fut) pal.muted else pal.ink)
                                    if (lebihOt) { Spacer(Modifier.width(4.dp)); Box(Modifier.size(6.dp).background(pal.out, CircleShape)) }
                                }
                                Spacer(Modifier.weight(1f))
                                if (inc > 0) Txt("+" + calNum(inc), Modifier.fillMaxWidth(), size = 10.5f, weight = FontWeight.SemiBold, color = pal.inn, align = TextAlign.End, num = true, maxLines = 1)
                                if (out > 0) Txt("−" + calNum(out), Modifier.fillMaxWidth(), size = 10.5f, color = pal.out, align = TextAlign.End, num = true, maxLines = 1)
                                if (aktif) Txt(
                                    (if (bz > 0.004) "+" else if (bz < -0.004) "−" else "") + calNum(bz), Modifier.fillMaxWidth(), size = 10.5f, weight = FontWeight.SemiBold,
                                    color = if (bz > 0.004) pal.inn else if (bz < -0.004) pal.out else pal.ink, align = TextAlign.End, num = true, maxLines = 1,
                                )
                            }
                        }
                    }
                }
            }
        }
        Column(Modifier.fillMaxWidth().hairlines(pal.line, top = true, bottom = false).padding(start = GL, end = GL, top = 8.dp, bottom = 10.dp)) {
            if (om) {
                Txt(rich("**+** pendapatan (OT + duit masuk)   **−** perbelanjaan", pal.inn), size = 12f, color = pal.muted)
                Txt("Angka bawah: baki hari itu. Titik merah: belanja harian melebihi OT. Latar biru: hari gaji masuk (OT dalam gaji tak dikira lagi).", size = 12f, color = pal.muted)
            } else {
                Txt(rich("**+** masuk   **−** keluar", pal.inn), size = 12f, color = pal.muted)
                Txt("Angka bawah: baki hari itu (masuk − keluar)", size = 12f, color = pal.muted)
            }
        }
    }
    Note("Tekan mana-mana hari untuk lihat butiran dan tambah transaksi.", Modifier.fillMaxWidth(), align = TextAlign.Center)
}

@Composable
private fun CalSum(v1: String, l1: String, neg1: Boolean, v2: String, l2: String, neg2: Boolean) {
    val pal = LocalPal.current
    Row(Modifier.fillMaxWidth().background(pal.line).padding(vertical = 1.dp).height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(1.dp)) {
        listOf(Triple(v1, l1, neg1), Triple(v2, l2, neg2)).forEachIndexed { i, (v, l, n) ->
            Column(Modifier.weight(1f).fillMaxHeight().background(pal.surface).padding(start = if (i == 0) GL else 12.dp, end = 12.dp, top = 10.dp, bottom = 10.dp)) {
                Txt(v, size = 14f, weight = FontWeight.SemiBold, color = if (n) pal.bad else pal.ink, num = true, maxLines = 1)
                Txt(l, size = 11.5f, color = pal.muted)
            }
        }
    }
}

/** Helaian butiran satu hari (openDay PoketGaji). */
@Composable
fun DaySheet(vm: MainViewModel, d: String) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val pk = vm.txPocket
    val ds = remember(s, d, pk) { PG.dailySummary(s, PG.ym(d), pk.ifEmpty { null }) }
    val x = ds.days.firstOrNull { it.tarikh == d } ?: return
    val om = akruanOn(s) && pk.isEmpty()
    val sett = remember(s) { PG.otSettlements(s).byTx }
    val list = s.transactions.filter { it.tarikh == d && (pk.isEmpty() || it.poket == pk || it.ke == pk) }.sortedBy { it.dibuat }
    SheetBody(actions = {
        SheetActions("+ Transaksi", { vm.newTx(Tx(tarikh = d, poket = pk)) }, { vm.close() }, cancel = "Tutup",
            extra = if (om) "Isi OT" else null, onExtra = { vm.open(Sheet.OtDay(d)) })
    }) {
        SheetTitle(longDate(d), if (pk.isNotEmpty()) rich("Poket " + pname(s, pk) + " sahaja") else null)
        Column(Modifier.padding(horizontal = GL).padding(bottom = 10.dp)) {
            if (om) {
                val ov = PG.otValue(s, d)
                val parts = otParts(s, d)
                val komit = PG.round2(x.tetap - x.bayarKad)
                val rows = ArrayList<Triple<androidx.compose.ui.text.AnnotatedString, String, Color?>>()
                val strong = HashSet<Int>()
                if (x.ot > 0 || ov.recorded) rows.add(Triple(two("OT diperoleh", parts.joinToString(" + "), pal.muted), "+" + M(x.ot), pal.inn))
                if (x.masuk > 0) rows.add(Triple(rich("Duit masuk"), "+" + M(x.masuk), pal.inn))
                if (x.otBayar > 0) rows.add(Triple(two("Tolak OT dalam gaji", "dah dikira pada hari kerja", pal.muted), M(-x.otBayar), pal.muted))
                strong.add(rows.size); rows.add(Triple(rich("Pendapatan"), Mp(x.pend), if (x.pend > 0.004) pal.inn else null))
                if (x.tunai > 0) rows.add(Triple(two("Tunai dari kad", "pinjaman, bukan pendapatan", pal.muted), "+" + M(x.tunai), pal.muted))
                if (x.harian > 0) rows.add(Triple(two("Belanja harian", "termasuk guna kad", pal.muted), M(-x.harian), pal.out))
                if (komit > 0) rows.add(Triple(rich("Komitmen & ansuran"), M(-komit), pal.out))
                if (x.kadLog > 0) rows.add(Triple(rich("Faedah, caj & fee kad"), M(-x.kadLog), pal.out))
                strong.add(rows.size); rows.add(Triple(rich("Perbelanjaan"), M(-x.belanja), if (x.belanja > 0.004) pal.out else null))
                strong.add(rows.size); rows.add(Triple(rich("Baki hari ini"), Mp(x.bersihL), if (x.bersihL < -0.004) pal.out else if (x.bersihL > 0.004) pal.inn else null))
                Kvl(rows, strong)
                if (x.ot > 0 || x.harian > 0) Txt(
                    if (x.harian > x.ot + 0.004) "Belanja harian " + M(x.harian) + " melebihi OT " + M(x.ot) + " sebanyak " + M(x.harian - x.ot) + "."
                    else "Belanja harian " + M(x.harian) + " dalam had OT " + M(x.ot) + ".",
                    Modifier.padding(top = 6.dp), size = 13f, color = if (x.harian > x.ot + 0.004) pal.bad else pal.muted,
                )
                if (x.bayarKad > 0) Txt("Bayar kad kredit " + M(x.bayarKad) + " tidak dikira belanja: belanja guna kad sudah dikira pada hari beli.", Modifier.padding(top = 6.dp), size = 13f, color = pal.muted)
            } else {
                val rows = ArrayList<Triple<androidx.compose.ui.text.AnnotatedString, String, Color?>>()
                rows.add(Triple(rich("Duit masuk"), "+" + M(x.masuk), pal.inn))
                if (x.tunai > 0) rows.add(Triple(two("Tunai dari kad", "pinjaman, bukan duit masuk", pal.muted), "+" + M(x.tunai), pal.muted))
                rows.add(Triple(rich("Belanja"), M(-x.keluar), pal.out))
                rows.add(Triple(two("Baki hari ini", "masuk − keluar", pal.muted), Mp(x.bersih), if (x.bersih < -0.004) pal.out else if (x.bersih > 0.004) pal.inn else null))
                Kvl(rows, setOf(rows.size - 1))
            }
        }
        if (list.isNotEmpty()) ListBlock { list.forEach { TxRow(vm, s, it, om, sett) } }
        else Empty(rich("Tiada transaksi pada hari ini."))
    }
}
