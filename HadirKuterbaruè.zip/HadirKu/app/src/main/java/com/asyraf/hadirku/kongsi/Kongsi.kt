package com.asyraf.hadirku.kongsi

import com.asyraf.hadirku.data.Repo
import com.asyraf.hadirku.pg.PG
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import org.json.JSONArray
import org.json.JSONObject
import java.security.SecureRandom

/* Data yang dikongsi antara telefon isteri dan suami (Firestore). Poket & transaksi kekal dalam telefon. */

data class Barang(val id: String, val nama: String, val nota: String, val dibeli: Boolean, val oleh: String, val dibuat: Long)
data class SejarahBeli(val id: String, val nama: String, val tarikh: List<String>)
data class BayarBil(val oleh: String, val tarikh: String, val jumlah: Double)
data class Bil(val id: String, val nama: String, val jumlah: Double, val hari: Int, val poket: String, val bayar: Map<String, BayarBil>, val dibuat: Long)
data class Nafkah(val id: String, val jumlah: Double, val catatan: String, val dari: String, val tarikh: String, val diterima: Boolean, val dibuat: Long)
data class ItemProjek(val id: String, val nama: String, val bajet: Double, val sebenar: Double)
data class Projek(val id: String, val nama: String, val item: List<ItemProjek>, val dibuat: Long)
data class Rumah(val id: String, val kod: String, val ahli: List<String>, val nama: Map<String, String>)

enum class Status { MATI, SAMBUNG, SEDIA, RALAT }

/**
 * Sambungan Firebase: log masuk tanpa nama (anonymous), satu "rumah" untuk setiap keluarga.
 * Telefon pertama buat rumah dan dapat kod 6 aksara; telefon kedua masuk guna kod itu.
 * Firestore simpan salinan luar talian, jadi perubahan semasa tiada internet dihantar kemudian.
 *
 * Struktur:
 *   rumah/{id}            kod, ahli[uid], nama{uid: nama}
 *   rumah/{id}/barang     senarai barang dapur
 *   rumah/{id}/sejarah    tarikh setiap barang dibeli (untuk cadangan beli semula)
 *   rumah/{id}/bil        bil & tarikh jatuh tempo, bayar{yyyy-mm: {...}}
 *   rumah/{id}/nafkah     duit yang suami hantar
 *   rumah/{id}/projek     projek (cth rumah baru) dengan item bajet vs sebenar
 *   jemputan/{kod}        rumah, uid  (untuk masuk guna kod)
 */
object Kongsi {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var regs: List<ListenerRegistration> = emptyList()

    private val _status = MutableStateFlow(Status.MATI)
    val status: StateFlow<Status> = _status.asStateFlow()
    private val _ralat = MutableStateFlow("")
    val ralat: StateFlow<String> = _ralat.asStateFlow()

    private val _rumah = MutableStateFlow<Rumah?>(null)
    val rumah: StateFlow<Rumah?> = _rumah.asStateFlow()
    private val _barang = MutableStateFlow<List<Barang>>(emptyList())
    val barang: StateFlow<List<Barang>> = _barang.asStateFlow()
    private val _sejarah = MutableStateFlow<List<SejarahBeli>>(emptyList())
    val sejarah: StateFlow<List<SejarahBeli>> = _sejarah.asStateFlow()
    private val _bil = MutableStateFlow<List<Bil>>(emptyList())
    val bil: StateFlow<List<Bil>> = _bil.asStateFlow()
    private val _nafkah = MutableStateFlow<List<Nafkah>>(emptyList())
    val nafkah: StateFlow<List<Nafkah>> = _nafkah.asStateFlow()
    private val _projek = MutableStateFlow<List<Projek>>(emptyList())
    val projek: StateFlow<List<Projek>> = _projek.asStateFlow()

    private val db: FirebaseFirestore get() = FirebaseFirestore.getInstance()
    private val auth: FirebaseAuth get() = FirebaseAuth.getInstance()

    fun hid(): String = Repo.getStr("kongsi.hid")
    fun namaSaya(): String = Repo.getStr("kongsi.nama", "Abang").ifBlank { "Abang" }
    fun uid(): String? = try { auth.currentUser?.uid } catch (e: Exception) { null }
    fun sedia(): Boolean = _status.value == Status.SEDIA

    /** Nama ahli rumah untuk paparan ("Abang", "Isteri"…). */
    fun namaAhli(uid: String): String = _rumah.value?.nama?.get(uid)?.ifBlank { null } ?: if (uid == uid()) namaSaya() else "Pasangan"

    // ---------------- sambung ----------------

    /** Mula sambungan (selamat dipanggil berkali-kali). */
    fun mula() {
        if (_status.value == Status.SAMBUNG || _status.value == Status.SEDIA) return
        _status.value = Status.SAMBUNG
        _ralat.value = ""
        scope.launch {
            try {
                if (auth.currentUser == null) auth.signInAnonymously().await()
                var h = hid()
                if (h.isEmpty()) h = buatRumah()
                dengar(h)
                _status.value = Status.SEDIA
            } catch (e: Exception) {
                gagal(e)
            }
        }
    }

    fun cubaLagi() {
        if (_status.value == Status.SAMBUNG) return
        _status.value = Status.MATI
        mula()
    }

    private fun gagal(e: Exception) {
        _ralat.value = pesan(e)
        _status.value = Status.RALAT
    }

    fun pesan(e: Exception): String = when {
        e is FirebaseNetworkException -> "Tiada internet. Sambung ke internet sekali untuk aktifkan perkongsian."
        e is FirebaseFirestoreException && e.code == FirebaseFirestoreException.Code.PERMISSION_DENIED ->
            "Firebase menolak akses. Semak peraturan Firestore (security rules) dalam Firebase Console."
        e is FirebaseFirestoreException && e.code == FirebaseFirestoreException.Code.UNAVAILABLE -> "Server Firebase tak dapat dihubungi. Cuba lagi sebentar."
        (e.message ?: "").contains("CONFIGURATION_NOT_FOUND") || (e.message ?: "").contains("ADMIN_ONLY_OPERATION") ->
            "Log masuk Anonymous belum dihidupkan dalam Firebase Console (Authentication → Sign-in method)."
        else -> e.message?.take(160) ?: "Ralat Firebase."
    }

    private fun kodRawak(): String {
        val abc = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789" // tanpa 0/O/1/I supaya senang dibaca
        val r = SecureRandom()
        return (1..6).map { abc[r.nextInt(abc.length)] }.joinToString("")
    }

    private suspend fun buatRumah(): String {
        val u = uid() ?: throw Exception("Belum log masuk.")
        var last: Exception? = null
        repeat(6) {
            val ref = db.collection("rumah").document()
            val kod = kodRawak()
            val b = db.batch()
            b.set(ref, mapOf("kod" to kod, "ahli" to listOf(u), "nama" to mapOf(u to namaSaya()), "dibuat" to System.currentTimeMillis()))
            b.set(db.collection("jemputan").document(kod), mapOf("rumah" to ref.id, "uid" to u))
            try {
                b.commit().await()
                Repo.putStr("kongsi.hid", ref.id)
                return ref.id
            } catch (e: FirebaseFirestoreException) {
                // kod sudah digunakan rumah lain → cuba kod lain
                if (e.code != FirebaseFirestoreException.Code.PERMISSION_DENIED) throw e
                last = e
            }
        }
        throw last ?: Exception("Tak dapat buat kod rumah.")
    }

    /** Masuk rumah pasangan guna kod. Pulang mesej ralat, atau null jika berjaya. */
    suspend fun masukRumah(kod0: String): String? {
        val kod = kod0.trim().uppercase()
        if (kod.length != 6) return "Kod rumah ada 6 aksara."
        val u = uid() ?: return "Belum bersambung ke Firebase."
        return try {
            val inv = db.collection("jemputan").document(kod).get().await()
            if (!inv.exists()) return "Kod $kod tidak dijumpai."
            val h = inv.getString("rumah") ?: return "Kod ini rosak."
            if (h == hid()) return "Ini kod rumah awak sendiri."
            db.collection("rumah").document(h).update(mapOf("ahli" to FieldValue.arrayUnion(u), "nama.$u" to namaSaya())).await()
            Repo.putStr("kongsi.hid", h)
            dengar(h)
            _status.value = Status.SEDIA
            null
        } catch (e: Exception) {
            pesan(e)
        }
    }

    fun tukarNama(n: String) {
        val nama = n.trim().take(20).ifEmpty { "Abang" }
        Repo.putStr("kongsi.nama", nama)
        val u = uid() ?: return
        val h = hid().ifEmpty { return }
        db.collection("rumah").document(h).update("nama.$u", nama)
    }

    // ---------------- dengar perubahan ----------------

    private fun col(h: String, c: String) = db.collection("rumah").document(h).collection(c)
    private fun ref(c: String) = col(hid(), c)

    private fun dengar(h: String) {
        regs.forEach { it.remove() }
        val r = ArrayList<ListenerRegistration>()
        r += db.collection("rumah").document(h).addSnapshotListener { d, e ->
            if (e != null) { gagal(e); return@addSnapshotListener }
            if (d != null && d.exists()) _rumah.value = Rumah(
                d.id, d.getString("kod") ?: "", (d.get("ahli") as? List<*>)?.map { it.toString() } ?: emptyList(),
                (d.get("nama") as? Map<*, *>)?.entries?.associate { it.key.toString() to it.value.toString() } ?: emptyMap(),
            )
        }
        r += col(h, "barang").addSnapshotListener { q, e ->
            if (e != null || q == null) return@addSnapshotListener
            _barang.value = q.documents.map { d ->
                Barang(d.id, d.str("nama"), d.str("nota"), d.getBoolean("dibeli") == true, d.str("oleh"), d.lng("dibuat"))
            }.sortedWith(compareBy<Barang> { it.dibeli }.thenBy { it.dibuat })
        }
        r += col(h, "sejarah").addSnapshotListener { q, e ->
            if (e != null || q == null) return@addSnapshotListener
            _sejarah.value = q.documents.map { d -> SejarahBeli(d.id, d.str("nama"), (d.get("tarikh") as? List<*>)?.map { it.toString() }?.sorted() ?: emptyList()) }
        }
        r += col(h, "bil").addSnapshotListener { q, e ->
            if (e != null || q == null) return@addSnapshotListener
            val list = q.documents.map { d ->
                val bm = (d.get("bayar") as? Map<*, *>)?.entries?.mapNotNull { (k, v) ->
                    val m = v as? Map<*, *> ?: return@mapNotNull null
                    k.toString() to BayarBil(m["oleh"]?.toString() ?: "", m["tarikh"]?.toString() ?: "", (m["jumlah"] as? Number)?.toDouble() ?: 0.0)
                }?.toMap() ?: emptyMap()
                Bil(d.id, d.str("nama"), d.dbl("jumlah"), d.lng("hari").toInt().coerceIn(1, 31), d.str("poket"), bm, d.lng("dibuat"))
            }.sortedWith(compareBy<Bil> { it.hari }.thenBy { it.nama })
            _bil.value = list
            cerminBil(list)
        }
        r += col(h, "nafkah").addSnapshotListener { q, e ->
            if (e != null || q == null) return@addSnapshotListener
            _nafkah.value = q.documents.map { d ->
                Nafkah(d.id, d.dbl("jumlah"), d.str("catatan"), d.str("dari"), d.str("tarikh"), d.getBoolean("diterima") == true, d.lng("dibuat"))
            }.sortedByDescending { it.dibuat }
        }
        r += col(h, "projek").addSnapshotListener { q, e ->
            if (e != null || q == null) return@addSnapshotListener
            _projek.value = q.documents.map { d ->
                val items = (d.get("item") as? List<*>)?.mapNotNull { v ->
                    val m = v as? Map<*, *> ?: return@mapNotNull null
                    ItemProjek(m["id"]?.toString() ?: PG.uid("i-"), m["nama"]?.toString() ?: "", (m["bajet"] as? Number)?.toDouble() ?: 0.0, (m["sebenar"] as? Number)?.toDouble() ?: 0.0)
                } ?: emptyList()
                Projek(d.id, d.str("nama"), items, d.lng("dibuat"))
            }.sortedBy { it.dibuat }
        }
        regs = r
    }

    private fun DocumentSnapshot.str(k: String): String = getString(k) ?: ""
    private fun DocumentSnapshot.dbl(k: String): Double = (get(k) as? Number)?.toDouble() ?: 0.0
    private fun DocumentSnapshot.lng(k: String): Long = (get(k) as? Number)?.toLong() ?: 0L

    /** Salinan bil dalam telefon supaya peringatan berjadual boleh jalan tanpa buka app. */
    private fun cerminBil(list: List<Bil>) {
        val a = JSONArray()
        list.forEach { b ->
            a.put(JSONObject().put("id", b.id).put("nama", b.nama).put("jumlah", b.jumlah).put("hari", b.hari).put("bayar", JSONArray(b.bayar.keys.toList())))
        }
        Repo.putStr("kongsi.bil.cermin", a.toString())
    }

    /** Bil dari cermin tempatan (untuk worker): nama, jumlah, hari, bulan yang sudah dibayar. */
    fun bilCermin(): List<Bil> = try {
        val a = JSONArray(Repo.getStr("kongsi.bil.cermin", "[]"))
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            val ks = o.optJSONArray("bayar") ?: JSONArray()
            Bil(o.getString("id"), o.optString("nama"), o.optDouble("jumlah", 0.0), o.optInt("hari", 1),
                "", (0 until ks.length()).associate { ks.getString(it) to BayarBil("", "", 0.0) }, 0L)
        }
    } catch (e: Exception) { emptyList() }

    // ---------------- senarai barang ----------------

    fun tambahBarang(nama: String, nota: String = "") {
        val n = nama.trim().take(60)
        if (n.isEmpty() || hid().isEmpty()) return
        ref("barang").add(mapOf("nama" to n, "nota" to nota.trim().take(60), "dibeli" to false, "oleh" to (uid() ?: ""), "dibuat" to System.currentTimeMillis()))
    }

    fun tickBarang(id: String, on: Boolean) { if (hid().isNotEmpty()) ref("barang").document(id).update("dibeli", on) }
    fun padamBarang(id: String) { if (hid().isNotEmpty()) ref("barang").document(id).delete() }

    fun kunciBarang(nama: String): String = PG.normNama(nama).replace(" ", "").ifEmpty { "x" }.take(80)

    /** Barang dah dibeli: buang dari senarai dan catat tarikh untuk cadangan beli semula. */
    fun selesaiBeli(ids: Collection<String>, tarikh: String) {
        if (hid().isEmpty()) return
        val b = db.batch()
        ids.forEach { id ->
            val it = _barang.value.find { x -> x.id == id } ?: return@forEach
            b.delete(ref("barang").document(id))
            b.set(ref("sejarah").document(kunciBarang(it.nama)), mapOf("nama" to it.nama, "tarikh" to FieldValue.arrayUnion(tarikh)), SetOptions.merge())
        }
        b.commit()
    }

    // ---------------- bil ----------------

    fun simpanBil(id: String?, nama: String, jumlah: Double, hari: Int, poket: String) {
        if (hid().isEmpty()) return
        val m = mapOf("nama" to nama, "jumlah" to jumlah, "hari" to hari, "poket" to poket)
        if (id == null) ref("bil").add(m + mapOf("bayar" to emptyMap<String, Any>(), "dibuat" to System.currentTimeMillis()))
        else ref("bil").document(id).update(m)
    }

    fun padamBil(id: String) { if (hid().isNotEmpty()) ref("bil").document(id).delete() }

    fun tandaBayar(id: String, ym: String, jumlah: Double, tarikh: String) {
        if (hid().isEmpty() || id.isEmpty()) return
        // FieldPath (bukan "bayar.$ym") supaya kunci bulan "2026-11" tidak dihurai sebagai laluan bertitik
        ref("bil").document(id).update(
            com.google.firebase.firestore.FieldPath.of("bayar", ym),
            mapOf("oleh" to (uid() ?: ""), "tarikh" to tarikh, "jumlah" to (if (jumlah.isFinite()) jumlah else 0.0)),
        ).addOnFailureListener { }
    }

    fun batalBayar(id: String, ym: String) {
        if (hid().isNotEmpty() && id.isNotEmpty()) ref("bil").document(id).update(com.google.firebase.firestore.FieldPath.of("bayar", ym), FieldValue.delete()).addOnFailureListener { }
    }

    // ---------------- nafkah ----------------

    fun hantarNafkah(jumlah: Double, catatan: String, tarikh: String) {
        if (hid().isEmpty()) return
        ref("nafkah").add(mapOf("jumlah" to jumlah, "catatan" to catatan.trim().take(80), "dari" to (uid() ?: ""), "tarikh" to tarikh, "diterima" to false, "dibuat" to System.currentTimeMillis()))
    }

    fun terimaNafkah(id: String) { if (hid().isNotEmpty()) ref("nafkah").document(id).update(mapOf("diterima" to true, "diterimaPada" to System.currentTimeMillis())) }

    // ---------------- projek ----------------

    private fun itemMap(i: ItemProjek) = mapOf("id" to i.id, "nama" to i.nama, "bajet" to i.bajet, "sebenar" to i.sebenar)

    fun simpanProjek(id: String?, nama: String) {
        if (hid().isEmpty()) return
        if (id == null) ref("projek").add(mapOf("nama" to nama, "item" to emptyList<Any>(), "dibuat" to System.currentTimeMillis()))
        else ref("projek").document(id).update("nama", nama)
    }

    fun padamProjek(id: String) { if (hid().isNotEmpty()) ref("projek").document(id).delete() }

    fun simpanItem(pid: String, item: ItemProjek) {
        val p = _projek.value.find { it.id == pid } ?: return
        val list = if (p.item.any { it.id == item.id }) p.item.map { if (it.id == item.id) item else it } else p.item + item
        ref("projek").document(pid).update("item", list.map { itemMap(it) })
    }

    fun padamItem(pid: String, iid: String) {
        val p = _projek.value.find { it.id == pid } ?: return
        ref("projek").document(pid).update("item", p.item.filter { it.id != iid }.map { itemMap(it) })
    }

    /** Tambah belanja sebenar pada item (selepas rekod transaksi). */
    fun tambahSebenar(pid: String, iid: String, jumlah: Double) {
        val p = _projek.value.find { it.id == pid } ?: return
        val it = p.item.find { x -> x.id == iid } ?: return
        simpanItem(pid, it.copy(sebenar = PG.round2(it.sebenar + jumlah)))
    }
}
