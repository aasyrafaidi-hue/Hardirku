package com.asyraf.hadirku.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.asyraf.hadirku.MainViewModel
import com.asyraf.hadirku.pg.KadLog
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.PgState
import com.asyraf.hadirku.pg.Tx

/* Pembantu paparan transaksi, dikongsi oleh Transaksi, Laporan, senarai kategori & poket. */

fun pname(s: PgState, id: String): String = PG.pocketName(s, id)
fun jenisLabel(id: String): String = PG.JENIS.find { it.id == id }?.label ?: id
fun hariLabel(id: String) = PG.JENIS_HARI.find { it.id == id } ?: PG.JENIS_HARI[0]
fun jenisHutang(id: String): String = PG.JENIS_HUTANG.find { it.id == id }?.label ?: "Hutang"
fun akruanOn(s: PgState): Boolean = s.settings.otPendapatan
fun longDate(d: String): String { val p = PG.parse(d); return PG.HARI_PENUH[PG.weekday(d)] + ", " + p.d + " " + PG.BULAN_PENUH[p.m - 1] + " " + p.y }
fun isKadPay(s: PgState, t: Tx): Boolean = t.jenis == "keluar" && t.hutangId.isNotEmpty() && s.debts.any { it.id == t.hutangId && it.jenis == "kad" }
fun ymAfter(today: String, n: Int): String = PG.shiftYm(PG.ym(today), n)
fun monthShort(today: String, n: Int): String { val p = ymAfter(today, n).split("-"); return PG.BULAN[p[1].toInt() - 1] + " " + p[0] }
fun tempoh(n: Int): String = if (n < 12) "$n bulan" else (n / 12).toString() + " thn" + (if (n % 12 != 0) " " + (n % 12) + " bln" else "")
fun fmtYm(s: String): String { val p = PG.parse(s); return PG.BULAN[p.m - 1] + " " + p.y }

fun txCat(s: PgState, t: Tx): String = when (t.jenis) {
    "pindah" -> "Pindah"
    "masuk" -> "Masuk"
    "baki-awal" -> "Baki awal"
    "pelarasan+", "pelarasan-" -> "Pelarasan"
    "tunai-kad" -> "Tunai kad"
    else -> pname(s, t.poket)
}

fun txSub(s: PgState, t: Tx, om: Boolean, sett: Map<String, Double>): String {
    if (t.jenis == "pindah") return pname(s, t.poket) + " → " + pname(s, t.ke)
    if (t.jenis == "kad") {
        val kc = s.debts.find { it.id == t.kadId }
        return "Guna " + (kc?.nama ?: "kad (dipadam)") + (if (t.catatan.isNotEmpty()) " · " + t.catatan else "")
    }
    if (t.jenis == "tunai-kad") {
        val kt = s.debts.find { it.id == t.kadId }
        return "Dari " + (kt?.nama ?: "kad (dipadam)") + " → " + pname(s, t.poket) + (if ((t.fee ?: 0.0) > 0) " · fee " + M(t.fee) else "") + " · pinjaman" + (if (t.catatan.isNotEmpty()) " · " + t.catatan else "")
    }
    val bits = ArrayList<String>()
    if (t.jenis != "keluar") bits.add(pname(s, t.poket))
    if (t.komitmenId.isNotEmpty() && s.commitments.any { it.id == t.komitmenId }) bits.add("Komitmen")
    if (t.hutangId.isNotEmpty()) {
        val d = s.debts.find { it.id == t.hutangId }
        if (d != null) bits.add("Hutang " + d.nama + if (om && d.jenis == "kad") " · pindah ke kad, bukan belanja" else "")
    }
    val ob = sett[t.id]
    if (t.jenis == "masuk" && om && ob != null) bits.add("termasuk OT " + M(ob))
    if (t.catatan.isNotEmpty()) bits.add(t.catatan)
    return bits.joinToString(" · ")
}

/** Jumlah transaksi berwarna: masuk biru, keluar merah, pindah kelabu. */
fun txAmount(s: PgState, t: Tx, om: Boolean, pal: Pal): Pair<String, Color> = when {
    t.jenis == "pindah" -> M(t.jumlah) to pal.muted
    t.jenis == "tunai-kad" -> "+" + M(t.jumlah) to pal.muted
    om && isKadPay(s, t) -> M(-t.jumlah) to pal.muted
    t.jenis == "kad" -> M(-t.jumlah) to pal.out
    PG.flows(t).inn != null -> "+" + M(t.jumlah) to pal.inn
    else -> M(-t.jumlah) to pal.out
}

/** Baris lejar: kategori | nama + keterangan | jumlah. */
@Composable
fun LRow(cat: String?, title: String, sub: String?, amt: String, amtColor: Color, onClick: () -> Unit, tag: String? = null) {
    val pal = LocalPal.current
    Row(
        Modifier.fillMaxWidth().hairlines(pal.line).pressable(onClick, scaleTo = 0.985f).padding(horizontal = GL, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (cat != null) {
            Txt(cat, Modifier.fillMaxWidth(0.28f).padding(end = 10.dp), size = 13f, color = pal.muted, maxLines = 1)
        }
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Txt(title, Modifier.weight(1f, fill = false), size = 15f, weight = FontWeight.Medium, maxLines = 1)
                if (tag != null) {
                    Spacer(Modifier.width(6.dp))
                    Txt(tag, Modifier.background(pal.accentSoft, RoundedCornerShape(3.dp)).padding(horizontal = 6.dp, vertical = 1.dp), size = 11f, weight = FontWeight.SemiBold, color = pal.accentStrong)
                }
            }
            if (!sub.isNullOrEmpty()) Txt(sub, size = 12.5f, color = pal.muted, maxLines = 1)
        }
        Spacer(Modifier.width(10.dp))
        Txt(amt, size = 15f, weight = FontWeight.Medium, color = amtColor, num = true, maxLines = 1)
    }
}

@Composable
fun TxRow(vm: MainViewModel, s: PgState, t: Tx, om: Boolean, sett: Map<String, Double>, showDate: Boolean = false, nocat: Boolean = false) {
    val pal = LocalPal.current
    var sub = txSub(s, t, om, sett)
    if (showDate) sub = PG.fmtShort(t.tarikh) + if (sub.isNotEmpty()) " · $sub" else ""
    if (nocat) {
        val bits = arrayListOf(PG.fmtShort(t.tarikh), PG.katLabel(PG.kategoriOf(t)))
        val s0 = txSub(s, t, om, sett)
        if (s0.isNotEmpty()) bits.add(s0)
        sub = bits.joinToString(" · ")
    }
    val (a, c) = txAmount(s, t, om, pal)
    LRow(if (nocat) null else txCat(s, t), t.perkara.ifEmpty { jenisLabel(t.jenis) }, sub, a, c, { vm.editTx(t.id) })
}

@Composable
fun KadLogRow(vm: MainViewModel, l: KadLog) {
    val pal = LocalPal.current
    val fee = l.jenis == "fee"
    LRow(
        "Kad",
        (if (fee) "Fee tunai · " else if (l.jenis == "faedah") "Faedah & caj · " else "Belanja kad · ") + l.nama,
        (if (fee) "Perbelanjaan (caj kad)" else "Rekod hutang") + if (l.catatan.isNotEmpty()) " · " + l.catatan else "",
        M(-l.jumlah), pal.out,
        { if (fee && l.txId != null) vm.editTx(l.txId) else vm.open(com.asyraf.hadirku.Sheet.HHist(l.debtId)) },
    )
}

class BarSpec(val frac: Double, val over: Boolean, val warn: Boolean)

/** Baris poket / hutang (nama kiri, jumlah kanan, keterangan di bawah). */
@Composable
fun PRow(name: String, right: String, onClick: () -> Unit, tag: String? = null, neg: Boolean = false, subs: List<String> = emptyList(), rightColor: Color? = null, bar: BarSpec? = null) {
    val pal = LocalPal.current
    Column(Modifier.fillMaxWidth().hairlines(pal.line).pressable(onClick, scaleTo = 0.985f).padding(horizontal = GL, vertical = 13.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                Txt(name, Modifier.weight(1f, fill = false), size = 15f, weight = FontWeight.SemiBold)
                if (tag != null) { Spacer(Modifier.width(6.dp)); Txt(tag.uppercase(), size = 11f, weight = FontWeight.SemiBold, color = pal.muted) }
            }
            Spacer(Modifier.width(12.dp))
            Txt(right, size = 15f, weight = FontWeight.SemiBold, color = rightColor ?: if (neg) pal.bad else pal.ink, num = true)
        }
        if (bar != null) { Spacer(Modifier.padding(top = 6.dp)); Bar(bar.frac, over = bar.over, warn = bar.warn) }
        subs.forEach { Txt(it, Modifier.padding(top = 4.dp), size = 12.5f, color = pal.muted) }
    }
}
