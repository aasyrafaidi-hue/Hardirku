@file:OptIn(ExperimentalLayoutApi::class)

package com.asyraf.hadirku.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.asyraf.hadirku.pg.PG

/* ================= teks ================= */

val TNUM = TextStyle(fontFeatureSettings = "tnum")

@Composable
fun Txt(
    text: String,
    modifier: Modifier = Modifier,
    size: Float = 15f,
    weight: FontWeight = FontWeight.Normal,
    color: Color = Color.Unspecified,
    align: TextAlign? = null,
    maxLines: Int = Int.MAX_VALUE,
    num: Boolean = false,
    lh: Float = 0f,
) {
    val pal = LocalPal.current
    Text(
        text = text, modifier = modifier, fontSize = size.sp, fontWeight = weight,
        color = if (color == Color.Unspecified) pal.ink else color, textAlign = align, maxLines = maxLines,
        overflow = if (maxLines == Int.MAX_VALUE) TextOverflow.Clip else TextOverflow.Ellipsis,
        lineHeight = if (lh > 0f) lh.sp else (size * 1.38f).sp,
        style = if (num) TNUM else TextStyle.Default,
    )
}

@Composable
fun Txt(
    text: AnnotatedString,
    modifier: Modifier = Modifier,
    size: Float = 15f,
    weight: FontWeight = FontWeight.Normal,
    color: Color = Color.Unspecified,
    align: TextAlign? = null,
) {
    val pal = LocalPal.current
    Text(
        text = text, modifier = modifier, fontSize = size.sp, fontWeight = weight,
        color = if (color == Color.Unspecified) pal.ink else color, textAlign = align,
        lineHeight = (size * 1.4f).sp, style = TNUM,
    )
}

/** Teks dengan bahagian tebal: **perkataan** dalam rentetan. */
fun rich(s: String, boldColor: Color? = null): AnnotatedString = buildAnnotatedString {
    val parts = s.split("**")
    parts.forEachIndexed { i, p ->
        if (i % 2 == 1) withStyle(SpanStyle(fontWeight = FontWeight.SemiBold, color = boldColor ?: Color.Unspecified)) { append(p) }
        else append(p)
    }
}

fun M(x: Double?): String = PG.money(x)
fun Mp(x: Double?): String = PG.money(x, plus = true)
fun fmtH(x: Double): String = PG.toFixed(Math.round(x * 10) / 10.0, 1)
fun pct(x: Double): String = (Math.round(x * 10) / 10.0).let { if (it == Math.floor(it)) it.toLong().toString() else it.toString() }

/* ================= garis & blok ================= */

fun Modifier.hairlines(color: Color, top: Boolean = false, bottom: Boolean = true): Modifier = this.drawBehind {
    val w = 1.dp.toPx()
    if (top) drawLine(color, Offset(0f, w / 2), Offset(size.width, w / 2), strokeWidth = w)
    if (bottom) drawLine(color, Offset(0f, size.height - w / 2), Offset(size.width, size.height - w / 2), strokeWidth = w)
}

val GL = 16.dp

/** Blok putih penuh lebar dengan garis atas & bawah (gaya lejar). */
@Composable
fun Block(modifier: Modifier = Modifier, bg: Color? = null, pad: Boolean = true, content: @Composable ColumnScope.() -> Unit) {
    val pal = LocalPal.current
    Column(
        modifier
            .fillMaxWidth()
            .background(bg ?: pal.surface)
            .hairlines(pal.line, top = true, bottom = true)
            .then(if (pad) Modifier.padding(horizontal = GL, vertical = 12.dp) else Modifier),
        content = content,
    )
}

/** Senarai baris (tiap baris melukis garis bawah sendiri). */
@Composable
fun ListBlock(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val pal = LocalPal.current
    Column(modifier.fillMaxWidth().background(pal.surface).hairlines(pal.line, top = true, bottom = true), content = content)
}

@Composable
fun SecHead(title: String, link: String? = null, right: String? = null, onLink: () -> Unit = {}) {
    val pal = LocalPal.current
    Row(
        Modifier.fillMaxWidth().padding(start = GL, end = GL, top = 6.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Txt(title, Modifier.weight(1f), size = 13f, weight = FontWeight.SemiBold, color = pal.muted)
        if (right != null) Txt(right, size = 13f, color = pal.muted, num = true)
        if (link != null) {
            Txt(link, Modifier.clickable(onClick = onLink).padding(vertical = 4.dp, horizontal = 2.dp), size = 13.5f, weight = FontWeight.SemiBold, color = pal.accent)
        }
    }
}

/** Tajuk bahagian dengan beberapa pautan di kanan (cth "Susun" dan "+ Poket"). */
@Composable
fun SecHeadLinks(title: String, links: List<Pair<String, () -> Unit>>) {
    val pal = LocalPal.current
    Row(
        Modifier.fillMaxWidth().padding(start = GL, end = GL, top = 6.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Txt(title, Modifier.weight(1f), size = 13f, weight = FontWeight.SemiBold, color = pal.muted)
        links.forEachIndexed { i, (label, act) ->
            if (i > 0) Spacer(Modifier.width(16.dp))
            Txt(label, Modifier.clickable(onClick = act).padding(vertical = 4.dp, horizontal = 2.dp), size = 13.5f, weight = FontWeight.SemiBold, color = pal.accent)
        }
    }
}

@Composable
fun Gap(h: Dp = 10.dp) = Spacer(Modifier.height(h))

/* ================= butang (animasi tekan) ================= */

enum class BtnKind { PRIMARY, GHOST, DANGER, SMALL }

@Composable
fun Modifier.pressable(onClick: () -> Unit, enabled: Boolean = true, scaleTo: Float = 0.95f, haptic: Boolean = false): Modifier {
    val src = remember { MutableInteractionSource() }
    val tick = rememberTick()
    val pressed by src.collectIsPressedAsState()
    // gaya iOS: tekan = kecut cepat & sedikit pudar; lepas = melantun balik dengan spring
    val sc by animateFloatAsState(
        targetValue = if (pressed) scaleTo else 1f,
        animationSpec = if (pressed) spring(dampingRatio = 1f, stiffness = 1400f) else spring(dampingRatio = 0.42f, stiffness = 520f),
        label = "tekan",
    )
    val al by animateFloatAsState(targetValue = if (pressed) 0.82f else 1f, animationSpec = spring(stiffness = 900f), label = "tekanAlpha")
    return this
        .graphicsLayer { scaleX = sc; scaleY = sc; alpha = al }
        .clickable(interactionSource = src, indication = LocalIndication.current, enabled = enabled, onClick = { if (haptic) tick(); onClick() })
}

@Composable
fun Btn(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    kind: BtnKind = BtnKind.GHOST,
    enabled: Boolean = true,
    color: Color? = null,
    icon: (@Composable () -> Unit)? = null,
) {
    val pal = LocalPal.current
    val (bg, fg, border) = when (kind) {
        BtnKind.PRIMARY -> Triple(pal.accent, pal.accentInk, Color.Transparent)
        BtnKind.GHOST -> Triple(pal.surface, color ?: pal.ink, pal.line)
        BtnKind.DANGER -> Triple(pal.bad, pal.badInk, Color.Transparent)
        BtnKind.SMALL -> Triple(pal.surface, color ?: pal.ink, color ?: pal.ink)
    }
    val small = kind == BtnKind.SMALL
    val shape = RoundedCornerShape(if (small) 6.dp else 8.dp)
    Row(
        modifier
            .graphicsLayer { alpha = if (enabled) 1f else 0.45f }
            .defaultMinSize(minHeight = if (small) 36.dp else 46.dp)
            .background(bg, shape)
            .border(1.dp, border, shape)
            .pressable(onClick, enabled, haptic = kind == BtnKind.PRIMARY || kind == BtnKind.DANGER)
            .padding(horizontal = if (small) 14.dp else 18.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) { icon(); Spacer(Modifier.width(8.dp)) }
        Txt(text, size = if (small) 14f else 15f, weight = FontWeight.SemiBold, color = fg, align = TextAlign.Center)
    }
}

@Composable
fun LinkDanger(text: String, onClick: () -> Unit) {
    val pal = LocalPal.current
    Txt(text, Modifier.clickable(onClick = onClick).padding(vertical = 10.dp), weight = FontWeight.SemiBold, color = pal.bad)
}

@Composable
fun LinkBtn(text: String, onClick: () -> Unit, size: Float = 14f) {
    val pal = LocalPal.current
    Txt(text, Modifier.clickable(onClick = onClick).padding(vertical = 4.dp), size = size, weight = FontWeight.SemiBold, color = pal.accentStrong)
}

/* ================= kepingan kecil ================= */

enum class Tone { GOOD, BAD, WARN, NEUTRAL, INFO }

@Composable
fun Pill(text: String, tone: Tone) {
    val pal = LocalPal.current
    val (bg, fg) = when (tone) {
        Tone.GOOD -> pal.goodSoft to pal.good
        Tone.BAD -> pal.badSoft to pal.bad
        Tone.WARN -> pal.warnSoft to pal.warn
        Tone.INFO -> pal.accentSoft to pal.accentStrong
        Tone.NEUTRAL -> pal.surface2 to pal.muted
    }
    val shape = RoundedCornerShape(4.dp)
    Box(
        Modifier.background(bg, shape)
            .then(if (tone == Tone.NEUTRAL) Modifier.border(1.dp, pal.line, shape) else Modifier)
            .padding(horizontal = 8.dp, vertical = 3.dp),
    ) { Txt(text, size = 12f, weight = FontWeight.SemiBold, color = fg, maxLines = 1) }
}

@Composable
fun Notice(text: AnnotatedString, tone: Tone, btn: String? = null, onBtn: () -> Unit = {}) {
    val pal = LocalPal.current
    val (bg, fg) = when (tone) {
        Tone.WARN -> pal.warnSoft to pal.warn
        Tone.BAD -> pal.badSoft to pal.bad
        else -> pal.accentSoft to pal.accentStrong
    }
    Row(
        Modifier.fillMaxWidth().background(bg).hairlines(pal.line, top = true, bottom = true).padding(horizontal = GL, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Txt(text, Modifier.weight(1f), size = 14f, color = fg)
        if (btn != null) { Spacer(Modifier.width(12.dp)); Btn(btn, onBtn, kind = BtnKind.SMALL, color = fg) }
    }
}

@Composable
fun Empty(text: AnnotatedString) {
    val pal = LocalPal.current
    Block { Txt(text, size = 14f, color = pal.muted) }
}

@Composable
fun Note(text: String, modifier: Modifier = Modifier, align: TextAlign? = null) {
    val pal = LocalPal.current
    Txt(text, modifier.padding(horizontal = GL), size = 12.5f, color = pal.muted, align = align)
}

/** Palang kemajuan (hijau dalam sasaran, oren hampir, merah lebih). */
@Composable
fun Bar(frac: Double, modifier: Modifier = Modifier, over: Boolean = false, warn: Boolean = false, h: Dp = 6.dp) {
    val pal = LocalPal.current
    val f by animateFloatAsState(targetValue = frac.coerceIn(0.0, 1.0).toFloat(), animationSpec = tween(700, easing = IosOut), label = "bar")
    val col = if (over) pal.bad else if (warn) pal.warn else pal.accent
    Box(modifier.fillMaxWidth().height(h).background(pal.track, RoundedCornerShape(2.dp))) {
        Box(Modifier.fillMaxWidth(f).fillMaxHeight().background(col, RoundedCornerShape(2.dp)))
    }
}

/* ================= jumlah beranimasi ================= */

@Composable
fun MoneyAnim(v: Double, size: Float, weight: FontWeight = FontWeight.SemiBold, color: Color = Color.Unspecified, plus: Boolean = false) {
    val a by animateFloatAsState(targetValue = v.toFloat(), animationSpec = tween(700, easing = IosOut), label = "wang")
    val shown = if (Math.abs(a - v) < 0.01) v else a.toDouble()
    Txt(if (plus) Mp(shown) else M(shown), size = size, weight = weight, color = color, num = true, maxLines = 1)
}

/* ================= blok utama ================= */

@Composable
fun Hero(eyebrow: String, amount: Double, neg: Boolean = false, content: @Composable ColumnScope.() -> Unit = {}) {
    val pal = LocalPal.current
    Block(Modifier.padding(0.dp)) {
        Txt(eyebrow, size = 12f, color = pal.muted)
        Spacer(Modifier.height(4.dp))
        MoneyAnim(amount, 30f, color = if (neg) pal.bad else pal.ink)
        Spacer(Modifier.height(6.dp))
        content()
    }
}

class TileData(val label: String, val value: String, val sub: String, val onClick: () -> Unit)

@Composable
fun Tiles(items: List<TileData>) {
    val pal = LocalPal.current
    Column(Modifier.fillMaxWidth().background(pal.line).padding(vertical = 1.dp), verticalArrangement = Arrangement.spacedBy(1.dp)) {
        items.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(1.dp)) {
                row.forEachIndexed { i, t ->
                    Column(
                        Modifier.weight(1f).fillMaxHeight().background(pal.surface).pressable(t.onClick, scaleTo = 0.97f)
                            .padding(start = if (i == 0) GL else 16.dp, end = if (i == 0) 16.dp else GL, top = 12.dp, bottom = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(3.dp),
                    ) {
                        Txt(t.label, size = 12.5f, color = pal.muted)
                        Txt(t.value, size = 17f, weight = FontWeight.SemiBold, num = true, maxLines = 1)
                        Txt(t.sub, size = 12f, color = pal.muted)
                    }
                }
                if (row.size == 1) Box(Modifier.weight(1f).fillMaxHeight().background(pal.surface))
            }
        }
    }
}

@Composable
fun Stats(items: List<Pair<String, String>>) {
    val pal = LocalPal.current
    Row(Modifier.fillMaxWidth().background(pal.line).padding(vertical = 1.dp).height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(1.dp)) {
        items.forEachIndexed { i, (v, l) ->
            Column(Modifier.weight(1f).fillMaxHeight().background(pal.surface).padding(start = if (i == 0) GL else 12.dp, end = 8.dp, top = 10.dp, bottom = 10.dp)) {
                Txt(v, size = 17f, weight = FontWeight.SemiBold, num = true, maxLines = 1)
                Txt(l, size = 11.5f, color = pal.muted)
            }
        }
    }
}

@Composable
fun SumStrip(masuk: Double, keluar: Double, la: String = "Masuk", lb: String = "Keluar", nota: String? = null) {
    val pal = LocalPal.current
    val bz = PG.round2(masuk - keluar)
    Column(Modifier.fillMaxWidth().background(pal.surface).hairlines(pal.line).padding(start = GL, end = GL, top = 8.dp, bottom = 10.dp)) {
        Row(Modifier.fillMaxWidth()) {
            listOf(Triple(la, masuk, pal.inn), Triple(lb, keluar, pal.out), Triple("Baki", bz, if (bz < -0.004) pal.out else pal.ink)).forEach { (l, v, c) ->
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Txt(l, size = 12.5f, color = pal.muted)
                    MoneyAnim(v, 16f, weight = FontWeight.Medium, color = c)
                }
            }
        }
        if (nota != null) { Spacer(Modifier.height(6.dp)); Txt(nota, size = 11.5f, color = pal.muted, align = TextAlign.Center, modifier = Modifier.fillMaxWidth()) }
    }
}

/** Tab teks bergaris bawah (Komitmen | Hutang, Kalendar | Senarai, Hadir | OT | Disiplin). */
@Composable
fun Seg(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    val pal = LocalPal.current
    val tick = rememberTick()
    Row(Modifier.fillMaxWidth().background(pal.surface).hairlines(pal.line)) {
        options.forEach { (id, label) ->
            val on = id == selected
            val col by animateColorAsState(if (on) pal.ink else pal.muted, label = "seg")
            val ul by animateFloatAsState(if (on) 1f else 0f, animationSpec = tween(220), label = "segul")
            Box(
                Modifier.weight(1f).height(46.dp).clickable { if (!on) tick(); onSelect(id) }.drawBehind {
                    if (ul > 0f) {
                        val w = size.width * ul
                        drawLine(pal.accent, Offset((size.width - w) / 2, size.height - 1.dp.toPx()), Offset((size.width + w) / 2, size.height - 1.dp.toPx()), strokeWidth = 2.dp.toPx())
                    }
                },
                contentAlignment = Alignment.Center,
            ) { Txt(label, size = 15f, weight = if (on) FontWeight.SemiBold else FontWeight.Medium, color = col) }
        }
    }
}

@Composable
fun NavRow(label: String, sub: String? = null, onPrev: () -> Unit, onNext: () -> Unit) {
    val pal = LocalPal.current
    Row(
        Modifier.fillMaxWidth().background(pal.surface).hairlines(pal.line).padding(horizontal = 12.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(40.dp).pressable(onPrev, scaleTo = 0.85f), contentAlignment = Alignment.Center) { Txt("‹", size = 26f, color = pal.muted) }
        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
            Txt(label, size = 16f, weight = FontWeight.SemiBold, align = TextAlign.Center)
            if (sub != null) Txt(sub, size = 12.5f, color = pal.muted, align = TextAlign.Center)
        }
        Box(Modifier.size(40.dp).pressable(onNext, scaleTo = 0.85f), contentAlignment = Alignment.Center) { Txt("›", size = 26f, color = pal.muted) }
    }
}

/** Kad ringkasan (Komitmen bulan ini, bayaran hutang). */
@Composable
fun SummaryCard(eyebrow: String, big: Double, of: Double, frac: Double, line: AnnotatedString, lineMuted: Boolean) {
    val pal = LocalPal.current
    Block {
        Txt(eyebrow, size = 12f, color = pal.muted)
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            MoneyAnim(big, 22f)
            Spacer(Modifier.weight(1f))
            Txt(rich("daripada **" + M(of) + "**"), size = 13f, color = pal.muted)
        }
        Spacer(Modifier.height(10.dp))
        Bar(frac, h = 8.dp)
        Spacer(Modifier.height(10.dp))
        Txt(line, size = 13f, color = if (lineMuted) pal.muted else pal.ink)
    }
}

/* ================= penyata (slip) ================= */

@Composable
fun Slip(headL: String, headR: String, content: @Composable ColumnScope.() -> Unit) {
    val pal = LocalPal.current
    Block(pad = false) {
        Column(Modifier.padding(horizontal = GL).padding(top = 6.dp, bottom = 10.dp)) {
            Row(Modifier.fillMaxWidth().hairlines(pal.line).padding(vertical = 8.dp)) {
                Txt(headL, Modifier.weight(1f), size = 12f, color = pal.muted)
                Txt(headR, size = 12f, color = pal.muted)
            }
            content()
        }
    }
}

@Composable
fun SlipRow(lbl: String, v: String, total: Boolean = false) {
    val pal = LocalPal.current
    Row(Modifier.fillMaxWidth().hairlines(pal.line).padding(vertical = if (total) 9.dp else 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Txt(lbl, Modifier.weight(1f), size = 13.5f, weight = if (total) FontWeight.Bold else FontWeight.Normal)
        Spacer(Modifier.width(8.dp))
        Txt(v, size = 13.5f, weight = if (total) FontWeight.Bold else FontWeight.Normal, num = true)
    }
}

@Composable
fun SlipNote(text: AnnotatedString) {
    val pal = LocalPal.current
    Txt(text, Modifier.padding(top = 8.dp), size = 12f, color = pal.muted)
}

/** Senarai kunci–nilai bergaris. */
@Composable
fun Kvl(rows: List<Triple<AnnotatedString, String, Color?>>, strongIdx: Set<Int> = emptySet()) {
    val pal = LocalPal.current
    Column(Modifier.fillMaxWidth()) {
        rows.forEachIndexed { i, (k, v, c) ->
            Row(
                Modifier.fillMaxWidth().then(if (i < rows.size - 1) Modifier.hairlines(pal.line) else Modifier).padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Txt(k, Modifier.weight(1f), size = 14f, weight = if (i in strongIdx) FontWeight.SemiBold else FontWeight.Normal)
                Spacer(Modifier.width(12.dp))
                Txt(v, size = 15f, weight = FontWeight.SemiBold, color = c ?: pal.ink, num = true)
            }
        }
    }
}

/* ================= suis ================= */

@Composable
fun Switch2(checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    val pal = LocalPal.current
    val x by animateFloatAsState(targetValue = if (checked) 1f else 0f, animationSpec = spring(dampingRatio = 0.6f, stiffness = 500f), label = "suis")
    val bg by animateColorAsState(if (checked) pal.accent else pal.lineStrong, label = "suisbg")
    val tick = rememberTick(strong = true)
    Box(
        Modifier.width(48.dp).height(28.dp).graphicsLayer { alpha = if (enabled) 1f else 0.45f }
            .background(bg, RoundedCornerShape(14.dp))
            .clickable(enabled = enabled) { tick(); onChange(!checked) },
    ) {
        Box(
            Modifier.padding(3.dp).graphicsLayer { translationX = x * 20.dp.toPx() }
                .size(22.dp).background(Color.White, CircleShape),
        )
    }
}

@Composable
fun StatusRow(title: String, sub: String? = null, trailing: @Composable () -> Unit) {
    val pal = LocalPal.current
    Row(
        Modifier.fillMaxWidth().background(pal.surface).hairlines(pal.line).defaultMinSize(minHeight = 52.dp).padding(horizontal = GL, vertical = 12.dp),
        verticalAlignment = if (sub != null) Alignment.Top else Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Txt(title, size = 14f, weight = if (sub != null) FontWeight.Bold else FontWeight.Normal)
            if (sub != null) Txt(sub, size = 13f, color = pal.muted)
        }
        Spacer(Modifier.width(12.dp))
        trailing()
    }
}

/* ================= borang gaya lejar ================= */

/** Lebar label & mod tulisan besar untuk semua baris borang. */
class FormLayout(val labelW: Dp, val stackAll: Boolean)
val LocalForm = staticCompositionLocalOf { FormLayout(120.dp, false) }
val LocalSaiz = staticCompositionLocalOf { 14 }

@Composable
fun Form(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val saiz = LocalSaiz.current
    BoxWithConstraints(modifier.fillMaxWidth()) {
        val lw = (maxWidth * 0.34f).coerceIn(88.dp, 160.dp)
        val fl = FormLayout(lw, saiz >= 17 && maxWidth < 440.dp)
        CompositionLocalProvider(LocalForm provides fl) {
            Column(Modifier.fillMaxWidth(), content = content)
        }
    }
}

@Composable
private fun FieldShell(label: String, stack: Boolean, ai: Boolean, minH: Dp = 52.dp, content: @Composable ColumnScope.() -> Unit) {
    val pal = LocalPal.current
    val fl = LocalForm.current
    val st = stack || fl.stackAll
    val lbl: @Composable (Modifier) -> Unit = { m ->
        Row(m, verticalAlignment = Alignment.CenterVertically) {
            Txt(label, size = 14f, weight = FontWeight.Medium, color = pal.muted, lh = 18f)
            if (ai) {
                Spacer(Modifier.width(6.dp))
                Box(Modifier.background(pal.accentSoft, RoundedCornerShape(3.dp)).padding(horizontal = 4.dp, vertical = 1.dp)) {
                    Txt("AI", size = 10.5f, weight = FontWeight.Bold, color = pal.accentStrong)
                }
            }
        }
    }
    if (st) {
        Column(Modifier.fillMaxWidth().background(pal.surface).hairlines(pal.line).padding(horizontal = GL).padding(top = 10.dp, bottom = 8.dp)) {
            lbl(Modifier.padding(bottom = 6.dp))
            content()
        }
    } else {
        Row(
            Modifier.fillMaxWidth().background(pal.surface).hairlines(pal.line).heightIn(min = minH).padding(horizontal = GL, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            lbl(Modifier.width(fl.labelW).padding(vertical = 8.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), content = content)
        }
    }
}

@Composable
fun FieldText(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    placeholder: String = "",
    kb: KeyboardType = KeyboardType.Text,
    big: Boolean = false,
    small: String? = null,
    smallColor: Color? = null,
    readOnly: Boolean = false,
    password: Boolean = false,
    stack: Boolean = false,
    ai: Boolean = false,
    fr: FocusRequester? = null,
    maxLen: Int = 200,
    lines: Int = 1,
    after: (@Composable () -> Unit)? = null,
) {
    val pal = LocalPal.current
    var focused by remember { mutableStateOf(false) }
    FieldShell(label, stack, ai, minH = if (big) 62.dp else 52.dp) {
        val ts = TextStyle(
            fontSize = if (big) 24.sp else 16.sp,
            fontWeight = if (big) FontWeight.SemiBold else FontWeight.Normal,
            color = if (readOnly) pal.muted else pal.ink,
            fontFeatureSettings = "tnum",
        )
        BasicTextField(
            value = value,
            onValueChange = { if (it.length <= maxLen) onChange(it) },
            modifier = Modifier.fillMaxWidth()
                .then(if (fr != null) Modifier.focusRequester(fr) else Modifier)
                .onFocusChanged { focused = it.isFocused }
                .drawBehind {
                    if (focused && !readOnly) drawLine(pal.accent, Offset(0f, size.height - 1.dp.toPx()), Offset(size.width, size.height - 1.dp.toPx()), strokeWidth = 2.dp.toPx())
                },
            readOnly = readOnly,
            textStyle = ts,
            singleLine = lines == 1,
            minLines = lines,
            maxLines = if (lines == 1) 1 else 8,
            keyboardOptions = KeyboardOptions(keyboardType = if (password) KeyboardType.Password else kb),
            visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
            cursorBrush = SolidColor(pal.accent),
            decorationBox = { inner ->
                Box(Modifier.fillMaxWidth().defaultMinSize(minHeight = if (big) 50.dp else 42.dp).padding(vertical = 8.dp), contentAlignment = Alignment.CenterStart) {
                    if (value.isEmpty() && placeholder.isNotEmpty()) Text(placeholder, style = ts.copy(color = pal.muted.copy(alpha = 0.75f)), maxLines = 1)
                    inner()
                }
            },
        )
        if (after != null) after()
        if (small != null && small.isNotEmpty()) Txt(small, Modifier.padding(bottom = 8.dp), size = 12.5f, color = smallColor ?: pal.muted, lh = 17f)
    }
}

/** Pilihan radio sebagai kotak kecil bucu rata. */
@Composable
fun FieldChips(
    label: String,
    options: List<Pair<String, String>>,
    selected: String,
    onSelect: (String) -> Unit,
    stack: Boolean? = null,
    ai: Boolean = false,
    note: (@Composable () -> Unit)? = null,
) {
    val st = stack ?: (options.size >= 4 || options.sumOf { it.second.length } > 28)
    FieldShell(label, st, ai) {
        Chips(options, selected, onSelect, Modifier.padding(vertical = if (st) 0.dp else 7.dp))
        if (note != null) Box(Modifier.padding(top = 6.dp, bottom = 4.dp)) { note() }
    }
}

@Composable
fun Chips(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit, modifier: Modifier = Modifier) {
    val pal = LocalPal.current
    FlowRow(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        options.forEach { (id, lbl) ->
            val on = id == selected
            val bg by animateColorAsState(if (on) pal.accentSoft else Color.Transparent, label = "chipbg")
            val bd by animateColorAsState(if (on) pal.accent else pal.line, label = "chipbd")
            val shape = RoundedCornerShape(4.dp)
            Box(
                Modifier.defaultMinSize(minHeight = 36.dp).background(bg, shape).border(1.dp, bd, shape)
                    .pressable({ onSelect(id) }, scaleTo = 0.93f).padding(horizontal = 12.dp, vertical = 6.dp),
                contentAlignment = Alignment.Center,
            ) { Txt(lbl, size = 14f, weight = if (on) FontWeight.SemiBold else FontWeight.Medium, color = if (on) pal.accentStrong else pal.ink) }
        }
    }
}

/** Satu pilihan dalam grid: label (maks 2 baris) dan tag kecil pilihan di bawahnya. */
class GridOpt(val id: String, val label: String, val sub: String? = null)

/** Pilihan dalam grid lajur sama lebar (cth pilihan poket, 4 lajur). Label sentiasa di atas grid. */
@Composable
fun FieldGrid(
    label: String,
    options: List<GridOpt>,
    selected: String,
    onSelect: (String) -> Unit,
    cols: Int = 4,
    ai: Boolean = false,
    note: (@Composable () -> Unit)? = null,
) {
    FieldShell(label, true, ai) {
        GridChips(options, selected, onSelect, cols)
        if (note != null) Box(Modifier.padding(top = 6.dp, bottom = 4.dp)) { note() }
    }
}

@Composable
fun GridChips(options: List<GridOpt>, selected: String, onSelect: (String) -> Unit, cols: Int = 4) {
    val pal = LocalPal.current
    Column(Modifier.fillMaxWidth().padding(bottom = 2.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        options.chunked(cols).forEach { row ->
            Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                row.forEach { o ->
                    val on = o.id == selected
                    val bg by animateColorAsState(if (on) pal.accentSoft else Color.Transparent, label = "gridbg")
                    val bd by animateColorAsState(if (on) pal.accent else pal.line, label = "gridbd")
                    val shape = RoundedCornerShape(6.dp)
                    Column(
                        Modifier.weight(1f).fillMaxHeight().defaultMinSize(minHeight = 50.dp)
                            .pressable({ onSelect(o.id) }, scaleTo = 0.92f, haptic = true)
                            .background(bg, shape).border(if (on) 1.5.dp else 1.dp, bd, shape)
                            .padding(horizontal = 4.dp, vertical = 6.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Txt(o.label, size = 12.5f, weight = if (on) FontWeight.SemiBold else FontWeight.Medium,
                            color = if (on) pal.accentStrong else pal.ink, align = TextAlign.Center, maxLines = 2, lh = 16f)
                        val sub = o.sub
                        if (sub != null) Txt(sub, size = 10.5f, color = if (on) pal.accentStrong else pal.muted, align = TextAlign.Center, maxLines = 1)
                    }
                }
                repeat(cols - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
fun FieldDate(label: String, value: String, onChange: (String) -> Unit, ai: Boolean = false, small: String? = null) {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    FieldShell(label, false, ai) {
        Box(
            Modifier.fillMaxWidth().defaultMinSize(minHeight = 42.dp).clickable {
                val p = runCatching { PG.parse(value) }.getOrNull() ?: PG.parse(PG.todayISO())
                android.app.DatePickerDialog(ctx, { _, y, m, d -> onChange(PG.iso(y, m + 1, d)) }, p.y, p.m - 1, p.d).show()
            }.padding(vertical = 8.dp),
            contentAlignment = Alignment.CenterStart,
        ) {
            Txt(if (value.isNotEmpty()) PG.fmtDate(value) else "Pilih tarikh", size = 16f, color = if (value.isNotEmpty()) pal.ink else pal.muted, num = true)
        }
        if (small != null) Txt(small, Modifier.padding(bottom = 8.dp), size = 12.5f, color = pal.muted, lh = 17f)
    }
}

class SelOpt(val id: String, val label: String, val header: Boolean = false)

@Composable
fun FieldSelect(label: String, options: List<SelOpt>, selected: String, onSelect: (String) -> Unit, ai: Boolean = false, small: String? = null) {
    val pal = LocalPal.current
    var open by remember { mutableStateOf(false) }
    FieldShell(label, false, ai) {
        Box {
            Row(
                Modifier.fillMaxWidth().defaultMinSize(minHeight = 42.dp).clickable { open = true }.padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Txt(options.firstOrNull { it.id == selected && !it.header }?.label ?: options.firstOrNull()?.label ?: "", Modifier.weight(1f), size = 16f, maxLines = 1)
                Txt("⌄", size = 18f, color = pal.muted)
            }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                options.forEach { o ->
                    if (o.header) {
                        Txt(o.label, Modifier.padding(horizontal = 16.dp, vertical = 6.dp), size = 12.5f, weight = FontWeight.SemiBold, color = pal.muted)
                    } else {
                        DropdownMenuItem(
                            text = { Txt(o.label, size = 15f, weight = if (o.id == selected) FontWeight.SemiBold else FontWeight.Normal, color = if (o.id == selected) pal.accentStrong else pal.ink) },
                            onClick = { open = false; onSelect(o.id) },
                        )
                    }
                }
            }
        }
        if (small != null && small.isNotEmpty()) Txt(small, Modifier.padding(bottom = 8.dp), size = 12.5f, color = pal.muted, lh = 17f)
    }
}

@Composable
fun FieldCheck(label: String, checked: Boolean, onChange: (Boolean) -> Unit, small: String? = null) {
    val pal = LocalPal.current
    FieldShell(label, false, false) {
        Checkbox(
            checked = checked, onCheckedChange = onChange,
            colors = CheckboxDefaults.colors(checkedColor = pal.accent, uncheckedColor = pal.lineStrong, checkmarkColor = pal.accentInk),
        )
        if (small != null) Txt(small, Modifier.padding(bottom = 8.dp), size = 12.5f, color = pal.muted, lh = 17f)
    }
}

/** Tab jenis transaksi (bergaris bawah, boleh leret). */
@Composable
fun JTabs(options: List<Pair<String, String>>, selected: String, colorFor: (String) -> Color?, onSelect: (String) -> Unit) {
    val pal = LocalPal.current
    val tick = rememberTick()
    Row(Modifier.fillMaxWidth().background(pal.surface).hairlines(pal.line).horizontalScroll(rememberScrollState()).padding(horizontal = 4.dp)) {
        options.forEach { (id, lbl) ->
            val on = id == selected
            val c = if (on) (colorFor(id) ?: pal.ink) else pal.muted
            val ulc = if (on) (colorFor(id) ?: pal.accent) else Color.Transparent
            Box(
                Modifier.height(46.dp).clickable { if (!on) tick(); onSelect(id) }.drawBehind {
                    if (on) drawLine(ulc, Offset(0f, size.height - 1.dp.toPx()), Offset(size.width, size.height - 1.dp.toPx()), strokeWidth = 2.dp.toPx())
                }.padding(horizontal = 12.dp),
                contentAlignment = Alignment.Center,
            ) { Txt(lbl, size = 14f, weight = if (on) FontWeight.SemiBold else FontWeight.Medium, color = c, maxLines = 1) }
        }
    }
}

@Composable
fun FormError(text: String?) {
    val pal = LocalPal.current
    if (text.isNullOrEmpty()) return
    Txt(
        text,
        Modifier.padding(top = 10.dp).fillMaxWidth().background(pal.badSoft, RoundedCornerShape(4.dp)).padding(horizontal = 12.dp, vertical = 10.dp),
        size = 13.5f, color = pal.bad,
    )
}

/** Kotak perbandingan (semak bank, kemas kini baki). */
@Composable
fun Compare(content: @Composable ColumnScope.() -> Unit) {
    val pal = LocalPal.current
    Column(
        Modifier.fillMaxWidth().background(pal.surface2).hairlines(pal.line).padding(horizontal = GL, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
        content = content,
    )
}

@Composable
fun KvLine(k: String, v: @Composable () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Txt(k, Modifier.weight(1f), size = 13.5f)
        v()
    }
}

@Composable
fun Preview(text: AnnotatedString, modifier: Modifier = Modifier) {
    val pal = LocalPal.current
    Txt(text, modifier.padding(horizontal = GL, vertical = 10.dp), size = 13.5f, color = pal.muted)
}

/** Butang tindakan bawah helaian: Batal | Simpan, kemudian zon padam jika ada. */
@Composable
fun SheetActions(
    primary: String,
    onPrimary: () -> Unit,
    onCancel: () -> Unit,
    cancel: String = "Batal",
    primaryKind: BtnKind = BtnKind.PRIMARY,
    extra: String? = null,
    onExtra: () -> Unit = {},
) {
    Row(Modifier.fillMaxWidth().padding(horizontal = GL).padding(top = 12.dp, bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Btn(cancel, onCancel, Modifier.weight(1f), kind = BtnKind.GHOST)
        if (extra != null) Btn(extra, onExtra, Modifier.weight(1f), kind = BtnKind.GHOST)
        if (primary.isNotEmpty()) Btn(primary, onPrimary, Modifier.weight(1f), kind = primaryKind)
    }
}

/** Label dua baris: utama + keterangan kecil kelabu. */
fun two(main: String, sub: String?, muted: Color): AnnotatedString = buildAnnotatedString {
    append(main)
    if (!sub.isNullOrEmpty()) { append("\n"); withStyle(SpanStyle(fontSize = 12.sp, color = muted, fontWeight = FontWeight.Normal)) { append(sub) } }
}

/** Zon padam dengan pengesahan dua langkah. */
@Composable
fun DelZone(label: String, confirm: String, onDel: () -> Unit, blocked: String? = null) {
    val pal = LocalPal.current
    var ask by remember { mutableStateOf(false) }
    Column(Modifier.padding(horizontal = GL)) {
        if (!ask) LinkDanger(label) { ask = true }
        else {
            Column(
                Modifier.fillMaxWidth().padding(vertical = 8.dp).background(pal.badSoft, RoundedCornerShape(12.dp)).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Txt(blocked ?: confirm, size = 14f, color = pal.bad)
                if (blocked == null) Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Btn("Tak jadi", { ask = false }, Modifier.weight(1f), kind = BtnKind.GHOST)
                    Btn("Padam", onDel, Modifier.weight(1f), kind = BtnKind.DANGER)
                }
            }
        }
    }
}

@Composable
fun SheetTitle(text: String, sub: AnnotatedString? = null) {
    val pal = LocalPal.current
    Column(Modifier.padding(horizontal = GL).padding(bottom = 10.dp)) {
        Txt(text, size = 20f, weight = FontWeight.Bold, lh = 26f)
        if (sub != null) { Spacer(Modifier.height(4.dp)); Txt(sub, size = 13.5f, color = pal.muted) }
    }
}

@Composable
fun MenuBtn(text: String, onClick: () -> Unit, primary: Boolean = false, color: Color? = null) {
    Btn(text, onClick, Modifier.fillMaxWidth().padding(horizontal = GL, vertical = 4.dp), kind = if (primary) BtnKind.PRIMARY else BtnKind.GHOST, color = color)
}
