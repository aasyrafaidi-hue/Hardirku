# HadirKu tiada reflection sendiri. Peraturan untuk WorkManager, Play Services
# dan Compose sudah dibekalkan oleh perpustakaan masing-masing.
-keepattributes SourceFile,LineNumberTable
