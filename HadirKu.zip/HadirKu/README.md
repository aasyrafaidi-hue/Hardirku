# Duitku — urus duit + kehadiran kerja dalam satu app

App Android native (Kotlin + Jetpack Compose), dahulu dikenali sebagai **HadirKu**. Gabungan rekod kehadiran (disiplin, geofence, amaran lupa check-in) dan **PoketGaji v0.9.3** (poket, lejar harian, komitmen, hutang, OT, laporan, AI, fail CFO). Rupa ikut PoketGaji — lejar rata, garis halus — dengan aksen **cyan lembut** (#0C7C8C cerah, #5CC3CF gelap). Masuk biru, keluar merah lembut.

> Nama pakej (`com.asyraf.hadirku`) dan kunci tandatangan kekal sama, jadi APK Duitku **update** atas HadirKu yang sedia ada — semua data kekal.

## Tab

| Tab | Isi |
|---|---|
| **Kerja → Hadir** | Butang check-in / check-out besar yang **berdenyut besar–kecil** dengan gelang riak, cap jari / muka, jarak ke kilang, streak, tepat masa, OT kitaran, skor, "OT hari ini vs belanja harian", jadual 7 hari |
| **Kerja → OT** | Kitaran 22hb–21hb, nilai OT, jam 1.5x / 2.0x / 3.0x, had OT, slip anggaran gaji, log harian (jam dari check-in/out terus masuk sini) |
| **Kerja → Disiplin** | Skor & gred, statistik kitaran, kalendar kehadiran, log, 12 pencapaian, jurulatih Claude, eksport CSV |
| **Poket** | Baki bank & e-wallet, semak bank, belum agih, senarai poket, jubin komitmen / OT / hutang / perbelanjaan |
| **Transaksi** | Kalendar & senarai lejar harian (OT dikira pendapatan), butiran hari |
| **Bayaran** | Komitmen 15hb / 30hb, hutang (kad, pinjaman, BNPL, EPP), bayar kad, pelan bebas hutang + carta |

> **Minimum kad kredit (lalai):** peratus minimum × (baki kad + pokok EPP belum dibil), sekurang-kurangnya minimum terendah (RM50) dan ansuran EPP bulan ini. Faedah EPP belum dibil dipaparkan berasingan daripada pokok. Boleh tukar per kad ke cara asal PoketGaji (ansuran EPP penuh + peratus baki biasa) dalam **Edit hutang → Minimum dikira daripada**.
| **Laporan** | Penyata pendapatan & perbelanjaan, OT vs belanja harian, donut poket / kategori, trend 6 bulan, OT 6 kitaran, belanja terbesar, fail CFO |
| **Tetapan (gear)** | Tema, saiz tulisan, gaji & OT, jadual shift, lokasi kilang, amaran lupa check-in, biometrik, Pembantu AI, cuti umum (Calendarific), poket, semakan bank, data |

## Bank, tunai dan e-wallet (diasingkan)
- Setiap poket ada tempat simpan: **Bank**, **Tunai (dompet)** atau **E-wallet** (Edit poket → *Duit poket ini disimpan di*).
- Tab Poket tunjuk **Baki dalam bank**, **Tunai dalam dompet**, e-wallet dan **Semua duit** secara berasingan. *Semak baki bank* hanya kira duit bank.
- Kad **Dompet tunai**: *Ambil ATM* (pindah dari poket bank → dompet tunai: bank turun, tunai naik), *Belanja* (belanja tunai, bank tak berubah), *Kira duit* (masukkan duit sebenar dalam dompet; beza direkod sebagai belanja tak direkod, duit masuk, atau pelarasan).
- Dompet Tunai dibuat sendiri sekali (selepas Belum Agih). Kalau sudah ada poket e-wallet bernama Tunai/Cash, poket itu yang ditukar jadi dompet tunai.
- Resit yang dibaca AI sebagai dibayar tunai terus pilih dompet tunai. Belanja guna kad kredit hanya dari poket bank.
- Dalam fail salinan, dompet tunai disimpan sebagai `"dompet": true, "tunai": true` — PoketGaji PWA membacanya sebagai e-wallet (tetap di luar bank).

## Susun & pilih poket
- Tab Poket atau Tetapan → Poket → **Susun**: anak panah naik/turun pada setiap poket. Belum Agih sentiasa di atas. Susunan ini dipakai di semua senarai dan pilihan poket, dan disimpan dalam fail salinan.
- Semua pilihan poket (transaksi, pindah, komitmen, hutang, bayar kad, tunai dari kad) dipaparkan dalam **grid 4 lajur** sama lebar; nama panjang turun ke baris kedua, dan poket tunai / e-wallet ada tag kecil.

## Satu sumber OT
Log OT PoketGaji ialah satu-satunya sumber OT. Bila check-out (atau edit rekod hari), jam di tempat kerja (dibundar ke bawah, lalai 30 minit) diisi ke log OT dengan jenis hari ikut jadual shift: hari kerja = Biasa, rest day = Rest, cuti umum = Umum, hari lain = Off, Cuti/MC = Tidak bekerja. Log masih boleh diubah manual.

## Salinan data
- **Simpan salinan** menghasilkan fail format PoketGaji v2 (`duitku-salinan-YYYY-MM-DD.json`) dengan bahagian tambahan `hadirku` (tetapan & rekod kehadiran — nama kunci dikekalkan supaya salinan lama tetap boleh dibaca). Fail ini masih boleh dibuka oleh PoketGaji PWA.
- **Pulihkan salinan** terima: salinan Duitku / gabungan, salinan PoketGaji biasa, atau salinan HadirKu v1. Hari yang ada rekod kehadiran lengkap tapi tiada log OT akan diisi sendiri.
- Kunci API (Anthropic, Calendarific) kekal dalam telefon, tidak masuk fail salinan.

## Bina APK di GitHub
1. Repo `Hadirmu` (private) sudah ada workflow `.github/workflows/build.yml` yang ekstrak `HadirKu.zip` (nama zip dikekalkan supaya workflow lama terus berfungsi).
2. Ganti `HadirKu.zip` dalam repo dengan zip baharu → **Commit changes**. (Pilihan: ganti juga `.github/workflows/build.yml` dengan versi dalam zip ini supaya fail APK dinamakan `Duitku-v2.0.N.apk`.)
3. Tab **Actions** → tunggu tanda hijau → **Releases** → muat turun APK.
4. Kunci tandatangan sama (`app/hadirku-release.jks`), jadi APK baharu **update** atas app lama tanpa padam rekod kehadiran.

## Kali pertama selepas update
Kalau app baru dipasang (bukan update), ia bermula dengan data contoh PoketGaji. Tekan **Pulihkan salinan** dan pilih fail salinan anda — semua poket, transaksi, komitmen, hutang, log OT dan rekod kehadiran dipulihkan.

## Dibuang
Pelan bertolak (cuaca Open-Meteo sepanjang laluan, trafik Google Routes / TomTom, notifikasi masa bertolak) dan lokasi rumah telah dibuang. Penggera dan kerja latar bertolak dari versi lama dibatalkan sendiri. Amaran lupa check-in dan check-in automatik (geofence kilang) kekal.

## Kongsi dengan isteri (Firebase)
App ini bersambung ke projek Firebase `duitku-isteri-1a996` yang sama dengan app **Duitku Isteri** (`app/google-services.json` mengandungi kedua-dua app).

| Ciri | Di mana |
|---|---|
| Senarai barang dikongsi (tambah, tick, rekod belanja, atau "Dah beli, tak perlu rekod") | Tab **Senarai** |
| Bil rumah dikongsi + kalendar + tanda siapa dah bayar; peringatan H-3 & H-1 pukul 8 pagi | **Bayaran → Bil rumah** |
| **Hantar nafkah**: dicatat sebagai Keluar dari poket kau, isteri tekan *Terima* dalam app dia | **Bayaran → Bil rumah** (bawah) |
| Projek (cth rumah baru): bajet vs belanja sebenar | **Bayaran → Projek** |
| Sambung ke rumah isteri guna kod 6 aksara | **Tetapan → Kongsi dengan isteri** |

Poket, transaksi, OT dan kehadiran kau kekal dalam telefon kau sahaja. Peraturan Firestore: `firestore.rules` (sama untuk kedua-dua app).
