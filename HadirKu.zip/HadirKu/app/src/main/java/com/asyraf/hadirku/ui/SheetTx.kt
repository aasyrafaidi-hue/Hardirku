package com.asyraf.hadirku.ui

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.asyraf.hadirku.MainViewModel
import com.asyraf.hadirku.Sheet
import com.asyraf.hadirku.ai.Ai
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.Tx
import kotlinx.coroutines.launch
import org.json.JSONObject

/** Pilih isi helaian ikut jenis. */
@Composable
fun SheetContent(vm: MainViewModel, s: Sheet) {
    when (s) {
        is Sheet.TxForm -> TxFormSheet(vm, s)
        is Sheet.PocketMenu -> PocketMenuSheet(vm, s.id)
        is Sheet.PocketForm -> PocketFormSheet(vm, s.id)
        is Sheet.Bank -> BankSheet(vm)
        is Sheet.KMenu -> KMenuSheet(vm, s.id)
        is Sheet.KForm -> KFormSheet(vm, s.id)
        is Sheet.HMenu -> HMenuSheet(vm, s.id)
        is Sheet.HForm -> HFormSheet(vm, s.id)
        is Sheet.CardPay -> CardPaySheet(vm, s.id)
        is Sheet.EppList -> EppListSheet(vm, s.id)
        is Sheet.EppForm -> EppFormSheet(vm, s.debtId, s.planId)
        is Sheet.HLog -> HLogSheet(vm, s.id, s.jenis)
        is Sheet.HHist -> HHistSheet(vm, s.id)
        is Sheet.PlanForm -> PlanFormSheet(vm)
        is Sheet.OtDay -> OtDaySheet(vm, s.date)
        is Sheet.Tunai -> TunaiSheet(vm, s)
        is Sheet.Day -> DaySheet(vm, s.date)
        is Sheet.KatList -> KatListSheet(vm, s.k)
        is Sheet.PoketList -> PoketListSheet(vm, s.id)
        is Sheet.Cfo -> CfoSheet(vm)
        is Sheet.TextOut -> TextOutSheet(vm, s.title, s.text)
        is Sheet.Confirm -> ConfirmSheet(vm, s)
        is Sheet.BackupMenu -> BackupSheet(vm)
        is Sheet.ImportAsk -> ImportSheet(vm, s)
        is Sheet.Attend -> AttendSheet(vm, s.date)
        is Sheet.Mood -> MoodSheet(vm, s.date)
        is Sheet.Coach -> CoachSheet(vm)
        is Sheet.Malas -> MalasSheet(vm)
        is Sheet.Far -> FarSheet(vm, s.dist)
        is Sheet.KiraTunai -> KiraTunaiSheet(vm, s.id)
        is Sheet.BilForm -> BilFormSheet(vm, s.id)
        is Sheet.BilMenu -> BilMenuSheet(vm, s.id, s.ym)
        is Sheet.ProjekForm -> ProjekFormSheet(vm, s.id)
        is Sheet.ItemForm -> ItemFormSheet(vm, s.pid, s.iid)
        is Sheet.BarangForm -> BarangFormSheet(vm)
    }
}

private fun legendFor(j: String) = when (j) {
    "kad" -> "Belanja untuk poket (bajet)"
    "masuk", "baki-awal", "pelarasan+" -> "Ke poket"
    else -> "Dari poket"
}

private fun numAi(v: Any?): Double = when (v) {
    is Number -> v.toDouble()
    is String -> v.replace(Regex("[^0-9.,\\-]"), "").replaceFirst(',', '.').toDoubleOrNull() ?: Double.NaN
    else -> Double.NaN
}

private fun okDate(s: String): Boolean = Regex("^\\d{4}-\\d{2}-\\d{2}$").matches(s) && runCatching { PG.addDays(s, 0) == s }.getOrDefault(false)

/** Paparan hasil imbasan resit. */
private class ScanView(
    val busy: Boolean = false,
    val thumb: Bitmap? = null,
    val pdf: Boolean = false,
    val title: String = "",
    val lines: List<String> = emptyList(),
    val warns: List<String> = emptyList(),
    val items: List<Pair<String, Double>> = emptyList(),
    val needKey: Boolean = false,
    val kadBtn: Boolean = false,
)

@Composable
private fun TxFormSheet(vm: MainViewModel, sh: Sheet.TxForm) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val la = launch()
    val scope = rememberCoroutineScope()
    val base = sh.base
    val isEdit = sh.editId != null
    val kads = s.debts.filter { it.jenis == "kad" }
    val jenisList = PG.JENIS.filter { it.id != "tunai-kad" && (it.id != "kad" || kads.isNotEmpty() || base.jenis == "kad") }
    var jenis by remember { mutableStateOf(base.jenis) }
    var tarikh by remember { mutableStateOf(base.tarikh.ifEmpty { vm.today() }) }
    var poket by remember { mutableStateOf(base.poket) }
    var ke by remember { mutableStateOf(base.ke) }
    var kadId by remember { mutableStateOf(if (base.jenis == "kad" && base.kadId.isEmpty() && kads.size == 1) kads[0].id else base.kadId) }
    var jumlah by remember { mutableStateOf(if (base.jumlah.isNaN()) "" else PG.toFixed(base.jumlah, 2)) }
    var perkara by remember { mutableStateOf(base.perkara) }
    var untuk by remember { mutableStateOf(if (base.komitmenId.isNotEmpty()) "k:" + base.komitmenId else if (base.hutangId.isNotEmpty()) "h:" + base.hutangId else "") }
    var catatan by remember { mutableStateOf(base.catatan) }
    var otRaw by remember { mutableStateOf(base.otBayar?.let { PG.toFixed(it, 2) } ?: "") }
    var kat by remember { mutableStateOf(if (PG.katValid(base.kategori)) base.kategori ?: "" else "") }
    var katSrc by remember { mutableStateOf(if (PG.katValid(base.kategori)) (if (base.katAuto) "ai" else "user") else "") }
    var err by remember { mutableStateOf("") }
    var scan by remember { mutableStateOf<ScanView?>(null) }
    var marks by remember { mutableStateOf(setOf<String>()) }
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { if (!isEdit) runCatching { fr.requestFocus() } }

    val hist = remember(s) { PG.kategoriSejarah(s) }
    val auto = katSrc == "" || katSrc == "sejarah"
    val effKat = if (auto) hist[PG.normNama(perkara)] ?: "" else kat
    val effSrc = if (auto) (if (effKat.isNotEmpty()) "sejarah" else "") else katSrc
    val untukHutang = jenis == "keluar" && untuk.startsWith("h:")
    val katShown = jenis == "kad" || (jenis == "keluar" && !untukHutang)
    val otShown = jenis == "masuk" && akruanOn(s)
    val dompet = s.pockets.filter { it.dompet }.map { it.id }.toSet()
    fun unmark(k: String) { if (k in marks) marks = marks - k }

    /* isi borang daripada jawapan AI */
    fun applyScan(d: JSONObject, thumb: Bitmap?, pdf: Boolean, usd: Double, secs: String) {
        if (d.has("boleh_baca") && !d.optBoolean("boleh_baca", true)) {
            scan = ScanView(thumb = thumb, pdf = pdf, title = "Tak dapat baca resit", warns = listOf(d.optString("nota").ifEmpty { "Gambar ini bukan resit atau terlalu kabur. Cuba ambil gambar semula dengan cahaya terang." }))
            return
        }
        val notes = ArrayList<String>()
        val mk = HashSet(marks)
        if (jenis != "keluar" && jenis != "kad") jenis = "keluar"
        val amt = numAi(d.opt("jumlah"))
        if (amt.isFinite() && amt > 0) { jumlah = PG.toFixed(Math.round(amt * 100) / 100.0, 2); mk.add("jumlah") } else notes.add("Jumlah tak dapat dibaca. Isi sendiri.")
        val tg = d.optString("tarikh").trim()
        val today = vm.today()
        if (okDate(tg) && tg <= today && tg >= PG.addDays(today, -366)) { tarikh = tg; mk.add("tarikh") }
        else if (tg.isNotEmpty()) notes.add("Tarikh dibaca ($tg) nampak pelik, jadi tarikh hari ini digunakan. Semak.")
        val kedai = d.optString("kedai").trim().take(80)
        if (kedai.isNotEmpty()) { perkara = kedai; mk.add("perkara") }
        val ring = d.optString("ringkasan").trim().take(120)
        if (ring.isNotEmpty()) { catatan = ring; mk.add("catatan") }
        val hk0 = Ai.kedaiPoket(s)[PG.normNama(kedai)]
        val bayar = d.optString("cara_bayar").ifEmpty { "tak_pasti" }
        val dwl = s.pockets.filter { it.dompet && !it.tunai }
        val tnl = s.pockets.filter { it.tunai }
        var pid = ""
        var dari = ""
        if (bayar == "ewallet" && dwl.isNotEmpty()) { pid = if (hk0 != null && dwl.any { it.id == hk0.poket }) hk0.poket else dwl[0].id; dari = "ewallet" }
        else if (bayar == "tunai" && tnl.isNotEmpty()) { pid = if (hk0 != null && tnl.any { it.id == hk0.poket }) hk0.poket else tnl[0].id; dari = "tunai" }
        else if (hk0 != null && s.pockets.any { it.id == hk0.poket } && (hk0.poket !in dompet || bayar == "tak_pasti" || bayar == "lain")) { pid = hk0.poket; dari = "sejarah" }
        else { val pAi = s.pockets.find { it.nama.equals(d.optString("poket"), ignoreCase = true) }; if (pAi != null) { pid = pAi.id; dari = "ai" } }
        if (pid.isNotEmpty()) { poket = pid; mk.add("poket") }
        var kk = ""
        var kd = ""
        if (katSrc != "user") {
            val hk = hist[PG.normNama(kedai)]
            if (hk != null) { kk = hk; kd = "sejarah" } else if (PG.katValid(d.optString("kategori"))) { kk = d.optString("kategori"); kd = "ai" }
            if (kk.isNotEmpty()) { kat = kk; katSrc = kd; mk.add("kat") }
        }
        val yakin = d.optString("keyakinan").ifEmpty { "sederhana" }
        if (yakin == "rendah") notes.add("Keyakinan rendah: semak semua maklumat dengan teliti.")
        if (d.optString("nota").isNotEmpty() && yakin != "tinggi") notes.add(d.optString("nota").take(200))
        val items = ArrayList<Pair<String, Double>>()
        val arr = d.optJSONArray("item")
        if (arr != null) for (i in 0 until minOf(arr.length(), 15)) {
            val it = arr.optJSONObject(i) ?: continue
            val v = numAi(it.opt("jumlah"))
            if (it.optString("nama").isNotEmpty() && v.isFinite()) items.add(it.optString("nama").take(60) to v)
        }
        marks = mk
        val lines = ArrayList<String>()
        lines.add("Dibaca AI · keyakinan " + yakin + " · " + secs + " s" + if (usd > 0) " · ~US$" + String.format(java.util.Locale.US, "%.4f", usd) else "")
        if (kk.isNotEmpty()) lines.add("Kategori: " + PG.katLabel(kk) + if (kd == "sejarah") " (ikut rekod lepas)" else "")
        lines.add((if (dari == "sejarah") "Poket ikut pilihan awak sebelum ini. " else if (dari == "ewallet") "Poket e-wallet sebab resit dibayar guna e-wallet. " else if (dari == "tunai") "Dompet tunai sebab resit dibayar tunai. " else "") + "Semak jumlah, tarikh dan poket sebelum simpan.")
        scan = ScanView(
            thumb = thumb, pdf = pdf, title = kedai.ifEmpty { "Resit" } + if (amt.isFinite() && amt > 0) " · " + M(amt) else "",
            lines = lines, warns = notes, items = items, kadBtn = bayar == "kad_kredit" && kads.isNotEmpty() && jenis != "kad",
        )
    }

    fun startScan(uri: android.net.Uri) {
        if (scan?.busy == true) return
        scan = ScanView(busy = true, title = "Membaca resit…", lines = listOf("Biasanya beberapa saat."))
        val t0 = System.currentTimeMillis()
        scope.launch {
            try {
                val prep = vm.prepFile(uri)
                scan = ScanView(busy = true, thumb = prep.thumb, pdf = prep.pdf, title = "Membaca resit…", lines = listOf("Biasanya beberapa saat."))
                val out = Ai.readReceipt(vm.pg.value, prep.block, prep.pdf, vm.today())
                applyScan(out.data, prep.thumb, prep.pdf, out.usd, PG.toFixed((System.currentTimeMillis() - t0) / 1000.0, 1))
            } catch (e: Exception) {
                val msg = e.message ?: "Ralat tidak diketahui."
                scan = ScanView(thumb = scan?.thumb, pdf = scan?.pdf ?: false, title = "Tak dapat baca resit", warns = listOf(msg), needKey = Regex("kunci api", RegexOption.IGNORE_CASE).containsMatchIn(msg))
            }
        }
    }

    fun save() {
        err = vm.saveTx(sh.editId, MainViewModel.TxInput(
            jenis, tarikh, poket, ke, kadId, jumlah, perkara, untuk, catatan, otShown, otRaw, katShown, effKat, effSrc,
        ))
    }

    SheetBody(actions = { SheetActions("Simpan", { save() }, { vm.close() }) }) {
        SheetTitle(sh.title ?: if (isEdit) "Edit transaksi" else "Transaksi baru")
        Form {
            JTabs(jenisList.map { it.id to it.label }, jenis, { j ->
                when (j) { "keluar", "pelarasan-" -> pal.out; "masuk", "pelarasan+", "baki-awal" -> pal.inn; else -> null }
            }) { j ->
                jenis = j
                if (j == "kad" && kadId.isEmpty() && kads.size == 1) kadId = kads[0].id
                if (j == "kad" && poket in dompet) poket = ""
            }
            if (!isEdit && (jenis == "keluar" || jenis == "kad")) {
                Row(Modifier.fillMaxWidth().background(pal.surface).hairlines(pal.line).padding(horizontal = GL, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Btn("Imbas resit (AI)", {
                        if (!Ai.ready()) scan = ScanView(title = "Perlu kunci API dulu", lines = listOf("Imbas resit guna AI Claude dengan kunci API awak sendiri (anggaran kurang 1 sen setiap imbasan)."), needKey = true)
                        else la.takePhoto { startScan(it) }
                    }, Modifier.weight(1f), color = pal.accentStrong, icon = { Ico(Ic.CAMERA, pal.accentStrong, 20.dp, stroke = 1.9f) })
                    Btn("Galeri / PDF", {
                        if (!Ai.ready()) scan = ScanView(title = "Perlu kunci API dulu", lines = listOf("Imbas resit guna AI Claude dengan kunci API awak sendiri (anggaran kurang 1 sen setiap imbasan)."), needKey = true)
                        else la.pickScan { startScan(it) }
                    }, color = pal.accentStrong)
                }
                val sv = scan
                if (sv != null) ScanBox(vm, sv) {
                    jenis = "kad"
                    if (kadId.isEmpty() && kads.size == 1) kadId = kads[0].id
                    if (poket in dompet) poket = ""
                    scan = ScanView(sv.busy, sv.thumb, sv.pdf, sv.title, sv.lines, sv.warns, sv.items, sv.needKey, false)
                }
            }
            if (jenis == "kad") {
                val kd = kads.find { it.id == kadId }
                FieldChips("Kad kredit", kads.map { it.id to it.nama }, kadId, { kadId = it }, note = {
                    Txt(if (kd == null) rich("Pilih kad yang digunakan.") else rich("Duit belum keluar dari bank. Baki " + kd.nama + " bertambah, dan jumlah ini dipindah ke poket **" + pname(s, kd.poket) + "** supaya cukup bila bayar kad nanti."), size = 12.5f, color = pal.muted)
                })
            }
            FieldText("Jumlah (RM)", jumlah, { jumlah = it; unmark("jumlah") }, placeholder = "0.00", kb = KeyboardType.Decimal, big = true, fr = fr, ai = "jumlah" in marks)
            val nota = aliranNota(s, jenis, poket, ke)
            FieldGrid(legendFor(jenis), pocketOpts(s.pockets.filter { !(jenis == "kad" && it.dompet) }), poket, { poket = it; unmark("poket") }, ai = "poket" in marks,
                note = notaUi(if (jenis != "pindah") nota else null))
            if (jenis == "pindah") FieldGrid("Ke poket", pocketOpts(s.pockets), ke, { ke = it },
                note = notaUi(nota))
            FieldText("Perkara", perkara, { perkara = it; unmark("perkara") }, placeholder = "cth: Barang dapur", maxLen = 80, ai = "perkara" in marks)
            if (katShown) {
                val opts = listOf(SelOpt("", if (Ai.ready() && Ai.autoKat()) "Auto" else "Tiada")) + PG.KATEGORI.map { SelOpt(it.id, it.label) }
                val note = when {
                    effSrc == "sejarah" -> "Ikut rekod lepas dengan nama sama."
                    effSrc == "ai" -> "Dipilih AI. Tukar jika salah."
                    effKat.isEmpty() -> if (Ai.ready() && Ai.autoKat()) "Biar Auto: AI pilih selepas simpan." else "Pilihan. Untuk carta belanja ikut kategori."
                    else -> ""
                }
                FieldSelect("Kategori", opts, effKat, { v -> kat = v; katSrc = if (v.isNotEmpty()) "user" else "kosong"; unmark("kat") }, ai = "kat" in marks, small = note)
            }
            FieldDate("Tarikh", tarikh, { tarikh = it; unmark("tarikh") }, ai = "tarikh" in marks)
            if (jenis == "keluar" && (s.commitments.isNotEmpty() || s.debts.isNotEmpty())) {
                val opts = ArrayList<SelOpt>()
                opts.add(SelOpt("", "Tiada"))
                if (s.commitments.isNotEmpty()) { opts.add(SelOpt("#k", "Komitmen", header = true)); s.commitments.forEach { opts.add(SelOpt("k:" + it.id, it.nama + " (" + M(it.jumlah) + ")")) } }
                if (s.debts.isNotEmpty()) { opts.add(SelOpt("#h", "Hutang", header = true)); s.debts.forEach { opts.add(SelOpt("h:" + it.id, it.nama)) } }
                FieldSelect("Bayaran untuk", opts, untuk, { uv ->
                    untuk = uv
                    var amt = 0.0
                    var nm = ""
                    var pk = ""
                    if (uv.startsWith("k:")) {
                        val c = PG.commitmentStatus(s, vm.today()).find { it.id == uv.substring(2) }
                        if (c != null) { amt = if (c.baki > 0) c.baki else c.jumlah; nm = c.nama; pk = c.poket }
                    } else if (uv.startsWith("h:")) {
                        val c = PG.debtStatus(s, vm.today()).find { it.id == uv.substring(2) }
                        if (c != null) { amt = (if (c.pelanBaki > 0.004) c.pelanBaki else c.bakiBayar).takeIf { it > 0 } ?: c.sasaran; nm = "Bayar " + c.nama; pk = c.poket }
                    }
                    if (nm.isNotEmpty()) {
                        if (jumlah.isEmpty() && amt > 0) jumlah = PG.toFixed(amt, 2)
                        if (perkara.isEmpty()) perkara = nm
                        if (poket.isEmpty()) poket = pk
                    }
                })
            }
            if (otShown) {
                val info = remember(s, tarikh, perkara, jumlah, sh.editId) {
                    PG.otAutoFor(s, Tx(id = sh.editId ?: "", jenis = "masuk", tarikh = tarikh, perkara = perkara, jumlah = vm.parseAmt(jumlah)))
                }
                val note = if (info == null) "" else {
                    val cyc = PG.fmtShort(info.cycle.start) + " – " + PG.fmtShort(info.cycle.end)
                    val sudah = info.sudah
                    when {
                        otRaw.trim().isNotEmpty() -> "Bahagian OT ini tak dikira pendapatan lagi kerana OT sudah dikira berasingan ikut kitaran OT. Kosongkan untuk kiraan auto."
                        info.auto > 0 -> "Auto: gaji ini termasuk OT " + cyc + " (" + M(info.nilai) + ") yang sudah dikira berasingan sebagai OT kitaran itu. Isi 0 kalau gaji ini tiada OT."
                        info.gaji && sudah != null -> "OT " + cyc + " sudah ditolak dalam duit masuk " + PG.fmtDate(sudah.tarikh) + "."
                        info.gaji -> "Tiada OT direkod untuk $cyc."
                        else -> "Isi kalau duit masuk ini termasuk bayaran OT, contohnya gaji."
                    }
                }
                FieldText("Termasuk OT (RM)", otRaw, { otRaw = it }, placeholder = if (info != null && info.auto > 0) "Auto " + PG.toFixed(info.auto, 2) else "0.00", kb = KeyboardType.Decimal, small = note)
            }
            FieldText("Catatan", catatan, { catatan = it; unmark("catatan") }, maxLen = 120, ai = "catatan" in marks)
        }
        Box(Modifier.padding(horizontal = GL)) { FormError(err) }
        if (isEdit) {
            Spacer(Modifier.height(8.dp))
            DelZone("Padam transaksi ini", "Padam transaksi ini? Baki poket akan dikira semula.", { vm.delTx(sh.editId ?: "") })
        }
    }
}

@Composable
private fun ScanBox(vm: MainViewModel, sv: ScanView, onKad: () -> Unit) {
    val pal = LocalPal.current
    var showItems by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().background(pal.surface2).hairlines(pal.line).padding(horizontal = GL, vertical = 10.dp), verticalAlignment = Alignment.Top) {
        val th = sv.thumb
        if (th != null) {
            Image(th.asImageBitmap(), contentDescription = "Gambar yang diimbas", modifier = Modifier.size(60.dp, 80.dp).border(1.dp, pal.line, RoundedCornerShape(4.dp)), contentScale = ContentScale.Crop)
            Spacer(Modifier.width(12.dp))
        } else if (sv.pdf) {
            Box(Modifier.size(60.dp, 80.dp).background(pal.surface, RoundedCornerShape(4.dp)).border(1.dp, pal.line, RoundedCornerShape(4.dp)), contentAlignment = Alignment.Center) {
                Txt("PDF", size = 13f, weight = FontWeight.Bold, color = pal.bad)
            }
            Spacer(Modifier.width(12.dp))
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Txt((if (sv.busy) "⏳ " else "") + sv.title, size = 13.5f, weight = FontWeight.SemiBold, color = if (sv.warns.isNotEmpty() && sv.lines.isEmpty()) pal.bad else pal.ink)
            sv.lines.forEach { Txt(it, size = 12.5f, color = pal.muted) }
            sv.warns.forEach { Txt(it, size = 12.5f, color = pal.bad) }
            if (sv.needKey) Btn("Ke Tetapan AI", { vm.aiSetup() }, kind = BtnKind.SMALL, color = pal.accentStrong)
            if (sv.kadBtn) Btn("Guna kad kredit? Tukar", onKad, kind = BtnKind.SMALL, color = pal.accentStrong)
            if (sv.items.isNotEmpty()) {
                LinkBtn((if (showItems) "▾ " else "▸ ") + sv.items.size + " item dibaca", { showItems = !showItems }, size = 12.5f)
                if (showItems) sv.items.forEach { (n, v) ->
                    Row(Modifier.fillMaxWidth().hairlines(pal.line).padding(vertical = 2.dp)) {
                        Txt(n, Modifier.weight(1f), size = 12.5f)
                        Txt(M(v), size = 12.5f, num = true)
                    }
                }
            }
        }
    }
}
