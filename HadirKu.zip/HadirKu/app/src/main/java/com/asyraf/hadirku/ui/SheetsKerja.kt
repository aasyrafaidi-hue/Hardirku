package com.asyraf.hadirku.ui

import android.app.TimePickerDialog
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.asyraf.hadirku.MainViewModel
import com.asyraf.hadirku.data.DayRecord
import com.asyraf.hadirku.data.RecordStatus
import com.asyraf.hadirku.logic.DayKind
import com.asyraf.hadirku.logic.Logic
import com.asyraf.hadirku.logic.Ms
import com.asyraf.hadirku.pg.PG
import java.time.Instant
import java.time.LocalDate

private fun minutesOf(ms: Long): Int {
    val t = Instant.ofEpochMilli(ms).atZone(Logic.zone()).toLocalTime()
    return t.hour * 60 + t.minute
}

@Composable
private fun TimeRow(label: String, value: Int?, onPick: (Int) -> Unit, def: Int) {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    Row(
        Modifier.fillMaxWidth().background(pal.surface).hairlines(pal.line).defaultMinSize(minHeight = 52.dp)
            .clickable { val v = value ?: def; TimePickerDialog(ctx, { _, h, m -> onPick(h * 60 + m) }, v / 60, v % 60, true).show() }
            .padding(horizontal = GL, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Txt(label, Modifier.weight(1f), size = 14f, weight = FontWeight.Medium, color = pal.muted)
        Txt(value?.let { Ms.hm(it) } ?: "--:--", size = 18f, weight = FontWeight.SemiBold, num = true, color = if (value == null) pal.muted else pal.ink)
    }
}

/** Editor rekod kehadiran satu hari (status, masa masuk/keluar, cuti umum, mood, nota). */
@Composable
fun AttendSheet(vm: MainViewModel, date: LocalDate) {
    val pal = LocalPal.current
    val s by vm.settings.collectAsState()
    val recs by vm.records.collectAsState()
    val pg by vm.pg.collectAsState()
    val record = recs[date]
    var status by remember { mutableStateOf(record?.status ?: RecordStatus.HADIR) }
    var inMin by remember { mutableStateOf(record?.checkIn?.let { minutesOf(it) }) }
    var outMin by remember { mutableStateOf(record?.checkOut?.let { minutesOf(it) }) }
    var mood by remember { mutableIntStateOf(record?.mood ?: 0) }
    var note by remember { mutableStateOf(record?.note ?: "") }
    val kind = Logic.dayKind(date, s)
    val shift = Logic.shiftType(date, s)
    val startMin = Logic.shiftStartMinutes(date, s)
    val isHoliday = date in s.holidays
    val c = vm.cfg()
    fun build(): DayRecord? {
        val zone = Logic.zone()
        val i = inMin
        val o = outMin
        fun toMs(min: Int, nextDay: Boolean): Long = date.plusDays(if (nextDay) 1 else 0).atStartOfDay(zone).plusMinutes(min.toLong()).toInstant().toEpochMilli()
        val inMs = if (status == RecordStatus.HADIR && i != null) toMs(i, false) else null
        val outMs = if (status == RecordStatus.HADIR && i != null && o != null) toMs(o, o <= i) else null
        if (status == RecordStatus.HADIR && inMs == null && mood == 0 && note.isBlank()) return null
        val r0 = record
        val method = if (r0 == null || r0.method.isBlank() || r0.checkIn != inMs) "edit" else r0.method
        return DayRecord(date = date, checkIn = inMs, checkOut = outMs, status = status, method = method, mood = mood, note = note.trim())
    }
    val preview = build()
    SheetBody(actions = {
        SheetActions("Simpan", {
            val r = build()
            if (r == null) { if (record != null) vm.deleteRecord(date) else vm.close() } else vm.saveRecord(r)
        }, { vm.close() })
    }) {
        SheetTitle(Ms.dateLong(date), rich(if (kind == DayKind.KERJA) Ms.shiftLabel(shift) + " · mula " + Ms.hm(startMin) else Ms.kindLabel(kind)))
        Form {
            FieldChips("Status", listOf("HADIR" to "Hadir", "CUTI" to "Cuti", "MC" to "MC"), status.name, { status = RecordStatus.valueOf(it) })
            if (status == RecordStatus.HADIR) {
                TimeRow("Masuk", inMin, { inMin = it }, startMin)
                TimeRow("Keluar", outMin, { outMin = it }, (startMin + (c.jamNormal * 60).toInt()) % 1440)
                Column(Modifier.fillMaxWidth().background(pal.surface).hairlines(pal.line).padding(horizontal = GL, vertical = 8.dp)) {
                    Txt("Kalau masa keluar lebih awal daripada masa masuk, ia dikira hari esok (shift malam).", size = 12.5f, color = pal.muted)
                    if (inMin != null || outMin != null) LinkBtn("Kosongkan masa", { inMin = null; outMin = null }, size = 13f)
                }
            }
            Row(Modifier.fillMaxWidth().background(pal.surface).hairlines(pal.line).padding(horizontal = GL, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Txt("Cuti umum", size = 14f, weight = FontWeight.Bold)
                    Txt("Kerja hari ini dikira kadar cuti umum (2.0x / 3.0x).", size = 13f, color = pal.muted)
                }
                Switch2(isHoliday) { vm.setHoliday(date, it) }
            }
            FieldChips("Mood", listOf("0" to "Tiada") + Ms.moods.mapIndexed { i, m -> (i + 1).toString() to m }, mood.toString(), { mood = it.toInt() }, stack = true)
            FieldText("Nota", note, { note = it.take(200) }, stack = true, lines = 2)
        }
        val e = if (preview != null) Logic.otEntryFor(preview, s) else null
        if (e != null && s.syncOt) {
            val ov = PG.otHours(e, c.jamNormal)
            val nilai = (ov.h15 * 1.5 + ov.h20 * 2 + ov.h30 * 3) * PG.hrp(c.gaji)
            Preview(rich("Log OT akan jadi **" + hariLabel(e.jenis).label + "**" +
                (e.jam?.let { " · " + fmtH(it) + " jam" } ?: "") + (if (nilai > 0) " · OT **" + M(nilai) + "**" else "")))
        } else if (pg.ot[Logic.iso(date)] != null) {
            Preview(rich("Log OT sedia ada: " + hariLabel(pg.ot[Logic.iso(date)]?.jenis ?: "biasa").label + (pg.ot[Logic.iso(date)]?.jam?.let { " · " + fmtH(it) + " jam" } ?: "")))
        }
        if (record != null) { Spacer(Modifier.height(8.dp)); DelZone("Padam rekod hari ini", "Padam rekod kehadiran hari ini? Log OT yang diisi daripada rekod ini juga dibuang.", { vm.deleteRecord(date) }) }
    }
}

@Composable
fun MoodSheet(vm: MainViewModel, date: LocalDate) {
    var mood by remember { mutableIntStateOf(0) }
    var note by remember { mutableStateOf("") }
    SheetBody(actions = { SheetActions("Simpan", { vm.saveMood(date, mood, note) }, { vm.close() }, cancel = "Langkau") }) {
        SheetTitle("Shift hari ni macam mana?", rich(Ms.dateLong(date)))
        Form {
            FieldChips("Mood", Ms.moods.mapIndexed { i, m -> (i + 1).toString() to m }, mood.toString(), { mood = it.toInt() }, stack = true)
            FieldText("Nota ringkas (pilihan)", note, { note = it.take(200) }, stack = true, lines = 2)
        }
    }
}

@Composable
fun CoachSheet(vm: MainViewModel) {
    val pal = LocalPal.current
    val c = vm.coach
    val la = launch()
    val inf = rememberInfiniteTransition(label = "tunggu")
    val a by inf.animateFloat(initialValue = 0.35f, targetValue = 1f, animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "kelip")
    SheetBody(actions = {
        SheetActions(if (c.text != null) "Salin" else if (c.error != null && c.error.contains("kunci", ignoreCase = true)) "Tetapan AI" else "",
            { if (c.text != null) la.copy(c.text, "Ulasan disalin") else vm.aiSetup() }, { vm.close() }, cancel = "Tutup")
    }) {
        SheetTitle("Jurulatih disiplin", c.label?.let { rich("Kitaran $it") })
        Column(Modifier.padding(horizontal = GL).padding(bottom = 10.dp)) {
            when {
                c.loading -> Txt("Claude sedang meneliti rekod kitaran ini…", Modifier.graphicsLayer { alpha = a }, size = 14f, color = pal.muted)
                c.error != null -> Txt(c.error, Modifier.fillMaxWidth().background(pal.badSoft).padding(10.dp), size = 14f, color = pal.bad)
                c.text != null -> MarkdownLite(c.text)
            }
        }
    }
}

/** Markdown ringkas: tajuk (#), senarai (-) dan **tebal**. */
@Composable
fun MarkdownLite(text: String) {
    val pal = LocalPal.current
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        text.lines().forEach { raw ->
            val l = raw.trimEnd()
            when {
                l.isBlank() -> Spacer(Modifier.height(4.dp))
                l.startsWith("#") -> Txt(l.trimStart('#', ' ').replace("**", ""), Modifier.padding(top = 6.dp), size = 15f, weight = FontWeight.Bold, color = pal.accentStrong)
                l.trimStart().startsWith("- ") || l.trimStart().startsWith("* ") || l.trimStart().startsWith("• ") ->
                    Row { Txt("•", Modifier.width(16.dp), size = 14f, color = pal.accent); Txt(rich(l.trimStart().substring(2)), Modifier.weight(1f), size = 14f) }
                else -> Txt(rich(l), size = 14f)
            }
        }
    }
}

@Composable
fun MalasSheet(vm: MainViewModel) {
    val pal = LocalPal.current
    val recs by vm.records.collectAsState()
    val now by vm.now.collectAsState()
    val c = vm.cfg()
    val quote = remember { Ms.quotes.random() }
    val st = remember(recs) { Logic.streaks(recs, c, now) }
    val today = Logic.today(now)
    val cy = Logic.cycleOf(today, c)
    val sum = remember(recs) { Logic.summarize(Logic.evalRange(Logic.cycleStart(cy), today, recs, c, now)) }
    val perShift = PG.hrp(c.gaji) * 8
    SheetBody(actions = { SheetActions("Okey, aku pergi", { vm.close() }, { vm.close() }, cancel = "Tutup") }) {
        SheetTitle("Jangan putuskan streak")
        Column(Modifier.padding(horizontal = GL).padding(bottom = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Txt(rich("Streak hadir kau sekarang **" + st.attend + " hari** (terbaik " + st.bestAttend + "). Kalau ponteng, kiraan bermula semula dari 0."), size = 14f)
            if (perShift > 0) Txt(rich("Sehari kerja bernilai lebih kurang **" + M(perShift) + "** gaji asas, belum kira OT."), size = 14f)
            if (sum.grade != "–") Txt(rich("Skor kitaran ini **" + sum.score + "/100** (" + sum.grade + "). Satu hari tidak hadir tolak 15 mata."), size = 14f)
            Box(Modifier.fillMaxWidth().background(pal.accentSoft).padding(12.dp)) { Txt("“$quote”", size = 14f, weight = FontWeight.Medium, color = pal.accentStrong) }
        }
    }
}

@Composable
fun FarSheet(vm: MainViewModel, dist: Float) {
    val s by vm.settings.collectAsState()
    val la = launch()
    SheetBody(actions = {
        SheetActions("Ya, check-in", {
            vm.close()
            if (s.useBiometric) com.asyraf.hadirku.system.Bio.authenticate(la.activity, "Sahkan check-in", onSuccess = { vm.checkIn("biometrik") }, onError = { vm.toast(it) })
            else vm.checkIn("manual")
        }, { vm.close() })
    }) {
        SheetTitle("Jauh dari kilang", rich("Kau berada kira-kira **" + (if (dist >= 1000) String.format(java.util.Locale.US, "%.1f km", dist / 1000f) else dist.toInt().toString() + " m") + "** dari kilang. Check-in sekarang juga?"))
    }
}
