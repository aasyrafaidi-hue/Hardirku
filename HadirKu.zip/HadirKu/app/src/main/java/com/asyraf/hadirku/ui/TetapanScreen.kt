@file:OptIn(ExperimentalLayoutApi::class)

package com.asyraf.hadirku.ui

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.asyraf.hadirku.BuildConfig
import com.asyraf.hadirku.MainViewModel
import com.asyraf.hadirku.Sheet
import com.asyraf.hadirku.ai.Ai
import com.asyraf.hadirku.logic.Logic
import com.asyraf.hadirku.logic.Ms
import com.asyraf.hadirku.logic.ShiftType
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.system.Bio
import com.asyraf.hadirku.system.LocationHelper
import com.asyraf.hadirku.system.Notif
import com.asyraf.hadirku.system.Reminders
import java.util.Locale

private fun numStr(d: Double): String = PG.jsNum(d)

@Composable
fun TetapanScreen(vm: MainViewModel) {
    val pal = LocalPal.current
    val pg by vm.pg.collectAsState()
    val s by vm.settings.collectAsState()
    val la = launch()
    val today = vm.today()

    // ---------- Paparan & kiraan ----------
    SecHead("Paparan & kiraan")
    Column(Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().background(pal.surface).hairlines(pal.line, top = true).padding(horizontal = GL, vertical = 10.dp)) {
            Txt("Tema", size = 14f, weight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Chips(listOf("0" to "Ikut sistem", "1" to "Cerah", "2" to "Gelap", "3" to "Gelap bila shift malam"), s.themeMode.toString(), { v ->
                vm.saveSettings("") { it.copy(themeMode = v.toInt()) }
            })
        }
        val okc = PG.otKitaranBulan(pg, PG.ym(today)).cycle
        StatusRow(
            "OT dikira pendapatan",
            "Pendapatan bulan = duit masuk (tanpa bahagian OT dalam gaji) + OT kitaran yang dibayar dalam gaji bulan itu, contohnya " + PG.fmtMonth(PG.ym(today)) + " = OT " + PG.fmtShort(okc.start) + " – " + PG.fmtShort(okc.end) +
                ". Kalendar harian tunjuk OT pada hari kerja. Perbelanjaan termasuk komitmen, ansuran dan guna kad; bayar kad dikira pindah. Matikan untuk ikut duit masuk & keluar bank sahaja.",
        ) { Switch2(pg.settings.otPendapatan) { vm.toggleOtp() } }
        val d = vm.saiz - 15
        StatusRow("Saiz tulisan") { Txt(vm.saiz.toString() + "px (" + (if (d > 0) "+" else if (d < 0) "−" else "±") + Math.abs(d) + ")", size = 14f, num = true) }
        Column(Modifier.fillMaxWidth().background(pal.surface).hairlines(pal.line).padding(horizontal = GL, vertical = 8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(44.dp).pressable({ vm.changeSaiz(vm.saiz - 1) }, scaleTo = 0.85f), contentAlignment = Alignment.Center) { Txt("A−", size = 15f, weight = FontWeight.Bold) }
                Slider(
                    value = vm.saiz.toFloat(), onValueChange = { vm.changeSaiz(Math.round(it)) }, valueRange = 10f..20f, steps = 9, modifier = Modifier.weight(1f),
                    colors = SliderDefaults.colors(thumbColor = pal.accent, activeTrackColor = pal.accent, inactiveTrackColor = pal.track, activeTickColor = pal.accentInk, inactiveTickColor = pal.lineStrong),
                )
                Box(Modifier.size(44.dp).pressable({ vm.changeSaiz(vm.saiz + 1) }, scaleTo = 0.85f), contentAlignment = Alignment.Center) { Txt("A+", size = 15f, weight = FontWeight.Bold) }
            }
            Txt("Asal 15px. Boleh kecilkan hingga −5px atau besarkan hingga +5px. Disimpan dalam peranti ini sahaja.", size = 12.5f, color = pal.muted)
            if (vm.saiz != 14) { Spacer(Modifier.height(8.dp)); Btn("Guna saiz lalai (14px)", { vm.changeSaiz(14) }, Modifier.fillMaxWidth()) }
        }
    }

    // ---------- Gaji & OT (PoketGaji) ----------
    GajiSection(vm)

    // ---------- Jadual shift (HadirKu) ----------
    JadualSection(vm)

    // ---------- Lokasi ----------
    LokasiSection(vm)

    // ---------- Peringatan & keselamatan ----------
    PeringatanSection(vm)

    // ---------- Kongsi dengan isteri (Firebase) ----------
    KongsiSection(vm)

    // ---------- Pembantu AI ----------
    AiSection(vm)

    // ---------- API lain ----------
    ApiSection(vm)

    // ---------- Poket ----------
    var susunP by remember { mutableStateOf(false) }
    SecHeadLinks("Poket", if (susunP) listOf("Siap" to { susunP = false; vm.lastMoved = null })
        else listOf("Susun" to { susunP = true; vm.lastMoved = null }, "+ Poket" to { vm.open(Sheet.PocketForm(null)) }))
    if (susunP) SusunPoketList(vm, pg.pockets) { p -> if (p.sasaran > 0) "Tambahan " + M(p.sasaran) + " sebulan" else "Tiada sasaran tambahan" }
    else ListBlock {
        pg.pockets.forEach { p ->
            PRow(p.nama, if (p.sasaran > 0) "Tambahan " + M(p.sasaran) else "Edit", { vm.open(Sheet.PocketForm(p.id)) },
                tag = simpanTag(p), rightColor = pal.muted)
        }
    }

    // ---------- Semakan bank ----------
    SecHead("Semakan bank", "+ Semak") { vm.open(Sheet.Bank) }
    val checks = pg.bankChecks.sortedByDescending { it.tarikh }.take(8)
    if (checks.isEmpty()) Empty(rich("Belum ada semakan. Bandingkan baki bank dengan app sekurang-kurangnya seminggu sekali."))
    else ListBlock {
        checks.forEach { c ->
            val tr = PG.total(pg, c.tarikh)
            val bz = PG.round2(c.baki - tr)
            Column(Modifier.fillMaxWidth().hairlines(pal.line).padding(horizontal = GL, vertical = 11.dp)) {
                Row { Txt(PG.fmtDate(c.tarikh), Modifier.weight(1f), size = 13.5f); Txt(M(c.baki), size = 13.5f, num = true) }
                Row {
                    Txt("Tracker " + M(tr), Modifier.weight(1f), size = 13f, color = pal.muted)
                    Txt(if (Math.abs(bz) < 0.005) "✔ Sama" else "Beza " + M(bz), size = 13f, color = if (Math.abs(bz) < 0.005) pal.ink else pal.bad)
                }
            }
        }
    }

    // ---------- App ----------
    SecHead("App")
    Column(Modifier.fillMaxWidth()) {
        val last = vm.lastBackupMs()
        StatusRow("Salinan terakhir") { Txt(if (last > 0) PG.fmtDate(Logic.iso(Logic.today(last))) else "Belum pernah", size = 14f, color = pal.muted) }
        StatusRow("Versi") { Txt(BuildConfig.VERSION_NAME, size = 14f, color = pal.muted, num = true) }
        StatusRow("Rekod kehadiran") { Txt(vm.records.value.size.toString() + " hari", size = 14f, color = pal.muted, num = true) }
    }

    // ---------- Data ----------
    SecHead("Data")
    Block {
        Txt("Semua data disimpan dalam telefon ini sahaja. Tiada akaun dan tiada server. Simpan salinan secara berkala, terutama sebelum tukar telefon. Salinan dalam format PoketGaji, termasuk rekod kehadiran.", size = 13f, color = pal.muted)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Btn("Simpan salinan", { vm.open(Sheet.BackupMenu) }, Modifier.weight(1f), kind = BtnKind.PRIMARY)
            Btn("Pulihkan salinan", { la.pickImport() }, Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))
        Btn("Fail untuk CFO (Claude)", { vm.open(Sheet.Cfo) }, Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Btn("Muat data contoh", { vm.open(Sheet.Confirm("Muat data contoh?", "Data kewangan dalam peranti ini akan diganti dengan data contoh. Rekod kehadiran kekal. Simpan salinan dulu kalau perlu.", "Muat contoh", "sample")) }, Modifier.weight(1f))
            Btn("Padam data kewangan", { vm.open(Sheet.Confirm("Padam semua data kewangan?", "Semua poket, transaksi, komitmen, hutang dan log OT dalam peranti ini akan dipadam. Rekod kehadiran kekal. Tindakan ini tak boleh dibatalkan.", "Padam semua", "reset")) }, Modifier.weight(1f), color = pal.bad)
        }
    }
    Txt("Duitku v" + BuildConfig.VERSION_NAME + " · urus duit + kehadiran kerja · data kekal dalam peranti ini", Modifier.fillMaxWidth().padding(horizontal = GL), size = 13f, color = pal.muted, align = TextAlign.Center)
}

@Composable
private fun GajiSection(vm: MainViewModel) {
    val pal = LocalPal.current
    val pg by vm.pg.collectAsState()
    val g = pg.settings.gaji
    val key = g.toString() + pg.settings.otMulaHari
    var basic by remember(key) { mutableStateOf(numStr(g.basic)) }
    var night by remember(key) { mutableStateOf(numStr(g.night)) }
    var transport by remember(key) { mutableStateOf(numStr(g.transport)) }
    var potongan by remember(key) { mutableStateOf(numStr(g.potongan)) }
    var advance by remember(key) { mutableStateOf(numStr(g.advance)) }
    var jam by remember(key) { mutableStateOf(numStr(g.jamNormal)) }
    var had by remember(key) { mutableStateOf(numStr(g.hadOT)) }
    var otd by remember(key) { mutableStateOf(pg.settings.otMulaHari.toString()) }
    var err by remember(key) { mutableStateOf("") }
    SecHead("Gaji & OT")
    Form {
        Column(Modifier.fillMaxWidth().hairlines(pal.line, top = true, bottom = false)) {}
        FieldText("Gaji asas (RM)", basic, { basic = it }, kb = KeyboardType.Decimal)
        FieldText("Elaun shift malam (RM)", night, { night = it }, kb = KeyboardType.Decimal)
        FieldText("Elaun transport (RM)", transport, { transport = it }, kb = KeyboardType.Decimal)
        FieldText("Anggaran potongan (RM)", potongan, { potongan = it }, kb = KeyboardType.Decimal)
        FieldText("Advance 15hb (RM)", advance, { advance = it }, kb = KeyboardType.Decimal)
        FieldText("Jam normal sehari", jam, { jam = it }, kb = KeyboardType.Decimal, small = "Termasuk rehat. Juga dipakai untuk kira bila shift tamat.")
        FieldText("Had OT sebulan (jam)", had, { had = it }, kb = KeyboardType.Decimal)
        FieldText("Kitaran OT mula (hari)", otd, { otd = it }, kb = KeyboardType.Number)
        Column(Modifier.fillMaxWidth().background(pal.surface).padding(horizontal = GL).padding(top = 10.dp, bottom = 12.dp)) {
            Txt(rich("Kadar sejam (HRP) = (gaji asas + elaun) ÷ 26 ÷ 8 = **RM" + PG.toFixed(PG.hrp(g), 4) + "**. Potongan termasuk KWSP, PERKESO, SIP, PCB dan pinjaman yang ditolak terus dari gaji."), size = 13f, color = pal.muted)
            FormError(err)
            Spacer(Modifier.height(12.dp))
            Btn("Simpan tetapan", { err = vm.saveGaji(listOf(basic, night, transport, potongan, advance, jam, had), otd) }, Modifier.fillMaxWidth(), kind = BtnKind.PRIMARY)
        }
    }
}

@Composable
private fun TimeField(label: String, minutes: Int, onPick: (Int) -> Unit) {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    Row(
        Modifier.fillMaxWidth().background(pal.surface).hairlines(pal.line).defaultMinSize(minHeight = 52.dp)
            .clickable { android.app.TimePickerDialog(ctx, { _, h, m -> onPick(h * 60 + m) }, minutes / 60, minutes % 60, true).show() }
            .padding(horizontal = GL, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Txt(label, Modifier.weight(1f), size = 14f, weight = FontWeight.Medium, color = pal.muted)
        Txt(Ms.hm(minutes), size = 16f, weight = FontWeight.SemiBold, num = true)
        Spacer(Modifier.width(6.dp))
        Txt("⌄", size = 16f, color = pal.muted)
    }
}

@Composable
private fun JadualSection(vm: MainViewModel) {
    val pal = LocalPal.current
    val s by vm.settings.collectAsState()
    val today = Logic.today(System.currentTimeMillis())
    val key = s.hashCode()
    var name by remember(key) { mutableStateOf(s.name) }
    var morning by remember(key) { mutableIntStateOf(s.morningStart) }
    var night by remember(key) { mutableIntStateOf(s.nightStart) }
    var pagiNow by remember(key) { mutableStateOf(Logic.shiftType(today, s) == ShiftType.PAGI) }
    var week by remember(key) { mutableIntStateOf(Logic.weekInBlock(today, s)) }
    var wpbStr by remember(key) { mutableStateOf(s.weeksPerBlock.toString()) }
    var workDays by remember(key) { mutableStateOf(s.workDays) }
    var restDay by remember(key) { mutableIntStateOf(s.restDay) }
    var grace by remember(key) { mutableStateOf(s.graceMinutes.toString()) }
    var rounding by remember(key) { mutableIntStateOf(s.otRounding) }
    var syncOt by remember(key) { mutableStateOf(s.syncOt) }
    val wpb = wpbStr.toIntOrNull()?.coerceIn(1, 8) ?: s.weeksPerBlock
    fun build() = s.copy(
        name = name.trim(), morningStart = morning, nightStart = night, weeksPerBlock = wpb,
        rotationAnchor = Logic.anchorFor(today, pagiNow, week.coerceIn(1, wpb), wpb),
        workDays = workDays.ifEmpty { s.workDays }, restDay = restDay,
        graceMinutes = grace.toIntOrNull()?.coerceIn(0, 120) ?: s.graceMinutes, otRounding = rounding, syncOt = syncOt,
    )
    SecHead("Jadual shift & kehadiran")
    Form {
        Column(Modifier.fillMaxWidth().hairlines(pal.line, top = true, bottom = false)) {}
        FieldText("Nama panggilan", name, { name = it.take(30) })
        TimeField("Shift pagi mula", morning) { morning = it }
        TimeField("Shift malam mula", night) { night = it }
        FieldChips("Minggu ini shift", listOf("p" to "Pagi", "m" to "Malam"), if (pagiNow) "p" else "m", { pagiNow = it == "p" })
        FieldChips("Minggu ke berapa dalam blok", (1..wpb).map { it.toString() to "Minggu $it" }, week.coerceIn(1, wpb).toString(), { week = it.toInt() }, stack = true)
        FieldText("Minggu setiap blok", wpbStr, { wpbStr = it.take(1) }, kb = KeyboardType.Number)
        Column(Modifier.fillMaxWidth().background(pal.surface).hairlines(pal.line).padding(horizontal = GL).padding(top = 10.dp, bottom = 10.dp)) {
            Txt("Hari bekerja", size = 14f, weight = FontWeight.Medium, color = pal.muted)
            Spacer(Modifier.height(6.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                (1..7).forEach { dow ->
                    val on = dow in workDays
                    val bg by animateColorAsState(if (on) pal.accentSoft else Color.Transparent, label = "hk")
                    val shape = RoundedCornerShape(4.dp)
                    Box(
                        Modifier.defaultMinSize(minWidth = 44.dp, minHeight = 36.dp).background(bg, shape).border(1.dp, if (on) pal.accent else pal.line, shape)
                            .pressable({ workDays = if (on) workDays - dow else workDays + dow }, scaleTo = 0.9f).padding(horizontal = 8.dp, vertical = 6.dp),
                        contentAlignment = Alignment.Center,
                    ) { Txt(Ms.daysShort[dow - 1], size = 14f, weight = if (on) FontWeight.SemiBold else FontWeight.Medium, color = if (on) pal.accentStrong else pal.ink) }
                }
            }
        }
        FieldChips("Rest day (2.0x / 3.0x)", listOf("6" to "Sabtu", "7" to "Ahad"), restDay.toString(), { restDay = it.toInt() })
        FieldText("Kelonggaran lewat (minit)", grace, { grace = it.take(3) }, kb = KeyboardType.Number)
        FieldChips("Bundar jam kerja", listOf("1" to "Tiada", "15" to "15 min", "30" to "30 min", "60" to "1 jam"), rounding.toString(), { rounding = it.toInt() },
            note = { Txt("Jam masuk–keluar dibundar ke bawah sebelum masuk log OT.", size = 12.5f, color = pal.muted) })
        Row(Modifier.fillMaxWidth().background(pal.surface).hairlines(pal.line).padding(horizontal = GL, vertical = 12.dp), verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f)) {
                Txt("Isi log OT dari check-in / check-out", size = 14f, weight = FontWeight.Bold)
                Txt("Jenis hari ikut jadual (hari kerja = Biasa, rest day = Rest, cuti umum = Umum, lain = Off). Cuti / MC = Tidak bekerja.", size = 13f, color = pal.muted)
            }
            Spacer(Modifier.width(12.dp))
            Switch2(syncOt) { syncOt = it }
        }
        Column(Modifier.fillMaxWidth().background(pal.surface).padding(horizontal = GL).padding(top = 10.dp, bottom = 12.dp)) {
            val preview = build()
            Txt("Semakan: minggu depan " + (if (Logic.shiftType(today.plusWeeks(1), preview) == ShiftType.PAGI) "pagi" else "malam") + ", 2 minggu lagi " +
                (if (Logic.shiftType(today.plusWeeks(2), preview) == ShiftType.PAGI) "pagi" else "malam") + ".", size = 13f, color = pal.muted)
            Spacer(Modifier.height(12.dp))
            Btn("Simpan jadual", { vm.saveSettings { build() } }, Modifier.fillMaxWidth(), kind = BtnKind.PRIMARY)
        }
    }
}

@Composable
private fun LokasiSection(vm: MainViewModel) {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    val s by vm.settings.collectAsState()
    val now by vm.now.collectAsState()
    var tick by remember { mutableIntStateOf(0) }
    val locL = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { tick++; vm.permissionsChanged() }
    val bgL = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++; vm.permissionsChanged() }
    val hasFine = remember(tick, now) { LocationHelper.hasFine(ctx) }
    val hasBg = remember(tick, now) { LocationHelper.hasBackground(ctx) }
    var radius by remember(s.workRadius) { mutableStateOf(s.workRadius.toString()) }
    SecHead("Lokasi & check-in automatik")
    Column(Modifier.fillMaxWidth()) {
        if (!hasFine) Notice(rich("Izin lokasi belum diberi."), Tone.WARN, "Benarkan") {
            locL.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
        }
        LocRow("Kilang / tempat kerja", s.workLat, s.workLng, { vm.setWorkLocationFromCurrent() }, { vm.clearWorkLocation() })
        Form {
            FieldText("Jejari kawasan kilang (meter)", radius, { radius = it.take(4) }, kb = KeyboardType.Number, small = "Tekan \"Guna lokasi semasa\" bila kau berada di kilang.",
                after = {
                    if (radius != s.workRadius.toString()) LinkBtn("Simpan jejari", { vm.saveSettings { it.copy(workRadius = radius.toIntOrNull()?.coerceIn(100, 2000) ?: it.workRadius) } })
                })
        }
        StatusRow("Check-in / out automatik", "Rekod terus bila masuk atau keluar kawasan kilang. Kalau ditutup, app hantar notifikasi untuk kau tekan.") {
            Switch2(s.autoCheckIn) { v -> vm.saveSettings(if (v) "Check-in automatik dihidupkan" else "Check-in automatik dimatikan") { it.copy(autoCheckIn = v) } }
        }
        if (hasFine && !hasBg) Notice(rich("Untuk geofence berfungsi bila app ditutup, pilih **Benarkan sepanjang masa** untuk lokasi."), Tone.INFO, "Benarkan") {
            if (Build.VERSION.SDK_INT >= 29) bgL.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
        }
    }
}

@Composable
private fun LocRow(label: String, lat: Double?, lng: Double?, onSet: () -> Unit, onClear: () -> Unit) {
    val pal = LocalPal.current
    Column(Modifier.fillMaxWidth().background(pal.surface).hairlines(pal.line, top = true).padding(horizontal = GL, vertical = 10.dp)) {
        Txt(label, size = 14f, weight = FontWeight.Bold)
        Txt(if (lat != null && lng != null) String.format(Locale.US, "%.5f, %.5f", lat, lng) else "Belum ditetapkan", size = 13f, color = pal.muted, num = true)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Btn("Guna lokasi semasa", onSet, kind = BtnKind.SMALL, color = pal.accentStrong)
            if (lat != null) LinkDanger("Padam", onClear)
        }
    }
}

@Composable
private fun PeringatanSection(vm: MainViewModel) {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    val s by vm.settings.collectAsState()
    val now by vm.now.collectAsState()
    var tick by remember { mutableIntStateOf(0) }
    val notifL = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++; vm.permissionsChanged() }
    val canNotify = remember(tick, now) { Notif.canPost(ctx) }
    val canExact = remember(tick, now) { Reminders.canExact(ctx) }
    SecHead("Peringatan & keselamatan")
    Column(Modifier.fillMaxWidth()) {
        Box(Modifier.fillMaxWidth().hairlines(pal.line, top = true, bottom = false)) {}
        StatusRow("Amaran lupa check-in", "Notifikasi kalau belum check-in " + (s.graceMinutes + 10) + " minit selepas shift mula.") {
            Switch2(s.remindersOn) { v -> vm.saveSettings("") { it.copy(remindersOn = v) } }
        }
        if (!canNotify && Build.VERSION.SDK_INT >= 33) Notice(rich("Notifikasi belum dibenarkan."), Tone.WARN, "Benarkan") { notifL.launch(Manifest.permission.POST_NOTIFICATIONS) }
        if (!canExact && Build.VERSION.SDK_INT >= 31) Notice(rich("Penggera tepat belum dibenarkan — peringatan mungkin lewat beberapa minit."), Tone.INFO, "Benarkan") {
            try { ctx.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + ctx.packageName))) }
            catch (e: Exception) { vm.toast("Buka tetapan app secara manual untuk benarkan penggera") }
        }
        StatusRow("Sahkan dengan cap jari / muka", if (Bio.available(ctx)) "Minta pengesahan biometrik setiap kali check-in manual." else "Telefon ini tiada kunci skrin / biometrik; check-in terus tanpa pengesahan.") {
            Switch2(s.useBiometric) { v -> vm.saveSettings("") { it.copy(useBiometric = v) } }
        }
    }
}

@Composable
private fun AiSection(vm: MainViewModel) {
    val pal = LocalPal.current
    val tickAi = vm.aiTick
    val ada = remember(tickAi) { Ai.ready() }
    val u = remember(tickAi) { Ai.usageMonth(vm.today()) }
    var key by remember { mutableStateOf("") }
    var model by remember(tickAi) { mutableStateOf(Ai.model()) }
    val perlu = vm.katPerlu().size
    SecHead("Pembantu AI")
    Form {
        Column(Modifier.fillMaxWidth().background(pal.surface).hairlines(pal.line, top = true).padding(horizontal = GL, vertical = 10.dp)) {
            Txt("Imbas resit, kategori automatik dan jurulatih disiplin, guna AI Claude dengan kunci API awak sendiri.", size = 13f, color = pal.muted)
        }
        FieldText("Kunci API Anthropic", key, { key = it.trim() }, placeholder = if (ada) "Tersimpan " + Ai.mask(Ai.key()) else "sk-ant-…", password = true)
        FieldText("Model", model, { model = it })
        Column(Modifier.fillMaxWidth().background(pal.surface).padding(horizontal = GL).padding(top = 10.dp, bottom = 12.dp)) {
            val st = if (vm.aiStatus.isNotEmpty()) vm.aiStatus else (if (ada) "✔ Kunci tersimpan dalam telefon ini. Untuk tukar, taip kunci baru." else "Belum ada kunci. Ciri AI guna kunci API Anthropic awak sendiri.") +
                (if (u.n > 0) " Bulan ini: " + u.n + " panggilan AI" + (if (u.usd > 0) " · anggaran US$" + String.format(Locale.US, "%.4f", u.usd) else "") + "." else "")
            Txt(st, size = 13f, color = pal.muted)
            FormError(vm.aiError)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Btn("Simpan", { vm.aiSave(key, model); key = "" }, Modifier.weight(1f), kind = BtnKind.PRIMARY)
                Btn(if (vm.aiTesting) "Menguji…" else "Uji kunci", { vm.aiTest(key, model); key = "" }, Modifier.weight(1f), enabled = !vm.aiTesting)
            }
            if (ada) LinkDanger("Padam kunci dari telefon ini") { vm.aiDel() }
        }
    }
    Column(Modifier.fillMaxWidth()) {
        StatusRow("Kategori automatik", "Bila simpan belanja tanpa kategori, app guna kategori transaksi lepas dengan nama sama. Kalau tiada, AI pilih.") {
            Switch2(ada && Ai.autoKat(), enabled = ada) { vm.aiToggleAuto() }
        }
        StatusRow(if (vm.katBusy) vm.katProg.ifEmpty { "Mengkategorikan…" } else if (perlu > 0) "$perlu belanja belum ada kategori" else "✔ Semua belanja ada kategori") {
            if (perlu > 0 && !vm.katBusy) Btn("Kategorikan semua", { vm.katSemua() }, kind = BtnKind.SMALL, enabled = ada)
        }
        Column(Modifier.fillMaxWidth().background(pal.surface).hairlines(pal.line).padding(horizontal = GL, vertical = 10.dp)) {
            Txt("Gambar resit dan nama belanja dihantar terus ke Anthropic (pembuat Claude) untuk diproses, dan tidak disimpan dalam app. Kunci kekal dalam telefon ini sahaja, tidak masuk fail salinan. Dapatkan kunci di platform.claude.com → API Keys, dan tetapkan had belanja bulanan di sana.", size = 12.5f, color = pal.muted)
        }
    }
}

@Composable
private fun ApiSection(vm: MainViewModel) {
    val pal = LocalPal.current
    val s by vm.settings.collectAsState()
    val key = s.calendarificKey + s.stateName
    var cal by remember(key) { mutableStateOf(s.calendarificKey) }
    var state by remember(key) { mutableStateOf(s.stateName) }
    val year = Logic.today(System.currentTimeMillis()).year
    SecHead("Cuti umum (pilihan)")
    Form {
        Column(Modifier.fillMaxWidth().background(pal.surface).hairlines(pal.line, top = true).padding(horizontal = GL, vertical = 10.dp)) {
            Txt("Untuk import cuti umum secara automatik. Kunci hanya disimpan dalam telefon ini, tidak masuk fail salinan.", size = 13f, color = pal.muted)
        }
        FieldText("Calendarific (cuti umum)", cal, { cal = it.trim() }, password = true, placeholder = "Kunci API")
        FieldText("Negeri (cuti negeri)", state, { state = it })
        Column(Modifier.fillMaxWidth().background(pal.surface).padding(horizontal = GL).padding(top = 10.dp, bottom = 12.dp)) {
            Txt(s.holidays.count { it.year == year }.toString() + " cuti umum $year dalam senarai. Boleh juga tanda manual dalam editor hari (Kerja → Disiplin).", size = 13f, color = pal.muted)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Btn("Simpan", { vm.saveSettings { it.copy(calendarificKey = cal, stateName = state.trim().ifEmpty { "Penang" }) } }, Modifier.weight(1f), kind = BtnKind.PRIMARY)
                Btn("Import cuti $year", {
                    vm.saveSettings("") { it.copy(calendarificKey = cal, stateName = state.trim().ifEmpty { "Penang" }) }
                    vm.importHolidays()
                }, Modifier.weight(1f))
            }
        }
    }
}
