package com.asyraf.hadirku.system

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.asyraf.hadirku.MainActivity
import com.asyraf.hadirku.R

object Notif {
    const val CH_REMIND = "peringatan"
    const val CH_GEO = "lokasi"

    const val ID_DEPART = 1001
    const val ID_MISSED = 1002
    const val ID_GEO = 1003
    const val ID_DONE = 1004

    const val ACTION_CHECK_IN = "com.asyraf.hadirku.CHECK_IN"
    const val ACTION_CHECK_OUT = "com.asyraf.hadirku.CHECK_OUT"

    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(
            NotificationChannel(CH_REMIND, "Peringatan kerja", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Amaran belum check-in"
            },
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_GEO, "Lokasi kilang", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "Check-in dan check-out bila sampai atau keluar kawasan kilang"
            },
        )
    }

    fun canPost(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun openAppIntent(ctx: Context): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(ctx, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun actionIntent(ctx: Context, action: String): PendingIntent {
        val i = Intent(ctx, ActionReceiver::class.java).setAction(action)
        return PendingIntent.getBroadcast(ctx, action.hashCode(), i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    @SuppressLint("MissingPermission")
    fun show(
        ctx: Context,
        id: Int,
        channel: String,
        title: String,
        text: String,
        action: Pair<String, String>? = null,
    ) {
        if (!canPost(ctx)) return
        val b = NotificationCompat.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_stat_hadir)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(openAppIntent(ctx))
            .setAutoCancel(true)
            .setColor(0xFF0C7C8C.toInt())
            .setPriority(if (channel == CH_REMIND) NotificationCompat.PRIORITY_HIGH else NotificationCompat.PRIORITY_DEFAULT)
        if (action != null) b.addAction(0, action.first, actionIntent(ctx, action.second))
        try {
            NotificationManagerCompat.from(ctx).notify(id, b.build())
        } catch (e: SecurityException) {
            // Izin notifikasi ditarik balik — abaikan.
        }
    }

    fun cancel(ctx: Context, id: Int) {
        NotificationManagerCompat.from(ctx).cancel(id)
    }
}
