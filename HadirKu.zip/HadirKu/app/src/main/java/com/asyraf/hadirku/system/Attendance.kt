package com.asyraf.hadirku.system

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.asyraf.hadirku.logic.Cfg
import com.asyraf.hadirku.data.DayRecord
import com.asyraf.hadirku.data.RecordStatus
import com.asyraf.hadirku.data.Repo
import com.asyraf.hadirku.logic.DayKind
import com.asyraf.hadirku.logic.Logic
import com.asyraf.hadirku.logic.Ms
import com.asyraf.hadirku.logic.Outcome

/** Tindakan check-in / check-out yang dikongsi oleh skrin, notifikasi dan geofence. */
object Attendance {
    private const val HOUR = 3_600_000L

    /** Pulang rekod baru, atau null jika sudah check-in / masih ada shift terbuka. */
    fun checkIn(ctx: Context, method: String, nowMs: Long = System.currentTimeMillis()): DayRecord? {
        Repo.init(ctx)
        val recs = Repo.records.value
        if (Logic.openRecord(recs, nowMs) != null) return null
        val today = Logic.today(nowMs)
        val existing = recs[today]
        if (existing != null && existing.status == RecordStatus.HADIR && existing.checkIn != null) return null
        val rec = (existing ?: DayRecord(today)).copy(
            checkIn = nowMs, checkOut = null, status = RecordStatus.HADIR, method = method,
        )
        Repo.upsert(rec)
        Notif.cancel(ctx, Notif.ID_MISSED)
        Notif.cancel(ctx, Notif.ID_GEO)
        Notif.cancel(ctx, Notif.ID_DEPART)
        Reminders.scheduleAll(ctx)
        return rec
    }

    fun checkOut(ctx: Context, method: String, nowMs: Long = System.currentTimeMillis()): DayRecord? {
        Repo.init(ctx)
        val open = Logic.openRecord(Repo.records.value, nowMs) ?: return null
        val rec = open.copy(checkOut = nowMs, method = if (open.method == method) method else "${open.method}/$method")
        Repo.upsert(rec)
        Notif.cancel(ctx, Notif.ID_GEO)
        return rec
    }

    fun describeCheckIn(rec: DayRecord, c: Cfg): String {
        val inMs = rec.checkIn ?: return ""
        val e = Logic.evaluate(rec.date, rec, c, System.currentTimeMillis())
        val t = Ms.time(inMs)
        return when (e.outcome) {
            Outcome.TEPAT -> {
                val early = e.arrivalDelta ?: 0
                if (early > 0) "Masuk $t · $early minit awal" else "Masuk $t · tepat masa"
            }
            Outcome.LEWAT -> "Masuk $t · lewat ${e.lateMinutes} minit"
            else -> "Masuk $t · ${Ms.kindLabel(e.kind)}"
        }
    }

    fun describeCheckOut(rec: DayRecord, c: Cfg): String {
        val outMs = rec.checkOut ?: return ""
        val e = Logic.evaluate(rec.date, rec, c, System.currentTimeMillis())
        val nilai = e.ot.nilai(c.gaji)
        val ot = if (e.ot.total > 0) " · OT ${Ms.hours(e.ot.total)} jam" + (if (nilai > 0) " (${Ms.rm(nilai)})" else "") else ""
        return "Keluar ${Ms.time(outMs)} · kerja ${Ms.duration(e.workedMinutes)}$ot"
    }

    /** Dipanggil bila geofence ENTER. */
    fun onArrive(ctx: Context) {
        Repo.init(ctx)
        val c = Repo.cfg()
        val s = c.s
        val now = System.currentTimeMillis()
        val recs = Repo.records.value
        if (Logic.openRecord(recs, now) != null) return
        val today = Logic.today(now)
        val r = recs[today]
        if (r != null && r.checkIn != null) return
        if (Logic.inArrivalWindow(today, c, now)) {
            if (s.autoCheckIn) {
                val rec = checkIn(ctx, "geofence", now) ?: return
                val st = Logic.streaks(Repo.records.value, c, now)
                Notif.show(
                    ctx, Notif.ID_GEO, Notif.CH_GEO, "Check-in automatik ✓",
                    describeCheckIn(rec, c) + if (st.attend > 0) " · streak ${st.attend} hari" else "",
                )
            } else {
                Notif.show(
                    ctx, Notif.ID_GEO, Notif.CH_GEO, "Dah sampai kilang",
                    "Tekan butang di bawah untuk check-in sekarang.",
                    "Check-in" to Notif.ACTION_CHECK_IN,
                )
            }
        } else if (Logic.dayKind(today, s) != DayKind.KERJA) {
            Notif.show(
                ctx, Notif.ID_GEO, Notif.CH_GEO, "Sampai kilang pada hari rehat",
                "Kerja OT hari ni? Check-in supaya jam OT direkod.",
                "Check-in" to Notif.ACTION_CHECK_IN,
            )
        }
    }

    /** Dipanggil bila geofence EXIT. */
    fun onLeave(ctx: Context) {
        Repo.init(ctx)
        val c = Repo.cfg()
        val s = c.s
        val now = System.currentTimeMillis()
        val open = Logic.openRecord(Repo.records.value, now) ?: return
        val inMs = open.checkIn ?: return
        if (now - inMs < 2 * HOUR) return
        if (s.autoCheckIn) {
            val rec = checkOut(ctx, "geofence", now) ?: return
            Notif.show(ctx, Notif.ID_GEO, Notif.CH_GEO, "Check-out automatik ✓", describeCheckOut(rec, c))
        } else {
            Notif.show(
                ctx, Notif.ID_GEO, Notif.CH_GEO, "Dah keluar kilang?",
                "Tekan butang di bawah untuk check-out.",
                "Check-out" to Notif.ACTION_CHECK_OUT,
            )
        }
    }
}

/** Butang tindakan dalam notifikasi. */
class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Repo.init(context)
        val c = Repo.cfg()
        when (intent.action) {
            Notif.ACTION_CHECK_IN -> {
                val rec = Attendance.checkIn(context, "notifikasi")
                if (rec != null) {
                    Notif.show(context, Notif.ID_DONE, Notif.CH_GEO, "Check-in direkod ✓", Attendance.describeCheckIn(rec, c))
                }
            }
            Notif.ACTION_CHECK_OUT -> {
                val rec = Attendance.checkOut(context, "notifikasi")
                if (rec != null) {
                    Notif.show(context, Notif.ID_DONE, Notif.CH_GEO, "Check-out direkod ✓", Attendance.describeCheckOut(rec, c))
                }
            }
        }
        Notif.cancel(context, Notif.ID_GEO)
        Notif.cancel(context, Notif.ID_MISSED)
    }
}
