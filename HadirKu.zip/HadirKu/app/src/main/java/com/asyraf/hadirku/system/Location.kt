package com.asyraf.hadirku.system

import android.Manifest
import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.os.Build
import androidx.core.content.ContextCompat
import com.asyraf.hadirku.data.Repo
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingEvent
import com.google.android.gms.location.GeofencingRequest
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import com.google.android.gms.tasks.Task
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

object LocationHelper {

    fun hasFine(ctx: Context): Boolean =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun hasAny(ctx: Context): Boolean = hasFine(ctx) ||
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun hasBackground(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 29 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED

    private suspend fun <T> Task<T>.awaitOrNull(): T? = suspendCancellableCoroutine { cont ->
        addOnSuccessListener { value -> if (cont.isActive) cont.resume(value) }
        addOnFailureListener { if (cont.isActive) cont.resume(null) }
        addOnCanceledListener { if (cont.isActive) cont.resume(null) }
    }

    /** Lokasi semasa (cuba GPS dulu, kemudian lokasi terakhir). Null jika tiada izin atau gagal. */
    @SuppressLint("MissingPermission")
    suspend fun current(ctx: Context): Location? {
        if (!hasAny(ctx)) return null
        val client = LocationServices.getFusedLocationProviderClient(ctx)
        val cts = CancellationTokenSource()
        val fresh = withTimeoutOrNull(20_000L) {
            client.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, cts.token).awaitOrNull()
        }
        if (fresh == null) cts.cancel()
        return fresh ?: withTimeoutOrNull(5_000L) { client.lastLocation.awaitOrNull() }
    }

    fun distanceMeters(aLat: Double, aLng: Double, bLat: Double, bLng: Double): Float {
        val r = FloatArray(1)
        Location.distanceBetween(aLat, aLng, bLat, bLng, r)
        return r[0]
    }
}

object GeofenceHelper {
    private const val ID = "kilang"

    private fun pendingIntent(ctx: Context): PendingIntent {
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
        return PendingIntent.getBroadcast(ctx, 7, Intent(ctx, GeofenceReceiver::class.java), flags)
    }

    @Volatile private var lastKey: String? = null

    /**
     * Daftar (atau daftar semula) kawasan kilang. Diam jika lokasi / izin belum ada.
     * Tanpa [force], tak buat apa-apa kalau tetapan & izin sama seperti pendaftaran terakhir.
     */
    @SuppressLint("MissingPermission")
    fun register(ctx: Context, force: Boolean = false) {
        Repo.init(ctx)
        val s = Repo.settings.value
        val key = "${s.workLat},${s.workLng},${s.workRadius},${LocationHelper.hasFine(ctx)},${LocationHelper.hasBackground(ctx)}"
        if (!force && key == lastKey) return
        lastKey = key
        val client = LocationServices.getGeofencingClient(ctx)
        try {
            client.removeGeofences(pendingIntent(ctx))
        } catch (e: Exception) {
            // abaikan
        }
        val lat = s.workLat ?: return
        val lng = s.workLng ?: return
        if (!LocationHelper.hasFine(ctx) || !LocationHelper.hasBackground(ctx)) return
        val fence = Geofence.Builder()
            .setRequestId(ID)
            .setCircularRegion(lat, lng, s.workRadius.coerceIn(100, 2000).toFloat())
            .setExpirationDuration(Geofence.NEVER_EXPIRE)
            .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER or Geofence.GEOFENCE_TRANSITION_EXIT)
            .build()
        val req = GeofencingRequest.Builder()
            .setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER)
            .addGeofence(fence)
            .build()
        try {
            client.addGeofences(req, pendingIntent(ctx))
        } catch (e: Exception) {
            // contohnya lokasi dimatikan — akan cuba lagi bila app dibuka
        }
    }
}

class GeofenceReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val event = GeofencingEvent.fromIntent(intent) ?: return
        if (event.hasError()) return
        when (event.geofenceTransition) {
            Geofence.GEOFENCE_TRANSITION_ENTER -> Attendance.onArrive(context)
            Geofence.GEOFENCE_TRANSITION_EXIT -> Attendance.onLeave(context)
        }
    }
}
