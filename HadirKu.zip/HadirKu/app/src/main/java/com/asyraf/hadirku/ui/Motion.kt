package com.asyraf.hadirku.ui

import androidx.compose.animation.core.AnimationState
import androidx.compose.animation.core.DecayAnimationSpec
import androidx.compose.animation.core.Easing
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.animateDecay
import androidx.compose.animation.core.exponentialDecay
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.gestures.FlingBehavior
import androidx.compose.foundation.gestures.ScrollScope
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.Velocity
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/* ================= gerakan gaya iPhone ================= */

/** Lengkung iOS (dikira oleh Gerak.java) untuk tween Compose. */
val IosEase = Easing { Gerak.iosEase(it) }
val IosOut = Easing { Gerak.iosOut(it) }
val BackOut = Easing { Gerak.easeOutBack(it) }

@Suppress("DEPRECATION")
private fun isDrag(s: NestedScrollSource): Boolean = s == NestedScrollSource.Drag

/** Fling licin: geseran rendah seperti iOS, baki halaju diserah kepada lantunan hujung. */
private class IosFling(private val decay: DecayAnimationSpec<Float>) : FlingBehavior {
    override suspend fun ScrollScope.performFling(initialVelocity: Float): Float {
        if (abs(initialVelocity) < 1f) return initialVelocity
        var left = initialVelocity
        var last = 0f
        AnimationState(initialValue = 0f, initialVelocity = initialVelocity).animateDecay(decay) {
            val delta = value - last
            val used = scrollBy(delta)
            last = value
            left = velocity
            if (abs(delta - used) > 0.5f) cancelAnimation()
        }
        return left
    }
}

@Composable
fun rememberIosFling(): FlingBehavior = remember { IosFling(exponentialDecay(frictionMultiplier = Gerak.FRICTION)) }

/**
 * Lantunan hujung macam iOS: tarik melepasi atas / bawah → kandungan ikut dengan rintangan getah,
 * lepas → melantun balik dengan spring. Fling yang terlanggar hujung juga melantun sedikit.
 */
@Composable
fun Modifier.iosBounce(): Modifier {
    val off = remember { mutableFloatStateOf(0f) }
    val h = remember { mutableFloatStateOf(1f) }
    val conn = remember {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                val o = off.floatValue
                if (o == 0f || !isDrag(source)) return Offset.Zero
                val dy = available.y
                if ((o > 0f && dy < 0f) || (o < 0f && dy > 0f)) {
                    val n = if (o > 0f) max(0f, o + dy) else min(0f, o + dy)
                    off.floatValue = n
                    return Offset(0f, n - o)
                }
                return Offset.Zero
            }

            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                if (!isDrag(source) || available.y == 0f) return Offset.Zero
                off.floatValue += available.y
                return Offset(0f, available.y)
            }

            override suspend fun onPreFling(available: Velocity): Velocity {
                if (off.floatValue == 0f) return Velocity.Zero
                animate(off.floatValue, 0f, 0f, spring(dampingRatio = 1f, stiffness = 260f)) { v, _ -> off.floatValue = v }
                return available
            }

            override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
                if (abs(available.y) < 60f) return Velocity.Zero
                animate(0f, 0f, Gerak.edgeVelocity(available.y), spring(dampingRatio = 1f, stiffness = 190f)) { v, _ -> off.floatValue = v }
                return available
            }
        }
    }
    return this
        .clipToBounds()
        .onSizeChanged { h.floatValue = it.height.toFloat() }
        .nestedScroll(conn)
        .graphicsLayer { translationY = Gerak.rubberBand(off.floatValue, h.floatValue) }
}

/** Skrol menegak gaya iPhone: fling licin + lantunan getah di hujung. */
@Composable
fun Modifier.iosScroll(state: ScrollState): Modifier = this.iosBounce().verticalScroll(state, flingBehavior = rememberIosFling())
