package com.asyraf.hadirku.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.StartOffset
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.asyraf.hadirku.MainViewModel
import com.asyraf.hadirku.Sheet
import com.asyraf.hadirku.data.RecordStatus
import com.asyraf.hadirku.logic.DayKind
import com.asyraf.hadirku.logic.Logic
import com.asyraf.hadirku.logic.Ms
import com.asyraf.hadirku.logic.Outcome
import com.asyraf.hadirku.logic.ShiftType
import com.asyraf.hadirku.pg.OtCycle
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.system.Bio
import java.time.Instant
import java.time.LocalDate

@Composable
fun KerjaScreen(vm: MainViewModel) {
    Seg(listOf("hadir" to "Hadir", "ot" to "OT", "disiplin" to "Disiplin"), vm.kerjaSeg) { vm.kerjaSeg = it }
    when (vm.kerjaSeg) {
        "ot" -> OtView(vm)
        "disiplin" -> DisiplinView(vm)
        else -> HadirView(vm)
    }
}

/* ================= HADIR ================= */

private enum class Mode { IN, OUT, DONE }

@Composable
private fun HadirView(vm: MainViewModel) {
    val pal = LocalPal.current
    val s by vm.settings.collectAsState()
    val recs by vm.records.collectAsState()
    val now by vm.now.collectAsState()
    val pg by vm.pg.collectAsState()
    val distance by vm.distance.collectAsState()
    val la = launch()
    val c = vm.cfg()
    val zone = Logic.zone()
    val today = Logic.today(now, zone)
    val todayIso = Logic.iso(today)
    val hour = Instant.ofEpochMilli(now).atZone(zone).hour
    val ev = Logic.evaluate(today, recs[today], c, now, zone)
    val open = Logic.openRecord(recs, now, zone)
    val todayRec = recs[today]
    val mode = when {
        open != null -> Mode.OUT
        todayRec != null && todayRec.checkIn != null && todayRec.checkOut != null -> Mode.DONE
        else -> Mode.IN
    }
    val streaks = remember(recs, s, pg.settings, todayIso) { Logic.streaks(recs, c, now, zone) }
    val cy = Logic.cycleOf(today, c)
    val sum = remember(recs, s, pg.settings, cy.start, now / 60_000L) { Logic.summarize(Logic.evalRange(Logic.cycleStart(cy), today, recs, c, now, zone)) }
    val os = remember(pg, cy.start) { PG.otSummary(pg, cy) }

    fun doCheckIn() {
        if (s.useBiometric) Bio.authenticate(la.activity, "Sahkan check-in", onSuccess = { vm.checkIn("biometrik") }, onError = { vm.toast(it) })
        else vm.checkIn("manual")
    }
    fun requestCheckIn() {
        val d = distance
        if (d != null && s.hasWorkLocation && d > s.workRadius + 300) vm.open(Sheet.Far(d)) else doCheckIn()
    }

    // ---------- sapaan ----------
    Block {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Txt(Ms.greeting(hour) + if (s.name.isNotBlank()) ", " + s.name.trim() else "", size = 17f, weight = FontWeight.SemiBold)
                val sub = when (ev.kind) {
                    DayKind.KERJA -> Ms.shiftLabel(ev.shift) + " · mula " + Ms.hm(Logic.shiftStartMinutes(today, s))
                    DayKind.CUTI_UMUM -> "Cuti umum"
                    DayKind.REST_DAY -> "Rest day"
                    DayKind.OFF_DAY -> "Off day"
                }
                Txt(sub, size = 13f, color = pal.muted)
            }
            Ico(if (ev.kind == DayKind.KERJA && ev.shift == ShiftType.MALAM) Ic.MOON else Ic.SUN, pal.accent, 26.dp)
        }
    }

    if (!s.hasWorkLocation) {
        Notice(rich("Tetapkan **lokasi kilang** dan **jadual shift** supaya check-in automatik, amaran lupa check-in dan log OT tepat."), Tone.INFO, "Tetapan") { vm.go("tetapan") }
    }

    // ---------- butang besar ----------
    Block {
        val startMs = Logic.shiftStartMs(today, s, zone)
        val headline = when {
            mode == Mode.OUT && open != null -> "Sedang bekerja sejak " + Ms.time(open.checkIn ?: now)
            mode == Mode.DONE -> "Shift hari ini selesai. Rehat secukupnya."
            ev.kind == DayKind.KERJA -> "Masuk kerja " + Ms.time(startMs)
            else -> "Hari rehat. Check-in kalau kerja OT."
        }
        Txt(headline, Modifier.fillMaxWidth(), size = 13.5f, color = pal.muted, align = TextAlign.Center)
        Spacer(Modifier.height(14.dp))
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            ClockButton(
                mode = mode,
                sub = when (mode) {
                    Mode.IN -> "Tekan untuk rekod"
                    Mode.OUT -> open?.checkIn?.let { Ms.duration(((now - it) / 60_000L).toInt()) } ?: ""
                    Mode.DONE -> "Tekan untuk edit"
                },
                onClick = {
                    when (mode) {
                        Mode.IN -> requestCheckIn()
                        Mode.OUT -> vm.checkOut()
                        Mode.DONE -> vm.open(Sheet.Attend(today))
                    }
                },
            )
        }
        Spacer(Modifier.height(14.dp))
        val active = open ?: todayRec
        val ai = active?.checkIn
        if (active != null && ai != null) {
            val e = Logic.evaluate(active.date, active, c, now, zone)
            val line = buildString {
                append("Masuk " + Ms.time(ai))
                when {
                    e.lateMinutes > 0 -> append(" · lewat ${e.lateMinutes} minit")
                    (e.arrivalDelta ?: 0) > 0 -> append(" · ${e.arrivalDelta} minit awal")
                }
                active.checkOut?.let { append(" · Keluar " + Ms.time(it)) }
                if (e.ot.total > 0) append(" · OT " + Ms.hours(e.ot.total) + "j (" + M(e.ot.nilai(c.gaji)) + ")")
            }
            Txt(line, Modifier.fillMaxWidth(), size = 14f, align = TextAlign.Center)
        } else if (todayRec != null && todayRec.status != RecordStatus.HADIR) {
            Txt("Hari ini direkod sebagai " + (if (todayRec.status == RecordStatus.CUTI) "cuti" else "MC"), Modifier.fillMaxWidth(), size = 14f, align = TextAlign.Center)
        }
        val d = distance
        if (d != null && s.hasWorkLocation) {
            Spacer(Modifier.height(4.dp))
            InfoLine(Ic.PIN, if (d <= s.workRadius) "Dalam kawasan kilang" else if (d < 1000) "${d.toInt()} m dari kilang" else String.format(java.util.Locale.US, "%.1f km dari kilang", d / 1000f))
        }
    }

    // ---------- jubin ----------
    val rate = sum.onTimeRate
    Tiles(listOf(
        TileData("Streak hadir", "${streaks.attend} hari", "Terbaik ${streaks.bestAttend} hari") { vm.kerjaSeg = "disiplin" },
        TileData("Tepat masa", if (rate != null) "$rate%" else "–", "Kitaran " + Logic.cycleLabel(cy)) { vm.kerjaSeg = "disiplin" },
        TileData("OT kitaran ini", M(os.nilai), fmtH(os.kiraHad) + " / " + PG.jsNum(os.had) + " jam had") { vm.kerjaSeg = "ot" },
        TileData("Skor disiplin", sum.grade, "${sum.score}/100") { vm.kerjaSeg = "disiplin" },
    ))

    // ---------- OT hari ini vs belanja harian (sambungan ke PoketGaji) ----------
    val ds = remember(pg, todayIso) { PG.dailySummary(pg, PG.ym(todayIso), null) }
    val x = ds.days.find { it.tarikh == todayIso }
    if (x != null) {
        SecHead("Hari ini dalam poket", "Butiran") { vm.open(Sheet.Day(todayIso)) }
        Block(pad = false) {
            Column(Modifier.padding(horizontal = GL, vertical = 4.dp)) {
                Kvl(listOf(
                    Triple(rich("OT diperoleh"), "+" + M(x.ot), pal.inn),
                    Triple(rich("Belanja harian"), M(-x.harian), pal.out),
                    Triple(rich("Baki (OT − belanja)"), Mp(x.bakiOt), if (x.bakiOt < -0.004) pal.out else pal.inn),
                ), strongIdx = setOf(2))
            }
        }
        if (x.harian > x.ot + 0.004 && x.harian > 0) Note("Belanja harian hari ini melebihi OT sebanyak " + M(x.harian - x.ot) + ".")
    }

    // ---------- 7 hari akan datang ----------
    SecHead("Jadual 7 hari")
    Row(Modifier.fillMaxWidth().background(pal.line).padding(vertical = 1.dp).height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(1.dp)) {
        (0 until 7).forEach { i ->
            val dd = today.plusDays(i.toLong())
            val k = Logic.dayKind(dd, s)
            val sh = Logic.shiftType(dd, s)
            val r = recs[dd]
            val (lbl, bg, fg) = when {
                r != null && r.status == RecordStatus.CUTI -> Triple("Cuti", pal.inSoft, pal.inn)
                r != null && r.status == RecordStatus.MC -> Triple("MC", pal.inSoft, pal.inn)
                k == DayKind.KERJA -> if (sh == ShiftType.PAGI) Triple("Pagi", pal.surface, pal.ink) else Triple("Malam", pal.accentSoft, pal.accentStrong)
                k == DayKind.CUTI_UMUM -> Triple("Umum", pal.goodSoft, pal.good)
                else -> Triple(if (k == DayKind.REST_DAY) "Rest" else "Off", pal.surface2, pal.muted)
            }
            Column(
                Modifier.weight(1f).fillMaxHeight().background(bg).clickable { vm.open(Sheet.Attend(dd)) }.padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Txt(Ms.daysShort[dd.dayOfWeek.value - 1], size = 11f, color = pal.muted, weight = if (i == 0) FontWeight.Bold else FontWeight.Normal)
                Txt(dd.dayOfMonth.toString(), size = 15f, weight = FontWeight.SemiBold, color = if (i == 0) pal.accent else pal.ink)
                Txt(lbl, size = 10.5f, weight = FontWeight.SemiBold, color = fg)
            }
        }
    }

    Gap(4.dp)
    Btn("Rasa malas nak pergi kerja hari ni?", { vm.open(Sheet.Malas) }, Modifier.fillMaxWidth().padding(horizontal = GL))
}

@Composable
private fun InfoLine(ic: Ic, text: String, onClick: (() -> Unit)? = null) {
    val pal = LocalPal.current
    Row(
        Modifier.fillMaxWidth().then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier).padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically,
    ) {
        Ico(ic, pal.muted, 16.dp)
        Spacer(Modifier.width(6.dp))
        Txt(text + if (onClick != null) "  ›" else "", Modifier.weight(1f, fill = false), size = 12.5f, color = pal.muted, align = TextAlign.Center)
    }
}

/**
 * Butang check-in / check-out: sentiasa berdenyut besar–kecil, dengan gelang riak yang mengembang.
 */
@Composable
private fun ClockButton(mode: Mode, sub: String, onClick: () -> Unit) {
    val pal = LocalPal.current
    val ring = when (mode) { Mode.IN -> pal.accent; Mode.OUT -> pal.out; Mode.DONE -> pal.lineStrong }
    val live = mode != Mode.DONE
    val inf = rememberInfiniteTransition(label = "denyut")
    // nilai animasi dibaca dalam fasa lukis sahaja (tidak recompose setiap bingkai)
    val pulse = inf.animateFloat(
        initialValue = 0.92f, targetValue = 1.08f,
        animationSpec = infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "skala",
    )
    val wave = inf.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1800, easing = LinearEasing), RepeatMode.Restart), label = "riak",
    )
    val wave2 = inf.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1800, easing = LinearEasing), RepeatMode.Restart, initialStartOffset = StartOffset(900)), label = "riak2",
    )
    Box(Modifier.size(236.dp), contentAlignment = Alignment.Center) {
        if (live) {
            Canvas(Modifier.fillMaxSize()) {
                val base = 84.dp.toPx()
                listOf(wave.value, wave2.value).forEach { w ->
                    val r = base * (1f + 0.36f * w)
                    drawCircle(ring.copy(alpha = 0.35f * (1f - w)), radius = r, center = Offset(size.width / 2, size.height / 2), style = Stroke(width = 3.dp.toPx()))
                }
            }
        }
        Box(
            Modifier.size(168.dp)
                .graphicsLayer { val sc = if (live) pulse.value else 1f; scaleX = sc; scaleY = sc; shadowElevation = if (live) 10.dp.toPx() else 2.dp.toPx(); shape = CircleShape; clip = true }
                .background(pal.surface, CircleShape)
                .border(7.dp, ring, CircleShape)
                .pressable(onClick, scaleTo = 0.9f),
            contentAlignment = Alignment.Center,
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Ico(when (mode) { Mode.IN -> Ic.FINGER; Mode.OUT -> Ic.LOGOUT; Mode.DONE -> Ic.CHECK }, ring, 40.dp, stroke = 2f)
                Spacer(Modifier.height(6.dp))
                Txt(when (mode) { Mode.IN -> "Check-in"; Mode.OUT -> "Check-out"; Mode.DONE -> "Selesai" }, size = 20f, weight = FontWeight.Bold)
                if (sub.isNotEmpty()) Txt(sub, size = 12.5f, color = pal.muted)
            }
        }
    }
}

/* ================= OT (port viewOT PoketGaji) ================= */

private fun payDateOf(c: OtCycle): String { val bp = PG.parse(c.bayarYm + "-01"); return PG.iso(bp.y, bp.m, Math.min(30, PG.lastDay(bp.y, bp.m))) }

@Composable
private fun OtView(vm: MainViewModel) {
    val pal = LocalPal.current
    val pg by vm.pg.collectAsState()
    val recs by vm.records.collectAsState()
    val today = vm.today()
    val c = vm.cyc
    val sd = vm.otSd()
    val s = remember(pg, c) { PG.otSummary(pg, c) }
    val oo = remember(pg, today) { PG.otOutstanding(pg, today) }
    val sett = remember(pg) { PG.otSettlements(pg).byCycle }[c.start]
    val ended = c.end < today
    val lepas = oo.lepas

    NavRow(PG.fmtShort(c.start) + " – " + PG.fmtShort(c.end), "Dibayar dalam gaji " + PG.fmtMonth(c.bayarYm),
        { vm.cyc = PG.shiftCycle(c, -1, sd) }, { vm.cyc = PG.shiftCycle(c, 1, sd) })
    Hero("Nilai OT kitaran ini", s.nilai) {
        Txt(s.hari.toString() + " hari direkod · " + fmtH(s.jam) + " jam di tempat kerja", size = 13f, color = pal.muted)
        if (oo.jumlah > 0.004) Txt(rich("OT belum masuk gaji: **" + M(oo.jumlah) + "**" + if (oo.lepas.dibayar != null || !(oo.lepas.nilai > 0)) "" else " (termasuk " + PG.fmtShort(oo.lepas.cycle.start) + " – " + PG.fmtShort(oo.lepas.cycle.end) + ")"), size = 13f)
    }
    if (lepas.dibayar == null && lepas.nilai > 0 && c.start == oo.kini.cycle.start && today >= PG.addDays(payDateOf(lepas.cycle), -3)) {
        Notice(rich("Gaji " + PG.fmtMonth(lepas.cycle.bayarYm) + " dah masuk? Rekod supaya OT " + PG.fmtShort(lepas.cycle.start) + " – " + PG.fmtShort(lepas.cycle.end) + " (" + M(lepas.nilai) + ") ditanda dibayar."),
            Tone.INFO, "Rekod gaji") { vm.recordGaji(lepas.cycle.start) }
    }
    Stats(listOf(fmtH(s.h15) to "Jam 1.5x", fmtH(s.h20) to "Jam 2.0x", fmtH(s.h30) to "Jam 3.0x", PG.toFixed(s.hrp, 2) to "RM sejam"))
    val pc = if (s.had > 0) Math.min(1.0, s.kiraHad / s.had) else 0.0
    val tone = if (s.bakiHad < 0) Tone.BAD else if (s.bakiHad <= 10) Tone.WARN else Tone.GOOD
    Block {
        Row(Modifier.fillMaxWidth()) {
            Txt("Jam dikira had (1.5x + 3.0x)", Modifier.weight(1f), size = 13f)
            Txt(fmtH(s.kiraHad) + " / " + PG.jsNum(s.had) + " jam", size = 13f, num = true)
        }
        Spacer(Modifier.height(8.dp))
        Bar(pc, over = tone == Tone.BAD, warn = tone == Tone.WARN, h = 8.dp)
        Spacer(Modifier.height(8.dp))
        Txt(if (s.bakiHad >= 0) "Baki " + fmtH(s.bakiHad) + " jam sebelum cecah had" else "Melebihi had sebanyak " + fmtH(-s.bakiHad) + " jam",
            size = 13f, weight = FontWeight.SemiBold, color = when (tone) { Tone.BAD -> pal.bad; Tone.WARN -> pal.warn; else -> pal.good })
    }
    Slip("Slip anggaran", PG.fmtMonth(c.bayarYm)) {
        SlipRow("Gaji asas + elaun", M(s.asas)); SlipRow("Overtime", M(s.nilai)); SlipRow("Gaji kasar", M(s.kasar), true)
        SlipRow("Potongan", M(-s.potongan)); SlipRow("Gaji bersih", M(s.bersih), true)
        SlipRow("Advance 15hb", M(s.advance)); SlipRow("Baki 30hb", M(s.gaji30), true)
        if (sett != null) SlipNote(rich("✔ Dibayar dalam duit masuk " + PG.fmtDate(sett.tarikh) + " · OT " + M(sett.jumlah) + if (sett.auto) " (dikira auto)" else ""))
        else if (ended) {
            SlipNote(rich("Gaji yang membayar OT ini belum direkod."))
            Btn("Rekod gaji masuk", { vm.recordGaji(c.start) }, Modifier.fillMaxWidth().padding(top = 8.dp))
        } else SlipNote(rich("Akan dibayar dalam gaji " + PG.fmtMonth(c.bayarYm) + "."))
        SlipNote(rich("Anggaran sahaja. Ubah gaji asas, elaun dan potongan di Tetapan (ikon gear di atas)."))
    }
    SecHead("Log harian", right = "Tekan tarikh untuk isi jam")
    ListBlock {
        s.rows.forEach { r ->
            val e = r.entry
            val p = PG.parse(r.tarikh)
            val fut = r.tarikh > today
            val now = r.tarikh == today
            val rec = recs[Logic.date(r.tarikh)]
            Row(
                Modifier.fillMaxWidth().background(if (now) pal.accentSoft else Color.Transparent).hairlines(pal.line)
                    .graphicsLayer { alpha = if (fut) 0.5f else 1f }
                    .clickable { vm.open(Sheet.OtDay(r.tarikh)) }.heightIn(min = 52.dp).padding(horizontal = GL, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.width(56.dp)) {
                    Txt(PG.pad(p.d) + "/" + PG.pad(p.m), size = 15f, weight = FontWeight.SemiBold, num = true)
                    Txt(if (now) "Hari ini" else PG.HARI[PG.weekday(r.tarikh)], size = 11.5f, color = pal.muted)
                }
                Spacer(Modifier.width(8.dp))
                Box(Modifier.width(64.dp)) { HariChip(e?.jenis) }
                Column(Modifier.weight(1f).padding(start = 8.dp)) {
                    val jam = e?.jam
                    if (jam != null) Txt(fmtH(jam) + " jam", size = 13.5f, color = pal.muted, num = true)
                    val ci = rec?.checkIn
                    val co = rec?.checkOut
                    if (ci != null) Txt(Ms.time(ci) + (if (co != null) "–" + Ms.time(co) else " · sedang kerja"), size = 11.5f, color = pal.accentStrong, num = true)
                }
                Txt(if (r.nilai > 0) M(r.nilai) else "", size = 13.5f, weight = FontWeight.SemiBold, num = true)
            }
        }
    }
    Note("Jam dari check-in / check-out masuk ke log ini sendiri (dibundar ke bawah ikut Tetapan). Boleh ubah manual bila perlu.")
}

@Composable
fun HariChip(jenis: String?) {
    val pal = LocalPal.current
    val shape = RoundedCornerShape(7.dp)
    val (bg, fg, bd) = when (jenis) {
        null -> Triple(pal.surface2, pal.muted, pal.line)
        "biasa" -> Triple(pal.surface2, pal.ink, pal.line)
        "off" -> Triple(pal.goodSoft, pal.good, Color.Transparent)
        "rest", "umum" -> Triple(pal.accentSoft, pal.accentStrong, Color.Transparent)
        else -> Triple(pal.surface2, pal.muted, pal.line)
    }
    Box(Modifier.background(bg, shape).border(1.dp, bd, shape).padding(horizontal = 7.dp, vertical = 3.dp)) {
        Txt(if (jenis == null) "–" else hariLabel(jenis).short, size = 11.5f, weight = FontWeight.SemiBold, color = fg)
    }
}

/* ================= DISIPLIN (statistik, kalendar, pencapaian, jurulatih) ================= */

@Composable
private fun DisiplinView(vm: MainViewModel) {
    val pal = LocalPal.current
    val s by vm.settings.collectAsState()
    val recs by vm.records.collectAsState()
    val now by vm.now.collectAsState()
    val pg by vm.pg.collectAsState()
    val la = launch()
    val c = vm.cfg()
    val zone = Logic.zone()
    val today = Logic.today(now, zone)
    val cy = vm.disCyc
    val sd = vm.otSd()
    val start = Logic.cycleStart(cy)
    val end = Logic.cycleEnd(cy)
    val evals = remember(recs, s, pg.settings, cy.start, now / 60_000L) { Logic.evalRange(start, end, recs, c, now, zone) }
    val upto = evals.filter { !it.date.isAfter(today) }
    val sum = remember(evals) { Logic.summarize(upto) }
    val st = remember(recs, s, pg.settings, today) { Logic.streaks(recs, c, now, zone) }
    val os = remember(pg, cy.start) { PG.otSummary(pg, cy) }
    val ach = remember(recs, s, pg, today) { Logic.achievements(recs, c, pg, now, zone) }

    NavRow(Logic.cycleLabel(cy), "Kitaran OT · gaji " + PG.fmtMonth(cy.bayarYm), { vm.disCyc = PG.shiftCycle(cy, -1, sd) }, { vm.disCyc = PG.shiftCycle(cy, 1, sd) })

    Block {
        Txt("Skor disiplin", size = 12f, color = pal.muted)
        Row(verticalAlignment = Alignment.Bottom) {
            Txt(sum.grade, size = 34f, weight = FontWeight.Bold, color = if (sum.score >= 85) pal.good else if (sum.score >= 70) pal.accent else pal.bad)
            Spacer(Modifier.width(10.dp))
            Txt("${sum.score}/100", Modifier.padding(bottom = 6.dp), size = 15f, color = pal.muted, num = true)
            Spacer(Modifier.weight(1f))
            val r = sum.onTimeRate
            Box(Modifier.padding(bottom = 6.dp)) { Pill(if (r != null) "Tepat masa $r%" else "Belum ada data", if (r == null) Tone.NEUTRAL else if (r >= 90) Tone.GOOD else if (r >= 70) Tone.WARN else Tone.BAD) }
        }
        Spacer(Modifier.height(6.dp))
        Bar(sum.score / 100.0, warn = sum.score in 70..84, over = sum.score < 70, h = 8.dp)
        Spacer(Modifier.height(8.dp))
        Txt("Tidak hadir tolak 15 mata, lewat tolak 5 mata, MC kedua dan seterusnya tolak 3 mata.", size = 12.5f, color = pal.muted)
    }
    Stats(listOf("${sum.attended}/${sum.scheduled}" to "Hadir", sum.late.toString() to "Lewat (${sum.lateMinutes}m)", sum.absent.toString() to "Tidak hadir", "${sum.cuti}/${sum.mc}" to "Cuti / MC"))
    Stats(listOf(fmtH(os.h15 + os.h20 + os.h30) to "Jam OT", (sum.avgArrival?.let { (if (it >= 0) "+" else "") + it + "m" } ?: "–") to "Purata tiba", sum.extraDays.toString() to "Kerja hari rehat", "${st.attend}" to "Streak hadir"))

    // ---------- kalendar kehadiran ----------
    SecHead("Kalendar kehadiran", right = "Tekan hari untuk edit")
    AttendCalendar(evals, today) { vm.open(Sheet.Attend(it)) }
    Block(pad = false) {
        Column(Modifier.padding(horizontal = GL, vertical = 8.dp)) {
            Legend(listOf(
                LegItem("Tepat masa", pal.goodSoft), LegItem("Lewat", pal.warnSoft), LegItem("Tidak hadir", pal.badSoft),
                LegItem("Cuti / MC", pal.inSoft), LegItem("Cuti umum", pal.accentSoft),
            ))
        }
    }

    // ---------- log hari ----------
    val list = upto.filter { it.record != null || it.outcome == Outcome.TIDAK_HADIR }.reversed()
    if (list.isNotEmpty()) {
        SecHead("Log kehadiran")
        ListBlock {
            list.forEach { e ->
                val r = e.record
                val (lbl, tone) = when (e.outcome) {
                    Outcome.TEPAT -> "Tepat" to Tone.GOOD
                    Outcome.LEWAT -> "Lewat ${e.lateMinutes}m" to Tone.WARN
                    Outcome.TIDAK_HADIR -> "Tidak hadir" to Tone.BAD
                    Outcome.CUTI -> "Cuti" to Tone.INFO
                    Outcome.MC -> "MC" to Tone.INFO
                    Outcome.KERJA_LEBIH -> "Hari rehat" to Tone.INFO
                    else -> Ms.outcomeLabel(e.outcome) to Tone.NEUTRAL
                }
                Row(
                    Modifier.fillMaxWidth().hairlines(pal.line).clickable { vm.open(Sheet.Attend(e.date)) }.padding(horizontal = GL, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Txt(Ms.dateShort(e.date), size = 15f, weight = FontWeight.Medium)
                        val bits = ArrayList<String>()
                        bits.add(if (e.shift == ShiftType.PAGI) "Pagi" else "Malam")
                        r?.checkIn?.let { bits.add("masuk " + Ms.time(it)) }
                        r?.checkOut?.let { bits.add("keluar " + Ms.time(it)) }
                        if (e.ot.total > 0) bits.add("OT " + Ms.hours(e.ot.total) + "j")
                        if (r != null && r.mood in 1..5) bits.add(Ms.moods[r.mood - 1])
                        Txt(bits.joinToString(" · "), size = 12.5f, color = pal.muted)
                    }
                    Pill(lbl, tone)
                }
            }
        }
    }

    // ---------- pencapaian ----------
    SecHead("Pencapaian", right = ach.count { it.unlocked }.toString() + "/" + ach.size)
    ListBlock {
        ach.forEach { a ->
            Column(Modifier.fillMaxWidth().hairlines(pal.line).padding(horizontal = GL, vertical = 11.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(30.dp).background(if (a.unlocked) pal.accentSoft else pal.surface2, CircleShape),
                        contentAlignment = Alignment.Center,
                    ) { if (a.unlocked) Ico(Ic.CHECK, pal.accent, 20.dp) else Ico(Ic.FIRE, pal.muted, 18.dp) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Txt(a.title, size = 15f, weight = FontWeight.SemiBold, color = if (a.unlocked) pal.ink else pal.muted)
                        Txt(a.desc, size = 12.5f, color = pal.muted)
                    }
                    Txt(Math.min(a.progress, a.target).toString() + "/" + a.target, size = 13f, color = pal.muted, num = true)
                }
                if (!a.unlocked) { Spacer(Modifier.height(8.dp)); Bar(a.progress.toDouble() / a.target, h = 5.dp) }
            }
        }
    }

    // ---------- jurulatih AI & eksport ----------
    SecHead("Jurulatih disiplin (Claude)")
    Block {
        Txt("Hantar ringkasan kitaran ini kepada Claude untuk ulasan: yang bagus, corak yang perlu dibaiki dan langkah untuk kitaran depan.", size = 13f, color = pal.muted)
        Spacer(Modifier.height(10.dp))
        Btn("Minta ulasan kitaran ini", { vm.askCoach(cy) }, Modifier.fillMaxWidth(), kind = BtnKind.PRIMARY)
    }
    SecHead("Eksport kehadiran")
    Block {
        Txt("CSV boleh dibuka dalam Excel atau Google Sheets. Termasuk masa masuk / keluar dan log OT.", size = 13f, color = pal.muted)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Btn("CSV kitaran ini", { la.saveFile("Duitku-kehadiran-" + cy.start + ".csv", "text/csv", vm.csvFor(cy), "CSV disimpan", false) }, Modifier.weight(1f))
            Btn("CSV semua", { la.saveFile("Duitku-kehadiran-semua-" + vm.today() + ".csv", "text/csv", vm.csvFor(null), "CSV disimpan", false) }, Modifier.weight(1f))
        }
    }
}

@Composable
private fun AttendCalendar(evals: List<com.asyraf.hadirku.logic.DayEval>, today: LocalDate, onDay: (LocalDate) -> Unit) {
    val pal = LocalPal.current
    if (evals.isEmpty()) return
    val lead = evals.first().date.dayOfWeek.value - 1
    val cells: List<com.asyraf.hadirku.logic.DayEval?> = List(lead) { null } + evals
    Column(Modifier.fillMaxWidth().background(pal.surface).hairlines(pal.line, top = true, bottom = true)) {
        Row(Modifier.fillMaxWidth().hairlines(pal.line)) {
            listOf("Isn", "Sel", "Rab", "Kha", "Jum", "Sab", "Ahd").forEachIndexed { k, h ->
                Txt(h, Modifier.weight(1f).padding(vertical = 7.dp), size = 11.5f, weight = FontWeight.SemiBold, color = if (k >= 5) pal.accentStrong else pal.muted, align = TextAlign.Center)
            }
        }
        Column(Modifier.fillMaxWidth().background(pal.line), verticalArrangement = Arrangement.spacedBy(1.dp)) {
            cells.chunked(7).forEach { week ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(1.dp)) {
                    (0 until 7).forEach { i ->
                        val e = week.getOrNull(i)
                        if (e == null) Box(Modifier.weight(1f).aspectRatio(0.95f).background(pal.surface2))
                        else {
                            val fut = e.date.isAfter(today)
                            val bg = when (e.outcome) {
                                Outcome.TEPAT -> pal.goodSoft
                                Outcome.LEWAT -> pal.warnSoft
                                Outcome.TIDAK_HADIR -> pal.badSoft
                                Outcome.CUTI, Outcome.MC -> pal.inSoft
                                Outcome.CUTI_UMUM -> pal.accentSoft
                                Outcome.KERJA_LEBIH -> pal.accentSoft
                                else -> pal.surface
                            }
                            val tag = when {
                                e.outcome == Outcome.CUTI -> "Cuti"
                                e.outcome == Outcome.MC -> "MC"
                                e.outcome == Outcome.CUTI_UMUM -> "Umum"
                                e.kind == DayKind.KERJA -> if (e.shift == ShiftType.PAGI) "P" else "M"
                                e.outcome == Outcome.KERJA_LEBIH -> "OT"
                                else -> "–"
                            }
                            Column(
                                Modifier.weight(1f).aspectRatio(0.95f).background(bg)
                                    .then(if (e.date == today) Modifier.border(2.dp, pal.accent) else Modifier)
                                    .graphicsLayer { alpha = if (fut) 0.55f else 1f }
                                    .clickable { onDay(e.date) }.padding(4.dp),
                            ) {
                                Txt(e.date.dayOfMonth.toString(), size = 12f, weight = FontWeight.SemiBold)
                                Spacer(Modifier.weight(1f))
                                Txt(tag, Modifier.fillMaxWidth(), size = 10.5f, color = pal.muted, align = TextAlign.End)
                            }
                        }
                    }
                }
            }
        }
    }
}
