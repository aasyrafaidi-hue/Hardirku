package com.asyraf.hadirku.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.asyraf.hadirku.MainViewModel
import com.asyraf.hadirku.Sheet
import com.asyraf.hadirku.pg.OtEntry
import com.asyraf.hadirku.pg.PG

/**
 * Tab Kerja: key in OT sahaja.
 * Atas: ringkasan kitaran. Tengah: borang isi jam OT (tarikh, jenis hari, jam). Bawah: log harian kitaran.
 */
@Composable
fun KerjaScreen(vm: MainViewModel) {
    val pal = LocalPal.current
    val pg by vm.pg.collectAsState()
    val today = vm.today()
    val c = vm.cyc
    val sd = vm.otSd()
    val sum = remember(pg, c) { PG.otSummary(pg, c) }

    NavRow(PG.fmtShort(c.start) + " – " + PG.fmtShort(c.end), "Dibayar dalam gaji " + PG.fmtMonth(c.bayarYm),
        { vm.cyc = PG.shiftCycle(c, -1, sd) }, { vm.cyc = PG.shiftCycle(c, 1, sd) })
    Hero("Nilai OT kitaran ini", sum.nilai) {
        Txt(sum.hari.toString() + " hari direkod · " + fmtH(sum.jam) + " jam di tempat kerja", size = 13f, color = pal.muted)
    }
    Stats(listOf(fmtH(sum.h15) to "Jam 1.5x", fmtH(sum.h20) to "Jam 2.0x", fmtH(sum.h30) to "Jam 3.0x", PG.toFixed(sum.hrp, 2) to "RM sejam"))

    OtKeyIn(vm)

    SecHead("Log harian", right = "Tekan tarikh untuk edit")
    ListBlock {
        sum.rows.forEach { r ->
            val e = r.entry
            val p = PG.parse(r.tarikh)
            val fut = r.tarikh > today
            val now = r.tarikh == today
            Row(
                Modifier.fillMaxWidth().background(if (now) pal.accentSoft else Color.Transparent).hairlines(pal.line)
                    .graphicsLayer { alpha = if (fut) 0.5f else 1f }
                    .clickable { vm.open(Sheet.OtDay(r.tarikh)) }.heightIn(min = 48.dp).padding(horizontal = GL, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.width(56.dp)) {
                    Txt(PG.pad(p.d) + "/" + PG.pad(p.m), size = 15f, weight = FontWeight.SemiBold, num = true)
                    Txt(if (now) "Hari ini" else PG.HARI[PG.weekday(r.tarikh)], size = 11.5f, color = pal.muted)
                }
                Spacer(Modifier.width(8.dp))
                Box(Modifier.width(64.dp)) { HariChip(e?.jenis) }
                Txt(e?.jam?.let { fmtH(it) + " jam" } ?: "", Modifier.weight(1f).padding(start = 8.dp), size = 13.5f, color = pal.muted, num = true)
                Txt(if (r.nilai > 0) M(r.nilai) else "", size = 13.5f, weight = FontWeight.SemiBold, num = true)
            }
        }
    }
}

/** Borang key in OT terus dalam tab (tanpa buka helaian). Enter pada jam = simpan. */
@Composable
private fun OtKeyIn(vm: MainViewModel) {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    val focus = LocalFocusManager.current
    val pg by vm.pg.collectAsState()
    val today = vm.today()
    var d by remember { mutableStateOf(today) }
    val cur = pg.ot[d]
    // nilai awal ikut tarikh dipilih (log sedia ada atau jenis hari ikut jadual)
    var jenis by remember(d, cur) { mutableStateOf(cur?.jenis ?: vm.defaultHari(d)) }
    var jam by remember(d, cur) { mutableStateOf(cur?.jam?.let { PG.jsNum(it) } ?: "") }
    var err by remember(d) { mutableStateOf("") }
    val g = pg.settings.gaji

    fun simpan() {
        focus.clearFocus()
        err = vm.saveOtDay(d, jenis, jam)
        if (err.isEmpty() && (d < vm.cyc.start || d > vm.cyc.end)) vm.cyc = PG.otCycleOf(d, vm.otSd())
    }
    fun step(dx: Double) {
        val v = vm.parseAmt(jam)
        jam = PG.jsNum(Math.max(0.0, Math.min(24.0, (if (v.isFinite()) v else 0.0) + dx)))
    }

    SecHead("Key in OT", right = if (cur != null) "Sudah direkod" else null)
    Block {
        // tarikh
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(40.dp).pressable({ d = PG.addDays(d, -1) }, scaleTo = 0.85f), contentAlignment = Alignment.Center) { Txt("‹", size = 26f, color = pal.muted) }
            Column(
                Modifier.weight(1f).clickable {
                    val p = PG.parse(d)
                    android.app.DatePickerDialog(ctx, { _, y, m, dd -> d = PG.iso(y, m + 1, dd) }, p.y, p.m - 1, p.d).show()
                }.padding(vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Txt(longDate(d), size = 16f, weight = FontWeight.SemiBold, align = TextAlign.Center)
                Txt(if (d == today) "Hari ini · tekan untuk tukar tarikh" else "Tekan untuk tukar tarikh", size = 12f, color = pal.muted)
            }
            Box(Modifier.size(40.dp).pressable({ d = PG.addDays(d, 1) }, scaleTo = 0.85f), contentAlignment = Alignment.Center) { Txt("›", size = 26f, color = pal.muted) }
        }
        Spacer(Modifier.height(10.dp))
        // jenis hari
        Chips(PG.JENIS_HARI.map { it.id to it.label }, jenis, { jenis = it })
        if (jenis != "tidak") {
            Spacer(Modifier.height(12.dp))
            Txt("Jam di tempat kerja (masuk sampai balik, termasuk rehat)", size = 13f, color = pal.muted)
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                QBtn("−", Modifier.size(48.dp)) { step(-0.5) }
                BasicTextField(
                    value = jam, onValueChange = { jam = it; err = "" },
                    modifier = Modifier.weight(1f).hairlines(pal.line).padding(vertical = 8.dp),
                    textStyle = TextStyle(fontSize = 26.sp, fontWeight = FontWeight.SemiBold, color = pal.ink, textAlign = TextAlign.Center, fontFeatureSettings = "tnum"),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal, imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { simpan() }),
                    cursorBrush = SolidColor(pal.accent),
                    decorationBox = { inner -> Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { if (jam.isEmpty()) Txt("0", size = 26f, color = pal.muted); inner() } },
                )
                QBtn("+", Modifier.size(48.dp)) { step(0.5) }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(8, 9, 10, 11, 12).forEach { n -> QBtn(n.toString() + "j", Modifier.weight(1f)) { jam = n.toString(); err = "" } }
            }
        }
        // anggaran nilai
        val v = vm.parseAmt(jam)
        val h = PG.otHours(OtEntry(jenis, if (v.isFinite()) v else 0.0), g.jamNormal)
        val nilai = (h.h15 * 1.5 + h.h20 * 2 + h.h30 * 3) * PG.hrp(g)
        val parts = ArrayList<String>()
        if (h.h15 > 0) parts.add(fmtH(h.h15) + "j × 1.5"); if (h.h20 > 0) parts.add(fmtH(h.h20) + "j × 2.0"); if (h.h30 > 0) parts.add(fmtH(h.h30) + "j × 3.0")
        Spacer(Modifier.height(10.dp))
        Txt(
            if (jenis == "tidak") rich("Hari tidak bekerja. Tiada OT.")
            else if (parts.isNotEmpty()) rich("OT: " + parts.joinToString(" + ") + " = **" + M(nilai) + "**")
            else rich("Tiada OT untuk jam ini (jam normal " + PG.jsNum(g.jamNormal) + " jam)."),
            size = 13.5f, color = pal.muted,
        )
        FormError(err)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (cur != null) Btn("Kosongkan", { vm.clearOtDay(d) }, Modifier.weight(1f), color = pal.bad)
            Btn(if (cur != null) "Kemas kini" else "Simpan OT", { simpan() }, Modifier.weight(2f), kind = BtnKind.PRIMARY)
        }
    }
}

@Composable
fun HariChip(jenis: String?) {
    val pal = LocalPal.current
    val shape = RoundedCornerShape(7.dp)
    val (bg, fg, bd) = when (jenis) {
        null -> Triple(pal.surface2, pal.muted, pal.line)
        "biasa" -> Triple(pal.surface2, pal.ink, pal.line)
        "off" -> Triple(pal.goodSoft, pal.good, Color.Transparent)
        "rest", "umum" -> Triple(pal.accentSoft, pal.accentStrong, Color.Transparent)
        else -> Triple(pal.surface2, pal.muted, pal.line)
    }
    Box(Modifier.background(bg, shape).border(1.dp, bd, shape).padding(horizontal = 7.dp, vertical = 3.dp)) {
        Txt(if (jenis == null) "–" else hariLabel(jenis).short, size = 11.5f, weight = FontWeight.SemiBold, color = fg)
    }
}
