package com.asyraf.hadirku.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.asyraf.hadirku.MainViewModel
import com.asyraf.hadirku.Sheet
import com.asyraf.hadirku.TunaiDraft
import com.asyraf.hadirku.logic.Logic
import com.asyraf.hadirku.logic.Ms
import com.asyraf.hadirku.pg.Epp
import com.asyraf.hadirku.pg.OtEntry
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.Tx

private fun numText(d: Double): String = if (d == 0.0) "" else PG.jsNum(d)

@Composable
internal fun autoFocus(on: Boolean): FocusRequester {
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { if (on) runCatching { fr.requestFocus() } }
    return fr
}

/* ================= poket ================= */

@Composable
fun PocketMenuSheet(vm: MainViewModel, id: String) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val p = s.pockets.find { it.id == id } ?: return
    val b = PG.balances(s)[id] ?: 0.0
    val dw = p.dompet
    val kads = s.debts.any { it.jenis == "kad" }
    if (p.tunai) {
        val kira = vm.tunaiKira(id)
        SheetBody {
            SheetTitle(p.nama, rich("Baki tunai **" + M(b) + "** · duit dalam dompet, tidak dikira dalam baki bank" +
                (if (kira != null) "\nKali terakhir dikira " + PG.fmtShort(kira.first) + " (" + M(kira.second) + ")" else "")))
            MenuBtn("Belanja tunai", { vm.newTx(Tx(jenis = "keluar", poket = id), "Belanja tunai") }, primary = true)
            MenuBtn("Ambil duit dari ATM (bank → tunai)", { vm.newTx(Tx(jenis = "pindah", poket = "", ke = id, perkara = "Keluar duit ATM"), "Ambil duit dari ATM") })
            MenuBtn("Kira duit dalam dompet", { vm.open(Sheet.KiraTunai(id)) })
            MenuBtn("Terima duit tunai", { vm.newTx(Tx(jenis = "masuk", poket = id, perkara = "Terima tunai"), "Duit tunai masuk") })
            MenuBtn("Masukkan tunai ke bank", { vm.newTx(Tx(jenis = "pindah", poket = id, ke = PG.BELUM_AGIH, perkara = "Deposit tunai ke bank"), "Masukkan tunai ke bank") })
            if (kads) MenuBtn("Keluar tunai guna kad kredit", { vm.open(Sheet.Tunai(null, null, id, null)) })
            MenuBtn("Pindah ke poket lain", { vm.newTx(Tx(jenis = "pindah", poket = id)) })
            MenuBtn("Lihat transaksi", { vm.close(); vm.txPocket = id; vm.tab = "transaksi" })
            MenuBtn("Edit poket", { vm.open(Sheet.PocketForm(id)) })
            Note("Ambil duit di ATM = pindah dari poket bank ke dompet ini. Baki bank turun, tunai naik; jumlah duit anda tak berubah.", Modifier.padding(top = 8.dp, bottom = 8.dp))
        }
        return
    }
    SheetBody {
        SheetTitle(p.nama, rich("Baki **" + M(b) + "**" + if (dw) " · e-wallet, tidak dikira dalam baki bank" else ""))
        MenuBtn("Belanja dari poket ini", { vm.newTx(Tx(jenis = "keluar", poket = id)) })
        if (dw && kads) MenuBtn("Tambah nilai guna kad kredit", { vm.open(Sheet.Tunai(null, null, id, null)) })
        if (!dw && kads) MenuBtn("Belanja guna kad kredit", { vm.newTx(Tx(jenis = "kad", poket = id, perkara = if (id == "p-minyak") "Isi minyak" else ""), "Belanja guna kad kredit") })
        if (dw) MenuBtn("Transfer ke bank", { vm.newTx(Tx(jenis = "pindah", poket = id, ke = PG.BELUM_AGIH, perkara = "Transfer ke bank"), "Pindah ke bank") })
        MenuBtn("Pindah ke poket lain", { vm.newTx(Tx(jenis = "pindah", poket = id)) })
        MenuBtn("Lihat transaksi", { vm.close(); vm.txPocket = id; vm.tab = "transaksi" })
        MenuBtn("Edit poket", { vm.open(Sheet.PocketForm(id)) })
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
fun PocketFormSheet(vm: MainViewModel, id: String?) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val p = if (id != null) s.pockets.find { it.id == id } else null
    val ct = if (id != null) PG.targetsFromCommitments(s, vm.today())[id] ?: 0.0 else 0.0
    val dipakai = id != null && PG.pocketUsage(s, id)
    var nama by remember { mutableStateOf(p?.nama ?: "") }
    var sas by remember { mutableStateOf(if ((p?.sasaran ?: 0.0) > 0) PG.jsNum(p?.sasaran ?: 0.0) else "") }
    var simpan by remember { mutableStateOf(if (p == null) "bank" else PG.simpanDi(p)) }
    var err by remember { mutableStateOf("") }
    val fr = autoFocus(id == null)
    SheetBody(actions = { SheetActions("Simpan", { err = vm.savePocket(id, nama, sas, simpan) }, { vm.close() }) }) {
        SheetTitle(if (id != null) "Edit poket" else "Poket baru")
        Form {
            FieldText("Nama poket", nama, { nama = it }, readOnly = p?.tetap == true, maxLen = 40, fr = fr,
                small = if (p?.tetap == true) "Poket ini tetap: gaji masuk ke sini dulu sebelum diagih." else null)
            FieldText("Sasaran tambahan sebulan (RM)", sas, { sas = it }, placeholder = "0.00", kb = KeyboardType.Decimal,
                small = if (ct > 0) "Komitmen dan bayaran hutang yang guna poket ini (" + M(ct) + ") ditambah sendiri ke sasaran." else "Untuk belanja seperti dapur atau minyak. Bil tetap lebih baik dimasukkan sebagai komitmen.")
            if (p?.tetap != true) FieldChips("Duit poket ini disimpan di", listOf("bank" to "Bank", "tunai" to "Tunai (dompet)", "ewallet" to "E-wallet"), simpan, { simpan = it }, note = {
                Txt(
                    when (simpan) {
                        "tunai" -> "Duit tunai fizikal dalam dompet. Tidak dikira dalam baki bank. Ambil duit di ATM = Pindah dari poket bank ke sini."
                        "ewallet" -> "Contoh Touch 'n Go. Tidak dikira dalam baki bank. Isi semula dari bank = Pindah ke poket ini; transfer ke bank = Pindah keluar."
                        else -> "Duit dalam akaun bank. Dikira dalam baki bank dan Semak baki bank."
                    } + if (dipakai && p != null && simpan != PG.simpanDi(p)) " Poket ini dah ada transaksi: menukar pilihan ini mengubah kiraan baki bank sebelum ini." else "",
                    size = 12.5f, color = pal.muted,
                )
            })
        }
        Box(Modifier.padding(horizontal = GL)) { FormError(err) }
        if (id != null && p?.tetap != true) {
            Spacer(Modifier.height(8.dp))
            DelZone("Padam poket", "Padam poket ini?", { vm.delPocket(id) },
                blocked = if (dipakai) "Poket ini ada transaksi atau komitmen, jadi tak boleh dipadam. Tukar nama sahaja." else null)
        }
    }
}

/* ================= semak bank ================= */

@Composable
fun BankSheet(vm: MainViewModel) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    var baki by remember { mutableStateOf("") }
    var tarikh by remember { mutableStateOf(vm.today()) }
    var cat by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    val fr = autoFocus(true)
    val dom = s.pockets.any { it.dompet }
    val adaTunai = s.pockets.any { it.tunai }
    val adaEw = s.pockets.any { it.dompet && !it.tunai }
    SheetBody(actions = { SheetActions("Simpan semakan", { err = vm.saveBank(baki, tarikh, cat) }, { vm.close() }) }) {
        SheetTitle("Semak baki bank", rich("Buka app bank anda dan masukkan baki akaun sekarang. App akan bandingkan dengan jumlah semua poket" +
            (if (dom) " bank (tanpa " + listOfNotNull(if (adaTunai) "duit tunai" else null, if (adaEw) "e-wallet" else null).joinToString(" dan ") + ")" else "") + "."))
        Form {
            FieldText("Baki dalam bank (RM)", baki, { baki = it }, placeholder = "0.00", kb = KeyboardType.Decimal, big = true, fr = fr)
            FieldDate("Tarikh", tarikh, { tarikh = it })
            val tr = PG.total(s, tarikh)
            val v = vm.parseAmt(baki)
            Compare {
                KvLine("Jumlah poket" + (if (dom) " bank" else "") + " pada " + PG.fmtDate(tarikh)) { Txt(M(tr), size = 14f, weight = FontWeight.SemiBold, num = true) }
                if (v.isFinite()) {
                    val bz = PG.round2(v - tr)
                    if (Math.abs(bz) < 0.005) KvLine("Keputusan") { Pill("✔ Sama", Tone.GOOD) }
                    else {
                        KvLine("Beza") { Txt(M(bz), size = 14f, weight = FontWeight.SemiBold, color = pal.bad, num = true) }
                        Txt((if (bz > 0) "Bank lebih. Mungkin ada duit masuk yang belum direkod." else "Bank kurang. Mungkin ada belanja yang belum direkod.") + " Kalau tak jumpa, rekod jenis Pelarasan.", size = 13f, color = pal.muted)
                    }
                }
            }
            FieldText("Catatan (pilihan)", cat, { cat = it }, maxLen = 120)
        }
        Box(Modifier.padding(horizontal = GL)) { FormError(err) }
    }
}

/* ================= komitmen ================= */

@Composable
fun KMenuSheet(vm: MainViewModel, id: String) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val c = PG.commitmentStatus(s, vm.today()).find { it.id == id } ?: return
    SheetBody {
        SheetTitle(c.nama, rich(M(c.jumlah) + " · gaji " + c.kitaran + "hb · " + pname(s, c.poket)))
        if (c.status != "sudah") MenuBtn("Rekod bayaran " + M(c.baki), { vm.payCommitment(id) }, primary = true)
        if (c.manualTanda) MenuBtn("Batal tanda dibayar", { vm.markK(id, false) })
        else if (c.status != "sudah") MenuBtn("Tanda dibayar di luar app", { vm.markK(id, true) })
        MenuBtn("Edit komitmen", { vm.open(Sheet.KForm(id)) })
        Note("\"Tanda dibayar di luar app\" untuk bayaran yang tak lalu akaun ini, contohnya potongan gaji terus.", Modifier.padding(top = 8.dp, bottom = 8.dp))
    }
}

@Composable
fun KFormSheet(vm: MainViewModel, id: String?) {
    val s by vm.pg.collectAsState()
    val c = if (id != null) s.commitments.find { it.id == id } else null
    var nama by remember { mutableStateOf(c?.nama ?: "") }
    var jumlah by remember { mutableStateOf(if (c != null) PG.toFixed(c.jumlah, 2) else "") }
    var kit by remember { mutableStateOf(c?.kitaran ?: "30") }
    var poket by remember { mutableStateOf(c?.poket ?: (s.pockets.getOrNull(1)?.id ?: "")) }
    var err by remember { mutableStateOf("") }
    val fr = autoFocus(id == null)
    SheetBody(actions = { SheetActions("Simpan", { err = vm.saveK(id, nama, jumlah, kit, poket) }, { vm.close() }) }) {
        SheetTitle(if (id != null) "Edit komitmen" else "Komitmen baru")
        Form {
            FieldText("Nama", nama, { nama = it }, placeholder = "cth: Sewa rumah", maxLen = 50, fr = fr)
            FieldText("Jumlah sebulan (RM)", jumlah, { jumlah = it }, placeholder = "0.00", kb = KeyboardType.Decimal, big = true)
            FieldChips("Bayar guna gaji", listOf("15" to "15hb", "30" to "30hb"), kit, { kit = it })
            FieldGrid("Dibayar dari poket", pocketOpts(s.pockets.filter { it.id != PG.BELUM_AGIH }), poket, { poket = it })
        }
        Box(Modifier.padding(horizontal = GL)) { FormError(err) }
        if (id != null) { Spacer(Modifier.height(8.dp)); DelZone("Padam komitmen", "Padam komitmen ini? Transaksi bayaran lama kekal, cuma tak lagi dikaitkan.", { vm.delK(id) }) }
    }
}

/* ================= hutang ================= */

@Composable
fun HMenuSheet(vm: MainViewModel, id: String) {
    val s by vm.pg.collectAsState()
    val d = PG.debtStatus(s, vm.today()).find { it.id == id } ?: return
    val payLbl = if (d.jenis == "kad") "Bayar kad ini" else if (d.bakiBayar > 0.004) "Rekod bayaran " + M(d.bakiBayar) else "Rekod bayaran tambahan"
    var info = if (d.jenis == "kad") {
        val parts = ArrayList<String>()
        if (d.eppBaki <= 0.004) parts.add("Baki **" + M(d.baki) + "** · " + pct(d.kadar) + "% setahun")
        parts.addAll(kadLines(d))
        val fk = faedahKadLine(d)
        if (fk.isNotEmpty()) parts.add(fk)
        parts.joinToString("\n")
    } else "Baki **" + M(d.baki) + "** · " + pct(d.kadar) + "% setahun · minimum " + M(d.min)
    val bl = bulanIniLine(d)
    if (bl.isNotEmpty()) info += "\n" + bl
    SheetBody {
        SheetTitle(d.nama, rich(info))
        if (d.baki > 0.004) MenuBtn(payLbl, { vm.payDebt(id) }, primary = true)
        if (d.jenis == "kad") MenuBtn("Pelan EPP" + if (d.d.epp.isNotEmpty()) " (" + d.eppAktif + " aktif)" else "", { vm.open(Sheet.EppList(id)) })
        MenuBtn("Kemas kini baki ikut penyata", { vm.open(Sheet.HLog(id, "penyata")) })
        if (d.jenis == "kad") MenuBtn("Keluarkan tunai (Touch 'n Go)", { vm.open(Sheet.Tunai(null, id, null, null)) })
        if (d.jenis == "kad") MenuBtn("Belanja guna kad ini", { vm.newTx(Tx(jenis = "kad", kadId = id), "Belanja guna kad kredit") })
        else MenuBtn("Tambah jumlah hutang", { vm.open(Sheet.HLog(id, "caj")) })
        MenuBtn("Rekod faedah atau caj", { vm.open(Sheet.HLog(id, "faedah")) })
        MenuBtn("Sejarah baki", { vm.open(Sheet.HHist(id)) })
        MenuBtn("Edit hutang", { vm.open(Sheet.HForm(id)) })
        Note("Bayaran direkod sebagai transaksi Keluar dari poket, jadi baki poket dan bank kekal tepat. Belanja guna kad dikira belanja pada hari itu dan menambah baki kad; jumlahnya diasingkan ke poket bayaran kad.", Modifier.padding(top = 8.dp, bottom = 8.dp))
    }
}

@Composable
fun HFormSheet(vm: MainViewModel, id: String?) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val d = if (id != null) s.debts.find { it.id == id } else null
    var nama by remember { mutableStateOf(d?.nama ?: "") }
    var jenis by remember { mutableStateOf(d?.jenis ?: "kad") }
    var baki by remember { mutableStateOf("") }
    var kadar by remember { mutableStateOf(if (d != null) PG.jsNum(d.kadar) else "18") }
    var minp by remember { mutableStateOf(if (d != null) PG.jsNum(d.minPeratus) else "5") }
    var minl by remember { mutableStateOf(if (d != null) (d.minLantai?.let { PG.jsNum(it) } ?: "") else "50") }
    var had by remember { mutableStateOf(numText(d?.hadKredit ?: 0.0)) }
    var ans by remember { mutableStateOf(numText(d?.ansuran ?: 0.0)) }
    var ranc by remember { mutableStateOf(numText(d?.rancangan ?: 0.0)) }
    val defPoket = d?.poket ?: (if (s.pockets.any { it.id == "p-komitmen" }) "p-komitmen" else s.pockets.getOrNull(1)?.id ?: "")
    var poket by remember { mutableStateOf(defPoket) }
    var minAsas by remember { mutableStateOf(d?.minAsas ?: "jumlah") }
    var err by remember { mutableStateOf("") }
    val fr = autoFocus(id == null)
    val kad = jenis == "kad"
    SheetBody(actions = {
        SheetActions("Simpan", { err = vm.saveH(id, MainViewModel.HInput(nama, jenis, baki, kadar, minp, minl, had, ans, ranc, poket, minAsas)) }, { vm.close() })
    }) {
        SheetTitle(if (id != null) "Edit hutang" else "Hutang baru")
        Form {
            FieldText("Nama", nama, { nama = it }, placeholder = "cth: Kad kredit Maybank", maxLen = 50, fr = fr)
            FieldChips("Jenis", PG.JENIS_HUTANG.map { it.id to it.label }, jenis, { jenis = it })
            if (d != null) {
                Column(Modifier.fillMaxWidth().background(pal.surface).hairlines(pal.line).padding(horizontal = GL, vertical = 10.dp)) {
                    Txt(rich("Baki sekarang **" + M(PG.debtBalance(s, d, null, vm.today())) + "**" + (if (d.epp.isNotEmpty()) " (tidak termasuk EPP belum dibil)" else "") + ". Untuk ubah baki, guna **Kemas kini baki ikut penyata**."), size = 13f, color = pal.muted)
                }
            } else FieldText("Baki hutang sekarang (RM)", baki, { baki = it }, placeholder = "0.00", kb = KeyboardType.Decimal, big = true, small = "Ikut penyata atau app bank yang terkini.")
            FieldText("Kadar faedah setahun (%)", kadar, { kadar = it }, placeholder = "18", kb = KeyboardType.Decimal, small = "Kad kredit biasanya 15% hingga 18%. Beli dulu bayar kemudian biasanya 0% kalau bayar ikut masa.")
            if (kad) {
                FieldText("Minimum (%)", minp, { minp = it }, placeholder = "5", kb = KeyboardType.Decimal)
                FieldChips("Minimum dikira daripada", listOf("jumlah" to "Baki kad + pokok EPP", "biasa" to "Baki biasa + ansuran EPP"), minAsas, { minAsas = it }, stack = true, note = {
                    Txt(
                        if (minAsas == "biasa") "Ansuran EPP bulan ini dibayar penuh, ditambah peratus minimum atas baki kad selebihnya."
                        else "Peratus minimum × (baki kad + pokok EPP belum dibil). Faedah EPP tidak dikira. Sekurang-kurangnya minimum terendah dan ansuran EPP bulan ini.",
                        size = 12.5f, color = pal.muted,
                    )
                })
                FieldText("Minimum terendah (RM)", minl, { minl = it }, placeholder = "50", kb = KeyboardType.Decimal)
                FieldText("Had kredit (RM, pilihan)", had, { had = it }, placeholder = "0.00", kb = KeyboardType.Decimal)
            } else FieldText("Ansuran sebulan (RM)", ans, { ans = it }, placeholder = "0.00", kb = KeyboardType.Decimal)
            FieldText("Rancangan bayar sebulan (RM, pilihan)", ranc, { ranc = it }, placeholder = "0.00", kb = KeyboardType.Decimal, small = "Kosongkan untuk bayar minimum sahaja. Jumlah ini masuk ke sasaran poket.")
            FieldGrid("Dibayar dari poket", pocketOpts(s.pockets.filter { it.id != PG.BELUM_AGIH && !it.dompet }), poket, { poket = it })
        }
        Box(Modifier.padding(horizontal = GL)) { FormError(err) }
        if (id != null) { Spacer(Modifier.height(8.dp)); DelZone("Padam hutang", "Padam hutang ini dan semua rekod bakinya? Transaksi bayaran kekal dalam poket, cuma tak lagi dikaitkan.", { vm.delH(id) }) }
    }
}

/* ================= bayar kad ================= */

@Composable
fun CardPaySheet(vm: MainViewModel, id: String) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val o = PG.cardPayOptions(s, id, vm.today()) ?: return
    val dsMin = PG.debtStatus(s, vm.today()).find { it.id == id }
    val tl = tambahLbl(o.belanja, o.tunai)
    val lbl = mapOf("penuh" to "Bayar penuh", "syor" to (if (o.pelan > 0.004) "Pelan + $tl" else tl.replaceFirstChar { it.uppercase() }), "pelan" to "Ikut pelan", "min" to "Minimum")
    val asasLbl = if (o.asal > o.rancangan + 0.004) "Minimum" else "Rancangan"
    fun note(oid: String): String {
        if (oid == "penuh") return if (o.eppBaki > 0.004) "Baki kad jadi RM0. Ansuran EPP diteruskan." else "Baki kad jadi RM0. Tiada faedah."
        if (oid == "min") {
            val w = if (dsMin != null) minWhy(dsMin) else ""
            return (if (dsMin != null && w.isNotEmpty()) "Minimum bulan ini " + M(dsMin.min) + " = " + w + ". " else "") + "Elak caj lewat. Baki selebihnya kena faedah."
        }
        if (oid == "pelan") return if (o.dibayar <= 0.004) "$asasLbl bulan ini" + (if (asasLbl == "Minimum") " (tiada rancangan)" else "") + "." else "Baki pelan bulan ini. Bayaran " + M(o.dibayar) + " dah ditolak dari pelan."
        val parts = ArrayList<String>()
        if (o.belanja > 0.004) parts.add("belanja kad " + M(o.belanja))
        if (o.tunai > 0.004) parts.add("tunai " + M(o.tunai))
        return if (o.pelan > 0.004) (if (o.dibayar > 0.004) "Baki pelan " else "Pelan ") + M(o.pelan) + " + " + parts.joinToString(" + ") + ". Supaya hutang kad tak bertambah." else "Baki $tl bulan ini. Pelan dah dibayar."
    }
    var pilih by remember { mutableStateOf(if (o.opts.isEmpty()) "lain" else o.lalai.ifEmpty { "lain" }) }
    var lain by remember { mutableStateOf("") }
    var poket by remember { mutableStateOf(o.poket) }
    var tarikh by remember { mutableStateOf(vm.today()) }
    var err by remember { mutableStateOf("") }
    val amt = if (pilih == "lain") vm.parseAmt(lain) else o.opts.find { it.id == pilih }?.jumlah ?: Double.NaN
    val ok = amt > 0
    SheetBody(actions = { SheetActions(if (ok) "Bayar " + M(amt) else "Bayar", { err = vm.payCard(id, amt, poket, tarikh) }, { vm.close() }) }) {
        SheetTitle("Bayar " + o.nama, rich("Baki kad **" + M(o.baki) + "**" + (if (o.dibayar > 0.004) " · sudah bayar **" + M(o.dibayar) + "** bulan ini" else "") +
            (if (o.belanja + o.tunai > 0.004 && !o.cukup) "\nBayaran ditolak dari pelan dulu, kemudian $tl." else "")))
        if (o.cukup) Notice(rich("Bayaran bulan ini sudah cukup. Bayar lagi kalau nak kurangkan baki kad."), Tone.INFO)
        Txt("Berapa nak bayar?", Modifier.padding(horizontal = GL, vertical = 8.dp), size = 14f, weight = FontWeight.Medium, color = pal.muted)
        Column(Modifier.fillMaxWidth().background(pal.surface).hairlines(pal.line, top = true, bottom = true)) {
            o.opts.forEach { op ->
                PayOpt(pilih == op.id, lbl[op.id] ?: op.id, M(op.jumlah), note(op.id)) { pilih = op.id; err = "" }
            }
            val on = pilih == "lain"
            Row(
                Modifier.fillMaxWidth().background(if (on) pal.accentSoft else Color.Transparent).clickable { pilih = "lain" }.heightIn(min = 52.dp).padding(horizontal = GL, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Radio(on)
                Spacer(Modifier.width(10.dp))
                Txt("Jumlah lain", Modifier.weight(1f), size = 15f, weight = FontWeight.SemiBold, color = if (on) pal.accentStrong else pal.ink)
                BasicTextField(
                    value = lain, onValueChange = { lain = it; pilih = "lain" },
                    modifier = Modifier.width(130.dp).hairlines(pal.line).padding(vertical = 6.dp),
                    textStyle = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = pal.ink, textAlign = TextAlign.End, fontFeatureSettings = "tnum"),
                    singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), cursorBrush = SolidColor(pal.accent),
                    decorationBox = { inner -> Box(contentAlignment = Alignment.CenterEnd) { if (lain.isEmpty()) Txt("0.00", size = 16f, color = pal.muted); inner() } },
                )
            }
        }
        if (ok) Column(Modifier.padding(horizontal = GL, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Txt(rich("Baki kad selepas bayar: **" + M(Math.max(0.0, o.baki - amt)) + "**"), size = 13.5f)
            if (amt > o.baki + 0.004) Txt("Lebih " + M(amt - o.baki) + " daripada baki kad.", size = 13.5f, color = pal.bad)
            val pb = PG.balances(s)[poket] ?: 0.0
            if (poket.isNotEmpty() && amt > pb + 0.004) Txt("Poket " + pname(s, poket) + " ada " + M(pb) + " sahaja.", size = 13.5f, color = pal.bad)
        }
        Form {
            FieldGrid("Dari poket", pocketOpts(s.pockets), poket, { poket = it })
            FieldDate("Tarikh", tarikh, { tarikh = it })
        }
        Box(Modifier.padding(horizontal = GL)) { FormError(err) }
    }
}

@Composable
private fun Radio(on: Boolean) {
    val pal = LocalPal.current
    Box(Modifier.size(20.dp).border(2.dp, if (on) pal.accent else pal.lineStrong, CircleShape), contentAlignment = Alignment.Center) {
        if (on) Box(Modifier.size(10.dp).background(pal.accent, CircleShape))
    }
}

@Composable
private fun PayOpt(on: Boolean, title: String, amt: String, note: String, onClick: () -> Unit) {
    val pal = LocalPal.current
    Row(
        Modifier.fillMaxWidth().background(if (on) pal.accentSoft else Color.Transparent).hairlines(pal.line).clickable(onClick = onClick).padding(horizontal = GL, vertical = 11.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Box(Modifier.padding(top = 2.dp)) { Radio(on) }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Row {
                Txt(title, Modifier.weight(1f), size = 15f, weight = FontWeight.SemiBold, color = if (on) pal.accentStrong else pal.ink)
                Txt(amt, size = 15f, weight = FontWeight.SemiBold, num = true)
            }
            Txt(note, size = 12.5f, color = pal.muted)
        }
    }
}

/* ================= EPP ================= */

@Composable
fun EppListSheet(vm: MainViewModel, id: String) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val today = vm.today()
    val d = s.debts.find { it.id == id } ?: return
    val ds = PG.debtStatus(s, today).find { it.id == id } ?: return
    val plans = d.epp.map { it to PG.eppInfo(it, today) }.sortedWith(compareByDescending<Pair<Epp, com.asyraf.hadirku.pg.EppInfo>> { if (it.second.aktif) 1 else 0 }.thenByDescending { it.first.mula })
    SheetBody(actions = { SheetActions("+ EPP baru", { vm.open(Sheet.EppForm(id, null)) }, { vm.close() }, cancel = "Tutup") }) {
        SheetTitle("EPP · " + d.nama)
        Column(Modifier.padding(horizontal = GL).padding(bottom = 12.dp)) {
            Kvl(listOf(
                Triple(rich("Baki kad (penyata)"), M(ds.baki), null),
                Triple(rich("Pokok EPP belum dibil"), M(ds.eppPokok), null),
                Triple(rich("Jumlah pokok"), M(ds.pokok), null),
                Triple(rich("Faedah EPP belum dibil"), M(ds.eppFaedah), null),
                Triple(rich("Jumlah termasuk faedah"), M(ds.jumlah), null),
                Triple(rich("Ansuran EPP bulan ini"), M(ds.eppDue), null),
                Triple(rich("Minimum bulan ini"), M(ds.min), null),
            ), strongIdx = setOf(2, 4))
            val mw = minWhy(ds)
            if (mw.isNotEmpty() && ds.min > 0.004) Txt("Minimum = " + mw, Modifier.padding(top = 6.dp), size = 12.5f, color = pal.muted)
        }
        if (plans.isNotEmpty()) {
            Note("Tekan pelan untuk edit.", Modifier.padding(bottom = 6.dp))
            ListBlock {
                plans.forEach { (p, e) ->
                    val subs = listOf(
                        if (e.aktif) "Ansuran " + e.dibil + "/" + e.tempoh + " dibil · tamat " + fmtYm(e.tamat) else "Selesai " + fmtYm(e.tamat),
                        if (e.aktif) "Baki pokok **" + M(e.pokokBaki) + "**" + (if (e.faedahBaki > 0.004) " + faedah **" + M(e.faedahBaki) + "**" else " · 0% faedah")
                        else "Pokok " + M(e.pokok) + (if (e.faedah > 0.004) " + faedah " + M(e.faedah) + " dah dibil" else " · 0% faedah"),
                        if (e.aktif && e.faedah > 0.004) "Setiap ansuran: pokok " + M(e.pokokAns) + " + faedah " + M(e.faedahAns) else "",
                    ).filter { it.isNotEmpty() }
                    Row(Modifier.fillMaxWidth().hairlines(pal.line).clickable { vm.open(Sheet.EppForm(id, p.id)) }.padding(horizontal = GL, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Txt(p.nama, size = 15f, weight = FontWeight.Medium)
                            subs.forEach { Txt(rich(it), size = 12.5f, color = pal.muted) }
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Txt(M(e.ans), size = 15f, num = true)
                            Txt("sebulan", size = 11.5f, color = pal.muted)
                        }
                    }
                }
            }
        } else Empty(rich("Belum ada pelan EPP untuk kad ini."))
        val mp = pct(if (d.minPeratus > 0) d.minPeratus else 5.0) + "%"
        val mlan = M(d.minLantai?.takeIf { it >= 0 } ?: 50.0)
        Note(
            "Ansuran EPP masuk ke baki kad sendiri setiap bulan pada tarikh bil. " +
                (if (d.minAsas == "biasa") "Minimum kad = ansuran EPP bulan ini penuh + $mp baki selebihnya (sekurang-kurangnya $mlan)."
                else "Minimum kad = $mp × (baki kad + pokok EPP belum dibil), sekurang-kurangnya $mlan dan tidak kurang daripada ansuran EPP bulan ini.") +
                " Faedah EPP belum dibil diasingkan daripada pokok kerana ia belum dikenakan; ia masuk sedikit demi sedikit dalam setiap ansuran (kaedah rata). Tukar cara kiraan minimum dalam Edit hutang.",
            Modifier.padding(top = 8.dp),
        )
    }
}

@Composable
fun EppFormSheet(vm: MainViewModel, debtId: String, planId: String?) {
    val s by vm.pg.collectAsState()
    val today = vm.today()
    val d = s.debts.find { it.id == debtId } ?: return
    val p = if (planId != null) d.epp.find { it.id == planId } else null
    var nama by remember { mutableStateOf(p?.nama ?: "") }
    var pokok by remember { mutableStateOf(if (p != null) PG.toFixed(p.pokok, 2) else "") }
    var tempohS by remember { mutableStateOf((p?.tempoh ?: 12).toString()) }
    var kadar by remember { mutableStateOf(PG.jsNum(p?.kadar ?: 0.0)) }
    var mula by remember { mutableStateOf(p?.mula ?: PG.addMonthsClamp(today, 1)) }
    var ans by remember { mutableStateOf(if ((p?.ansuran ?: 0.0) > 0) PG.toFixed(p?.ansuran ?: 0.0, 2) else "") }
    var err by remember { mutableStateOf("") }
    val fr = autoFocus(planId == null)
    fun numOr(raw: String, def: Double) = if (raw.trim().isEmpty()) def else vm.parseAmt(raw)
    fun build() = Epp("", nama.trim(), numOr(pokok, Double.NaN), tempohS.trim().toIntOrNull() ?: 0, numOr(kadar, 0.0), numOr(ans, 0.0), mula, p?.catatan ?: "")
    SheetBody(actions = { SheetActions("Simpan", { err = vm.saveEpp(debtId, planId, build()) }, { vm.close() }) }) {
        SheetTitle((if (planId != null) "Edit EPP" else "EPP baru") + " · " + d.nama)
        Form {
            FieldText("Nama barang / pelan", nama, { nama = it }, placeholder = "cth: Telefon, peti sejuk", maxLen = 50, fr = fr)
            FieldText("Jumlah pokok EPP (RM)", pokok, { pokok = it }, placeholder = "0.00", kb = KeyboardType.Decimal, big = true, small = "Harga barang atau jumlah yang ditukar ke EPP, tanpa faedah.")
            FieldText("Tempoh (bulan)", tempohS, { tempohS = it.take(3) }, kb = KeyboardType.Number, after = {
                Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(6, 12, 18, 24, 36).forEach { n -> QBtn(n.toString(), Modifier.weight(1f)) { tempohS = n.toString() } }
                }
            })
            FieldText("Kadar faedah setahun (%)", kadar, { kadar = it }, placeholder = "0", kb = KeyboardType.Decimal, small = "Kebanyakan EPP 0%. Kalau ada faedah, masukkan kadar rata (flat) setahun.")
            FieldDate("Tarikh bil ansuran pertama", mula, { mula = it }, small = "Biasanya tarikh penyata kad. Untuk EPP lama, masukkan tarikh ansuran pertama dulu; ansuran yang dah lepas dikira sendiri.")
            FieldText("Ansuran ikut penyata (RM, pilihan)", ans, { ans = it }, placeholder = "Kira sendiri", kb = KeyboardType.Decimal, small = "Isi kalau ansuran dalam penyata berbeza sedikit daripada kiraan app.")
        }
        val f = build()
        Preview(if (!(f.pokok > 0) || !(f.tempoh >= 1) || f.mula.isEmpty()) rich("Masukkan jumlah, tempoh dan tarikh untuk lihat ansuran.") else {
            val e = PG.eppInfo(f, today)
            rich("Ansuran **" + M(e.ans) + "** sebulan × " + e.tempoh + " = **" + M(e.jumlahBayar) + "**" +
                (if (e.faedah > 0.004) " (pokok " + M(e.pokok) + " + faedah " + M(e.faedah) + "). Setiap ansuran: pokok " + M(e.pokokAns) + " + faedah " + M(e.faedahAns) else " (0% faedah)") +
                ". Tamat " + fmtYm(e.tamat) + "." +
                if (e.dibil > 0) " " + e.dibil + " ansuran dah dibil; baki belum dibil: pokok " + M(e.pokokBaki) + (if (e.faedahBaki > 0.004) " + faedah " + M(e.faedahBaki) else "") + "." else "")
        })
        if (planId == null) Note("Kalau EPP ini ditukar daripada baki kad sedia ada (balance conversion), kemas kini baki ikut penyata selepas simpan.")
        Box(Modifier.padding(horizontal = GL)) { FormError(err) }
        if (planId != null) { Spacer(Modifier.height(8.dp)); DelZone("Padam EPP", "Padam pelan EPP ini? Ansuran yang dah dibil kekal dalam baki kad kalau ada penyata selepasnya; selebihnya dibuang.", { vm.delEpp(debtId, planId) }) }
    }
}

@Composable
fun QBtn(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val pal = LocalPal.current
    Box(
        modifier.defaultMinSize(minHeight = 36.dp).border(1.dp, pal.line, RoundedCornerShape(4.dp)).pressable(onClick, scaleTo = 0.9f),
        contentAlignment = Alignment.Center,
    ) { Txt(text, size = 14f, weight = FontWeight.SemiBold, num = true) }
}

/* ================= log hutang ================= */

private val LOGTXT = mapOf(
    "penyata" to Triple("Kemas kini baki", "Masukkan baki terkini dalam penyata atau app bank. Baki ini menggantikan semua rekod sebelum tarikh itu, termasuk faedah yang belum direkod.", "Baki ikut penyata (RM)"),
    "caj" to Triple("Belanja guna kad", "Belanja guna kad tak keluar dari poket. Ia tambah baki hutang sahaja.", "Jumlah (RM)"),
    "faedah" to Triple("Faedah & caj", "Rekod faedah, caj lewat atau yuran tahunan yang dikenakan.", "Jumlah (RM)"),
)

@Composable
fun HLogSheet(vm: MainViewModel, id: String, jenis: String) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val today = vm.today()
    val d = s.debts.find { it.id == id } ?: return
    val tx = LOGTXT[jenis] ?: LOGTXT.getValue("faedah")
    var v by remember { mutableStateOf("") }
    var dt by remember { mutableStateOf(today) }
    var cat by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    val fr = autoFocus(true)
    SheetBody(actions = { SheetActions("Simpan", { err = vm.saveHLog(id, jenis, v, dt, cat) }, { vm.close() }) }) {
        SheetTitle((if (jenis == "caj" && d.jenis != "kad") "Tambah hutang" else tx.first) + " · " + d.nama, rich(tx.second))
        Form {
            FieldText(tx.third, v, { v = it }, placeholder = "0.00", kb = KeyboardType.Decimal, big = true, fr = fr)
            FieldDate("Tarikh", dt, { dt = it })
            if (jenis == "penyata") {
                val cur = PG.debtBalance(s, d, dt, today)
                val n = vm.parseAmt(v)
                Compare {
                    KvLine("Baki dalam app pada " + PG.fmtDate(dt)) { Txt(M(cur), size = 14f, weight = FontWeight.SemiBold, num = true) }
                    if (n.isFinite()) {
                        val bz = PG.round2(n - cur)
                        if (Math.abs(bz) < 0.005) KvLine("Keputusan") { Pill("✔ Sama", Tone.GOOD) }
                        else {
                            KvLine("Beza") { Txt(Mp(bz), size = 14f, weight = FontWeight.SemiBold, num = true) }
                            Txt(if (bz > 0) "Biasanya faedah atau belanja kad yang belum direkod." else "Mungkin ada bayaran atau rebat yang belum direkod.", size = 13f, color = pal.muted)
                        }
                    }
                }
            }
            FieldText("Catatan (pilihan)", cat, { cat = it }, placeholder = if (jenis == "caj") "cth: Belanja online" else "", maxLen = 80)
        }
        Box(Modifier.padding(horizontal = GL)) { FormError(err) }
    }
}

private val EVLBL = mapOf("penyata" to "Baki ikut penyata", "caj" to "Belanja / hutang baru", "beli" to "Belanja guna kad", "tunai" to "Tunai dari kad", "faedah" to "Faedah & caj", "bayar" to "Bayaran", "epp" to "Ansuran EPP")

@Composable
fun HHistSheet(vm: MainViewModel, id: String) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val d = s.debts.find { it.id == id } ?: return
    val ev = remember(s) { PG.debtEvents(s, d, null, vm.today()).reversed() }
    var armed by remember { mutableStateOf("") }
    SheetBody(actions = { SheetActions("Kemas kini baki", { vm.open(Sheet.HLog(id, "penyata")) }, { vm.close() }, cancel = "Tutup") }) {
        SheetTitle("Sejarah · " + d.nama, rich("Terkini di atas. Bayaran datang daripada transaksi; edit atau padam di sana."))
        if (ev.isEmpty()) Empty(rich("Tiada rekod."))
        else ListBlock {
            ev.forEach { e ->
                val amt = if (e.jenis == "penyata") "= " + M(e.jumlah) else if (e.jenis == "bayar") M(-e.jumlah) else "+" + M(e.jumlah)
                Column(Modifier.fillMaxWidth().hairlines(pal.line).padding(horizontal = GL, vertical = 11.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Txt(rich("**" + (EVLBL[e.jenis] ?: e.jenis) + "**" + if (e.catatan.isNotEmpty()) " · " + e.catatan else ""), Modifier.weight(1f), size = 14f)
                        Txt(amt, size = 14f, color = if (e.jenis == "bayar") pal.inn else pal.ink, num = true)
                    }
                    Row(Modifier.fillMaxWidth().padding(top = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                        Txt(PG.fmtDate(e.tarikh) + " · baki " + M(e.baki), Modifier.weight(1f), size = 12.5f, color = pal.muted)
                        when {
                            e.jenis == "epp" -> Txt("Dari pelan EPP", size = 12.5f, color = pal.muted)
                            e.log -> Txt(if (armed == e.id) "Tekan lagi untuk padam" else "Padam", Modifier.clickable {
                                if (armed == e.id) { vm.delHLog(id, e.id); armed = "" } else armed = e.id
                            }.padding(vertical = 4.dp), size = 12.5f, weight = FontWeight.SemiBold, color = pal.bad)
                            else -> Txt("Buka transaksi", Modifier.clickable { vm.editTx(e.id) }.padding(vertical = 4.dp), size = 12.5f, weight = FontWeight.SemiBold, color = pal.accentStrong)
                        }
                    }
                }
            }
        }
    }
}

/* ================= pelan hutang ================= */

@Composable
fun PlanFormSheet(vm: MainViewModel) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val today = vm.today()
    val plan0 = remember(s) { PG.debtPlan(s, 0.0, "avalanche", today) }
    var bajet by remember { mutableStateOf(PG.toFixed(vm.budgetNow(), 2)) }
    var strat by remember { mutableStateOf(s.settings.hutangStrategi) }
    var err by remember { mutableStateOf("") }
    SheetBody(actions = { SheetActions("Simpan pelan", { err = vm.savePlan(bajet, strat) }, { vm.close() }) }) {
        SheetTitle("Pelan bebas hutang")
        Form {
            FieldText("Bajet bayar hutang sebulan (RM)", bajet, { bajet = it }, kb = KeyboardType.Decimal, big = true,
                small = "Bayaran minimum semua hutang sekarang: " + M(plan0.minimum) + ". Lebihan bajet dibayar ke satu hutang dulu sehingga langsai, kemudian ke hutang seterusnya.")
            FieldChips("Hutang mana dulu", listOf("avalanche" to "Faedah tertinggi dulu", "snowball" to "Baki terkecil dulu"), strat, { strat = it })
        }
        Preview(rich("**Faedah tertinggi dulu** jimat faedah paling banyak. **Baki terkecil dulu** cepat langsaikan hutang pertama, jadi lebih mudah kekal bermotivasi."))
        val b = vm.parseAmt(bajet)
        if (b.isFinite()) {
            val p = PG.debtPlan(s, b, strat, today)
            Txt(
                if (p.kosong) rich("Tiada baki hutang.") else if (!p.cukup) rich("Bajet kurang daripada bayaran minimum " + M(p.minimum) + ".")
                else if (p.never) rich("Bajet ini tak cukup untuk langsaikan hutang.")
                else rich("Bebas hutang **" + monthShort(today, p.bulan) + "** (" + tempoh(p.bulan) + ") · anggaran faedah **" + M(p.faedah) + "**"),
                Modifier.padding(horizontal = GL), size = 13.5f, color = if (!p.kosong && (!p.cukup || p.never)) pal.bad else pal.muted,
            )
        }
        Box(Modifier.padding(horizontal = GL)) { FormError(err) }
    }
}

/* ================= log OT harian ================= */

@Composable
fun OtDaySheet(vm: MainViewModel, d: String) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val cur = s.ot[d]
    val e0 = cur ?: OtEntry(vm.defaultHari(d))
    var jenis by remember { mutableStateOf(e0.jenis) }
    var jam by remember { mutableStateOf(e0.jam?.let { PG.jsNum(it) } ?: "") }
    var err by remember { mutableStateOf("") }
    val g = s.settings.gaji
    SheetBody(actions = { SheetActions("Simpan", { err = vm.saveOtDay(d, jenis, jam) }, { vm.close() }) }) {
        SheetTitle(longDate(d))
        Form {
            FieldChips("Jenis hari", PG.JENIS_HARI.map { it.id to it.label }, jenis, { jenis = it })
            if (jenis != "tidak") {
                val pal2 = LocalPal.current
                Column(Modifier.fillMaxWidth().background(pal2.surface).hairlines(pal2.line).padding(horizontal = GL).padding(top = 10.dp, bottom = 10.dp)) {
                    Txt("Jam di tempat kerja (masuk sampai balik, termasuk rehat)", size = 14f, weight = FontWeight.Medium, color = pal2.muted)
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        QBtn("−", Modifier.size(48.dp)) { val v = vm.parseAmt(jam); jam = PG.jsNum(Math.max(0.0, Math.min(24.0, (if (v.isFinite()) v else 0.0) - 0.5))) }
                        BasicTextField(
                            value = jam, onValueChange = { jam = it },
                            modifier = Modifier.weight(1f).hairlines(pal2.line).padding(vertical = 8.dp),
                            textStyle = TextStyle(fontSize = 24.sp, fontWeight = FontWeight.SemiBold, color = pal2.ink, textAlign = TextAlign.Center, fontFeatureSettings = "tnum"),
                            singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), cursorBrush = SolidColor(pal2.accent),
                            decorationBox = { inner -> Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { if (jam.isEmpty()) Txt("0", size = 24f, color = pal2.muted); inner() } },
                        )
                        QBtn("+", Modifier.size(48.dp)) { val v = vm.parseAmt(jam); jam = PG.jsNum(Math.max(0.0, Math.min(24.0, (if (v.isFinite()) v else 0.0) + 0.5))) }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(8, 9, 10, 11, 12).forEach { n -> QBtn(n.toString() + "j", Modifier.weight(1f)) { jam = n.toString() } }
                    }
                }
            }
        }
        val v = vm.parseAmt(jam)
        val h = PG.otHours(OtEntry(jenis, if (v.isFinite()) v else 0.0), g.jamNormal)
        val nilai = (h.h15 * 1.5 + h.h20 * 2 + h.h30 * 3) * PG.hrp(g)
        val parts = ArrayList<String>()
        if (h.h15 > 0) parts.add(fmtH(h.h15) + " jam × 1.5"); if (h.h20 > 0) parts.add(fmtH(h.h20) + " jam × 2.0"); if (h.h30 > 0) parts.add(fmtH(h.h30) + " jam × 3.0")
        Preview(if (jenis == "tidak") rich("Hari tidak bekerja. Tiada OT.") else if (parts.isNotEmpty()) rich("OT: " + parts.joinToString(" + ") + " = **" + M(nilai) + "**") else rich("Tiada OT untuk jam ini (jam normal " + PG.jsNum(g.jamNormal) + " jam)."))
        Box(Modifier.padding(horizontal = GL)) { FormError(err) }
        if (cur != null) Box(Modifier.padding(horizontal = GL)) { LinkDanger("Kosongkan hari ini") { vm.clearOtDay(d) } }
    }
}

/* ================= tunai dari kad ================= */

@Composable
fun TunaiSheet(vm: MainViewModel, sh: Sheet.Tunai) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val today = vm.today()
    val t = sh.tx
    val dr = sh.draft
    var kads = s.debts.filter { it.jenis == "kad" }
    if (t != null && kads.none { it.id == t.kadId }) { val k0 = s.debts.find { it.id == t.kadId }; if (k0 != null) kads = kads + k0 }
    if (kads.isEmpty() && t == null) {
        SheetBody(actions = { SheetActions("", {}, { vm.close() }, cancel = "Tutup") }) {
            SheetTitle("Keluarkan tunai dari kad")
            Note("Tambah kad kredit dulu di Bayaran → Hutang.")
        }
        return
    }
    val fl = s.settings.tunaiFee
    val dom = s.pockets.filter { it.dompet && !it.tunai }
    var kadId by remember { mutableStateOf(dr?.kadId ?: t?.kadId ?: sh.kadId ?: if (kads.size == 1) kads[0].id else "") }
    var jumlah by remember { mutableStateOf(dr?.jumlah ?: t?.let { PG.toFixed(it.jumlah, 2) } ?: "") }
    var mode by remember { mutableStateOf(dr?.mode ?: if (t != null) (if (t.feePct != null) "pct" else "rm") else (if (fl?.mode == "rm") "rm" else "pct")) }
    var fee by remember { mutableStateOf(dr?.fee ?: if (t != null) (t.feePct?.let { PG.jsNum(it) } ?: PG.jsNum(t.fee ?: 0.0)) else (fl?.nilai?.let { PG.jsNum(it) } ?: "")) }
    var poket by remember { mutableStateOf(sh.poket ?: t?.poket ?: dom.firstOrNull()?.id ?: PG.BELUM_AGIH) }
    var perkara by remember { mutableStateOf(dr?.perkara ?: t?.perkara ?: "") }
    var tarikh by remember { mutableStateOf(dr?.tarikh ?: t?.tarikh ?: today) }
    var cat by remember { mutableStateOf(dr?.catatan ?: t?.catatan ?: "") }
    var err by remember { mutableStateOf("") }
    val fr = autoFocus(t == null && dr == null)
    val amt = vm.parseAmt(jumlah)
    val raw = fee.trim()
    val feeN = if (raw.isEmpty()) 0.0 else vm.parseAmt(raw)
    val feeOk = raw.isEmpty() || (feeN.isFinite() && feeN >= 0)
    val feeRm = if (!feeOk) Double.NaN else if (raw.isEmpty()) 0.0 else if (mode == "pct") (if (amt.isFinite()) PG.round2(amt * feeN / 100) else 0.0) else PG.round2(feeN)
    val d = s.debts.find { it.id == kadId }
    fun save() {
        val tx = Tx(
            tarikh = tarikh, jenis = "tunai-kad", poket = poket, kadId = kadId, jumlah = amt,
            perkara = perkara.trim().ifEmpty { "Tunai dari " + (d?.nama ?: "kad") }, catatan = cat.trim(), fee = feeRm,
            feePct = if (feeOk && mode == "pct" && raw.isNotEmpty()) feeN else null,
        )
        err = vm.saveTunai(t?.id, tx, mode, if (raw.isEmpty()) null else feeN, feeOk)
    }
    SheetBody(actions = { SheetActions("Simpan", { save() }, { vm.close() }) }) {
        SheetTitle(if (t != null) "Edit tunai dari kad" else "Keluarkan tunai dari kad", rich("Contoh tambah nilai Touch 'n Go guna kad kredit. Duit ini pinjaman: hutang kad bertambah, tapi tidak dikira pendapatan. Fee dikira perbelanjaan."))
        Form {
            FieldChips("Kad kredit", kads.map { it.id to it.nama }, kadId, { kadId = it })
            FieldText("Jumlah dikeluarkan (RM)", jumlah, { jumlah = it }, placeholder = "0.00", kb = KeyboardType.Decimal, big = true, fr = fr)
            FieldText("Fee", fee, { fee = it }, placeholder = if (mode == "pct") "contoh 1" else "0.00", kb = KeyboardType.Decimal,
                small = if (!feeOk) "Fee mesti nombor 0 atau lebih." else if (mode == "pct") (if (amt > 0 && raw.isNotEmpty()) PG.jsNum(feeN) + "% daripada " + M(amt) + " = " + M(feeRm) else "Peratus daripada jumlah dikeluarkan.") else "Fee dalam RM, ikut yang dikenakan.",
                after = {
                    Row(Modifier.padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("pct" to "%", "rm" to "RM").forEach { (m, l) ->
                            val on = mode == m
                            Box(
                                Modifier.border(1.dp, if (on) pal.accent else pal.lineStrong, RoundedCornerShape(6.dp)).background(if (on) pal.accentSoft else Color.Transparent, RoundedCornerShape(6.dp))
                                    .clickable { if (mode != m) { mode = m; fee = "" } }.padding(horizontal = 14.dp, vertical = 6.dp),
                            ) { Txt(l, size = 13f, weight = FontWeight.SemiBold, color = if (on) pal.accentStrong else pal.muted) }
                        }
                    }
                })
            FieldGrid("Masuk ke", pocketOpts(s.pockets), poket, { poket = it }, note = {
                if (vm.isTunai(poket)) Txt("Duit tunai dari ATM guna kad kredit masuk ke dompet tunai. Hutang kad bertambah; baki bank tidak berubah.", size = 12.5f, color = pal.muted)
                else if (dom.isNotEmpty()) Txt("Pilih poket e-wallet kalau duit kekal dalam Touch 'n Go. Pilih dompet tunai kalau keluar duit di ATM. Pilih poket bank (contoh Belum Agih) kalau terus transfer ke bank.", size = 12.5f, color = pal.muted)
                else Row(verticalAlignment = Alignment.CenterVertically) {
                    Txt("Tiada poket e-wallet lagi. ", size = 12.5f, color = pal.muted)
                    LinkBtn("+ Buat poket Touch 'n Go", {
                        val p = vm.ensureDompet()
                        vm.open(Sheet.Tunai(t, sh.kadId, p.id, TunaiDraft(kadId, jumlah, mode, fee, perkara, tarikh, cat)))
                    }, size = 12.5f)
                }
            })
            FieldText("Perkara", perkara, { perkara = it }, placeholder = "Tunai dari kad", maxLen = 80)
            FieldDate("Tarikh", tarikh, { tarikh = it })
            FieldText("Catatan", cat, { cat = it }, maxLen = 120)
        }
        if (amt > 0 && feeOk) Column(Modifier.padding(horizontal = GL, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            val naik = PG.round2(amt + feeRm)
            Txt(rich("Hutang " + (d?.nama ?: "kad") + " bertambah **" + M(naik) + "**" + (if (feeRm > 0) " (termasuk fee " + M(feeRm) + ")" else "") + "."), size = 13.5f)
            if (poket.isNotEmpty()) Txt(rich("Masuk ke " + pname(s, poket) + ": **+" + M(amt) + "**" + if (vm.isTunai(poket)) " · duit tunai, tidak dikira dalam baki bank." else if (vm.isDompet(poket)) " · e-wallet, tidak dikira dalam baki bank." else " · dikira dalam baki bank."), size = 13.5f)
            val perB = PG.finPeriod(today, 1)
            if (d != null && tarikh >= perB.start && tarikh <= perB.end) {
                val hyp = s.copy(transactions = s.transactions.filter { it.id != t?.id } + Tx(id = "_tunai", tarikh = tarikh, jenis = "tunai-kad", poket = poket.ifEmpty { PG.BELUM_AGIH }, kadId = d.id, jumlah = amt, fee = feeRm))
                val sb = PG.debtStatus(hyp, today).find { it.id == d.id }
                if (sb != null) Txt(rich("Bayaran " + d.nama + " bulan ini jadi **" + M(sb.sasaran) + "**: pelan " + M(sb.sasaranAsal) + (if (sb.belanjaKad > 0.004) " + belanja kad " + M(sb.belanjaKad) else "") +
                    " + tunai " + M(sb.tunaiKad) + (if (sb.dibayar > 0.004) " (dah bayar " + M(sb.dibayar) + ")" else "") + "."), size = 13.5f)
            }
            val kadar = d?.kadar ?: 0.0
            if (kadar > 0) Txt("Kalau baki kad tak dibayar penuh, faedah " + pct(kadar) + "% setahun (lebih kurang " + M(naik * kadar / 1200) + " sebulan untuk jumlah ini).", size = 13.5f, color = pal.bad)
        }
        Box(Modifier.padding(horizontal = GL)) { FormError(err) }
        if (t != null) { Spacer(Modifier.height(8.dp)); DelZone("Padam transaksi ini", "Padam transaksi ini? Baki poket akan dikira semula.", { vm.delTx(t.id) }) }
    }
}

/* ================= senarai kategori / poket ================= */

@Composable
fun KatListSheet(vm: MainViewModel, k: String) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val per = vm.lap
    val pm = pieModeNow(vm, s)
    val list = s.transactions.filter { it.tarikh >= per.start && it.tarikh < per.endExcl && inPieMode(it, pm) && PG.kategoriOf(it) == k }
        .sortedWith { a, b -> val c = b.tarikh.compareTo(a.tarikh); if (c != 0) c else b.dibuat.compareTo(a.dibuat) }
    val tot = PG.round2(list.sumOf { it.jumlah })
    val sett = remember(s) { PG.otSettlements(s).byTx }
    SheetBody(actions = {
        SheetActions(if (k == "belum" && com.asyraf.hadirku.ai.Ai.ready() && list.isNotEmpty()) "Kategorikan dengan AI" else "", { vm.katSemua() }, { vm.close() }, cancel = "Tutup")
    }) {
        SheetTitle(PG.katLabel(k), rich(periodLabel(per) + " · " + list.size + " transaksi · **" + M(tot) + "**"))
        if (list.isNotEmpty()) ListBlock { list.forEach { TxRow(vm, s, it, akruanOn(s), sett, showDate = true) } } else Empty(rich("Tiada transaksi."))
        Note(if (k == "hutang") "Bayar hutang & kad kredit tak perlu kategori." else "Tekan transaksi untuk tukar kategori. Kategori baru juga dipakai untuk transaksi lain dengan nama sama.", Modifier.padding(top = 8.dp))
    }
}

@Composable
fun PoketListSheet(vm: MainViewModel, pid: String) {
    val s by vm.pg.collectAsState()
    val per = vm.lap
    val p = s.pockets.find { it.id == pid } ?: return
    val list = s.transactions.filter { it.poket == pid && (it.jenis == "keluar" || it.jenis == "kad") && it.tarikh >= per.start && it.tarikh < per.endExcl }
        .sortedWith { a, b -> val c = b.tarikh.compareTo(a.tarikh); if (c != 0) c else b.dibuat.compareTo(a.dibuat) }
    val tot = PG.round2(list.sumOf { it.jumlah })
    val sett = remember(s) { PG.otSettlements(s).byTx }
    SheetBody(actions = { SheetActions("Semua transaksi", { vm.close(); vm.txPocket = pid; vm.tab = "transaksi" }, { vm.close() }, cancel = "Tutup") }) {
        SheetTitle(p.nama, rich("Belanja " + periodLabel(per) + " · " + list.size + " transaksi · **" + M(tot) + "**"))
        if (list.isNotEmpty()) ListBlock { list.forEach { TxRow(vm, s, it, akruanOn(s), sett, nocat = true) } } else Empty(rich("Tiada belanja dari poket ini dalam bulan ini."))
    }
}

/* ================= CFO, salinan, pengesahan ================= */

@Composable
fun CfoSheet(vm: MainViewModel) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val la = launch()
    var mat by remember { mutableStateOf(s.settings.cfoMatlamat ?: com.asyraf.hadirku.pg.PgCfo.MATLAMAT_LALAI) }
    var soal by remember { mutableStateOf("") }
    var withTx by remember { mutableStateOf(true) }
    val name = "poketgaji-cfo-" + vm.today()
    SheetBody(actions = { SheetActions("", {}, { vm.close() }, cancel = "Tutup") }) {
        SheetTitle("Fail untuk CFO (Claude)", rich("Satu fail dengan semua angka penting dan arahan untuk Claude: baki, gaji & OT, komitmen, hutang, ringkasan 6 bulan, kategori belanja dan semakan data. Hantar kepada Claude dan minta semakan."))
        Form {
            FieldText("Matlamat kewangan (diingat)", mat, { mat = it }, stack = true, lines = 3, maxLen = 400)
            FieldText("Soalan kali ini (pilihan)", soal, { soal = it }, stack = true, lines = 3, maxLen = 600, placeholder = "cth: Patut ke aku beli PC RM3,500 bulan Mac?")
            FieldCheck("Sertakan transaksi 90 hari", withTx, { withTx = it })
        }
        Note("Fail ini tiada kunci API dan tiada nombor akaun, tapi ada nama perkara transaksi. Semak dulu sebelum hantar.", Modifier.padding(vertical = 10.dp))
        MenuBtn("Kongsi ke app Claude", { la.share("$name.md", "text/plain", vm.cfoText(mat, soal, withTx), "Fail CFO PoketGaji " + PG.fmtDate(vm.today())) }, primary = true)
        MenuBtn("Simpan fail (.md)", { la.saveFile("$name.md", "text/markdown", vm.cfoText(mat, soal, withTx), "Fail CFO disimpan", false) })
        MenuBtn("Salin teks", { la.copy(vm.cfoText(mat, soal, withTx), "Teks disalin. Tampal dalam chat Claude.") })
    }
}

@Composable
fun TextOutSheet(vm: MainViewModel, title: String, text: String) {
    val pal = LocalPal.current
    val la = launch()
    SheetBody(actions = { SheetActions("Salin", { la.copy(text, "Disalin") }, { vm.close() }, cancel = "Tutup") }) {
        SheetTitle(title)
        Txt(text, Modifier.padding(horizontal = GL).fillMaxWidth().background(pal.surface2, RoundedCornerShape(8.dp)).padding(10.dp), size = 12f)
    }
}

@Composable
fun ConfirmSheet(vm: MainViewModel, c: Sheet.Confirm) {
    SheetBody(actions = { SheetActions(c.label, { vm.confirmed(c.act) }, { vm.close() }, primaryKind = BtnKind.DANGER) }) {
        SheetTitle(c.title, rich(c.body))
    }
}

@Composable
fun BackupSheet(vm: MainViewModel) {
    val la = launch()
    SheetBody(actions = { SheetActions("", {}, { vm.close() }) }) {
        SheetTitle("Simpan salinan", rich("Paling selamat: hantar ke Google Drive, emel atau WhatsApp diri sendiri, supaya salinan tetap ada walaupun telefon hilang. Salinan ini format PoketGaji (boleh dibuka dalam PoketGaji PWA) dan termasuk rekod kehadiran kerja."))
        MenuBtn("Kongsi ke Drive / emel / WhatsApp", { la.share(vm.backupName(), "application/json", vm.backupJson(), "Salinan PoketGaji " + PG.fmtDate(vm.today())); vm.markBackup(); vm.close() }, primary = true)
        MenuBtn("Simpan ke telefon (pilih folder)", { la.saveFile(vm.backupName(), "application/json", vm.backupJson(), "Salinan disimpan", true) })
        MenuBtn("Salin teks JSON", { la.copy(vm.backupJson(), "Data disalin"); vm.markBackup() })
    }
}

@Composable
fun ImportSheet(vm: MainViewModel, sh: Sheet.ImportAsk) {
    val p = sh.p
    val bits = ArrayList<String>()
    if (p.pg != null) bits.add("Semua data kewangan dalam peranti ini akan diganti dengan salinan dari fail **" + p.name + "** (" + p.txCount + " transaksi).")
    else bits.add("Fail **" + p.name + "** ialah salinan HadirKu lama. Data kewangan kekal.")
    if (p.records != null) bits.add("Rekod kehadiran: **" + p.recCount + " hari** (menggantikan rekod sekarang).") else bits.add("Rekod kehadiran dalam telefon ini kekal.")
    bits.add("Hari yang ada rekod kehadiran lengkap tapi tiada log OT akan diisi sendiri.")
    SheetBody(actions = { SheetActions("Pulihkan", { vm.applyImport(p) }, { vm.close() }, primaryKind = BtnKind.DANGER) }) {
        SheetTitle("Pulihkan salinan?", rich(bits.joinToString("\n\n")))
    }
}
