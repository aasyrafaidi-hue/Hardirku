package com.asyraf.hadirku.system

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.work.WorkManager
import com.asyraf.hadirku.data.RecordStatus
import com.asyraf.hadirku.data.Repo
import com.asyraf.hadirku.logic.DayKind
import com.asyraf.hadirku.logic.Logic
import com.asyraf.hadirku.logic.Ms

object Reminders {
    /** kod penggera "bertolak" versi lama — hanya untuk dibatalkan */
    private const val RC_DEPART_LAMA = 101
    private const val RC_MISSED = 102
    const val EXTRA_TYPE = "type"
    const val TYPE_MISSED = "missed"

    private fun pi(ctx: Context, type: String, rc: Int): PendingIntent {
        val i = Intent(ctx, ReminderReceiver::class.java).putExtra(EXTRA_TYPE, type)
        return PendingIntent.getBroadcast(ctx, rc, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    fun canExact(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT < 31) return true
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return false
        return am.canScheduleExactAlarms()
    }

    private fun set(ctx: Context, at: Long, p: PendingIntent) {
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return
        try {
            if (canExact(ctx)) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
        }
    }

    /** Jadualkan semula penggera seterusnya: semakan lupa check-in. */
    fun scheduleAll(ctx: Context) {
        Repo.init(ctx)
        val s = Repo.settings.value
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return
        // buang penggera & kerja latar "bertolak" dari versi lama (fungsi pelan bertolak telah dibuang)
        am.cancel(pi(ctx, "depart", RC_DEPART_LAMA))
        try { WorkManager.getInstance(ctx).cancelUniqueWork("bertolak") } catch (e: Exception) { }
        val missed = pi(ctx, TYPE_MISSED, RC_MISSED)
        am.cancel(missed)
        if (!s.remindersOn) return
        val now = System.currentTimeMillis()
        val missOffset = (s.graceMinutes + 10) * 60_000L
        Logic.nextWorkStart(s, now, missOffset)?.let { (_, start) -> set(ctx, start + missOffset, missed) }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Repo.init(context)
        if (intent.getStringExtra(Reminders.EXTRA_TYPE) == Reminders.TYPE_MISSED) checkMissed(context)
        Reminders.scheduleAll(context)
    }

    private fun checkMissed(ctx: Context) {
        val s = Repo.settings.value
        val recs = Repo.records.value
        val now = System.currentTimeMillis()
        val today = Logic.today(now)
        for (d in listOf(today, today.minusDays(1))) {
            if (Logic.dayKind(d, s) != DayKind.KERJA) continue
            val start = Logic.shiftStartMs(d, s)
            if (now < start || now - start > 3 * 3_600_000L) continue
            val r = recs[d]
            if (r == null || (r.status == RecordStatus.HADIR && r.checkIn == null)) {
                Notif.show(
                    ctx, Notif.ID_MISSED, Notif.CH_REMIND, "Belum check-in",
                    "${Ms.shiftLabel(Logic.shiftType(d, s))} mula ${Ms.time(start)}. Dah sampai? Check-in sekarang supaya rekod tepat.",
                    "Check-in" to Notif.ACTION_CHECK_IN,
                )
                return
            }
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Repo.init(context)
        GeofenceHelper.register(context, force = true)
        Reminders.scheduleAll(context)
    }
}
