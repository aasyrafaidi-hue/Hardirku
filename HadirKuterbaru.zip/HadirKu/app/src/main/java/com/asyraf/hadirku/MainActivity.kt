package com.asyraf.hadirku

import android.app.Application
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.fragment.app.FragmentActivity
import com.asyraf.hadirku.data.Repo
import com.asyraf.hadirku.logic.Logic
import com.asyraf.hadirku.logic.ShiftType
import com.asyraf.hadirku.system.Cleanup
import android.content.Intent
import com.asyraf.hadirku.kongsi.Kongsi
import com.asyraf.hadirku.kongsi.Status
import com.asyraf.hadirku.rumah.Peringatan
import com.asyraf.hadirku.ui.HadirApp
import com.asyraf.hadirku.ui.PgTheme

class HadirKuApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        Repo.init(this)
        Cleanup.lama(this)
        Peringatan.saluran(this)
        Peringatan.pasang(this)
    }
}

class MainActivity : FragmentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        Repo.init(this)
        setContent {
            val s by vm.settings.collectAsState()
            val now by vm.now.collectAsState()
            val systemDark = isSystemInDarkTheme()
            val dark = when (s.themeMode) {
                1 -> false
                2 -> true
                3 -> Logic.shiftType(Logic.today(now), s) == ShiftType.MALAM
                else -> systemDark
            }
            val view = LocalView.current
            SideEffect {
                val controller = WindowCompat.getInsetsController(window, view)
                controller.isAppearanceLightStatusBars = !dark
                controller.isAppearanceLightNavigationBars = !dark
            }
            PgTheme(dark = dark, saiz = vm.saiz) {
                HadirApp(vm, this@MainActivity)
            }
        }
        if (savedInstanceState == null) vm.bukaDari(intent?.getStringExtra(Peringatan.EXTRA_BUKA))
    }

    /** Notifikasi bil ditekan semasa app sudah terbuka. */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        vm.bukaDari(intent.getStringExtra(Peringatan.EXTRA_BUKA))
    }

    override fun onResume() {
        super.onResume()
        vm.tick()
        if (Kongsi.status.value == Status.RALAT) Kongsi.cubaLagi()
    }
}
