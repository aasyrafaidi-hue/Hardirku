package com.asyraf.hadirku.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.asyraf.hadirku.MainViewModel
import com.asyraf.hadirku.Sheet
import com.asyraf.hadirku.ai.Ai
import com.asyraf.hadirku.pg.PG
import com.asyraf.hadirku.pg.PgState
import com.asyraf.hadirku.pg.Period
import com.asyraf.hadirku.pg.PeriodReport
import com.asyraf.hadirku.pg.Tx

private class PI(val id: String, val name: String, val v: Double, var slot: Int)
private class It(val id: String, val nama: String, val dompet: Boolean, val v: Double, val t: Double, val lp: Double, val tunai: Boolean = false)
private class OtBlockData(
    val kcLbl: String, val kcRun: Boolean, val bayarYm: String, val hariOt: Int, val cOt: Double, val cHar: Double, val bzOt: Double,
    val lebih: Int, val n: Int, val otVals: List<Double>, val harVals: List<Double>, val titles: List<String>, val ticks: List<Pair<Int, String>>, val trows: List<List<String>>,
)

@Composable
private fun OtBlock(d: OtBlockData) {
    val pal = LocalPal.current
    ChartBlock("OT vs belanja harian", "Kitaran OT " + d.kcLbl + (if (d.kcRun) " · setakat hari ini" else "") + " · komitmen & bayaran hutang tidak dikira") {
        Kvl(listOf(
            Triple(rich("OT diperoleh (" + d.hariOt + " hari)"), M(d.cOt), pal.inn),
            Triple(rich("Belanja harian"), M(d.cHar), pal.out),
            Triple(rich("Baki (OT − belanja)"), Mp(d.bzOt), if (d.bzOt < -0.004) pal.out else pal.inn),
            Triple(rich("Hari belanja melebihi OT"), d.lebih.toString() + " / " + d.n, if (d.lebih > 0) pal.bad else null),
        ), strongIdx = setOf(2))
        if (d.n >= 2) {
            LineChart(listOf(LSeries("OT terkumpul", pal.c1, d.otVals), LSeries("Belanja harian terkumpul", pal.c2, d.harVals)), d.titles, d.ticks)
            Legend(listOf(LegItem("OT terkumpul", pal.c1, true), LegItem("Belanja harian terkumpul", pal.c2, true)))
        }
        TableView(listOf("Tarikh", "OT", "Belanja harian", "Baki"), d.trows)
        Txt("Hari " + d.kcLbl + " ialah kitaran OT yang dibayar dalam gaji " + PG.fmtMonth(d.bayarYm) + ". OT setiap hari ikut kadar dalam Tetapan.", size = 12.5f, color = pal.muted)
    }
}

private fun pocketSlot(s: PgState, id: String): Int {
    val idx = s.pockets.filter { it.id != PG.BELUM_AGIH }.indexOfFirst { it.id == id }
    return if (idx in 0..4) idx + 1 else 6
}

@Composable
private fun Tog(opts: List<Pair<String, String>>, cur: String, onSel: (String) -> Unit) {
    val pal = LocalPal.current
    val shape = RoundedCornerShape(8.dp)
    Row(Modifier.border(1.dp, pal.lineStrong, shape).background(pal.surface, shape)) {
        opts.forEachIndexed { i, (id, l) ->
            val on = id == cur
            if (i > 0) Box(Modifier.width(1.dp).height(36.dp).background(pal.lineStrong))
            Box(
                Modifier.height(36.dp).background(if (on) pal.accentSoft else Color.Transparent).clickable { onSel(id) }.padding(horizontal = 12.dp),
                contentAlignment = Alignment.Center,
            ) { Txt(l, size = 13f, weight = FontWeight.SemiBold, color = if (on) pal.accentStrong else pal.muted) }
        }
    }
}

fun pieModeNow(vm: MainViewModel, s: PgState): String = vm.pieMode ?: if (akruanOn(s)) "harian" else "semua"
fun inPieMode(t: Tx, pm: String): Boolean = if (pm == "harian") (t.jenis == "kad" || (t.jenis == "keluar" && t.komitmenId.isEmpty() && t.hutangId.isEmpty())) else t.jenis == "keluar"

@Composable
fun LaporanScreen(vm: MainViewModel) {
    val pal = LocalPal.current
    val s by vm.pg.collectAsState()
    val today = vm.today()
    val per = vm.lap
    val prev = PG.shiftPeriod(per, -1, 1)
    val r = remember(s, per) { PG.periodReport(s, per) }
    val rp = remember(s, per) { PG.periodReport(s, prev) }
    val running = today >= per.start && today <= per.end
    val future = per.start > today
    val yr = PG.parse(per.end).y
    val lv = if (vm.lapView == "poket") "poket" else "ringkasan"
    Seg(listOf("ringkasan" to "Ringkasan", "poket" to "Poket"), lv) { vm.setLapViewMode(it) }
    NavRow(periodLabel(per), if (running) "Bulan semasa · setakat hari ini" else if (future) "Bulan akan datang" else PG.fmtShort(per.start) + " – " + PG.fmtShort(per.end) + " " + yr,
        { vm.lap = PG.shiftPeriod(per, -1, 1) }, { vm.lap = PG.shiftPeriod(per, 1, 1) })
    if (lv == "poket") { LaporanPoket(vm, s, per, r, rp, running); return }
    val ak = akruanOn(s)
    if (r.masuk == 0.0 && r.keluar == 0.0 && r.tunaiKad == 0.0 && !(ak && (r.otEarned > 0 || r.kad > 0))) {
        Empty(rich("Tiada transaksi Masuk atau Keluar dalam bulan ini."))
        return
    }
    val dK = if (ak) PG.round2(r.belanja - rp.belanja) else PG.round2(r.keluar - rp.keluar)
    val prevK = if (ak) rp.belanja else rp.keluar
    val deltaK = if (prevK > 0) (if (dK >= 0) "▲ " else "▼ ") + M(Math.abs(dK)) + " vs bulan lepas" else "Tiada data bulan lepas"
    val kc = r.otKitaran

    // ---------- penyata ----------
    if (ak && kc != null) {
        Slip("Pendapatan & perbelanjaan", periodLabel(per)) {
            SlipRow("Duit masuk (gaji & lain-lain)", M(r.masuk))
            if (r.otBayar > 0) SlipRow("Tolak OT dalam gaji", M(-r.otBayar))
            SlipRow("OT " + PG.fmtShort(kc.start) + " – " + PG.fmtShort(kc.end) + if (today >= kc.start && today <= kc.end) " (setakat ini)" else "", M(r.otEarned))
            SlipRow("Jumlah pendapatan", M(r.pend), true)
            SlipRow("Komitmen", M(-r.komitmen))
            if (r.bayarPinjaman > 0) SlipRow("Ansuran pinjaman", M(-r.bayarPinjaman))
            SlipRow("Belanja harian (termasuk guna kad)", M(-r.harian))
            if (r.kadLog > 0) SlipRow(if (r.feeTunai > 0) "Faedah, caj & fee kad" else "Faedah & caj kad", M(-r.kadLog))
            SlipRow("Jumlah perbelanjaan", M(-r.belanja), true)
            SlipRow(if (r.lebihan >= 0) "Lebihan" else "Kurangan", M(r.lebihan), true)
            SlipNote(rich("Perbelanjaan " + deltaK + (if (running) " (bulan ini belum habis)" else "") + ". Ikut bank: masuk " + M(r.masuk) + ", keluar " + M(r.keluar) + "."))
            SlipNote(rich("OT bulan ini ikut kitaran OT " + PG.fmtShort(kc.start) + " – " + PG.fmtShort(kc.end) + " yang dibayar dalam gaji " + PG.fmtMonth(kc.bayarYm) + ", bukan 1hb hingga hujung bulan." +
                if (r.otBayar > 0) " Bahagian OT dalam gaji (" + M(r.otBayar) + ") ditolak supaya tidak dikira dua kali." else ""))
            if (r.bayarKad > 0) SlipNote(rich("Bayar kad kredit " + M(r.bayarKad) + " tidak dikira belanja: belanja guna kad sudah dikira pada hari beli."))
            TunaiNote(s, r, per, ak)
        }
    } else {
        Slip("Penyata bulan", periodLabel(per)) {
            SlipRow("Duit masuk", M(r.masuk)); SlipRow("Komitmen", M(-r.komitmen)); SlipRow("Bayar hutang", M(-r.hutang)); SlipRow("Belanja lain", M(-r.harianTunai))
            SlipRow(if (r.bersih >= 0) "Lebihan" else "Kurangan", M(r.bersih), true)
            SlipNote(rich("Jumlah keluar dari bank " + M(r.keluar) + " · " + deltaK + if (running) " (bulan ini belum habis)" else ""))
            if (r.kad > 0) SlipNote(rich("Belanja guna kad kredit " + M(r.kad) + " tidak termasuk di atas; ia menambah baki kad dan dibayar kemudian."))
            TunaiNote(s, r, per, ak)
        }
    }

    // ---------- ringkasan bertulis ----------
    val ins = ArrayList<AnnotatedString>()
    val lb = if (ak) r.lebihan else r.bersih
    val inn = if (ak) "Pendapatan" else "Duit masuk"
    val outn = if (ak) "perbelanjaan" else "belanja"
    ins.add(if (lb >= 0) rich("$inn melebihi $outn sebanyak **" + M(lb) + "**" + if (running) " setakat hari ini." else ".")
    else rich((if (ak) "Perbelanjaan" else "Belanja") + " melebihi " + inn.lowercase() + " sebanyak **" + M(-lb) + "**" + if (running) " setakat hari ini." else ". Lihat Laporan → Poket untuk poket yang paling banyak digunakan."))
    if (ak && running && r.otBayar == 0.0 && kc != null) {
        val oo2 = PG.otOutstanding(s, today)
        if (oo2.lepas.nilai > 0 && oo2.lepas.dibayar == null) ins.add(rich("Gaji bulan ini belum direkod; pendapatan setakat ini ialah duit masuk lain dan OT " + PG.fmtShort(kc.start) + " – " + PG.fmtShort(kc.end) + " yang akan dibayar bersama gaji."))
    }
    val asasP = if (ak) r.pend else r.masuk
    val kedua = if (ak) r.bayarPinjaman else r.hutang
    val tetapP = r.komitmen + kedua
    if (!running && asasP > 0 && tetapP > 0) ins.add(rich((if (kedua > 0) "Komitmen dan " + (if (ak) "ansuran pinjaman" else "bayaran hutang") else "Komitmen") + " ambil **" + Math.round(tetapP / asasP * 100) + "%** daripada " + (if (ak) "pendapatan" else "duit masuk") +
        " (" + (if (kedua > 0) M(r.komitmen) + " komitmen, " + M(kedua) + (if (ak) " ansuran" else " hutang") else M(r.komitmen)) + ")."))
    var best: Triple<String, Double, Double>? = null
    (r.poket.keys + rp.poket.keys).distinct().forEach { pid ->
        val a = r.poket[pid] ?: 0.0
        val b = rp.poket[pid] ?: 0.0
        val d = a - b
        val bb = best
        if (b > 0 && Math.abs(d) >= 20 && (bb == null || Math.abs(d) > Math.abs(bb.second))) best = Triple(pid, d, b)
    }
    val be = best
    if (be != null && !(running && be.second < 0)) ins.add(rich("Belanja **" + pname(s, be.first) + "** " + (if (be.second > 0) "naik " else "turun ") + M(Math.abs(be.second)) + " (" + Math.round(Math.abs(be.second) / be.third * 100) + "%) berbanding bulan lepas."))
    val sdOt = vm.otSd()
    val ocyc = PG.otCycleOf(per.start, sdOt)
    val ot = remember(s, ocyc.start) { PG.otTrend(s, ocyc, 6, sdOt) }
    val otHas = ot.any { it.hari > 0 }
    if (otHas && ot.size >= 3) {
        val pastOt = ot.dropLast(1)
        val avg = pastOt.sumOf { it.nilai } / pastOt.size
        val last = ot.last()
        if (avg > 0 && last.end < today) ins.add(rich("OT kitaran " + PG.fmtShort(last.start) + " – " + PG.fmtShort(last.end) + " ialah **" + M(last.nilai) + "**, " + Math.abs(Math.round((last.nilai - avg) / avg * 100)) + "% " + (if (last.nilai >= avg) "atas" else "bawah") + " purata kitaran sebelumnya."))
    }

    // ---------- OT vs belanja harian ----------
    var otData: OtBlockData? = null
    if (ak && kc != null) {
        val kcRun = today >= kc.start && today <= kc.end
        val dsA = remember(s, kc.start) { PG.dailySummary(s, PG.ym(kc.start), null) }
        val dsB = remember(s, kc.end) { if (PG.ym(kc.end) == PG.ym(kc.start)) null else PG.dailySummary(s, PG.ym(kc.end), null) }
        val upto = (dsA.days + (dsB?.days ?: emptyList())).filter { it.tarikh >= kc.start && it.tarikh <= kc.end && it.tarikh <= today }
        var cJam = 0.0; var cOt = 0.0; var cHar = 0.0; var lebih = 0; var hariOt = 0
        val kadar = PG.hrp(s.settings.gaji)
        val otVals = ArrayList<Double>(); val harVals = ArrayList<Double>(); val titles = ArrayList<String>(); val trows = ArrayList<List<String>>()
        upto.forEach { x ->
            val ov = PG.otValue(s, x.tarikh)
            cJam += ov.h15 * 1.5 + ov.h20 * 2 + ov.h30 * 3; cOt = cJam * kadar
            cHar += x.harian; otVals.add(PG.round2(cOt)); harVals.add(PG.round2(cHar)); titles.add(longDate(x.tarikh))
            if (x.harian > x.ot + 0.004) lebih++
            if (x.ot > 0) hariOt++
            if (x.ot > 0 || x.harian > 0) trows.add(listOf(PG.fmtShort(x.tarikh), M(x.ot), M(x.harian), Mp(x.bakiOt)))
        }
        cOt = PG.round2(cOt); cHar = PG.round2(cHar)
        val bzOt = PG.round2(cOt - cHar)
        val kcLbl = PG.fmtShort(kc.start) + " – " + PG.fmtShort(kc.end)
        if (cOt > 0 || cHar > 0) {
            ins.add(0, if (bzOt >= 0) rich("Dalam kitaran OT $kcLbl, belanja harian **" + M(cHar) + "** masih dalam OT yang diperoleh **" + M(cOt) + "**. Baki **" + M(bzOt) + "**.")
            else rich("Dalam kitaran OT $kcLbl, belanja harian **" + M(cHar) + "** melebihi OT yang diperoleh **" + M(cOt) + "** sebanyak **" + M(-bzOt) + "**."))
            val ticks = ArrayList<Pair<Int, String>>()
            var tm = -1
            upto.forEachIndexed { i, x -> if (i % 7 == 0) { val tp = PG.parse(x.tarikh); ticks.add(i to (tp.d.toString() + if (tp.m != tm) " " + PG.BULAN[tp.m - 1] else "")); tm = tp.m } }
            otData = OtBlockData(kcLbl, kcRun, kc.bayarYm, hariOt, cOt, cHar, bzOt, lebih, upto.size, otVals, harVals, titles, ticks, trows)
        }
    }
    Block {
        ins.forEach { t ->
            Row(Modifier.padding(vertical = 4.dp)) {
                Box(Modifier.padding(top = 7.dp).size(7.dp).background(pal.accent, CircleShape))
                Spacer(Modifier.width(9.dp))
                Txt(t, size = 14f)
            }
        }
    }
    val od = otData
    if (od != null) OtBlock(od)

    // ---------- donut ----------
    val pm = pieModeNow(vm, s)
    val by = if (vm.pieBy == "kategori") "kategori" else "poket"
    val items: List<PI> = if (by == "kategori") {
        val src = if (pm == "harian") r.katHarian else r.katTunai
        var rank = 0
        src.keys.filter { (src[it] ?: 0.0) > 0.004 }.map { PI(it, PG.katLabel(it), src[it] ?: 0.0, 0) }
            .sortedWith(compareBy<PI> { if (it.id == "belum") 1 else 0 }.thenByDescending { it.v })
            .onEach { x -> x.slot = if (x.id == "belum") 0 else if (rank < 5) ++rank else 6 }
    } else {
        val src = if (pm == "harian") r.poketHarian else r.poketTunai
        src.keys.filter { (src[it] ?: 0.0) > 0.004 }.map { PI(it, pname(s, it), src[it] ?: 0.0, pocketSlot(s, it)) }.sortedByDescending { it.v }
    }
    val pTot = PG.round2(items.sumOf { it.v })
    // pie: susun besar → kecil, "Tiada kategori" di hujung; warna cerah ikut susunan
    val sortedI = items.sortedWith(compareBy<PI> { if (it.id == "belum") 1 else 0 }.thenByDescending { it.v })
    val maxS = 11
    val mainI = sortedI.take(maxS)
    val restI = sortedI.drop(maxS)
    val grey = pal.p[5]
    val colMap = HashMap<String, Color>()
    var ci = 0
    mainI.forEach { colMap[it.id] = if (it.id == "belum") grey else pieColor(ci++) }
    fun colFor(id: String): Color = colMap[id] ?: grey
    val slices = ArrayList<Slice>()
    mainI.forEach { slices.add(Slice(it.id, it.name, it.v, colFor(it.id))) }
    if (restI.isNotEmpty()) slices.add(Slice("lain", if (restI.size == 1) restI[0].name else if (by == "kategori") "Kategori lain (" + restI.size + ")" else "Lain-lain (" + restI.size + " poket)", PG.round2(restI.sumOf { it.v }), grey))
    ChartBlock("Belanja ikut $by", if (pm == "harian") "Belanja harian termasuk guna kad, tanpa komitmen & bayaran hutang" else "Semua keluar dari bank, termasuk komitmen & bayaran hutang") {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Tog(listOf("poket" to "Poket", "kategori" to "Kategori"), by) { vm.setPieByMode(it) }
            Tog(listOf("harian" to "Belanja harian", "semua" to "Keluar bank"), pm) { vm.pieMode = it }
        }
        if (items.isEmpty()) { Txt("Tiada " + (if (pm == "harian") "belanja harian" else "transaksi Keluar") + " dalam bulan ini.", size = 12.5f, color = pal.muted); return@ChartBlock }
        PieChart(slices, pTot, if (pm == "harian") "Jumlah belanja harian" else "Jumlah keluar")
        val belumI = if (pm == "harian") r.belumHarian else r.belumTunai
        if (by == "kategori") {
            if (vm.katBusy) Txt(vm.katProg.ifEmpty { "Mengkategorikan…" }, Modifier.fillMaxWidth().background(pal.accentSoft, RoundedCornerShape(6.dp)).padding(10.dp), size = 14f, color = pal.accentStrong)
            else if (belumI.n > 0) {
                Column(Modifier.fillMaxWidth().background(pal.accentSoft, RoundedCornerShape(6.dp)).padding(10.dp)) {
                    Txt(rich("**" + belumI.n + " belanja** (" + M(belumI.jumlah) + ") belum ada kategori." + if (Ai.ready()) "" else " Pilih kategori dalam transaksi, atau guna AI."), size = 14f, color = pal.accentStrong)
                    Spacer(Modifier.height(8.dp))
                    if (Ai.ready()) Btn("Kategorikan dengan AI", { vm.katSemua() }, kind = BtnKind.SMALL, color = pal.accentStrong)
                    else Btn("Tetapan AI", { vm.aiSetup() }, kind = BtnKind.SMALL, color = pal.accentStrong)
                }
            }
        }
        Column(Modifier.fillMaxWidth().padding(top = 4.dp)) {
            sortedI.forEach { x ->
                PieRowCompact(pct(x.v / pTot * 100) + "%", colFor(x.id), x.name, M(x.v), if (by == "kategori") ({ vm.open(Sheet.KatList(x.id)) }) else null)
            }
        }
        if (by == "kategori") Txt("Tekan kategori untuk lihat transaksinya dan betulkan kategori.", size = 12.5f, color = pal.muted)
        TableView(listOf(if (by == "kategori") "Kategori" else "Poket", "Jumlah", "Peratus"), items.map { listOf(it.name, M(it.v), pct(it.v / pTot * 100) + "%") })
    }

    // ---------- trend 6 bulan ----------
    val tr = remember(s, per) { PG.trendPeriods(s, per, 6, 1) }
    val tIn = if (ak) "Pendapatan" else "Masuk"
    val tOut = if (ak) "Perbelanjaan" else "Keluar"
    val tTitle = if (ak) "Pendapatan & perbelanjaan 6 bulan" else "Masuk & keluar 6 bulan"
    fun tv(t: com.asyraf.hadirku.pg.TrendRow, k: String): Double = if (ak) (if (k == "in") t.pend else if (k == "out") t.belanja else t.lebihan) else (if (k == "in") t.masuk else if (k == "out") t.keluar else t.bersih)
    if (tr.size < 2) ChartBlock(tTitle, null) { Txt("Trend akan muncul selepas ada data untuk dua bulan.", size = 12.5f, color = pal.muted) }
    else {
        val cats = tr.map { t ->
            val e = PG.parse(t.end)
            val run = today >= t.start && today <= t.end
            ColCat(PG.BULAN[e.m - 1], PG.fmtMonth(PG.ym(t.start)), if (run) "Bulan semasa, setakat hari ini" else (if (ak) "Lebihan " else "Baki bersih ") + M(tv(t, "net")))
        }
        ChartBlock(tTitle, "1hb hingga hujung bulan" + if (ak) " · OT ikut kitaran yang dibayar dalam gaji bulan itu" else "") {
            ColumnChart(listOf(tIn to pal.c1, tOut to pal.c2), cats, listOf(tr.map { tv(it, "in") }, tr.map { tv(it, "out") }))
            Legend(listOf(LegItem(tIn, pal.c1), LegItem(tOut, pal.c2)))
            TableView(listOf("Bulan", tIn, tOut, if (ak) "Lebihan" else "Bersih"), tr.mapIndexed { i, t -> listOf(cats[i].title, M(tv(t, "in")), M(tv(t, "out")), M(tv(t, "net"))) })
        }
    }

    // ---------- OT 6 kitaran ----------
    if (otHas) {
        val avgAll = ot.sumOf { it.nilai } / ot.size
        val ocats = ot.map { o ->
            val bp = o.bayarYm.split("-")
            ColCat(PG.BULAN[bp[1].toInt() - 1], PG.fmtShort(o.start) + " – " + PG.fmtShort(o.end) + " · gaji " + PG.fmtMonth(o.bayarYm), fmtH(o.jam) + " jam OT · " + o.hari + " hari direkod")
        }
        ChartBlock("Nilai OT " + ot.size + " kitaran", "Purata " + M(avgAll) + " · label ikut bulan gaji dibayar") {
            ColumnChart(listOf("Nilai OT" to pal.c1), ocats, listOf(ot.map { it.nilai }))
            TableView(listOf("Kitaran", "Jam OT", "Nilai"), ot.mapIndexed { i, o -> listOf(ocats[i].title, fmtH(o.jam), M(o.nilai)) })
            Txt("Dikira dengan kadar gaji dalam Tetapan sekarang.", size = 12.5f, color = pal.muted)
        }
    }

    // ---------- belanja terbesar ----------
    val topL = if (ak) r.topL else r.top
    if (topL.isNotEmpty()) {
        val sett = remember(s) { PG.otSettlements(s).byTx }
        SecHead("Belanja terbesar")
        ListBlock { topL.forEach { TxRow(vm, s, it, ak, sett, showDate = true) } }
    }

    SecHead("CFO peribadi (Claude)")
    Block {
        Txt("Buat satu fail dengan semua angka penting dan arahan, kemudian hantar kepada Claude sebagai CFO untuk semakan dan pelan 30 hari.", size = 13f, color = pal.muted)
        Spacer(Modifier.height(10.dp))
        Btn("Buat fail CFO", { vm.open(Sheet.Cfo) }, Modifier.fillMaxWidth(), kind = BtnKind.PRIMARY)
    }
}

@Composable
private fun PieRowCompact(p: String, c: Color, name: String, v: String, onClick: (() -> Unit)?) {
    val pal = LocalPal.current
    Row(
        Modifier.fillMaxWidth().hairlines(pal.line).then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier).padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.background(c, RoundedCornerShape(5.dp)).padding(horizontal = 6.dp, vertical = 3.dp).width(44.dp), contentAlignment = Alignment.Center) {
            Txt(p, size = 13f, weight = FontWeight.SemiBold, color = inkOn(c), num = true)
        }
        Spacer(Modifier.width(12.dp))
        Txt(name, Modifier.weight(1f), size = 15f, maxLines = 1)
        Txt(v, size = 15f, num = true)
        if (onClick != null) { Spacer(Modifier.width(8.dp)); Txt("›", size = 18f, color = pal.muted) }
    }
}

@Composable
fun ChartBlock(title: String, sub: String?, content: @Composable () -> Unit) {
    val pal = LocalPal.current
    Block {
        Txt(title, size = 15f, weight = FontWeight.Bold)
        if (sub != null) Txt(sub, size = 12.5f, color = pal.muted)
        Spacer(Modifier.height(10.dp))
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) { content() }
    }
}

@Composable
private fun TunaiNote(s: PgState, r: PeriodReport, per: Period, ak: Boolean) {
    if (!(r.tunaiKad > 0)) return
    val yr = per.end.substring(0, 4)
    var ytd = 0.0
    s.transactions.forEach { t -> if (t.jenis == "tunai-kad" && t.tarikh.substring(0, 4) == yr && t.tarikh <= per.end) ytd += t.fee ?: 0.0 }
    SlipNote(rich("Tunai dari kad " + M(r.tunaiKad) + (if (r.feeTunai > 0) " (fee " + M(r.feeTunai) + ")" else "") + " ialah pinjaman: tidak dikira " + (if (ak) "pendapatan" else "duit masuk") + ", tapi menambah hutang kad." +
        (if (ak && r.feeTunai > 0) " Fee dikira perbelanjaan." else "") + " Fee tunai tahun " + yr + ": **" + M(PG.round2(ytd)) + "**."))
}

/* Laporan → Poket: belanja setiap poket berbanding sasaran */
@Composable
private fun LaporanPoket(vm: MainViewModel, s: PgState, per: Period, r: PeriodReport, rp: PeriodReport, running: Boolean) {
    val pal = LocalPal.current
    val today = vm.today()
    val ct = remember(s, today) { PG.targetsFromCommitments(s, today) }
    var totV = 0.0; var totT = 0.0; var totTV = 0.0; var over = 0
    val items = s.pockets.map { p ->
        val v = r.poket[p.id] ?: 0.0
        val t = PG.round2((ct[p.id] ?: 0.0) + p.sasaran)
        val lp = rp.poket[p.id] ?: 0.0
        totV += v; if (t > 0) { totT += t; totTV += v; if (v > t + 0.004) over++ }
        It(p.id, p.nama, p.dompet, PG.round2(v), PG.round2(t), PG.round2(lp), p.tunai)
    }
    totV = PG.round2(totV); totT = PG.round2(totT); totTV = PG.round2(totTV)
    Block {
        Txt("Belanja semua poket " + if (running) "(setakat hari ini)" else periodLabel(per), size = 12f, color = pal.muted)
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            MoneyAnim(totV, 22f)
            Spacer(Modifier.weight(1f))
            if (totT > 0) Txt(rich("sasaran **" + M(totT) + "**"), size = 13f, color = pal.muted)
        }
        if (totT > 0) { Spacer(Modifier.height(10.dp)); val pc = totTV / totT; Bar(pc, over = totTV > totT + 0.004, warn = pc >= 0.85, h = 8.dp) }
        Spacer(Modifier.height(10.dp))
        Txt(if (totT > 0) (if (over > 0) "$over poket melebihi sasaran" else "✔ Semua poket dalam sasaran") + " · baki bajet " + M(Math.max(0.0, totT - totTV)) else "Belum ada sasaran poket. Tetapkan di Tetapan → Poket.",
            size = 13f, color = if (over > 0) pal.bad else pal.muted)
    }
    SecHead("Belanja setiap poket")
    ListBlock {
        items.forEach { x ->
            val d = PG.round2(x.v - x.lp)
            val sub = ArrayList<String>()
            if (x.t > 0) sub.add("Belanja " + M(x.v) + " daripada " + M(x.t) + " · " + if (x.v > x.t + 0.004) "lebih " + M(x.v - x.t) else "baki bajet " + M(x.t - x.v))
            else sub.add(if (x.v > 0.004) "Belanja " + M(x.v) + " · tiada sasaran" else "Tiada belanja bulan ini")
            if (x.lp > 0.004) sub.add(if (Math.abs(d) < 0.005) "Sama dengan bulan lepas" else (if (d > 0) "▲ Naik " else "▼ Turun ") + M(Math.abs(d)) + " berbanding bulan lepas")
            PRow(x.nama, M(x.v), { vm.open(Sheet.PoketList(x.id)) }, tag = if (x.tunai) "tunai" else if (x.dompet) "e-wallet" else null, subs = sub,
                bar = if (x.t > 0) BarSpec(x.v / x.t, x.v > x.t + 0.004, x.v / x.t >= 0.85) else null)
        }
    }
    Block {
        TableView(listOf("Poket", "Belanja", "Sasaran", "Baki bajet", "Bulan lepas"), items.map { listOf(it.nama, M(it.v), if (it.t > 0) M(it.t) else "–", if (it.t > 0) M(it.t - it.v) else "–", M(it.lp)) })
    }
    Note("Belanja = semua Keluar dan Guna kad kredit dari poket itu dalam bulan ini, termasuk komitmen & bayaran hutang. Sasaran = tambahan sebulan + komitmen & bayaran hutang yang guna poket itu (ikut tetapan sekarang). Garisan: hijau dalam sasaran, oren 85% ke atas, merah lebih. Tekan poket untuk lihat transaksinya.")
}
