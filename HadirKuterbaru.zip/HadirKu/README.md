# Duitku — urus duit + kehadiran kerja dalam satu app

App Android native (Kotlin + Jetpack Compose), dahulu dikenali sebagai **HadirKu**. Gabungan rekod kehadiran (disiplin, geofence, amaran lupa check-in) dan **PoketGaji v0.9.3** (poket, lejar harian, komitmen, hutang, OT, laporan, AI, fail CFO). Rupa ikut PoketGaji — lejar rata, garis halus — dengan aksen **cyan lembut** (#0C7C8C cerah, #5CC3CF gelap). Masuk biru, keluar merah lembut.

> Nama pakej (`com.asyraf.hadirku`) dan kunci tandatangan kekal sama, jadi APK Duitku **update** atas HadirKu yang sedia ada — semua data kekal.

## Tab

| Tab | Isi |
|---|---|
| **OT** | Nilai OT kitaran (22hb–21hb) + palang had OT, jam 1.5x / 2.0x / 3.0x, kad **Hari ini**, peringatan hari belum diisi, log harian (terkini di atas, hari depan disembunyikan). Key in guna **helaian papan nombor**: tarikh ‹ ›, jenis hari (Biasa / Off / Rest / Umum / Cuti), jam besar dengan kiraan OT terus, jam cepat 8–12, papan nombor sendiri (⌫, C, −½, +½) dan Simpan. *Simpan & hari seterusnya* simpan tanpa tutup dan terus ke esoknya. |
| **Poket** | Baki bank & e-wallet, semak bank, belum agih, senarai poket, jubin komitmen / OT / hutang / perbelanjaan |
| **Transaksi** | Kalendar & senarai lejar harian (OT dikira pendapatan), butiran hari |
| **Bayaran** | Komitmen 15hb / 30hb, hutang (kad, pinjaman, BNPL, EPP), bayar kad, pelan bebas hutang + carta |

> **Minimum kad kredit (lalai):** peratus minimum × (baki kad + pokok EPP belum dibil), sekurang-kurangnya minimum terendah (RM50) dan ansuran EPP bulan ini. Faedah EPP belum dibil dipaparkan berasingan daripada pokok. Boleh tukar per kad ke cara asal PoketGaji (ansuran EPP penuh + peratus baki biasa) dalam **Edit hutang → Minimum dikira daripada**.
| **Transaksi baru** | Skrin penuh: Masuk / Keluar / Pindah (+ Lain), baris Tarikh · Jumlah · Kategori · Poket · Perkara, Catatan + kamera imbas resit, butang Simpan / Teruskan. Papan nombor sendiri (boleh + / −), grid kategori & poket. Pilih / Selesai / Enter terus ke medan seterusnya. |
| **Laporan** | Penyata pendapatan & perbelanjaan, OT vs belanja harian, pie poket / kategori (label & peratus di luar), trend 6 bulan, OT 6 kitaran, belanja terbesar, fail CFO |
| **Tetapan (gear)** | Tema, saiz tulisan, gaji & OT, jadual shift, Pembantu AI, cuti umum (Calendarific), poket, semakan bank, data |

## Bank, tunai dan e-wallet (diasingkan)
- Setiap poket ada tempat simpan: **Bank**, **Tunai (dompet)** atau **E-wallet** (Edit poket → *Duit poket ini disimpan di*).
- Tab Poket tunjuk **Baki dalam bank**, **Tunai dalam dompet**, e-wallet dan **Semua duit** secara berasingan. *Semak baki bank* hanya kira duit bank.
- Kad **Dompet tunai**: *Ambil ATM* (pindah dari poket bank → dompet tunai: bank turun, tunai naik), *Belanja* (belanja tunai, bank tak berubah), *Kira duit* (masukkan duit sebenar dalam dompet; beza direkod sebagai belanja tak direkod, duit masuk, atau pelarasan).
- Dompet Tunai dibuat sendiri sekali (selepas Belum Agih). Kalau sudah ada poket e-wallet bernama Tunai/Cash, poket itu yang ditukar jadi dompet tunai.
- Resit yang dibaca AI sebagai dibayar tunai terus pilih dompet tunai. Belanja guna kad kredit hanya dari poket bank.
- Dalam fail salinan, dompet tunai disimpan sebagai `"dompet": true, "tunai": true` — PoketGaji PWA membacanya sebagai e-wallet (tetap di luar bank).

## Susun & pilih poket
- Tab Poket atau Tetapan → Poket → **Susun**: anak panah naik/turun pada setiap poket. Belum Agih sentiasa di atas. Susunan ini dipakai di semua senarai dan pilihan poket, dan disimpan dalam fail salinan.
- Semua pilihan poket (transaksi, pindah, komitmen, hutang, bayar kad, tunai dari kad) dipaparkan dalam **grid 4 lajur** sama lebar; nama panjang turun ke baris kedua, dan poket tunai / e-wallet ada tag kecil.

## Satu sumber OT
Log OT PoketGaji ialah satu-satunya sumber OT. Bila check-out (atau edit rekod hari), jam di tempat kerja (dibundar ke bawah, lalai 30 minit) diisi ke log OT dengan jenis hari ikut jadual shift: hari kerja = Biasa, rest day = Rest, cuti umum = Umum, hari lain = Off, Cuti/MC = Tidak bekerja. Log masih boleh diubah manual.

## Salinan data
- **Simpan salinan** menghasilkan fail format PoketGaji v2 (`duitku-salinan-YYYY-MM-DD.json`) dengan bahagian tambahan `hadirku` (tetapan & rekod kehadiran — nama kunci dikekalkan supaya salinan lama tetap boleh dibaca). Fail ini masih boleh dibuka oleh PoketGaji PWA.
- **Pulihkan salinan** terima: salinan Duitku / gabungan, salinan PoketGaji biasa, atau salinan HadirKu v1. Hari yang ada rekod kehadiran lengkap tapi tiada log OT akan diisi sendiri.
- Kunci API (Anthropic, Calendarific) kekal dalam telefon, tidak masuk fail salinan.

## Bina APK di GitHub
1. Repo `Hadirmu` (private) sudah ada workflow `.github/workflows/build.yml` yang ekstrak `HadirKu.zip` (nama zip dikekalkan supaya workflow lama terus berfungsi).
2. Ganti `HadirKu.zip` dalam repo dengan zip baharu → **Commit changes**. (Pilihan: ganti juga `.github/workflows/build.yml` dengan versi dalam zip ini supaya fail APK dinamakan `Duitku-v2.0.N.apk`.)
3. Tab **Actions** → tunggu tanda hijau → **Releases** → muat turun APK.
4. Kunci tandatangan sama (`app/hadirku-release.jks`), jadi APK baharu **update** atas app lama tanpa padam rekod kehadiran.

## Kali pertama selepas update
Kalau app baru dipasang (bukan update), ia bermula dengan data contoh PoketGaji. Tekan **Pulihkan salinan** dan pilih fail salinan anda — semua poket, transaksi, komitmen, hutang, log OT dan rekod kehadiran dipulihkan.

## Kenapa OT kekal tab sendiri
OT dikira ikut kitaran **22hb–21hb**, manakala Poket, Transaksi, Bayaran dan Laporan ikut bulan biasa **1hb–hujung bulan**. Kalau OT digabung ke tab lain, dua jenis tempoh akan bercampur dalam satu skrin. Jadi OT kekal sebagai tab pertama (key in setiap hari), dinamakan semula daripada *Kerja* kepada **OT**. Nilai OT masih dipaparkan di jubin Poket dan dalam lejar Transaksi. Menekan "Isi OT" dari Transaksi membuka helaian papan nombor yang sama.

## Animasi gaya iPhone
- **Gerak.java** (Java): lengkung cubic-bezier UIKit, ease-out-back, lantunan, stagger dan rumus getah iOS. Dipanggil dari Kotlin/Compose.
- **Motion.kt**: `iosScroll` = fling licin (geseran rendah) + lantunan getah bila tarik melepasi atas/bawah; "stretch" Android dimatikan.
- Tukar tab **meluncur perlahan ikut arah** (tab di kanan masuk dari kanan, tab di kiri masuk dari kiri) + pudar; helaian naik dengan spring; butang kecut & melantun bila ditekan.
- **Kapsul tab bawah**: latar cyan lembut di belakang ikon tab aktif, meluncur dengan spring bila tukar tab; warna ikon bertukar beransur.
- **Ingat skrol setiap tab**: balik ke tab = kekal di tempat tadi. **Tekan tab yang sedang dibuka sekali lagi** → naik ke atas dengan licin (macam iPhone).
- **Butang Transaksi mengecil** jadi bulat (+) bila skrol ke bawah, kembang semula bila skrol ke atas atau sampai ke atas.
- **Tarik helaian ke bawah untuk tutup**: tarik pemegang di atas helaian; lepas melebihi ~120dp (atau leret laju) = tutup, kurang = melantun balik. Latar gelap pudar ikut tarikan.
- **Getaran sentuh ringan** (`rememberTick` dalam Motion.kt): tab bawah, Seg, tab jenis transaksi, suis, butang utama, grid kategori/poket, papan nombor, Simpan / Teruskan. Ikut tetapan *Getaran sentuh* telefon — matikan di situ kalau tak suka.
- Teks konteks bar atas bertukar dengan pudar + luncur; toast boleh ditekan untuk tutup; palang kemajuan & jumlah wang beranimasi dengan lengkung iOS.
- Pie: berpusing masuk, potongan pop satu-satu dengan lantunan, label pudar & meluncur masuk, potongan ditekan melantun keluar.

## Dibuang
**Clock in / clock out sepenuhnya**: butang check-in/out, geofence kilang, check-in automatik, amaran lupa check-in, cap jari/muka, mood, jurulatih disiplin, eksport CSV kehadiran. Izin lokasi, lokasi latar, biometrik dan penggera tepat dibuang dari manifest. Kali pertama app versi ini dibuka, geofence & penggera lama dibatalkan sendiri (`Cleanup` dalam `system/Notif.kt`). Data kehadiran lama kekal dalam fail salinan tetapi tidak dipakai lagi. Jadual shift kekal (untuk jenis hari lalai dalam log OT).

Pelan bertolak (cuaca Open-Meteo sepanjang laluan, trafik Google Routes / TomTom, notifikasi masa bertolak) dan lokasi rumah telah dibuang. Penggera dan kerja latar bertolak dari versi lama dibatalkan sendiri. Amaran lupa check-in dan check-in automatik (geofence kilang) kekal.

## Kongsi dengan isteri (Firebase)
App ini bersambung ke projek Firebase `duitku-isteri-1a996` yang sama dengan app **Duitku Isteri** (`app/google-services.json` mengandungi kedua-dua app).

| Ciri | Di mana |
|---|---|
| Senarai barang dikongsi (tambah, tick, rekod belanja, atau "Dah beli, tak perlu rekod") | Tab **Senarai** |
| Bil rumah dikongsi + kalendar + tanda siapa dah bayar; peringatan H-3 & H-1 pukul 8 pagi | **Bayaran → Bil rumah** |
| **Hantar nafkah**: dicatat sebagai Keluar dari poket kau, isteri tekan *Terima* dalam app dia | **Bayaran → Bil rumah** (bawah) |
| Projek (cth rumah baru): bajet vs belanja sebenar | **Bayaran → Projek** |
| Sambung ke rumah isteri guna kod 6 aksara | **Tetapan → Kongsi dengan isteri** |

Poket, transaksi, OT dan kehadiran kau kekal dalam telefon kau sahaja. Peraturan Firestore: `firestore.rules` (sama untuk kedua-dua app).
